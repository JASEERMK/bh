


 -- =============================================
-- Author:		Anoob V B
-- Create date: 15/07/2024
-- Description:	languageQuery
-- @ReturnStatus - 0 - success
-- @ReturnStatus - 1 - failure
-- ErrorCode - 8 - Required parameter value is not specified.
-- ErrorCode - ErrorNumber - Exception Occurred
-- =============================================
CREATE PROCEDURE [dbo].[sp_eplus_rt_GetMemberPreferenceDtl] 	
	@returnstatus NUMERIC(2,0) OUTPUT
AS

BEGIN
	BEGIN TRY
	
		---Setting the default returnstatus
		SET @ReturnStatus=0;
		
		---Get taxonomy details of provider
		select cd_entry_txt,short_name from code_entry with(nolock) where CD_SET_NAME = 'LanguageDomain' order by cd_entry_txt

	END TRY
	BEGIN CATCH
		SET @returnstatus=1;
		SELECT ERROR_NUMBER() AS ErrorCode,ERROR_MESSAGE() AS ErrorMessage
		RETURN;
	END CATCH
END
GO


