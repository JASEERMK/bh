package com.usthealthproof.eplus.hrp.member.preference.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Preferred Communication Insert/Update Response")
public class UpdatePreferenceResponse {

	@Schema(description = "Status Message of the Insert/Update function")
	private String statusMessage;
}
