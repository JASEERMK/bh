package com.usthealthproof.eplus.hrp.member.preference.exception;

import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstants;
import com.usthealthproof.eplus.hrp.member.preference.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.ProblemDetails;
import com.usthealthproof.eplus.hrp.member.preference.util.APIUtils;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class IntegrationExceptionHandler {

	@Autowired
	private APIUtils apiUtils;

	@Value("${preference.charactersToReplace}")
	private String charactersToReplace;

	/**
	 * Exception Handler for invalid request types
	 * 
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> requestValidationExceptionHandler(RequestValidationException ex,
			WebRequest request) {
		log.error("RequestValidationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(getErrorInfo(ex.getMessage(), MemberPreferenceConstants.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for invalid responses
	 * 
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(ResponseValidationException.class)
	public final ResponseEntity<ErrorResponse> responseValidationExceptionHandler(ResponseValidationException ex,
			WebRequest request) {
		log.error("ResponseValidationExceptionHandler Caught :  Error Message: {} and Exception: ", ex.getMessage(), ex);

		int httpStatusCode = 400;
		String exceptionMessage = StringUtils.split(ex.getMessage(), "|")[0];
		List<String> charactersToReplaceList = Arrays.asList(StringUtils.split(charactersToReplace, ","));
		String delimiter = "";
		exceptionMessage = Pattern.compile(delimiter).splitAsStream(exceptionMessage)
				.filter(s -> !charactersToReplaceList.contains(s)).collect(Collectors.joining(delimiter));

		if (StringUtils.split(ex.getMessage(), "|").length == 2) {
			httpStatusCode = Integer.parseInt(StringUtils.split(ex.getMessage(), "|")[1]);
		}

		if (StringUtils.containsIgnoreCase(ex.getMessage(), "No match found")) {
			log.info("Provided MemberID is not found in the connector service");

			httpStatusCode = 500;
			exceptionMessage = "No match Found";
		}

		String status = MemberPreferenceConstants.FAILURE;
		if (404 == httpStatusCode) {
			status = MemberPreferenceConstants.SUCCESS;
		}
		return new ResponseEntity<>(getErrorInfo(exceptionMessage, status), HttpStatus.valueOf(httpStatusCode));
	}

	/**
	 * NoContentException Handler
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoContentException.class)
	public final ResponseEntity<ErrorResponse> noContentExceptionHandler(NoContentException ex, WebRequest request) {
		log.error("NoContentExceptionHandler Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	/**
	 *Global Exception Handler
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		if (StringUtils.containsAnyIgnoreCase(ex.getMessage(), "Could not receive Message", "Could not send Message",
				"Connection reset", "Read timed out")
				|| StringUtils.containsAnyIgnoreCase(ex.toString(), "Connection reset", "Read timed out")) {
			return new ResponseEntity<>(apiUtils.setErrorDetails(MemberPreferenceConstants.TIMEOUT_EXCEPTION_MESSAGE,
					MemberPreferenceConstants.FAILURE), HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<>(
					apiUtils.setErrorDetails(MemberPreferenceConstants.EXCEPTION_MESSAGE, MemberPreferenceConstants.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Exception Handler for JDBC connection problems
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(CannotGetJdbcConnectionException.class)
	public final ResponseEntity<ErrorResponse> jdbcExceptionHandler(CannotGetJdbcConnectionException ex, WebRequest request) {
		log.error("CannotGetJdbcConnectionException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		ErrorResponse errorResponse = new ErrorResponse();
		if (StringUtils.containsIgnoreCase(ex.getMessage(), "Failed to obtain JDBC Connection")) {
			errorResponse.setProblemDetails(
					apiUtils.createProblemDetails(MemberPreferenceConstants.JDBC_EXCEPTION, MemberPreferenceConstants.FAILURE));
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			errorResponse.setProblemDetails(apiUtils.createProblemDetails(MemberPreferenceConstants.EXCEPTION_MESSAGE,
					MemberPreferenceConstants.FAILURE));
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,  WebRequest request) {
		log.error("MethodArgumentNotValidException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(setErrorDetailsAsList(ex.getBindingResult().getFieldErrors(), "Failed"),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for ConstraintViolationException types
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse> handleConstraintViolationException(ConstraintViolationException ex, WebRequest request) {
		log.error("ConstraintViolationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);

		List<String> errorMessage = new ArrayList<>();
		ex.getConstraintViolations().forEach(cv -> errorMessage.add(cv.getMessage()));
		return new ResponseEntity<>(setErrorDetailsAsListConstraintViolation(errorMessage, MemberPreferenceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for IllegalArgumentException
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<ErrorResponse> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
		log.error("IllegalArgumentException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(getErrorInfo("Invalid Request :" + ex.getMessage(), MemberPreferenceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling Missing mandatory fields in the request
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<ErrorResponse> missingServletRequestParameterException(MissingServletRequestParameterException ex,
																					   WebRequest request) {
		log.error("MissingServletRequestParameterException Caught. Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(getErrorInfo(ex.getMessage(),MemberPreferenceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling the invalid URL's
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoResourceFoundException.class)
	public final ResponseEntity<ErrorResponse> noResourceFoundException(NoResourceFoundException ex, WebRequest request) {
		log.error("NoResourceFoundException Caught.  Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(getErrorInfo(MemberPreferenceConstants.INVALID_REQUEST_URL, MemberPreferenceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}


	/**
	 * Method for setting the details regarding the exception into ErrorResponse
	 * model class
	 *
	 * @return ErrorResponse
	 */
	private ErrorResponse getErrorInfo(String exceptionMessage, String statusMessage) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(exceptionMessage, statusMessage));
		return errorResponse;
	}

	/**
	 * Common Method for the error details
	 */
	public ErrorResponse setErrorDetailsAsList(List<FieldError> fieldErrors, String status) {
		log.info("Inside setErrorDetailsAsList() in IntegrationExceptionHandler class");

		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		ArrayList<String> errorList = new ArrayList<>();
		for (FieldError fieldError : fieldErrors) {
			errorList.add(fieldError.getDefaultMessage());
		}
		problemDetails.setErrors(errorList);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

	/**
	 * Common Method for the error details having list of error messages
	 *
	 * @param list
	 * @param status
	 * @return
	 */
	private ErrorResponse setErrorDetailsAsListConstraintViolation(List<String> list, String status) {
		log.info("Inside setErrorDetailsAsListConstraintViolation() in IntegrationExceptionHandler class");

		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(list);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

}
