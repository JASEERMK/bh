
package com.usthealthproof.eplus.hrp.member.preference.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Language class")
@JsonInclude(value = Include.NON_EMPTY)
public class LanguageResponse {

	@Schema(description = "Language Name")
	private String languageName;

	@Schema(description = "Language Code")
	private String languageCode;
}
