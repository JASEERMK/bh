package com.usthealthproof.eplus.hrp.member.preference.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = -3109030129467123408L;

	public ResponseValidationException(String message) {
		super(message);
	}

}
