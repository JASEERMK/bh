package com.usthealthproof.eplus.hrp.member.preference.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponse;

@Component
public class LanguageMapper implements RowMapper<LanguageResponse> {

	@Override
	public LanguageResponse mapRow(ResultSet rs, int i) throws SQLException {
		LanguageResponse languageResponse = new LanguageResponse();
		languageResponse.setLanguageCode(rs.getString("cd_entry_txt"));
		languageResponse.setLanguageName(rs.getString("short_name"));
		return languageResponse;
	}
}
