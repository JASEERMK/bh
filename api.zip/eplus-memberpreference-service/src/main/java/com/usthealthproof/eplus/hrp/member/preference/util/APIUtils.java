package com.usthealthproof.eplus.hrp.member.preference.util;

import java.util.Arrays;

import com.usthealthproof.eplus.hrp.member.preference.model.ErrorResponse;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.member.preference.model.ProblemDetails;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class APIUtils {

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		log.info("Inside createProblemDetails() in APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(Arrays.asList(errorMsg));
		return problemDetails;
	}

	public ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(createProblemDetails(message, status));
		return errorResponse;
	}
}
