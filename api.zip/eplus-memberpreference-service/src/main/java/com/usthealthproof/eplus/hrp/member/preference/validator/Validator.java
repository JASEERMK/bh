package com.usthealthproof.eplus.hrp.member.preference.validator;

import com.healthedge.connector.schema.basetypes.ErrorInfoType;
import com.healthedge.connector.schema.basetypes.ErrorsType;
import com.healthedge.connector.schema.basetypes.TransactionExceptionType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentSparseResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.MemberResponseType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstants;
import com.usthealthproof.eplus.hrp.member.preference.exception.NoContentException;
import com.usthealthproof.eplus.hrp.member.preference.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.preference.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.isAllBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
@Slf4j
public class Validator {

	/**
	 * Method to validate the preferenceRequest
	 *
	 * @param memberId
	 */
	public void validateMemberPreferenceRequest(String memberId) throws RequestValidationException {
		log.info("Inside validateMemberPreferenceRequest() of get communication in Validator class");

		if (StringUtils.isBlank(memberId) || StringUtils.containsIgnoreCase(memberId, "null")) {
			throw new RequestValidationException("Invalid Request: Provide a valid Member ID");
		}
	}

	/**
	 * Method to validate the MemberPreferenceRequest
	 *
	 * @param memberPreferenceRequest
	 */

	public void validateMemberPreferenceRequest(MemberPreferenceRequest memberPreferenceRequest) {
		log.info("Inside validateMemberPreferenceRequest() in Validator class");

		if (Objects.isNull(memberPreferenceRequest)) {
			throw new RequestValidationException("Invalid Request: Request Fields are Empty or Null");
		}

		if (isBlank(memberPreferenceRequest.getMemberId())) {
			throw new RequestValidationException("Invalid Request: MemberId cannot be Empty or Null");
		}

		if (isAllBlank(memberPreferenceRequest.getPreferredContactMethod(), memberPreferenceRequest.getPreferredDeliveryMethod(),
				memberPreferenceRequest.getPreferredEmailFormat())
				&& CollectionUtils.isEmpty(memberPreferenceRequest.getPreferredLanguage())) {
			throw new RequestValidationException("Invalid Request: No details to update");
		}

		//added as part of [API-1738]
		if (!CollectionUtils.isEmpty(memberPreferenceRequest.getPreferredLanguage())) {
			if (memberPreferenceRequest.getPreferredLanguage().stream()
					.anyMatch(language -> (StringUtils.isNotBlank(language.getPrimaryLanguage())
							&& !StringUtils.equalsAnyIgnoreCase(language.getPrimaryLanguage(), "True", "False"))
							|| (StringUtils.isNotBlank(language.getNativeLanguage())
							&& !StringUtils.equalsAnyIgnoreCase(language.getNativeLanguage(), "True", "False")))) {
				throw new RequestValidationException("Invalid Request: Language field (Primary/Native) should be True or False");
			}
		}
	}

	/**
	 * Method to validate the EnrollmentResponseType
	 *
	 * @param enrollmentResponseType
	 */

	public void validateSubmitResponse(EnrollmentResponseType enrollmentResponseType) {
		log.info("Inside validateSubmitResponse() and the HRP Status received is: {}",
				enrollmentResponseType.getStatus().value());


		// Checking for the status of the transaction is SUCCESS or not
		if (!StringUtils.equalsIgnoreCase("SUCCESS", enrollmentResponseType.getStatus().value())) {
			ErrorsType errors = enrollmentResponseType.getErrors();

			if (errors != null && !CollectionUtils.isEmpty(errors.getError())) {
				ErrorInfoType error = errors.getError().get(0);
				throw new ResponseValidationException(error.getMessage() + "|500");
			} else {
				String exceptionMsg = Optional.ofNullable(enrollmentResponseType.getMember()).orElse(Collections.emptyList())
						.stream().map(MemberResponseType::getTransactionInformation).filter(Objects::nonNull)
						.flatMap(transactionInformationType -> transactionInformationType.getExceptions().stream())
						.filter(transactionExceptionType -> StringUtils
								.isNotBlank(transactionExceptionType.getMessageDescription()))
						.findFirst().map(TransactionExceptionType::getMessageDescription)
						.orElse(MemberPreferenceConstants.EXCEPTION_MESSAGE);
				throw new ResponseValidationException(exceptionMsg + "|500");
			}

		}

	}

	/**
	 * Method to validate the EnrollmentSparseResponseType
	 *
	 * @param enrollmentSparseResponseType
	 */
	public void validateLookupResponse(EnrollmentSparseResponseType enrollmentSparseResponseType) {
		log.info("Inside validateLookupResponse() in Validator class");

		if (Objects.isNull(enrollmentSparseResponseType) || Objects.isNull(enrollmentSparseResponseType.getEnrollment())) {
			log.info("EnrollmentSparseResponseType/Enrollment details is null");

			throw new ResponseValidationException(MemberPreferenceConstants.NO_DATA_FOUND + "|404");
		}

		if (null == enrollmentSparseResponseType.getStatus()
				|| !StringUtils.equalsIgnoreCase(enrollmentSparseResponseType.getStatus().value(), "Match Found")) {
			log.info("The transaction status from HRP is not Match Found, but it is : {}",
					enrollmentSparseResponseType.getStatus().value());

			throw new ResponseValidationException(MemberPreferenceConstants.NO_DATA_FOUND + "|404");
		}

		if (CollectionUtils.isEmpty(enrollmentSparseResponseType.getEnrollment().getMember())) {
			log.info("Enrollment member details is null");

			throw new ResponseValidationException(MemberPreferenceConstants.NO_DATA_FOUND + "|404");
		}
	}

	public void validateLookupMember(MembershipType membership) {

		if(membership == null) {
			log.info("Enrollment membership details is null");

			throw new ResponseValidationException(MemberPreferenceConstants.NO_DATA_FOUND + "|404");
		}

		if (Objects.isNull(membership.getCommunicationPreferences())
				&& Objects
				.isNull(membership.getIndividual().getLanguages())) {
			log.info("Communication Preference and Languages is not available ");

			throw new NoContentException(MemberPreferenceConstants.NO_DATA_FOUND );
		}
	}
}
