package com.usthealthproof.eplus.hrp.member.preference.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(description = "Language class")
@JsonInclude(value = Include.NON_EMPTY)
public class Language {
	@Schema(description = "Indicates if it is the primary language: True if yes.",defaultValue="Primary Language")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Primary Language is not in valid format")
	private String primaryLanguage;

	@Schema(description = "Indicates if it is the native language: True if yes.",defaultValue="Native Language")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Native Language is not in valid format")
	private String nativeLanguage;

	@Schema(description = "Language",defaultValue="Language Name")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Language Name is not in valid format")
	private String languageName;
}
