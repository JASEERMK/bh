package com.usthealthproof.eplus.hrp.member.preference.exception;

public class RequestValidationException extends RuntimeException {

	private static final long serialVersionUID = -3109030129467123408L;

	public RequestValidationException(String message) {
		super(message);
	}
}
