package com.usthealthproof.eplus.hrp.member.preference.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(description = "Response object to get Member Preference details")
@JsonInclude(value = Include.NON_EMPTY)
public class MemberPreferenceResponse {

	@Schema(description = "Member ID")
	private String memberId;

	@Schema(description = "Preferred Contact Method")
	private String preferredContactMethod;

	@Schema(description = "Preferred Delivery Method")
	private String preferredDeliveryMethod;

	@Schema(description = "Email Format Code")
	private String preferredEmailFormat;

	@Schema(description = "List of Preferred Language")
	private List<Language> preferredLanguage;
}
