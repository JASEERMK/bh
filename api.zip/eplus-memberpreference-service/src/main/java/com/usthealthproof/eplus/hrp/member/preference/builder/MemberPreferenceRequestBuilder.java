package com.usthealthproof.eplus.hrp.member.preference.builder;


import com.healthedge.connector.schema.basetypes.CodeEntryInputType;
import com.healthedge.connector.schema.basetypes.CommunicationContactMethodType;
import com.healthedge.connector.schema.basetypes.IndividualCommunicationPreferencesType;
import com.healthedge.connector.schema.basetypes.LanguageSpokenType;
import com.healthedge.connector.schema.basetypes.LanguagesType;
import com.healthedge.connector.schema.basetypes.ListActionType;
import com.healthedge.connector.schema.enrollmentsparse.ActionModeType;
import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentLookupType;
import com.healthedge.connector.schema.matchinput.MemberMatchInputType;
import com.healthedge.connector.schema.membershipsparse.MaintenanceCodeType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.usthealthproof.eplus.hrp.member.preference.configuration.MemberPreferenceConfig;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.GregorianCalendar;

@Component
@Slf4j
public class MemberPreferenceRequestBuilder {
	@Autowired
	MemberPreferenceConfig memberPreferenceConfig;

	private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");


	public EnrollmentType createEnrollmentRequest(MemberPreferenceRequest memberPreferenceRequest) throws DatatypeConfigurationException, ParseException {
		log.info("Inside createEnrollmentRequest() in MemberPreferenceRequestBuilder class");

		final String asOfDate = getTodayDate();
		EnrollmentType enrollmentType = new EnrollmentType();
		enrollmentType.setActionMode(ActionModeType.SPARSE);
		enrollmentType.setAsOfDate(getXMLGregorianCalendarDate(asOfDate));
		enrollmentType.setSendToWorkBasketIfExceptionsPresent(false);

		MembershipType membershipType = new MembershipType();
		membershipType.setMaintenanceTypeCode(MaintenanceCodeType.CHANGE);
		membershipType.setMaintenanceReasonCode(getCodeEntry("SubscriptionAmendReason", memberPreferenceConfig.getSubscriptionAmendReasonCode()));
		membershipType.setMemberMatchData(getMemberMatchData(memberPreferenceRequest));

		if(StringUtils.isNotBlank(memberPreferenceRequest.getMemberId())) {
			membershipType.setHccIdentifier(memberPreferenceRequest.getMemberId());
		}

		// Language
		if(memberPreferenceRequest.getPreferredLanguage() != null && !memberPreferenceRequest.getPreferredLanguage().isEmpty()) {
			membershipType.setIndividual(setPreferredLanguage(memberPreferenceRequest));
		}

		// Communication Preference
		IndividualCommunicationPreferencesType individualCommunicationPreferencesType = new IndividualCommunicationPreferencesType();
		if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredContactMethod())) {
			individualCommunicationPreferencesType
					.setContactMethod(CommunicationContactMethodType.fromValue(memberPreferenceRequest.getPreferredContactMethod()));
		}

		if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredDeliveryMethod())) {
			individualCommunicationPreferencesType.setDocumentDeliveryMethodCode(
					getCodeEntry("DocumentDeliveryMethod", memberPreferenceRequest.getPreferredDeliveryMethod()));
		}

		if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredEmailFormat())) {
			individualCommunicationPreferencesType
					.setEmailFormatCode(getCodeEntry("EmailFormat", memberPreferenceRequest.getPreferredEmailFormat()));
		}

		if(individualCommunicationPreferencesType !=null) {
			membershipType.setCommunicationPreferences(individualCommunicationPreferencesType);
		}

		enrollmentType.getMember().add(membershipType);
		return enrollmentType;
	}

	private MembershipType.Individual  setPreferredLanguage(MemberPreferenceRequest memberPreferenceRequest ) {
		LanguagesType languagesType = new LanguagesType();
		MembershipType.Individual individual = new MembershipType.Individual();
		languagesType.setListMode(ListActionType.REPLACE);
		for (int i = 0; i < memberPreferenceRequest.getPreferredLanguage().size(); i++) {
			LanguageSpokenType languageSpokenType = new LanguageSpokenType();

			if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredLanguage().get(i).getPrimaryLanguage())) {
				languageSpokenType.setPrimaryLanguage(
						Boolean.valueOf(memberPreferenceRequest.getPreferredLanguage().get(i).getPrimaryLanguage()));
			}

			if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredLanguage().get(i).getNativeLanguage())) {
				languageSpokenType.setNativeLanguage(
						Boolean.valueOf(memberPreferenceRequest.getPreferredLanguage().get(i).getNativeLanguage()));
			}

			if(StringUtils.isNotBlank(memberPreferenceRequest.getPreferredLanguage().get(i).getLanguageName())) {
				languageSpokenType.setLanguageDomainCode(
						getCodeEntry("LanguageDomain", memberPreferenceRequest.getPreferredLanguage().get(i).getLanguageName()));
			}

			languagesType.getLanguage().add(languageSpokenType);
		}

		if(languagesType != null) {
			individual.setLanguages(languagesType);
		}
		return individual;
	}


	private CodeEntryInputType getCodeEntry(String codeSetName, String codeEntry) {
		CodeEntryInputType codeEntryInputType = new CodeEntryInputType();
		codeEntryInputType.setCodeSetName(codeSetName);
		codeEntryInputType.setCodeEntry(codeEntry);
		return codeEntryInputType;
	}

	private MemberMatchInputType getMemberMatchData(MemberPreferenceRequest memberPreferenceRequest) {
		MemberMatchInputType memberMatchData = new MemberMatchInputType();
		memberMatchData.setDefinitionName(memberPreferenceConfig.getMemberMatchDefinition());
		if (StringUtils.isNotBlank(memberPreferenceRequest.getMemberId())) {
			memberMatchData.setId(memberPreferenceRequest.getMemberId());
		}
		return memberMatchData;
	}

	public XMLGregorianCalendar getXMLGregorianCalendarDate(String stringDate) throws DatatypeConfigurationException {
		if (StringUtils.isBlank(stringDate)) {
			return null;
		}
		LocalDate localDate = LocalDate.parse(stringDate, DATE_FORMATTER);
		GregorianCalendar calendar = GregorianCalendar.from(localDate.atStartOfDay(ZoneId.systemDefault()));
		XMLGregorianCalendar xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
		xmlCalendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		xmlCalendar.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
		return xmlCalendar;
	}

	private String getTodayDate() {
		return LocalDate.now().format(DATE_FORMATTER);
	}

	//Enrollment Lookup Request
	public EnrollmentLookupType createEnrollmentLookupRequest(String memberId) {
		EnrollmentLookupType enrollmentLookupType = new EnrollmentLookupType();
		enrollmentLookupType.setDefinitionName(memberPreferenceConfig.getMemberMatchDefinition());
		enrollmentLookupType.setId(memberId);
		return enrollmentLookupType;
	}

}