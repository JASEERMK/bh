package com.usthealthproof.eplus.hrp.member.preference.constants;

public class MemberPreferenceConstants {

	private MemberPreferenceConstants() {

	}

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details.";
	public static final String NO_DATA_FOUND = "No records to display";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String JDBC_EXCEPTION = "Error occurred during Search. Please contact your supervisor";
	public static final String SUBMIT_SUCCESS_MESSAGE = "Member Preferences updated successfully";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";
	public static final String SOAP_FAULT_EXCEPTION = "SoapFaultClientException caught in MemberPreferenceDaoImpl class.";
	public static final String ILLEGAL_ARGUMENT_EXCEPTION = "IllegalArgumentException caught in MemberPreferenceDaoImpl class.";
	public static final String EXCEPTION = "Exception caught in MemberPreferenceDaoImpl class.";
}
