package com.usthealthproof.eplus.hrp.member.preference.configuration;

import com.usthealthproof.eplus.hrp.member.preference.util.CustomNamespacePrefixMapper;
import jakarta.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;

import java.time.Duration;
import java.util.Collections;


@Configuration
@Slf4j
public class WebServiceConfig {

    @Value("${enrollmentLookup.service.address}")
    private String enrollmentLookupAddress;
    @Value("${enrollment.service.address}")
    private String enrollmentSparseTypeAddress;
    @Value("${preference.service.connectionTimeout}")
    private String connectionTimeout;
    @Value("${preference.service.readTimeout}")
    private String readTimeout;
    @Value("${preference.service.enrollmentLookUpContextPackage}")
    private String enrollmentLookUpContext;
    @Value("${preference.service.enrollmentSparseContextPackage}")
    private String enrollmentSparseTypeContext;
    @Value("${preference.service.nameSpaceMapper}")
    private String nameSpaceMapper;

    @Autowired
    CustomNamespacePrefixMapper customNamespacePrefixMapper;

    @Bean(name = "sparseLookup")
    public Jaxb2Marshaller marshaller() {

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(enrollmentLookUpContext);
        marshaller.setMarshallerProperties(Collections.singletonMap(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE));

        // Set the custom namespace prefix mapper
        marshaller.setMarshallerProperties(
                Collections.singletonMap(nameSpaceMapper, customNamespacePrefixMapper)
        );
        return marshaller;
    }

    @Bean(name = "sparseTypePort")
    public Jaxb2Marshaller sparseTypeMarshaller() {

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(enrollmentSparseTypeContext);
        marshaller.setMarshallerProperties(Collections.singletonMap(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE));

        // Set the custom namespace prefix mapper
        marshaller.setMarshallerProperties(
                Collections.singletonMap(nameSpaceMapper, customNamespacePrefixMapper)
        );
        return marshaller;
    }

    @Bean
    public ClientInterceptor customLoggingInterceptor() {
        return new CustomLoggingInterceptor();
    }

    @Bean(name = "enrollmentSparseLookupPortType")
    public WebServiceTemplate webServiceTemplate(@Qualifier("sparseLookup")Jaxb2Marshaller marshaller,MemberPreferenceConfig memberPreferenceConfig) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        try {
            webServiceTemplate.setMarshaller(marshaller);
            webServiceTemplate.setUnmarshaller(marshaller);
            webServiceTemplate.setDefaultUri(enrollmentLookupAddress);
            memberPreferenceConfig.setReadTimeout(Duration.ofMillis(Long.parseLong(readTimeout)));
            memberPreferenceConfig.setConnectionTimeout(Duration.ofMillis(Long.parseLong(connectionTimeout)));
            webServiceTemplate.setInterceptors(new ClientInterceptor[]{customLoggingInterceptor()});
            webServiceTemplate.setMessageSender(memberPreferenceConfig);

        }catch (Exception e) {
            log.error("Exception in MemberIDCardServiceConfiguration:: ", e);
        }
        return  webServiceTemplate;
    }

    @Bean(name = "enrollmentSparsePortType")
    public WebServiceTemplate webServiceTemplateSparsePortType(@Qualifier("sparseTypePort")Jaxb2Marshaller marshaller,MemberPreferenceConfig memberPreferenceConfig) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        try {
            webServiceTemplate.setMarshaller(marshaller);
            webServiceTemplate.setUnmarshaller(marshaller);
            webServiceTemplate.setDefaultUri(enrollmentSparseTypeAddress);
            memberPreferenceConfig.setReadTimeout(Duration.ofMillis(Long.parseLong(readTimeout)));
            memberPreferenceConfig.setConnectionTimeout(Duration.ofMillis(Long.parseLong(connectionTimeout)));
            webServiceTemplate.setInterceptors(new ClientInterceptor[]{customLoggingInterceptor()});
            webServiceTemplate.setMessageSender(memberPreferenceConfig);

        }catch (Exception e) {
            log.error("Exception in MemberIDCardServiceConfiguration:: ", e);
        }
        return  webServiceTemplate;
    }

}
