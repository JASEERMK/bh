package com.usthealthproof.eplus.hrp.member.preference.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.hrp.member.preference.dao.MemberPreferenceDAO;
import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponseList;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.UpdatePreferenceResponse;

import lombok.extern.slf4j.Slf4j;

import javax.xml.datatype.DatatypeConfigurationException;
import java.text.ParseException;

@Service
public class MemberPreferenceService {

	@Autowired
	private MemberPreferenceDAO memberPreferenceDAO;

	public MemberPreferenceResponse getMemberPreference(String memberId)  {
		return memberPreferenceDAO.getMemberPreference(memberId);
	}

	public UpdatePreferenceResponse updateMemberPreference(MemberPreferenceRequest memberPreferenceRequest) throws DatatypeConfigurationException, ParseException {
		return memberPreferenceDAO.updateMemberPreference(memberPreferenceRequest);
	}

	public LanguageResponseList getAllLanguages() {
		return memberPreferenceDAO.getAllLanguages();
	}
}