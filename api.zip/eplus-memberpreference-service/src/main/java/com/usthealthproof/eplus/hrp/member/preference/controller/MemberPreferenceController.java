package com.usthealthproof.eplus.hrp.member.preference.controller;

import com.usthealthproof.eplus.hrp.member.preference.validator.Validator;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.hrp.member.preference.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponseList;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.UpdatePreferenceResponse;
import com.usthealthproof.eplus.hrp.member.preference.service.MemberPreferenceService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@RestController
@Validated
@Slf4j
@Tag(name = "Member Preference Service")
@RequestMapping("/v1/member/preference")
@SecurityRequirement(name = "Member Preference Service")
public class MemberPreferenceController {

	@Autowired
	private MemberPreferenceService memberPreferenceService;

	@Autowired
	private Validator validator;

	@GetMapping(value = "/communication", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Get Communication Preferences", description = "Service for retrieving the current preferences of the specified member. Member ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Preferred Member Preference Response", content = {
					@Content(schema = @Schema(implementation = MemberPreferenceResponse.class)) }),
			@ApiResponse(responseCode = "204", description = "No Content", content = @Content),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<MemberPreferenceResponse> getMemberPreference(
			@Parameter(description = "Member ID", required = true) @RequestParam(value = "memberId") @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: memberId is not in valid format") String memberId)
			throws Exception {
		log.info("Inside getMemberPreference() in Controller class");
		log.debug("Inside getMemberPreference() in Controller class: {}", memberId);

		validator.validateMemberPreferenceRequest(memberId);
		return new ResponseEntity<>(memberPreferenceService.getMemberPreference(memberId), HttpStatus.OK);
	}

	@PostMapping(value = "/communication", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Create/Update Communication Preferences", description = "The member's preference can be updated or inserted using this service. If the member listed in the request already exists, the service will update the preferred communication; if not, it will add the preferred communication that has been provided. The mandatory field is Member ID. It is necessary to provide either the Preferred Contact Method, Preferred Delivery Method, Preferred Email Format, or Preferred Language in addition to the Member ID. Failure to provide any of these fields will result in a validation error.", method = "POST", responses = {
			@ApiResponse(responseCode = "200", description = "Preferred Communication Insert/Update Response", content = {
					@Content(schema = @Schema(implementation = UpdatePreferenceResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<UpdatePreferenceResponse> updateMemberPreference(
			@Valid @RequestBody MemberPreferenceRequest memberPreferenceRequest) throws Exception {
		log.info("Inside updateMemberPreference() in Controller class");
		log.debug("Inside updateMemberPreference() in Controller class: {}", memberPreferenceRequest);

		validator.validateMemberPreferenceRequest(memberPreferenceRequest);
		return new ResponseEntity<>(memberPreferenceService.updateMemberPreference(memberPreferenceRequest), HttpStatus.OK);
	}

	@GetMapping(value = "/languages", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Retrieves the languages", description = "Service for retrieving all the available languages", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Preferred Languages Response", content = {
					@Content(schema = @Schema(implementation = LanguageResponseList.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No Data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<LanguageResponseList> getAllLanguages() throws Exception {
		log.info("Inside getAllLanguages() in Controller class");

		return new ResponseEntity<>(memberPreferenceService.getAllLanguages(), HttpStatus.OK);
	}
}