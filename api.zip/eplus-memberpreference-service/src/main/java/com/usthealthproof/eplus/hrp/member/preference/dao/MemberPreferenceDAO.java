
package com.usthealthproof.eplus.hrp.member.preference.dao;

import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentLookupType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentSparseResponseType;
import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponseList;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.UpdatePreferenceResponse;

import javax.xml.datatype.DatatypeConfigurationException;
import java.text.ParseException;

public interface MemberPreferenceDAO {

	MemberPreferenceResponse getMemberPreference(String memberId);

	UpdatePreferenceResponse updateMemberPreference(MemberPreferenceRequest memberPreferenceRequest) throws DatatypeConfigurationException, ParseException;

	EnrollmentSparseResponseType getEnrollmentSparseResponse(EnrollmentLookupType enrollmentLookupType);

	LanguageResponseList getAllLanguages();
}