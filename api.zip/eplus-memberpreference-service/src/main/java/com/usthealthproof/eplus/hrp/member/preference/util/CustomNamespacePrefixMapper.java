package com.usthealthproof.eplus.hrp.member.preference.util;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CustomNamespacePrefixMapper extends NamespacePrefixMapper {

    private static final Logger log = LoggerFactory.getLogger(CustomNamespacePrefixMapper.class);
    @Value("${preference.service.nameSpacePrefix}")
    private String nameSpacePrefix;
    @Value("${preference.service.enrollmentLookupNameSpaceUri}")
    private String enrollmentLookUpNameSpace;
    @Value("${preference.service.enrollmentSparseTypeNameSpaceUri}")
    private String enrollmentSparseTypeNameSpace;

    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        log.info("namespaceUri {}", namespaceUri);
        if (StringUtils.equalsIgnoreCase(enrollmentLookUpNameSpace, namespaceUri) || (StringUtils.equalsIgnoreCase(enrollmentSparseTypeNameSpace, namespaceUri))) {
            return nameSpacePrefix;
        }
        return suggestion;
    }
}
