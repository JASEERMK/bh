package com.usthealthproof.eplus.hrp.member.preference.exception;

import java.io.Serial;

public class NoContentException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 6750599496820339919L;

    public NoContentException(String message) {
        super(message);
    }

}
