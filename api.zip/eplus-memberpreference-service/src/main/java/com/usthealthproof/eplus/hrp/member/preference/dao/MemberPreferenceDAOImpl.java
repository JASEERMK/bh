package com.usthealthproof.eplus.hrp.member.preference.dao;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentLookupType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentSparseResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.usthealthproof.eplus.hrp.member.preference.builder.MemberPreferenceRequestBuilder;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstants;
import com.usthealthproof.eplus.hrp.member.preference.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.member.preference.mapper.LanguageMapper;
import com.usthealthproof.eplus.hrp.member.preference.model.*;
import com.usthealthproof.eplus.hrp.member.preference.validator.Validator;
import jakarta.annotation.PreDestroy;
import jakarta.xml.bind.JAXBElement;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.namespace.QName;
import java.sql.Types;
import java.text.ParseException;
import java.util.*;

@Repository
@Slf4j
public class MemberPreferenceDAOImpl implements MemberPreferenceDAO {

    @Autowired
    private Validator validator;

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    private LanguageMapper languagesMapper;

    @Autowired
    private MemberPreferenceRequestBuilder memberPreferenceRequestBuilder;

    @Value("#{${preference.config.emailFormat}}")
    private HashMap<String, String> emailFormatMap;

    @Value("#{${preference.config.documentDeliveryMethod}}")
    private HashMap<String, String> documentDeliveryMethodMap;

    @Value("${preference.config.languageQuery}")
    private String languageQuery;

    @Autowired
    @Qualifier("enrollmentSparseLookupPortType")
    WebServiceTemplate webServiceTemplate;

    @Autowired
    @Qualifier("enrollmentSparsePortType")
    WebServiceTemplate webServiceTemplateSparsePortType;

    @Value("${preference.service.enrollmentLookupNameSpaceUri}")
    private String enrollmentLookupNameSpace;

    @Value("${preference.service.enrollmentSparseTypeNameSpaceUri}")
    private String enrollmentSparseTypeNameSpace;



    public MemberPreferenceResponse getMemberPreference(String memberId) {
        log.info("Inside getMemberPreference() in MemberPreferenceDAOImpl class");

        List<Language> languageList = new ArrayList<>();
        EnrollmentLookupType enrollmentLookup = memberPreferenceRequestBuilder.createEnrollmentLookupRequest(memberId);
        long startServiceRequestTime = System.currentTimeMillis();
        EnrollmentSparseResponseType enrollmentSparseResponse = getEnrollmentSparseResponse(enrollmentLookup);
        long endServiceRequestTime = System.currentTimeMillis();

        log.info("Execution time for the external service - HRP enrollmentLookup call, in ms: {}",
                endServiceRequestTime - startServiceRequestTime);

        validator.validateLookupResponse(enrollmentSparseResponse);
        MemberPreferenceResponse memberPreferenceResponse = new MemberPreferenceResponse();
        MembershipType membership = enrollmentSparseResponse.getEnrollment().getMember().stream()
                .filter(member -> memberId.equals(member.getHccIdentifier())).findAny().orElse(null);
        validator.validateLookupMember(membership);

        if ((membership != null) && membership.getCommunicationPreferences() != null) {
            memberPreferenceResponse = setCommunicationPreferences(membership,memberPreferenceResponse);
        }

        if ((membership != null) && StringUtils.isNotBlank(membership.getHccIdentifier())) {
            memberPreferenceResponse.setMemberId(membership.getHccIdentifier());
        }

        if ((membership != null) && membership.getIndividual() != null && membership.getIndividual().getLanguages() != null) {
             languageList = setLanguages(membership);
        }

        memberPreferenceResponse.setPreferredLanguage(languageList);
        log.info("Successfully completed the member preference service call");

        return memberPreferenceResponse;
    }

    private MemberPreferenceResponse setCommunicationPreferences(MembershipType membership, MemberPreferenceResponse memberPreferenceResponse) {
        if (membership.getCommunicationPreferences().getContactMethod() != null) {
            memberPreferenceResponse.setPreferredContactMethod(membership.getCommunicationPreferences().getContactMethod().value());
        }

        if (membership.getCommunicationPreferences().getDocumentDeliveryMethodCode() != null) {
            memberPreferenceResponse.setPreferredDeliveryMethod(documentDeliveryMethodMap.get(membership.getCommunicationPreferences().getDocumentDeliveryMethodCode().getCodeEntry()));
        }

        if (membership.getCommunicationPreferences().getEmailFormatCode() != null) {
            memberPreferenceResponse.setPreferredEmailFormat(emailFormatMap.get(membership.getCommunicationPreferences().getEmailFormatCode().getCodeEntry()));
        }
        return memberPreferenceResponse;
    }

    private static List<Language>  setLanguages(MembershipType membership) {
        List<Language> languageList = new ArrayList<>();
        for (int i = 0; i < membership.getIndividual().getLanguages()
                .getLanguage().size(); i++) {
            Language language = new Language();
            if (membership.getIndividual().getLanguages().getLanguage()
                    .get(i).isPrimaryLanguage() != null) {
                language.setPrimaryLanguage(membership.getIndividual()
                        .getLanguages().getLanguage().get(i).isPrimaryLanguage().toString());
            }
            else {
                language.setPrimaryLanguage("false");
            }

            if (membership.getIndividual().getLanguages().getLanguage()
                    .get(i).isNativeLanguage() != null) {
                language.setNativeLanguage(membership.getIndividual()
                        .getLanguages().getLanguage().get(i).isNativeLanguage().toString());
            }
            else {
                language.setNativeLanguage("false");
            }

            if (membership.getIndividual()
                    .getLanguages().getLanguage() != null && membership.getIndividual()
                    .getLanguages().getLanguage().get(i).getLanguageDomainCode() != null) {
                language.setLanguageName(membership.getIndividual()
                        .getLanguages().getLanguage().get(i).getLanguageDomainCode().getCodeEntry());
            }
            languageList.add(language);
        }
        return  languageList;
    }

    public UpdatePreferenceResponse updateMemberPreference(MemberPreferenceRequest memberPreferenceRequest) throws DatatypeConfigurationException, ParseException {
        log.info("Inside updateMemberPreference() in MemberPreferenceDAOImpl class");

        applyEmailAndDeliveryPreferences(memberPreferenceRequest);

        UpdatePreferenceResponse updatePreferenceResponse = new UpdatePreferenceResponse();
        EnrollmentType enrollmentType = memberPreferenceRequestBuilder.createEnrollmentRequest(memberPreferenceRequest);
        long startServiceRequestTime = System.currentTimeMillis();
        EnrollmentResponseType enrollmentResponse = null;

        try {
            // Create the JAXBElement for the request
            JAXBElement<EnrollmentType> getEnrollmentTypeJAXBElement = new JAXBElement<>(
                    new QName(enrollmentSparseTypeNameSpace, "enrollment"),
                    EnrollmentType.class,
                    enrollmentType
            );
            // Send the SOAP request and receive the response
            JAXBElement<EnrollmentResponseType> getEnrollmentResponse =
                    (JAXBElement<EnrollmentResponseType>) webServiceTemplateSparsePortType.marshalSendAndReceive(
                            getEnrollmentTypeJAXBElement,
                            new SoapActionCallback("")
                    );
            long endServiceRequestTime = System.currentTimeMillis();
            log.info("Execution time for the external service - HRP enrollment call, in ms: {}",
                    endServiceRequestTime - startServiceRequestTime);
            if (Objects.nonNull(getEnrollmentResponse)) {
                enrollmentResponse = getEnrollmentResponse.getValue();
            }
        } catch (SoapFaultClientException soapFaultClientException) {
            log.error(MemberPreferenceConstants.SOAP_FAULT_EXCEPTION);
            throw soapFaultClientException;
        } catch (IllegalArgumentException illegalArgumentException) {
            log.error(MemberPreferenceConstants.ILLEGAL_ARGUMENT_EXCEPTION);
            throw illegalArgumentException;
        } catch (Exception ex) {
            log.error(MemberPreferenceConstants.EXCEPTION);
            throw ex;
        }

        validator.validateSubmitResponse(enrollmentResponse);
        updatePreferenceResponse.setStatusMessage(MemberPreferenceConstants.SUBMIT_SUCCESS_MESSAGE);

        log.info("Successfully completed the Update member preference service call");

        return updatePreferenceResponse;
    }

    /**
     *  API-1926
     *  Method to map emailFormat and documentDeliveryMethod from configuration values.
     */
    private void applyEmailAndDeliveryPreferences(MemberPreferenceRequest memberPreferenceRequest) {
        if (StringUtils.isNotBlank(memberPreferenceRequest.getPreferredEmailFormat())) {
            memberPreferenceRequest.setPreferredEmailFormat(
                    emailFormatMap.entrySet().stream()
                            .filter(entry -> entry.getValue().equals(memberPreferenceRequest.getPreferredEmailFormat()))
                            .map(Map.Entry::getKey)
                            .findFirst()
                            .orElse(memberPreferenceRequest.getPreferredEmailFormat())
            );
        }

        if (StringUtils.isNotBlank(memberPreferenceRequest.getPreferredDeliveryMethod())) {
            memberPreferenceRequest.setPreferredDeliveryMethod(
                    documentDeliveryMethodMap.entrySet().stream()
                            .filter(entry -> entry.getValue().equals(memberPreferenceRequest.getPreferredDeliveryMethod()))
                            .map(Map.Entry::getKey)
                            .findFirst()
                            .orElse(memberPreferenceRequest.getPreferredDeliveryMethod())
            );
        }
    }

    public EnrollmentSparseResponseType getEnrollmentSparseResponse(EnrollmentLookupType enrollmentLookupType) {

        EnrollmentSparseResponseType enrollmentSparseResponseType = null;
        try {
            // Create the JAXBElement for the request
            JAXBElement<EnrollmentLookupType> getEnrollmentLookupTypeJAXBElement = new JAXBElement<>(
                    new QName(enrollmentLookupNameSpace, "enrollmentLookupCriteria"),
                    EnrollmentLookupType.class,
                    enrollmentLookupType
            );

            // Send the SOAP request and receive the response
            JAXBElement<EnrollmentSparseResponseType> getEnrollmentSparseResponseType =
                    (JAXBElement<EnrollmentSparseResponseType>) webServiceTemplate.marshalSendAndReceive(
                            getEnrollmentLookupTypeJAXBElement,
                            new SoapActionCallback("")
                    );

            if (Objects.nonNull(getEnrollmentSparseResponseType)) {
                enrollmentSparseResponseType = getEnrollmentSparseResponseType.getValue();
            }
        } catch (SoapFaultClientException soapFaultClientException) {
            log.error(MemberPreferenceConstants.SOAP_FAULT_EXCEPTION);
            throw soapFaultClientException;
        } catch (IllegalArgumentException illegalArgumentException) {
            log.error(MemberPreferenceConstants.ILLEGAL_ARGUMENT_EXCEPTION);
            throw illegalArgumentException;
        } catch (Exception ex) {
            log.error(MemberPreferenceConstants.EXCEPTION);
            throw ex;
        }
        return enrollmentSparseResponseType;
    }


    public LanguageResponseList getAllLanguages() {
        log.info("Inside getAllLanguages() in MemberPreferenceDAOImpl class");

        LanguageResponseList languageResponseList;
        List<LanguageResponse> languageResponse;

        MapSqlParameterSource languageParams = new MapSqlParameterSource()
                .addValue("returnStatus", 0, Types.NUMERIC);
        log.info("Going for DB call of languagesQuery");

        String languageQuerySql = "{CALL " + languageQuery + "(:returnStatus)}";

        long startServiceRequestTime = System.currentTimeMillis();

        try {
            languageResponse = namedParameterJdbcTemplate.query(languageQuerySql, languageParams, languagesMapper);
            long endServiceRequestTime = System.currentTimeMillis();
            log.info("Completed the DB call. Execution time in ms: {}", endServiceRequestTime - startServiceRequestTime);

            if (languageResponse.isEmpty()) {
                log.info("No Languages found in the table");

                throw new ResponseValidationException(MemberPreferenceConstants.NO_DATA_FOUND + "|404");
            } else {
                languageResponseList = new LanguageResponseList();
                languageResponseList.setLanguages(languageResponse);
            }
        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error("CannotGetJdbcConnectionException occurred in MemberPreferenceDAOImpl class");
            throw jdbcException;
        } catch (Exception exception) {
            log.error("General Exception occurred in MemberPreferenceDAOImpl class");
            throw exception;
        }

        log.info("Successfully received response for the language request");
        return languageResponseList;
    }


    /**
     * @PreDestroy method to clear collections before the bean is destroyed.
     */
    @PreDestroy
    public void cleanUp() {
        log.info("Clearing collections before destroying MemberPreferenceDAOImpl bean...");
        emailFormatMap.clear();
        documentDeliveryMethodMap.clear();
        log.info("Successfully cleared collections in MemberPreferenceDAOImpl.");
    }
}
