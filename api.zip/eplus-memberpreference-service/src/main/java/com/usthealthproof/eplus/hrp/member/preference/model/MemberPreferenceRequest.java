package com.usthealthproof.eplus.hrp.member.preference.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.util.List;

@Data
@Schema(description = "Request object to Update Member Preference")
public class MemberPreferenceRequest {

	@Schema(description = "Member ID",requiredMode = Schema.RequiredMode.REQUIRED,defaultValue="Member ID")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Member ID is not in valid format")
	private String memberId;

	@Schema(description = "Preferred Contact Method",defaultValue = "Contact Method")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Preferred Contact Method is not in valid format")
	private String preferredContactMethod;

	@Schema(description = "Preferred Delivery Method",defaultValue = "Delivery Method")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Preferred Delivery Method is not in valid format")
	private String preferredDeliveryMethod;

	@Schema(description = "Preferred Email Format",defaultValue = "Email Format")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Preferred Email Format is not in valid format")
	private String preferredEmailFormat;

	@Valid
	@Schema(description = "List of language preferred")
	private List<Language> preferredLanguage;
}
