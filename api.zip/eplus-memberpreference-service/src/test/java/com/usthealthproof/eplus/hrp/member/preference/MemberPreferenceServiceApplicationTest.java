package com.usthealthproof.eplus.hrp.member.preference;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class MemberPreferenceServiceApplicationTest {
    @Test
    void testMainClass() {
        MemberPreferenceServiceApplication.main(new String[]{"args"});
        assertTrue(true);
    }
}