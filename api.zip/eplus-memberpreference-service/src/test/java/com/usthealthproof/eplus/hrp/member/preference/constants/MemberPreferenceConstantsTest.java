package com.usthealthproof.eplus.hrp.member.preference.constants;

public class MemberPreferenceConstantsTest {

    public static final String ENDPOINT_MEMBERPREFERENCE = "/v1/member/preference/communication";
    public static final String ENDPOINT_LANGUAGES = "/v1/member/preference/languages";

    public static final String MEMBER_ID = "200013324-01";
}