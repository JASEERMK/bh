package com.usthealthproof.eplus.hrp.member.preference.util;

import com.usthealthproof.eplus.hrp.member.preference.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.ProblemDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import java.util.Arrays;

@ExtendWith(MockitoExtension.class)
class APIUtilsTest {
    @Mock
    Logger log;
    @InjectMocks
    APIUtils apiUtils;
    ProblemDetails problemDetails = new ProblemDetails();
    ErrorResponse errorResponse = new ErrorResponse();

    @BeforeEach
    void setUp() {
        problemDetails.setErrors(Arrays.asList("Data Not found"));
        problemDetails.setStatus("No data");
    }

    @Test
    void testCreateProblemDetails() {
        // when - action or the behaviour
        ProblemDetails result = apiUtils.createProblemDetails("Data Not found", "No data");
        // then - verify the output
        Assertions.assertEquals(problemDetails, result);
    }

    @Test
    void testErrorDetails() {
        // when - action or the behaviour
        ErrorResponse result = apiUtils.setErrorDetails("Data Not found", "No data");
        // then - verify the output
        Assertions.assertEquals(problemDetails, result.getProblemDetails());
    }

}