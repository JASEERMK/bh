package com.usthealthproof.eplus.hrp.member.preference.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class CustomNamespacePrefixMapperTest {

    String nameSpaceUri = "http://www.healthedge.com/connector/schema/enrollmentsparselookup";
    String suggestion = "ns";
    String expected = "enr";

    @Test
    void getPreferredPrefix() {
        CustomNamespacePrefixMapper mapper = new CustomNamespacePrefixMapper();
        ReflectionTestUtils.setField(mapper, "enrollmentLookUpNameSpace", "http://www.healthedge.com/connector/schema/enrollmentsparselookup");
        ReflectionTestUtils.setField(mapper, "nameSpacePrefix", "enr");
        String result = mapper.getPreferredPrefix(nameSpaceUri, suggestion, true);
        Assertions.assertEquals(expected, result);
    }

    @Test
    void getDefaultPrefix() {
        CustomNamespacePrefixMapper mapper = new CustomNamespacePrefixMapper();
        ReflectionTestUtils.setField(mapper, "enrollmentLookUpNameSpace", "http://www.healthedge.com/connector/schema/enrollmentsparselookup");
        ReflectionTestUtils.setField(mapper, "nameSpacePrefix", "enr");
        String result = mapper.getPreferredPrefix("http://www.healthedge.com/", suggestion, true);
        Assertions.assertEquals(suggestion, result);
    }
}
