package com.usthealthproof.eplus.hrp.member.preference.service;

import com.usthealthproof.eplus.hrp.member.preference.dao.MemberPreferenceDAO;
import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponseList;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.UpdatePreferenceResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MemberPreferenceServiceTest {
    @Mock
    MemberPreferenceDAO memberPreferenceDAO;
    @Mock
    Logger log;
    @InjectMocks
    MemberPreferenceService memberPreferenceService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMemberPreference() throws Exception {
        when(memberPreferenceDAO.getMemberPreference(anyString())).thenReturn(new MemberPreferenceResponse());

        MemberPreferenceResponse result = memberPreferenceService.getMemberPreference("memberId");
        Assertions.assertEquals(new MemberPreferenceResponse(), result);
    }

    @Test
    void testUpdateMemberPreference() throws Exception {
        when(memberPreferenceDAO.updateMemberPreference(any())).thenReturn(new UpdatePreferenceResponse());

        UpdatePreferenceResponse result = memberPreferenceService.updateMemberPreference(new MemberPreferenceRequest());
        Assertions.assertEquals(new UpdatePreferenceResponse(), result);
    }

    @Test
    void testGetAllLanguages() throws Exception {
        when(memberPreferenceDAO.getAllLanguages()).thenReturn(new LanguageResponseList());

        LanguageResponseList result = memberPreferenceService.getAllLanguages();
        Assertions.assertEquals(new LanguageResponseList(), result);
    }
}
