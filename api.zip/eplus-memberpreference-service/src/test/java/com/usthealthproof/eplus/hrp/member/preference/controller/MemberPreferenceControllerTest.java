package com.usthealthproof.eplus.hrp.member.preference.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstantsTest;
import com.usthealthproof.eplus.hrp.member.preference.model.*;
import com.usthealthproof.eplus.hrp.member.preference.service.MemberPreferenceService;
import com.usthealthproof.eplus.hrp.member.preference.util.APIUtils;
import com.usthealthproof.eplus.hrp.member.preference.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(MemberPreferenceController.class)
class MemberPreferenceControllerTest {
    @MockitoBean
    MemberPreferenceService memberPreferenceService;
    @MockitoBean
    Validator validator;
    @MockitoBean
    private APIUtils apiUtils;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
    UpdatePreferenceResponse updatePreferenceResponse = new UpdatePreferenceResponse();
    MemberPreferenceResponse memberPreferenceResponse = new MemberPreferenceResponse();
    LanguageResponseList languageResponseList = new LanguageResponseList();
    List<LanguageResponse> languageResponseListing = new ArrayList<>();

    @BeforeEach
    void setUp() {
        //Get
        memberPreferenceResponse.setMemberId(MemberPreferenceConstantsTest.MEMBER_ID);
        memberPreferenceResponse.setPreferredEmailFormat("Plain text");
        memberPreferenceResponse.setPreferredContactMethod("Email");
        memberPreferenceResponse.setPreferredDeliveryMethod("Online");
        Language language = new Language();
        language.setPrimaryLanguage("true");
        language.setNativeLanguage("false");
        language.setLanguageName("EN");
        List<Language>  languageList= List.of (language);
        memberPreferenceResponse.setPreferredLanguage(languageList);
        //Update
        updatePreferenceResponse.setStatusMessage("Member Preferences updated successfully");
        //Language
        LanguageResponse languageResponse = new LanguageResponse();
        languageResponse.setLanguageName("Arabic - Algerian");
        languageResponse.setLanguageCode("1AG");
        languageResponseListing = List.of(languageResponse);
        languageResponseList.setLanguages(languageResponseListing);
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getMemberPreference")
    void testGetMemberPreference() throws Exception {
        // given - precondition or setup
        given(memberPreferenceService.getMemberPreference(anyString())).willReturn(memberPreferenceResponse);
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(MemberPreferenceConstantsTest.ENDPOINT_MEMBERPREFERENCE)
                .param("memberId", MemberPreferenceConstantsTest.MEMBER_ID));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for updatingMemberPreference")
    void testUpdateMemberPreference() throws Exception {
        // given - precondition or setup
        given(memberPreferenceService.updateMemberPreference(any())).willReturn(updatePreferenceResponse);
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post(MemberPreferenceConstantsTest.ENDPOINT_MEMBERPREFERENCE)
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(memberPreferenceRequest)));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for listing languages - ValidInput")
    void testGetAllLanguages() throws Exception {
        // given - precondition or setup
        given(memberPreferenceService.getAllLanguages()).willReturn(languageResponseList);
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(MemberPreferenceConstantsTest.ENDPOINT_LANGUAGES));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isOk());
    }
}
