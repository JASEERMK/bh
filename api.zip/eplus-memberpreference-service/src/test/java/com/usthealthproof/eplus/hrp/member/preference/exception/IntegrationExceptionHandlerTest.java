package com.usthealthproof.eplus.hrp.member.preference.exception;

import com.usthealthproof.eplus.hrp.member.preference.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.preference.model.ProblemDetails;
import com.usthealthproof.eplus.hrp.member.preference.util.APIUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.apache.commons.logging.Log;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class IntegrationExceptionHandlerTest {
    @Mock
    APIUtils apiUtils;
    @Mock
    Logger log;
    @Mock
    Log logger;
    @Mock
    MessageSource messageSource;

    @Mock
    HttpMethod httpMethod;

    @Mock
    WebRequest webRequest;

    @InjectMocks
    IntegrationExceptionHandler integrationExceptionHandler;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRequestValidationExceptionHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.requestValidationExceptionHandler(new RequestValidationException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testResponseValidationExceptionHandler() {
        String charactersToReplace = "{,},\n,\",>,\\";
        ReflectionTestUtils.setField(integrationExceptionHandler, "charactersToReplace", charactersToReplace);
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());
        WebRequest request = mock(WebRequest.class);

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.responseValidationExceptionHandler(new ResponseValidationException("message|400"), request);
        assertThat(result).isNotNull();
    }

    @Test
    void testNoContentExceptionHandler() {
        WebRequest request = mock(WebRequest.class);
        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.noContentExceptionHandler(new NoContentException("message"), request);
        assertThat(result).isNotNull();
    }

    @Test
    void testGlobalHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.globalHandler(new Exception(), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testHandleConstraintViolationException() {

        ConstraintViolationException ex = mock(ConstraintViolationException.class);
        when(ex.getMessage()).thenReturn("Validation failed");
        WebRequest request = mock(WebRequest.class);
        ConstraintViolation<?> constraintViolation = mock(ConstraintViolation.class);
        when(constraintViolation.getMessage()).thenReturn("Field cannot be null");
        when(ex.getConstraintViolations()).thenReturn(Set.of(constraintViolation));
        ResponseEntity<ErrorResponse> responseEntity = integrationExceptionHandler.handleConstraintViolationException(ex, request);
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(responseEntity.getBody()).isNotNull();
    }

    @Test
    void testJdbcExceptionHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.jdbcExceptionHandler(new CannotGetJdbcConnectionException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testHandleIllegalArgumentException() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.handleIllegalArgumentException(new IllegalArgumentException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testNoResourceFoundExceptionHandler()
    {
        ResponseEntity<ErrorResponse> errorResponse = integrationExceptionHandler.noResourceFoundException(new NoResourceFoundException(httpMethod,"v1/member/preference/communication"), webRequest);
        assertThat(errorResponse).isNotNull();
    }

    @Test
    void testHandleMethodArgumentNotValid()
    {
        HttpHeaders headers=new HttpHeaders();
        MethodArgumentNotValidException ex= mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        FieldError fieldError = mock(FieldError.class);

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(ex.getBindingResult().getFieldErrors()).thenReturn(List.of(fieldError));

        ResponseEntity<Object> errorResponse=integrationExceptionHandler.handleMethodArgumentNotValid(ex,webRequest);
        assertNotNull(errorResponse);
    }


    @Test
    void testMissingServletRequestParameterException()
    {
        ResponseEntity<ErrorResponse> errorResponse = integrationExceptionHandler.missingServletRequestParameterException(new MissingServletRequestParameterException("memberId", "String"), webRequest);
        assertThat(errorResponse).isNotNull();
    }



}