package com.usthealthproof.eplus.hrp.member.preference.validator;

import com.healthedge.connector.schema.basetypes.ErrorInfoType;
import com.healthedge.connector.schema.basetypes.ErrorsType;
import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentSparseResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstantsTest;
import com.usthealthproof.eplus.hrp.member.preference.exception.NoContentException;
import com.usthealthproof.eplus.hrp.member.preference.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.preference.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.member.preference.model.Language;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.healthedge.connector.schema.basetypes.ErrorType.SYSTEM;
import static com.healthedge.connector.schema.basetypes.ServiceStatusType.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ValidatorTest {
    @Mock
    Logger log;
    @InjectMocks
    Validator validator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testValidateGetMemberPreferenceRequest() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest((String) null));
    }

    @Test
    void testValidateUpdateMemberPreferenceRequest() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest((MemberPreferenceRequest) null));
        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        memberPreferenceRequest.setMemberId(null);
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest(memberPreferenceRequest));
        memberPreferenceRequest.setMemberId(MemberPreferenceConstantsTest.MEMBER_ID);
        memberPreferenceRequest.setPreferredEmailFormat(null);
        memberPreferenceRequest.setPreferredDeliveryMethod(null);
        memberPreferenceRequest.setPreferredContactMethod(null);
        memberPreferenceRequest.setPreferredLanguage(null);
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest(memberPreferenceRequest));
    }
    @Test
    void testValidateMemberPreferenceRequest_InvalidPrimaryLanguage() {
        // Request with invalid primary language
        MemberPreferenceRequest request = new MemberPreferenceRequest();
        request.setMemberId("12345");
        Language invalidLanguage = new Language();
        invalidLanguage.setPrimaryLanguage("Invalid");
        invalidLanguage.setNativeLanguage("True");
        request.setPreferredLanguage(Arrays.asList(invalidLanguage));
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest(request));
    }

    @Test
    void testValidateMemberPreferenceRequest_InvalidNativeLanguage() {
        // Request with invalid native language
        MemberPreferenceRequest request = new MemberPreferenceRequest();
        request.setMemberId("12345");
        Language invalidLanguage = new Language();
        invalidLanguage.setPrimaryLanguage("True");
        invalidLanguage.setNativeLanguage("Invalid");
        request.setPreferredLanguage(Arrays.asList(invalidLanguage));
        assertThrows(RequestValidationException.class, () -> validator.validateMemberPreferenceRequest(request));
    }

    @Test
    void testValidateSubmitResponse() {
        EnrollmentResponseType enrollmentResponseType = new EnrollmentResponseType();
        enrollmentResponseType.setStatus(FAILURE);
        enrollmentResponseType.setErrors(null);
        assertThrows(ResponseValidationException.class, () -> validator.validateSubmitResponse(enrollmentResponseType));

        ErrorInfoType errorInfoType = new ErrorInfoType();
        errorInfoType.setErrorType(SYSTEM);
        errorInfoType.setMessage("Error Occured");

        ErrorsType errorsType = new ErrorsType();
        errorsType.getError().add(errorInfoType);
        enrollmentResponseType.setErrors(errorsType);
        assertThrows(ResponseValidationException.class, () -> validator.validateSubmitResponse(enrollmentResponseType));
    }

    @Test
    void testValidateLookupResponse() {
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupResponse(null));
        EnrollmentSparseResponseType enrollmentSparseResponseType = new EnrollmentSparseResponseType();
        enrollmentSparseResponseType.setStatus(null);
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupResponse(enrollmentSparseResponseType));
        enrollmentSparseResponseType.setStatus(NO_MATCH_FOUND);
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupResponse(enrollmentSparseResponseType));
        EnrollmentType enrollmentType = new EnrollmentType();
        enrollmentSparseResponseType.setEnrollment(enrollmentType);
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupResponse(enrollmentSparseResponseType));
        enrollmentSparseResponseType.setStatus(SUCCESS);
        enrollmentSparseResponseType.setStatus(MATCH_FOUND);
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupResponse(enrollmentSparseResponseType));
    }

    @Test
    void testValidateLookupMember() {
        assertThrows(ResponseValidationException.class, () -> validator.validateLookupMember(null));
        MembershipType membershipType = new MembershipType();
        membershipType.setCommunicationPreferences(null);
        MembershipType.Individual individual = new MembershipType.Individual();
        individual.setLanguages(null);
        membershipType.setIndividual(individual);
        assertThrows(NoContentException.class, () -> validator.validateLookupMember(membershipType));
    }
}