package com.usthealthproof.eplus.hrp.member.preference.mapper;

import com.usthealthproof.eplus.hrp.member.preference.model.LanguageResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.sql.ResultSet;
import java.sql.SQLException;

class LanguageMapperTest {
    LanguageMapper languageMapper = new LanguageMapper();

    @Test
    void testMapRow() throws SQLException {
        ResultSet resultSetMock = Mockito.mock(ResultSet.class);
        Mockito.when(resultSetMock.getString("cd_entry_txt")).thenReturn("EN");
        Mockito.when(resultSetMock.getString("short_name")).thenReturn("English");
        LanguageResponse result = languageMapper.mapRow(resultSetMock, 0);
        Assertions.assertEquals(result.getLanguageCode(), "EN");
        Assertions.assertEquals(result.getLanguageName(), "English");
    }
}
