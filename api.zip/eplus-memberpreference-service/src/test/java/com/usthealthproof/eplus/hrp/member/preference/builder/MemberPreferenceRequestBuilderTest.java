package com.usthealthproof.eplus.hrp.member.preference.builder;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentLookupType;
import com.usthealthproof.eplus.hrp.member.preference.configuration.MemberPreferenceConfig;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstantsTest;
import com.usthealthproof.eplus.hrp.member.preference.model.Language;
import com.usthealthproof.eplus.hrp.member.preference.model.MemberPreferenceRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.datatype.XMLGregorianCalendar;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MemberPreferenceRequestBuilderTest {
    @Mock
    MemberPreferenceConfig memberPreferenceConfig;
    @InjectMocks
    MemberPreferenceRequestBuilder memberPreferenceRequestBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateEnrollmentRequest() throws Exception {
        EnrollmentType enrollmentType = new EnrollmentType();
        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        memberPreferenceRequest.setMemberId(MemberPreferenceConstantsTest.MEMBER_ID);
        memberPreferenceRequest.setPreferredContactMethod("Email");
        memberPreferenceRequest.setPreferredDeliveryMethod("Online");
        memberPreferenceRequest.setPreferredEmailFormat("Plain text");
        Language language = new Language();
        language.setPrimaryLanguage("true");
        language.setNativeLanguage("false");
        language.setLanguageName("EN");
        List<Language> languageList= List.of (language);
        memberPreferenceRequest.setPreferredLanguage(languageList);
        when(memberPreferenceConfig.getMemberMatchDefinition()).thenReturn("MemberMatchDefinition");
        when(memberPreferenceConfig.getSubscriptionAmendReasonCode()).thenReturn("01");
        EnrollmentType result = memberPreferenceRequestBuilder.createEnrollmentRequest(memberPreferenceRequest);
        assertThat(result).isNotNull();
    }

    @Test
    void testGetXMLGregorianCalendarDate() throws Exception {
        XMLGregorianCalendar result = memberPreferenceRequestBuilder.getXMLGregorianCalendarDate(null);
        Assertions.assertEquals(null, result);
    }

    @Test
    void testCreateEnrollmentLookupRequest() {
        when(memberPreferenceConfig.getMemberMatchDefinition()).thenReturn("MemberMatchDefinition");

        EnrollmentLookupType result = memberPreferenceRequestBuilder.createEnrollmentLookupRequest(MemberPreferenceConstantsTest.MEMBER_ID);
        assertThat(result).isNotNull();
    }
}