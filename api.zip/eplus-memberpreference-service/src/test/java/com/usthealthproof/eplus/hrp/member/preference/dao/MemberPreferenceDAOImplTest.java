package com.usthealthproof.eplus.hrp.member.preference.dao;

import com.healthedge.EnrollmentSparseLookupPortType;
import com.healthedge.EnrollmentSparsePortType;
import com.healthedge.connector.schema.basetypes.*;
import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentLookupType;
import com.healthedge.connector.schema.enrollmentsparselookup.EnrollmentSparseResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.usthealthproof.eplus.hrp.member.preference.builder.MemberPreferenceRequestBuilder;
import com.usthealthproof.eplus.hrp.member.preference.constants.MemberPreferenceConstantsTest;
import com.usthealthproof.eplus.hrp.member.preference.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.member.preference.mapper.LanguageMapper;
import com.usthealthproof.eplus.hrp.member.preference.model.*;
import com.usthealthproof.eplus.hrp.member.preference.validator.Validator;
import jakarta.xml.bind.JAXBElement;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MemberPreferenceDAOImplTest {
    @Mock
    Validator validator;
    @Mock
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Mock
    LanguageMapper languagesMapper;
    @Mock
    EnrollmentSparsePortType enrollmentSparsePortType;
    @Mock
    EnrollmentSparseLookupPortType enrollmentSparseLookupPortType;
    @Mock
    MemberPreferenceRequestBuilder memberPreferenceRequestBuilder;
    @Mock
    Logger log;
    @InjectMocks
    MemberPreferenceDAOImpl memberPreferenceDAOImpl;
    LanguageResponseList languageResponseList = new LanguageResponseList();
    List<LanguageResponse> languageResponseListing = new ArrayList<>();
    MemberPreferenceResponse memberPreferenceResponse = new MemberPreferenceResponse();

    @Mock
    WebServiceTemplate webServiceTemplate;
    @Mock
    WebServiceTemplate webServiceTemplateSparsePortType;

    @BeforeEach
    void setUp() {
        Map<String, String> emailFormatMap = new HashMap<>();
        emailFormatMap.put("1","HTML");
        emailFormatMap.put("2","Plain text");
        ReflectionTestUtils.setField(memberPreferenceDAOImpl, "emailFormatMap", emailFormatMap);

        Map<String, String> documentDeliveryMethodMap = new HashMap<>();
        documentDeliveryMethodMap.put("1","Online");
        documentDeliveryMethodMap.put("2","Paper");
        ReflectionTestUtils.setField(memberPreferenceDAOImpl, "documentDeliveryMethodMap", documentDeliveryMethodMap);

        memberPreferenceResponse.setMemberId(MemberPreferenceConstantsTest.MEMBER_ID);
        memberPreferenceResponse.setPreferredEmailFormat("Plain text");
        memberPreferenceResponse.setPreferredContactMethod("Email");
        memberPreferenceResponse.setPreferredDeliveryMethod("Online");
        Language language = new Language();
        language.setPrimaryLanguage("true");
        language.setNativeLanguage("false");
        language.setLanguageName("EN");
        List<Language>  languageList= List.of (language);
        memberPreferenceResponse.setPreferredLanguage(languageList);
        //Language
        LanguageResponse languageResponse = new LanguageResponse();
        languageResponse.setLanguageName("Arabic - Algerian");
        languageResponse.setLanguageCode("1AG");
        languageResponseListing = List.of(languageResponse);
        languageResponseList.setLanguages(languageResponseListing);
    }

    @Test
    void testGetMemberPreference() {
        // when - action or the behaviour
        EnrollmentSparseResponseType enrollmentSparseResponseType = new EnrollmentSparseResponseType();
        EnrollmentType type = new EnrollmentType();
        MembershipType membershipType = new MembershipType();
        membershipType.setHccIdentifier(MemberPreferenceConstantsTest.MEMBER_ID);
        IndividualCommunicationPreferencesType individualCommunicationPreferencesType = new IndividualCommunicationPreferencesType();
        CodeEntryInputType codeEntryInputType = new CodeEntryInputType();
        codeEntryInputType.setCodeEntry("2");
        individualCommunicationPreferencesType.setEmailFormatCode(codeEntryInputType);
        CodeEntryInputType codeEntryInputType2 = new CodeEntryInputType();
        codeEntryInputType2.setCodeEntry("1");
        individualCommunicationPreferencesType.setDocumentDeliveryMethodCode(codeEntryInputType2);
        individualCommunicationPreferencesType.setContactMethod(CommunicationContactMethodType.EMAIL);
        membershipType.setCommunicationPreferences(individualCommunicationPreferencesType);
        LanguageSpokenType languageSpokenType = new LanguageSpokenType();
        CodeEntryInputType codeEntryInputType3 = new CodeEntryInputType();
        codeEntryInputType3.setCodeEntry("EN");
        languageSpokenType.setLanguageDomainCode(codeEntryInputType3);
        languageSpokenType.setPrimaryLanguage(Boolean.TRUE);
        languageSpokenType.setNativeLanguage(Boolean.FALSE);
        LanguagesType languagesType = new LanguagesType();
        languagesType.getLanguage().add(languageSpokenType);
        MembershipType.Individual individual = new MembershipType.Individual();
        individual.setLanguages(languagesType);
        membershipType.setIndividual(individual);
        type.getMember().add(membershipType);
        enrollmentSparseResponseType.setEnrollment(type);
 //       when(enrollmentSparseLookupPortType.get(any())).thenReturn(enrollmentSparseResponseType);
        EnrollmentLookupType enrollmentLookupType = new EnrollmentLookupType();
        JAXBElement<EnrollmentSparseResponseType> jaxbElement = new JAXBElement<>(
                new QName("http://www.healthedge.com/connector/schema/enrollmentsparselookup", "enrollmentLookupCriteria"),
                EnrollmentSparseResponseType.class,
                enrollmentSparseResponseType
        );


        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenReturn(jaxbElement);

        MemberPreferenceResponse result = memberPreferenceDAOImpl.getMemberPreference(MemberPreferenceConstantsTest.MEMBER_ID);
        // then - verify the output
        Assertions.assertEquals(memberPreferenceResponse, result);
    }

    @Test
    void testUpdateMemberPreference() throws Exception {
        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        memberPreferenceRequest.setMemberId(MemberPreferenceConstantsTest.MEMBER_ID);
        memberPreferenceRequest.setPreferredEmailFormat("Plain text");
        memberPreferenceRequest.setPreferredContactMethod("Email");
        memberPreferenceRequest.setPreferredDeliveryMethod("Online");
        Language language = new Language();
        language.setPrimaryLanguage("true");
        language.setNativeLanguage("false");
        language.setLanguageName("EN");
        List<Language> languageList = List.of(language);
        memberPreferenceRequest.setPreferredLanguage(languageList);
        EnrollmentResponseType enrollmentResponseType = new EnrollmentResponseType();
        enrollmentResponseType.setStatus(ServiceStatusType.SUCCESS);

        // when - action or the behaviour
 //       when(enrollmentSparsePortType.submit(any())).thenReturn(enrollmentResponseType);

        EnrollmentResponseType enrollmentResponse = new EnrollmentResponseType();
        JAXBElement<EnrollmentResponseType> jaxbElement = new JAXBElement<>(
                new QName("http://www.healthedge.com/connector/schema/enrollmentsparse", "enrollment"),
                EnrollmentResponseType.class,
                enrollmentResponse
        );

        when(webServiceTemplateSparsePortType.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenReturn(jaxbElement);

        UpdatePreferenceResponse result = memberPreferenceDAOImpl.updateMemberPreference(memberPreferenceRequest);
        // then - verify the output
        Assertions.assertEquals("Member Preferences updated successfully", result.getStatusMessage());
    }

    @Test
    void testGetAllLanguages() {
        // given - precondition or setup
        when(namedParameterJdbcTemplate.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class), Mockito.<LanguageMapper> any())).thenReturn(languageResponseList.getLanguages());

        // when - action or the behaviour
        LanguageResponseList result = memberPreferenceDAOImpl.getAllLanguages();
        // then - verify the output
        assertThat(result).isNotNull();
        assertThat(result.getLanguages()).isEqualTo(languageResponseList.getLanguages());

        when(namedParameterJdbcTemplate.query(Mockito.anyString(),
                Mockito.any(SqlParameterSource.class), Mockito.<LanguageMapper> any())).thenReturn(Collections.EMPTY_LIST);
        assertThrows(ResponseValidationException.class, () -> memberPreferenceDAOImpl.getAllLanguages());
    }

    @Test
    void testGetMemberPreferenceSoapFaultException() throws Exception {
        // when - action or the behaviour
        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenThrow(SoapFaultClientException.class);
        // then - verify the output
        assertThatThrownBy(()->memberPreferenceDAOImpl.getMemberPreference(MemberPreferenceConstantsTest.MEMBER_ID)).isInstanceOf(SoapFaultClientException.class);
    }

    @Test
    void testGetMemberPreferenceIllegalException() throws Exception {
        // when - action or the behaviour
        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenThrow(IllegalArgumentException.class);
        // then - verify the output
        assertThatThrownBy(()->memberPreferenceDAOImpl.getMemberPreference(MemberPreferenceConstantsTest.MEMBER_ID)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testGetMemberPreferenceException() throws Exception {
        EnrollmentSparseResponseType enrollmentSparseResponseType = new EnrollmentSparseResponseType();
        EnrollmentLookupType enrollmentLookupType = new EnrollmentLookupType();
        JAXBElement<EnrollmentLookupType> jaxbElement = new JAXBElement<>(
                new QName("http://www.healthedge.com/connector/schema/enrollmentsparselookup", "enrollmentLookupCriteria"),
                EnrollmentLookupType.class,
                enrollmentLookupType
        );

        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenReturn(jaxbElement);
        assertThatThrownBy(()->memberPreferenceDAOImpl.getMemberPreference(MemberPreferenceConstantsTest.MEMBER_ID)).isInstanceOf(Exception.class);
    }

    @Test
    void testUpdateMemberPreferenceSoapFaultException() throws Exception {

        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        // when - action or the behaviour
        when(webServiceTemplateSparsePortType.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenThrow(SoapFaultClientException.class);
        // then - verify the output
        assertThatThrownBy(()->memberPreferenceDAOImpl.updateMemberPreference(memberPreferenceRequest)).isInstanceOf(SoapFaultClientException.class);
    }

    @Test
    void testUpdateMemberPreferenceIllegalException() throws Exception {

        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        // when - action or the behaviour
        when(webServiceTemplateSparsePortType.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenThrow(IllegalArgumentException.class);
        // then - verify the output
        assertThatThrownBy(()->memberPreferenceDAOImpl.updateMemberPreference(memberPreferenceRequest)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testUpdateMemberPreferenceException() throws Exception {

        MemberPreferenceRequest memberPreferenceRequest = new MemberPreferenceRequest();
        JAXBElement<MemberPreferenceRequest> getEnrollmentTypeJAXBElement = new JAXBElement<>(
                new QName("http://www.healthedge.com/connector/schema/enrollmentsparse", "enrollment"),
                MemberPreferenceRequest.class,
                memberPreferenceRequest
        );

        when(webServiceTemplateSparsePortType.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenReturn(getEnrollmentTypeJAXBElement);
        assertThatThrownBy(()->memberPreferenceDAOImpl.updateMemberPreference(memberPreferenceRequest)).isInstanceOf(Exception.class);
    }

    @Test
    void testCleanUp() {
        memberPreferenceDAOImpl.cleanUp();

        // Verify collections are cleared using ReflectionTestUtils
        Map<String, String> emailFormatMap = (Map<String, String>) ReflectionTestUtils.getField(memberPreferenceDAOImpl, "emailFormatMap");
        Map<String, String> documentDeliveryMethodMap = (Map<String, String>) ReflectionTestUtils.getField(memberPreferenceDAOImpl, "documentDeliveryMethodMap");

        assertTrue(emailFormatMap.isEmpty(), "emailFormatMap should be empty after cleanup");
        assertTrue(documentDeliveryMethodMap.isEmpty(), "documentDeliveryMethodMap should be empty after cleanup");
    }
}