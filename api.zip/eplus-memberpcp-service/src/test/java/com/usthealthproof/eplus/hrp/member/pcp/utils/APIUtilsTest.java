package com.usthealthproof.eplus.hrp.member.pcp.utils;

import com.usthealthproof.eplus.hrp.member.pcp.domain.ProblemDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

@ExtendWith(MockitoExtension.class)
public class APIUtilsTest {

    @InjectMocks
    APIUtils apiUtils;

    ProblemDetails problemDetails = new ProblemDetails();

    @BeforeEach
    void setUp() {
        problemDetails.setErrors(List.of("Data Not found"));
        problemDetails.setStatus("No data");
    }

    @Test
    void testCreateProblemDetails() {
        // when - action or the behaviour
        ProblemDetails result = apiUtils.createProblemDetails("Data Not found", "No data");
        // then - verify the output
        Assertions.assertEquals(problemDetails, result);
    }
}
