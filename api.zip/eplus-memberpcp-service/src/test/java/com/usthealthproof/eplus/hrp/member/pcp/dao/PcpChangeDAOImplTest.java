package com.usthealthproof.eplus.hrp.member.pcp.dao;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import jakarta.xml.bind.JAXBElement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PcpChangeDAOImplTest {

    @InjectMocks
    private PcpChangeDAOImpl pcpChangeDAO;

    @Mock
    private WebServiceTemplate webServiceTemplate;

    private EnrollmentType enrollmentType;
    private EnrollmentResponseType enrollmentResponseType;
    private JAXBElement<EnrollmentResponseType> responseElement;

    @BeforeEach
    void setUp() {
        enrollmentType = new EnrollmentType();
        enrollmentResponseType = new EnrollmentResponseType();
        responseElement = new JAXBElement<>(
                new QName("http://example.com", "EnrollmentResponseType"),
                EnrollmentResponseType.class,
                enrollmentResponseType
        );
    }

    @Test
    void testChangePcp() {
        when(webServiceTemplate.marshalSendAndReceive(any(JAXBElement.class), any(SoapActionCallback.class)))
                .thenReturn(responseElement);

        EnrollmentResponseType result = pcpChangeDAO.changePcp(enrollmentType);

        assertNotNull(result);
        assertEquals(enrollmentResponseType, result);
    }
}
