package com.usthealthproof.eplus.hrp.member.pcp.validator;

import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.Auth;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CompositeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class HealthTrioPCPValidatorTest {

    @InjectMocks
    HealthTrioPCPValidator validator;
    private HttpServletRequest httpRequest;

    @Test
    void testValidateHeader() {

        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        when(mockRequest.getHeader(MemberPcpConstants.CORRELATIONID)).thenReturn("   ");

        // Act & Assert
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateHeader(mockRequest);
        });

        assertEquals("Missing CorrelationId in request header coming from HealthTrio Potral", exception.getMessage());

    }

    @Test
    void testValidateAccessResponse() {
        Auth auth = null;
        assertThrows(USTIntegrationException.class, () -> validator.validateAccessResponse(auth));
    }

    @Test
    void testValidateCrmResponse() {
        CrmResponse crmresponse = new CrmResponse();
        List<CompositeResponse> compositeResponse = new ArrayList<>();

        compositeResponse.add(null);
        compositeResponse.add(null);
        crmresponse.setCompositeResponse(compositeResponse);
        assertThrows(USTIntegrationException.class, () -> validator.validateCrmResponse(crmresponse));


        CompositeResponse response = new CompositeResponse();
        response.setBody(null);
        compositeResponse.set(1, response);
        crmresponse.setCompositeResponse(compositeResponse);
        assertThrows(USTIntegrationException.class, () -> validator.validateCrmResponse(crmresponse));
    }


    @Test
    void testValidateCrmCaseId() {
        CrmResponseBody body = new CrmResponseBody();
        body.setId(null);
        assertThrows(USTIntegrationException.class, () -> validator.validateCrmCaseId(body));
    }

    @Test
    void testValidateReferenceId() {
        assertThrows(USTIntegrationException.class, () -> validator.validateReferenceId(null));
    }

    @Test
    void testValidateCrmCompositeResponse() {
        List<CrmResponseBody> bodylist = new ArrayList<>();
        assertThrows(USTIntegrationException.class, () -> validator.validateCrmCompositeResponse(null));
        CrmResponseBody crmResponseBody = new CrmResponseBody();
        bodylist.add(crmResponseBody);
        assertThrows(USTIntegrationException.class, () -> validator.validateCrmCompositeResponse(bodylist));

    }
}
