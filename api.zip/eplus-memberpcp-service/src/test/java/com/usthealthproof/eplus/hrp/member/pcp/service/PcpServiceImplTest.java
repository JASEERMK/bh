package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.usthealthproof.eplus.hrp.member.pcp.config.MemberPCPServiceConfig;
import com.usthealthproof.eplus.hrp.member.pcp.builder.PcpChangeRequestBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.dao.PcpChangeDAO;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static com.healthedge.connector.schema.basetypes.ServiceStatusType.SUCCESS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PcpServiceImplTest {

    @InjectMocks
    PcpServiceImpl pcpServiceImpl;
    @Mock
    PcpChangeDAO pcpChangeDAO;
    @Mock
    PcpChangeRequestBuilder pcpChangeRequestBuilder;
    @Mock
    MemberPCPServiceConfig memberPCPServiceConfig;

    @Test
    void testSubmitPcpChangeRequest() throws Exception {

        PcpChangeRequest pcpRequest = new PcpChangeRequest();
        pcpRequest.setReasonForPcpChange("abc");
        pcpRequest.setMemberId("123");
        List<ProviderSelection> providerSelections = new ArrayList<>();
        ProviderSelection providerSelection = new ProviderSelection();
        providerSelection.setPractitionerRoleName("S00000321");
        providerSelection.setStartDate("2023-01-01");
        providerSelection.setEndDate("2023-01-01");
        providerSelection.setPractitionerId("asd");
        providerSelections.add(providerSelection);
        pcpRequest.setProviderSelections(providerSelections);
        EnrollmentResponseType enrollmentSparseResponseType = new EnrollmentResponseType();
        enrollmentSparseResponseType.setStatus(SUCCESS);
        PcpChangeResponse pcpChangeResponse = new PcpChangeResponse();
        pcpChangeResponse.setRequestId("PcpChange -28052024-171149197-8b39d8be-8d55-4723-a868-80155115c7aa");
        pcpChangeResponse.setCrmReferenceId(null);
        pcpChangeResponse.setStatus(null);

        //  when - action or the behaviour
        when(pcpChangeDAO.changePcp(any())).thenReturn(enrollmentSparseResponseType);
        PcpChangeResponse response = pcpServiceImpl.submitPcpChangeRequest(pcpRequest);
        assertThat(response).isNotNull();

        assertThrows(Exception.class, () -> pcpServiceImpl.submitPcpChangeRequest(null));
    }
}
