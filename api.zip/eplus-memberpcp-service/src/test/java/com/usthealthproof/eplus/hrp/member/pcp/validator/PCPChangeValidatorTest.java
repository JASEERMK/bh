package com.usthealthproof.eplus.hrp.member.pcp.validator;

import com.healthedge.connector.schema.basetypes.ErrorInfoType;
import com.healthedge.connector.schema.basetypes.ErrorsType;
import com.healthedge.connector.schema.basetypes.TransactionExceptionType;
import com.healthedge.connector.schema.basetypes.TransactionInformationType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.MemberResponseType;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import com.usthealthproof.eplus.hrp.member.pcp.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.pcp.exception.ResponseValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static com.healthedge.connector.schema.basetypes.ErrorType.SYSTEM;
import static com.healthedge.connector.schema.basetypes.ServiceStatusType.FAILURE;
import static com.healthedge.connector.schema.basetypes.TransactionExceptionStatusType.REJECT;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class PCPChangeValidatorTest {

    @Mock
    Logger log;
    @InjectMocks
    PCPChangeValidator validator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testValidatePcpChangeRequest() {
        // when and then - verify the output

        PcpChangeRequest pcpChangeRequest = new PcpChangeRequest();
        pcpChangeRequest.setMemberId("123");
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((PcpChangeRequest) null));

        pcpChangeRequest.setMemberId(null);
        pcpChangeRequest.setReasonForPcpChange("ghj");
        List<ProviderSelection> providerSelection = new ArrayList<>();
        ProviderSelection providerSelection1 = new ProviderSelection();
        providerSelection1.setPractitionerId("123");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId("123");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId("123");
        providerSelection1.setStartDate("2024-05-27");
        providerSelection1.setEndDate(null);
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId("123");
        providerSelection1.setStartDate("2024-05-27");
        providerSelection1.setEndDate("2024-05-28");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId("123");
        providerSelection1.setStartDate("2024-05-27");
        providerSelection1.setEndDate("05-28-2024");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId(null);
        providerSelection1.setStartDate("2024-05-27");
        providerSelection1.setEndDate("2024-05-28");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

        pcpChangeRequest.setMemberId("123");
        pcpChangeRequest.setReasonForPcpChange("ghj");
        providerSelection1.setPractitionerId(null);
        providerSelection1.setPractitionerRoleName("abc");
        providerSelection1.setStartDate("2024-05-27");
        providerSelection1.setEndDate("2024-05-28");
        providerSelection.add(providerSelection1);
        pcpChangeRequest.setProviderSelections(providerSelection);
        assertThrows(RequestValidationException.class, () -> validator.validatePcpChangeRequest((pcpChangeRequest)));

    }

    @Test
    void testValidatePcpChangeResponse() {

        EnrollmentResponseType enrollmentSparseResponseType = new EnrollmentResponseType();
        enrollmentSparseResponseType.setStatus(FAILURE);
        ErrorsType errorsType = new ErrorsType();
        ErrorInfoType list1 = new ErrorInfoType();
        list1.setAuthenticatedUser("abc");
        list1.setMessage("exception occured");
        list1.setErrorType(SYSTEM);
        errorsType.getError().add(list1);
        enrollmentSparseResponseType.setErrors(errorsType);
        assertThrows(ResponseValidationException.class,
                () -> validator.validatePcpChangeResponse((enrollmentSparseResponseType)));

        enrollmentSparseResponseType.setStatus(FAILURE);
        errorsType.getError().add(null);
        enrollmentSparseResponseType.setErrors(null);
        MemberResponseType memberResponseType = new MemberResponseType();
        memberResponseType.setMemberId(null);
        validator.validatePcpChangeResponse((enrollmentSparseResponseType));

        enrollmentSparseResponseType.setStatus(FAILURE);
        errorsType.getError().add(null);
        enrollmentSparseResponseType.setErrors(null);
        memberResponseType.setMemberId(null);
        enrollmentSparseResponseType.getMember().add(memberResponseType);
        validator.validatePcpChangeResponse((enrollmentSparseResponseType));

        enrollmentSparseResponseType.setStatus(FAILURE);
        errorsType.getError().add(null);
        enrollmentSparseResponseType.setErrors(null);
        memberResponseType.setMemberId("123");
        TransactionInformationType transactionInformationType = new TransactionInformationType();
        TransactionExceptionType transactionExceptionType = new TransactionExceptionType();
        transactionExceptionType.setExceptionType(REJECT);
        transactionInformationType.getExceptions().add(transactionExceptionType);
        memberResponseType.setTransactionInformation(transactionInformationType);
        enrollmentSparseResponseType.getMember().add(memberResponseType);
        assertThrows(ResponseValidationException.class,
                () -> validator.validatePcpChangeResponse((enrollmentSparseResponseType)));
    }

}
