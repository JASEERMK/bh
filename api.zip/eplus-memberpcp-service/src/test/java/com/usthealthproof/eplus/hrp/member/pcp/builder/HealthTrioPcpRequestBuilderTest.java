package com.usthealthproof.eplus.hrp.member.pcp.builder;

import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.CrmRequest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class HealthTrioPcpRequestBuilderTest {

    @InjectMocks
    HealthTrioPcpRequestBuilder healthTrioPcpRequestBuilder;
    @Mock
    PcpChangeRequest pcpRequest;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateCRMRequest() {

        PcpChangeRequest pcpRequest = new PcpChangeRequest();
        List<ProviderSelection> providerSelections = new ArrayList<>();
        ProviderSelection providerSelection = new ProviderSelection();
        providerSelection.setAffiliatedSupplierNetwork("abc");
        providerSelection.setLineOfBusiness("'PA Medicare Assured'");
        providerSelections.add(providerSelection);
        pcpRequest.setProviderSelections(providerSelections);
        pcpRequest.setMemberId("123");
        pcpRequest.setReasonForPcpChange("new");

        //        given(pcpConfig.getMedicaidDesc()).willReturn("PA Medicaid, WV Medicaid, DE Medicaid");
        ReflectionTestUtils.setField(healthTrioPcpRequestBuilder, "medicaidDesc", "'PA Medicaid'");
        CrmRequest crmRequest = healthTrioPcpRequestBuilder.createCRMRequest(pcpRequest);
        Assertions.assertNotNull(crmRequest);

    }

    @Test
    void testCreateCRMRequestWithMedicare() {

        PcpChangeRequest pcpRequest = new PcpChangeRequest();
        List<ProviderSelection> providerSelections = new ArrayList<>();
        ProviderSelection providerSelection = new ProviderSelection();
        providerSelection.setAffiliatedSupplierNetwork("abc");
        providerSelection.setLineOfBusiness("'PA Medicare Assured'");
        providerSelections.add(providerSelection);
        pcpRequest.setProviderSelections(providerSelections);
        pcpRequest.setMemberId("123");
        pcpRequest.setReasonForPcpChange("new");

        ReflectionTestUtils.setField(healthTrioPcpRequestBuilder,"medicareDesc", "'PA Medicare Assured'");
        CrmRequest crmRequest2 = healthTrioPcpRequestBuilder.createCRMRequest(pcpRequest);
        Assertions.assertNotNull(crmRequest2);
    }
}
