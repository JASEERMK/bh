package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.usthealthproof.eplus.hrp.member.pcp.builder.HealthTrioPcpRequestBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.builder.HtCrmResponseBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.Auth;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.CrmRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
public class HealthTrioPcpServiceImplTest {
    @InjectMocks
    private HealthTrioPcpServiceImpl healthTrioPcpService;

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;
    @Mock
    private HealthTrioPcpRequestBuilder htRequestBuilder;

    @Mock
    CrmRequest crmRequest;
    @Mock
    CrmResponse crmResponse;
    @Mock
    HtCrmResponseBuilder htCrmResponseBuilder;
    @Mock
    PcpChangeResponse pcpChangeResponse;
    @Mock
    CrmResponseBody body;
    @Mock
    PcpChangeRequest pcpRequest;


    @Test
    void testCreateCaseInCRM() throws USTIntegrationException {

        PcpChangeRequest pcpRequest = new PcpChangeRequest();
        pcpRequest.setReasonForPcpChange("abc");
        pcpRequest.setMemberId("123");
        List<ProviderSelection> providerSelections = new ArrayList<>();
        ProviderSelection providerSelection = new ProviderSelection();
        providerSelection.setPractitionerRoleName("S00000321");
        providerSelection.setStartDate("2023-01-01");
        providerSelection.setEndDate("2023-01-01");
        providerSelection.setPractitionerId("asd");
        providerSelections.add(providerSelection);
        pcpRequest.setProviderSelections(providerSelections);
        Auth auth = new Auth();
        auth.setAccessToken("123");

        ReflectionTestUtils.setField(healthTrioPcpService, "accessUrl", "http//localhost:8080");
        ReflectionTestUtils.setField(healthTrioPcpService, "crmUrl", "http//localhost:8080");
//      mock for first webclient call
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(Auth.class)).thenReturn(Mono.just(auth));

        when(htRequestBuilder.createCRMRequest(pcpRequest)).thenReturn(crmRequest);
//      mock for second webclient call
        when(requestBodySpec.header(any(), any())).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(crmRequest)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(CrmResponse.class)).thenReturn(Mono.just(crmResponse));

        when(htCrmResponseBuilder.extractCrmResponse(any(), any())).thenReturn(body);

        when(body.getId()).thenReturn("12345");

        PcpChangeResponse response = healthTrioPcpService.createCaseInCRM(pcpRequest);
        assertNotNull(response);
        assertEquals(response.getCrmCaseId(),"12345" );
    }

    @Test
    void testCreateCaseInCRMWithException() throws USTIntegrationException {
        assertThrows(Exception.class, () -> {
            healthTrioPcpService.createCaseInCRM(pcpRequest);
        });
    }

}
