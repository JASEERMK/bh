package com.usthealthproof.eplus.hrp.member.pcp.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomNamespacePrefixMapperTest {

    @InjectMocks
    private CustomNamespacePrefixMapper customNamespacePrefixMapper;

    private final String nameSpacePrefix = "pcpPrefix";
    private final String nameSpace = "http://example.com/namespace";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(customNamespacePrefixMapper, "nameSpacePrefix", nameSpacePrefix);
        ReflectionTestUtils.setField(customNamespacePrefixMapper, "nameSpace", nameSpace);
    }

    @Test
    void testGetPreferredPrefix_MatchingNamespace() {
        String result = customNamespacePrefixMapper.getPreferredPrefix(nameSpace, "default", true);
        assertEquals(nameSpacePrefix, result);
    }

    @Test
    void testGetPreferredPrefix_NonMatchingNamespace() {
        String result = customNamespacePrefixMapper.getPreferredPrefix("http://different.com", "default", true);
        assertEquals("default", result);
    }
}
