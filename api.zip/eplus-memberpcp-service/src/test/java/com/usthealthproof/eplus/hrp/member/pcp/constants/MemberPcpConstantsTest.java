package com.usthealthproof.eplus.hrp.member.pcp.constants;

public class MemberPcpConstantsTest {

    public static final String ENDPOINT_MEMBERPCPCHANGE = "/v1/member/pcp/change";
    public static final String ENDPOINT_MEMBERPCPUPDATE = "/v1/member/pcpupdate";
}
