package com.usthealthproof.eplus.hrp.member.pcp.builder;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class PcpChangeRequestBuilderTest {

    @InjectMocks
    PcpChangeRequestBuilder pcpChangeRequestBuilder;
    @Mock
    EnrollmentType enrollmentType;

    @BeforeEach
    void setup() {

        enrollmentType = new EnrollmentType();
    }

    @Test
    void testCreateEnrollmentRequest() throws Exception {
        PcpChangeRequest pcpRequest = new PcpChangeRequest();
        List<ProviderSelection> providerSelections = new ArrayList<>();
        ProviderSelection providerSelection = new ProviderSelection();
        providerSelection.setPractitionerId("1234");
        providerSelection.setPractitionerRoleName("abc");
        providerSelection.setSupplierLocationId("234");
        providerSelection.setAffiliatedSupplierNetwork("qwe");
        providerSelections.add(providerSelection);
        pcpRequest.setProviderSelections(providerSelections);
        pcpRequest.setMemberId("123");
        pcpRequest.setReasonForPcpChange("abc");

        EnrollmentType result = pcpChangeRequestBuilder.createEnrollmentRequest(pcpRequest);

        Assertions.assertNotNull(result);
    }
}
