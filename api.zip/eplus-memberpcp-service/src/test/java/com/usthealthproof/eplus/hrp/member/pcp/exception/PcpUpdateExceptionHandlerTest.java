package com.usthealthproof.eplus.hrp.member.pcp.exception;

import com.usthealthproof.eplus.hrp.member.pcp.domain.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProblemDetails;
import com.usthealthproof.eplus.hrp.member.pcp.utils.APIUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class PcpUpdateExceptionHandlerTest {

    @InjectMocks
    PcpUpdateExceptionHandler pcpUpdateExceptionHandler;
    @Mock
    APIUtils apiUtils;
    @Mock
    private HttpHeaders headers;

    @Mock
    private MethodArgumentNotValidException ex;
    @Mock
    private WebRequest request;
    @Mock
    private BindingResult bindingResult;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRequestValidationExceptionHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = pcpUpdateExceptionHandler.requestValidationHandler(
                new RequestValidationException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testResponseValidationExceptionHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = pcpUpdateExceptionHandler.entityNotFoundHandler(
                new ResponseValidationException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testGlobalHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = pcpUpdateExceptionHandler.globalHandler(new Exception(), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testHandleMethodArgumentNotValid() {

        // Arrange
        List<FieldError> fieldErrors = new ArrayList<>();
        fieldErrors.add(new FieldError("objectName", "field", "defaultMessage"));

        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getFieldErrors()).thenReturn(fieldErrors);

        // Act
        ResponseEntity<Object> responseEntity = pcpUpdateExceptionHandler.handleMethodArgumentNotValid(ex, headers,
                HttpStatus.BAD_REQUEST, request);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void testRequestValidationExceptionWithNoArgument() {
        RequestValidationException exception = new RequestValidationException();
        assertNotNull(exception);
    }

    @Test
    public void testRequestValidationExceptionWithCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        RequestValidationException exception = new RequestValidationException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    public void testRequestValidationExceptionWithMessageAndCause() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        RequestValidationException exception = new RequestValidationException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    public void testResponseValidationExceptionWithNoArgument() {
        ResponseValidationException exception = new ResponseValidationException();
        assertNotNull(exception);
    }

    @Test
    public void testResponseValidationExceptionWithCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        ResponseValidationException exception = new ResponseValidationException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    public void testResponseValidationExceptionWithMessageAndCause() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        ResponseValidationException exception = new ResponseValidationException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    public void testUSTIntegrationExceptionWithNoArgument() {
        USTIntegrationException exception = new USTIntegrationException();
        assertNotNull(exception);
    }

    @Test
    public void testUSTIntegrationExceptionWithCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        USTIntegrationException exception = new USTIntegrationException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    public void testUSTIntegrationExceptionWithMessage() {
        // Arrange
        String message = "message";
        // Act
        USTIntegrationException exception = new USTIntegrationException(message);
        // Assert
        assertNotNull(exception);
    }

    @Test
    public void testUSTIntegrationExceptionWithMessageAndCause() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        USTIntegrationException exception = new USTIntegrationException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

}
