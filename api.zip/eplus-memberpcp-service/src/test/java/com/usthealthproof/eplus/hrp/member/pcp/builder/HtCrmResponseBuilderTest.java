package com.usthealthproof.eplus.hrp.member.pcp.builder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CompositeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class HtCrmResponseBuilderTest {

    @InjectMocks
    HtCrmResponseBuilder htCrmResponseBuilder;
    @Mock
    ObjectMapper mapper;
    @Mock
    Object object;
    @Mock
    PcpChangeResponse pcpChangeResponse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testExtractCrmResponse() throws USTIntegrationException {

        CrmResponse crmresponse = new CrmResponse();
        List<CompositeResponse> compositeResponses = new ArrayList<>();
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(0);
        compositeResponse.setBody(object);
        compositeResponse.setReferenceId("123");
        compositeResponses.add(compositeResponse);

        Object compositeBody = new Object();
        CrmResponseBody expectedBody = new CrmResponseBody();
        expectedBody.setId("crmCaseId");
        compositeResponse.setBody(compositeBody);
        compositeResponses.add(compositeResponse);
        crmresponse.setCompositeResponse(compositeResponses);

        when(mapper.convertValue(compositeBody, CrmResponseBody.class)).thenReturn(expectedBody);

        CrmResponseBody body = htCrmResponseBuilder.extractCrmResponse(pcpChangeResponse, crmresponse);
        assertNotNull(body);
        assertEquals("crmCaseId", body.getId());
    }

    @Test
    void testCheckSecondSubResponse_BodyIsArrayList() throws USTIntegrationException {
        // Arrange
        CrmResponse crmresponse = new CrmResponse();
        List<CompositeResponse> compositeResponse = new ArrayList<>();
        List<CrmResponseBody> bodyList = new ArrayList<>();
        CrmResponseBody crmResponseBody = new CrmResponseBody();
        crmResponseBody.setErrorCode("errorCode");
        crmResponseBody.setMessage("errorMessage");
        bodyList.add(crmResponseBody);
        CompositeResponse compositeResponse1 = new CompositeResponse();
        compositeResponse1.setHttpStatusCode(0);
        compositeResponse1.setBody(object);
        compositeResponse1.setReferenceId("123");
        compositeResponse.add(compositeResponse1);
        CrmResponseBody expectedBody = new CrmResponseBody();
        expectedBody.setId("crmCaseId");
        compositeResponse1.setBody(bodyList);
        compositeResponse.add(compositeResponse1);
        crmresponse.setCompositeResponse(compositeResponse);

        ArgumentCaptor<Object> bodyCaptor = ArgumentCaptor.forClass(Object.class);
        ArgumentCaptor<TypeReference<List<CrmResponseBody>>> typeReferenceCaptor = ArgumentCaptor.forClass(
                (Class<TypeReference<List<CrmResponseBody>>>) (Class<?>) TypeReference.class);

        when(mapper.convertValue(bodyCaptor.capture(), typeReferenceCaptor.capture())).thenReturn(bodyList);

        // Act & Assert
        USTIntegrationException exception = assertThrows(USTIntegrationException.class, () -> {
            htCrmResponseBuilder.extractCrmResponse(pcpChangeResponse, crmresponse);
        });
        assertEquals("errorMessage", exception.getMessage());
    }

}
