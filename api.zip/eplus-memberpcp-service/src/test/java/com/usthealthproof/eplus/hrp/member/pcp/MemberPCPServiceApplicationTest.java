package com.usthealthproof.eplus.hrp.member.pcp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class MemberPCPServiceApplicationTest {

    @Test
    void testMainClass() {
        MemberPCPServiceApplication.main(new String[] { "args" });
        assertTrue(true);

    }

}
