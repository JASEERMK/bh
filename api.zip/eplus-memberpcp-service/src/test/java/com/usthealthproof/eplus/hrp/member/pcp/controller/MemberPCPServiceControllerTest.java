package com.usthealthproof.eplus.hrp.member.pcp.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.hrp.member.pcp.constants.MemberPcpConstantsTest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.service.HealthTrioPcpServiceImpl;
import com.usthealthproof.eplus.hrp.member.pcp.service.PcpServiceImpl;
import com.usthealthproof.eplus.hrp.member.pcp.utils.APIUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(MemberPCPServiceController.class)
public class MemberPCPServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @MockBean
    PcpServiceImpl pcpService;
    @MockBean
    HealthTrioPcpServiceImpl htPcpService;
    @MockBean
    APIUtils apiUtils;
    PcpChangeResponse pcpChangeResponse = new PcpChangeResponse();
    PcpChangeRequest pcpRequest = new PcpChangeRequest();

    @BeforeEach
    void setup() {
        // pcpChange
        pcpChangeResponse.setCrmCaseId("123");
        pcpChangeResponse.setStatus("open");
        pcpChangeResponse.setCrmErrorCode("A123");
        pcpChangeResponse.setRequestId("B123");
        pcpChangeResponse.setCrmReferenceId("abc");
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for pcp change")
    void testChangePcp() throws Exception {
        // given - precondition or setup
        given(pcpService.submitPcpChangeRequest(any())).willReturn(pcpChangeResponse);
        // when - action or the behaviour
        ResultActions results = mockMvc.perform(
                post(MemberPcpConstantsTest.ENDPOINT_MEMBERPCPCHANGE).contentType(MediaType.APPLICATION_JSON)
                        .with(csrf().asHeader()).content(objectMapper.writeValueAsString(pcpRequest)));
        // then - verify the output
        results.andDo(print()).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for pcp update")
    void testUpdatePcp() throws Exception {
        // given - precondition or setup
        given(htPcpService.createCaseInCRM(any())).willReturn(pcpChangeResponse);
        // when - action or the behaviour
        ResultActions results = mockMvc.perform(
                post(MemberPcpConstantsTest.ENDPOINT_MEMBERPCPUPDATE).contentType(MediaType.APPLICATION_JSON)
                        .with(csrf().asHeader()).content(objectMapper.writeValueAsString(pcpRequest)));
        // then - verify the output
        results.andDo(print()).andExpect(status().isOk());
    }
}
