package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.usthealthproof.eplus.hrp.member.pcp.builder.HealthTrioPcpRequestBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.builder.HtCrmResponseBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.Auth;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.CrmRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import com.usthealthproof.eplus.hrp.member.pcp.utils.APIUtils;
import com.usthealthproof.eplus.hrp.member.pcp.validator.HealthTrioPCPValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@Slf4j
public class HealthTrioPcpServiceImpl implements HealthTrioPcpService {

	public static final String ERROR_MESSAGE = "Error Msg: ";

	@Value("${salesforce.url.login.path}")
	private String accessUrl;
	@Value("${salesforce.url.login.crmUrl}")
	private String crmUrl;

	@Autowired
	private WebClient webClient;

	@Autowired
	private HealthTrioPcpRequestBuilder htRequestBuilder;
	@Autowired
	private HtCrmResponseBuilder htCrmResponseBuilder;
	@Autowired
	private HealthTrioPCPValidator healthTrioPCPValidator;
	@Autowired
	private APIUtils apiUtils;

	@Override
	public PcpChangeResponse createCaseInCRM(PcpChangeRequest pcpRequest) {
		log.info("Inside createCaseInCRM() in HealthTrioPcpServiceImpl class");

		PcpChangeResponse pcpChangeResponse = new PcpChangeResponse();
		try {
			Auth auth;
			CrmResponse crmresponse;

			// ** 1) Retrieving ACCESS TOKEN
			long startServiceRequestTime1 = System.currentTimeMillis();
			auth = webClient.post()
					.uri(accessUrl)
					.retrieve().bodyToMono(Auth.class).block();
			long endServiceRequestTime1 = System.currentTimeMillis();
			log.info("Execution time of the external service - CRM Auth Token, in ms:: {}",
					endServiceRequestTime1 - startServiceRequestTime1);
			log.debug("Sales Force Access Token Details: {}", auth);
			HealthTrioPCPValidator.validateAccessResponse(auth);

			// ** 2) Sending REQUEST to CRM QUEUE
			CrmRequest crmRequest = htRequestBuilder.createCRMRequest(pcpRequest);
			log.debug("CRM Request : {}", crmRequest);
			long startServiceRequestTime2 = System.currentTimeMillis();
			log.info("CRM url {}", crmUrl);
			crmresponse = webClient.post()
					.uri(crmUrl)
					.header("Authorization", "Bearer "+auth.getAccessToken())
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(crmRequest)
					.retrieve().bodyToMono(CrmResponse.class).block();
			long endServiceRequestTime2 = System.currentTimeMillis();
			log.info(
					"Execution time of the external service - CRM API, in ms:: {} & Total Execution time of the external service, in ms:: {}",
					endServiceRequestTime2 - startServiceRequestTime2,
					(endServiceRequestTime1 - startServiceRequestTime1) + (endServiceRequestTime2 - startServiceRequestTime2));
			CrmResponseBody body = htCrmResponseBuilder.extractCrmResponse(pcpChangeResponse, crmresponse);

			pcpChangeResponse.setStatus("SUCCESS");
			pcpChangeResponse.setCrmCaseId(body.getId());

		} catch (USTIntegrationException e) {
			log.error("USTIntegrationException Caught : {} {}", e.getMessage(), e);
			pcpChangeResponse.setProblemDetails(
					apiUtils.createProblemDetails(MemberPcpConstants.EXCEPTION_MESSAGE, MemberPcpConstants.SUCCESS));
		} catch (Exception e) {
			log.error("Error occured for HealthTrio PCP Update. Exception caught in HealthTrioPcpServiceImpl class");
			throw e;
		}
		log.info("Successfully completed the case creation service call");
		return pcpChangeResponse;
	}
}
