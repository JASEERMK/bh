package com.usthealthproof.eplus.hrp.member.pcp.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = 8900398116821943151L;

	public ResponseValidationException() {
	}

	public ResponseValidationException(String message) {
		super(message);

	}

	public ResponseValidationException(Throwable cause) {
		super(cause);

	}

	public ResponseValidationException(String message, Throwable cause) {
		super(message, cause);
	}
}
