package com.usthealthproof.eplus.hrp.member.pcp.domain.crm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PcpDetails {

	@JsonProperty("UST_EPLUS__CIL_Provider_Key__c")
	private String providerKey;
}
