package com.usthealthproof.eplus.hrp.member.pcp.builder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CompositeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import com.usthealthproof.eplus.hrp.member.pcp.validator.HealthTrioPCPValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class HtCrmResponseBuilder {

	private ObjectMapper mapper = new ObjectMapper();

	public CrmResponseBody extractCrmResponse(PcpChangeResponse pcpChangeResponse, CrmResponse crmresponse)
			throws USTIntegrationException {
		log.info("Inside extractCrmResponse() in HtCrmResponseBuilder class");

		HealthTrioPCPValidator.validateCrmResponse(crmresponse);
		pcpChangeResponse.setCrmReferenceId(
				StringUtils.defaultIfBlank(crmresponse.getCompositeResponse().get(1).getReferenceId(), " "));
		log.debug("CRM Response: {}", crmresponse);
		checkSecondSubResponse(crmresponse.getCompositeResponse().get(1), pcpChangeResponse);
		CrmResponseBody body = mapper.convertValue(crmresponse.getCompositeResponse().get(1).getBody(),
				CrmResponseBody.class);
		HealthTrioPCPValidator.validateCrmCaseId(body);

		return body;
	}

	private void checkSecondSubResponse(CompositeResponse compositeResponse, PcpChangeResponse pcpChangeResponse)
			throws USTIntegrationException {

		HealthTrioPCPValidator.validateReferenceId(compositeResponse.getReferenceId());
		if (compositeResponse.getBody().getClass().getSimpleName().equalsIgnoreCase("ArrayList")) {

			List<CrmResponseBody> bodylist;
			bodylist = mapper.convertValue(compositeResponse.getBody(), new TypeReference<List<CrmResponseBody>>() {
			});
			HealthTrioPCPValidator.validateCrmCompositeResponse(bodylist);
			pcpChangeResponse.setCrmErrorCode(bodylist.get(0).getErrorCode());
			log.error("Error message from CRM : {}, ErrorCode: {}", bodylist.get(0).getMessage(),
					bodylist.get(0).getErrorCode());
			throw new USTIntegrationException(bodylist.get(0).getMessage());
		}
	}
}
