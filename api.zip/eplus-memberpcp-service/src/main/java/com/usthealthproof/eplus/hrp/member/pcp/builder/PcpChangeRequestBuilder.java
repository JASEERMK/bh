package com.usthealthproof.eplus.hrp.member.pcp.builder;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import jakarta.xml.bind.JAXBElement;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import com.healthedge.connector.schema.basetypes.CodeEntryInputType;
import com.healthedge.connector.schema.enrollmentsparse.ActionModeType;
import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.matchinput.MemberMatchInputType;
import com.healthedge.connector.schema.membershipsparse.MaintenanceCodeType;
import com.healthedge.connector.schema.membershipsparse.MembershipType;
import com.healthedge.connector.schema.membershipsparse.ObjectFactory;
import com.healthedge.connector.schema.membershipsparse.ProviderDateRangeType;
import com.healthedge.connector.schema.membershipsparse.ProviderSelectionType;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class PcpChangeRequestBuilder {

	@Value("${pcp.subscriptionAmendReason}")
	private String subscriptionAmendReason;

	@Value("${pcp.subscriptionAmendReasonCode}")
	private String subscriptionAmendReasonCode;

	private static final String DATE_FORMAT = "yyyy-MM-dd";


	public EnrollmentType createEnrollmentRequest(PcpChangeRequest pcpRequest)
			throws DatatypeConfigurationException, ParseException {
		log.info("Inside createEnrollmentRequest() in PcpChangeRequestBuilder class");

		final String asOfDate = "1800-01-01";
		EnrollmentType enrollmentType = new EnrollmentType();
		enrollmentType.setActionMode(ActionModeType.SPARSE);
		enrollmentType.setAsOfDate(getXMLGregorianCalendarDate(asOfDate));
		enrollmentType.setSendToWorkBasketIfExceptionsPresent(false);

		MembershipType membershipType = new MembershipType();
		membershipType.setMaintenanceTypeCode(MaintenanceCodeType.CHANGE);
		membershipType.setMaintenanceReasonCode(getCodeEntry());
		membershipType.setMemberMatchData(getMemberMatchData(pcpRequest));
		membershipType.setProviderSelections(setProviderSelections(pcpRequest));

		enrollmentType.getMember().add(membershipType);
		return enrollmentType;
	}

	private CodeEntryInputType getCodeEntry() {

		CodeEntryInputType codeEntry = new CodeEntryInputType();
		codeEntry.setCodeSetName(subscriptionAmendReason);
		codeEntry.setCodeEntry(subscriptionAmendReasonCode);
		return codeEntry;
	}

	private MembershipType.ProviderSelections setProviderSelections(PcpChangeRequest pcpRequest)
			throws DatatypeConfigurationException, ParseException {

		MembershipType.ProviderSelections providerSelections = new MembershipType.ProviderSelections();
		ProviderSelectionType providerSelectionType = new ProviderSelectionType();
		JAXBElement<String> providerRoleType = (new ObjectFactory()).createProviderSelectionTypeProviderRoleType("PCP");
		providerSelectionType.setProviderRoleType(providerRoleType);
		for (ProviderSelection selection : pcpRequest.getProviderSelections()) {
			ProviderDateRangeType providerDateRangesObj = new ProviderDateRangeType();
			providerDateRangesObj.setStartDate(getXMLGregorianCalendarDate(selection.getStartDate()));
			providerDateRangesObj.setEndDate(getXMLGregorianCalendarDate(selection.getEndDate()));
			ProviderDateRangeType.ProviderMatch providerMatchObj = new ProviderDateRangeType.ProviderMatch();
			if (StringUtils.isNotBlank(selection.getPractitionerId())) {
				ProviderDateRangeType.ProviderMatch.Practitioner practitioner = new ProviderDateRangeType.ProviderMatch.Practitioner();
				practitioner.setHccIdentificationNumber(selection.getPractitionerId());
				providerMatchObj.setPractitioner(practitioner);
			}
			if (StringUtils.isNotBlank(selection.getPractitionerRoleName())) {
				ProviderDateRangeType.ProviderMatch.PractitionerRole role = new ProviderDateRangeType.ProviderMatch.PractitionerRole();
				role.setRoleName(selection.getPractitionerRoleName());
				providerMatchObj.setPractitionerRole(role);
			}
			if (StringUtils.isNotBlank(selection.getSupplierLocationId())) {
				ProviderDateRangeType.ProviderMatch.SupplierLocation location = new ProviderDateRangeType.ProviderMatch.SupplierLocation();
				location.setHccIdentificationNumber(selection.getSupplierLocationId());
				providerMatchObj.setSupplierLocation(location);
			}
//			Adding new field mapping for affiliatedSupplierNetwork
			if (StringUtils.isNotBlank(selection.getAffiliatedSupplierNetwork())) {
				ProviderDateRangeType.ProviderMatch.AffiliatedSupplierNetwork affiliatedSupplierNetwork = new ProviderDateRangeType.ProviderMatch.AffiliatedSupplierNetwork();
				affiliatedSupplierNetwork.setHccIdentificationNumber(selection.getAffiliatedSupplierNetwork());
				providerMatchObj.setAffiliatedSupplierNetwork(affiliatedSupplierNetwork);
			}

			providerDateRangesObj.setProviderMatch(providerMatchObj);
			providerSelectionType.getProviderDateRanges().add(providerDateRangesObj);
		}
		providerSelections.getProviderSelection().add(providerSelectionType);
		return providerSelections;
	}

	private MemberMatchInputType getMemberMatchData(PcpChangeRequest pcpRequest) {

		MemberMatchInputType memberMatchData = new MemberMatchInputType();
		memberMatchData.setDefinitionName(pcpRequest.getMemberMatchDefinition());
		if (StringUtils.isNotBlank(pcpRequest.getMemberId()) && !pcpRequest.getMemberId().trim().equals("0")) {
			memberMatchData.setId(pcpRequest.getMemberId());
		}
		return memberMatchData;
	}

	public XMLGregorianCalendar getXMLGregorianCalendarDate(String stringDate)
			throws ParseException, DatatypeConfigurationException {

		if (stringDate == null || StringUtils.isBlank(stringDate)) {
			return null;
		}
		XMLGregorianCalendar xmlCalender = null;
		try {
			GregorianCalendar calender = new GregorianCalendar();
			DateFormat format = new SimpleDateFormat(DATE_FORMAT);
			Date date = format.parse(stringDate);
			calender.setTime(date);
			xmlCalender = DatatypeFactory.newInstance().newXMLGregorianCalendar(calender);
			xmlCalender.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
			// To remove Time information
			xmlCalender.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
					DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
		} catch (ParseException parseException) {
			log.error("ParseException caught in PcpChangeRequestBuilder class");
			throw parseException;
		} catch (DatatypeConfigurationException dataTypeConfigException) {
			log.error("DatatypeConfigurationException caught in PcpChangeRequestBuilder class");
			throw dataTypeConfigException;
		}
		return xmlCalender;
	}
}