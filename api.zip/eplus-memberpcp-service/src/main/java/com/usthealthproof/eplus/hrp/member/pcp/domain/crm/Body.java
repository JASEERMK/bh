package com.usthealthproof.eplus.hrp.member.pcp.domain.crm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Body {

	@JsonProperty("Type")
	private String type;

	@JsonProperty("Subject")
	private String subject;

	@JsonProperty("Origin")
	private String origin;

	@JsonProperty("Priority")
	private String priority;

	@JsonProperty("Description")
	private String description;

	@JsonProperty("UST_EPLUS__New_PCP_Start_Date__c")
	private String startDate;

	@JsonProperty("UST_EPLUS__Department__c")
	private String department;

	@JsonProperty("RecordTypeId")
	private String recordTypeId;

	@JsonProperty("Account")
	private Account account;

	@JsonProperty("UST_EPLUS__New_PCP_Name__r")
	private PcpDetails pcpName;
}
