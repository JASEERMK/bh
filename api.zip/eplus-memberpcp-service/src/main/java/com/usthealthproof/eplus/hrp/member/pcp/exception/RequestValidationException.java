package com.usthealthproof.eplus.hrp.member.pcp.exception;

public class RequestValidationException extends RuntimeException {

	private static final long serialVersionUID = 8900398116821943151L;

	public RequestValidationException() {
	}

	public RequestValidationException(String message) {
		super(message);

	}

	public RequestValidationException(Throwable cause) {
		super(cause);

	}

	public RequestValidationException(String message, Throwable cause) {
		super(message, cause);
	}
}
