package com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompositeResponse {

	private Object body;
	private int httpStatusCode;
	private String referenceId;
}
