package com.usthealthproof.eplus.hrp.member.pcp.domain.crm;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CrmRequest {

	private boolean allOrNone = true;
	private List<CompositeRequest> compositeRequest;
}
