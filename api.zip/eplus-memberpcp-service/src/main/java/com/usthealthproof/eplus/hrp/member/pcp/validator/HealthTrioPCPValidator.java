package com.usthealthproof.eplus.hrp.member.pcp.validator;

import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.Auth;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse.CrmResponseBody;
import com.usthealthproof.eplus.hrp.member.pcp.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.pcp.exception.USTIntegrationException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.isAllBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;
@Slf4j
@Component
public class HealthTrioPCPValidator {

	private HealthTrioPCPValidator() {

	}

	/**
	 * Validation of PCP Change request header from HealthTrio.
	 */
	public static void validateHeader(HttpServletRequest httpRequest) {
		log.info("Inside validateHeader() in HealthTrioPCPValidator class");

		if (isBlank(httpRequest.getHeader(MemberPcpConstants.CORRELATIONID))) {
			throw new RequestValidationException(
					"Missing CorrelationId in request header coming from HealthTrio Potral");
		}
	}

	/**
	 * Validation CRM access token details response .
	 * 
	 * @throws USTIntegrationException
	 */
	public static void validateAccessResponse(Auth auth) throws USTIntegrationException {
		log.info("Inside validateAccessResponse() in HealthTrioPCPValidator class");

		if (Objects.isNull(auth) || isBlank(auth.getAccessToken())) {
			throw new USTIntegrationException("Access token from CRM is Empty or Null");
		}
	}

	/**
	 * Validation of response from CRM and ReferenceId in CRM SubResponse2.
	 */
	public static void validateCrmResponse(CrmResponse crmresponse) throws USTIntegrationException {
		log.info("Inside validateCrmResponse() in HealthTrioPCPValidator class");

		if (Objects.isNull(crmresponse) || CollectionUtils.isEmpty(crmresponse.getCompositeResponse())) {
			throw new USTIntegrationException("Response from CRM is Empty or Null");
		}
		if (Objects.isNull(crmresponse.getCompositeResponse().get(1))) {
			throw new USTIntegrationException("CRM subresponse is Empty or Null");
		}
		if (Objects.isNull(crmresponse.getCompositeResponse().get(1).getBody())) {
			throw new USTIntegrationException("Record body details is missing in response from CRM");
		}
	}

	/**
	 * Validation of CaseId in CRM SubResponse2 - for SUCCESS response.
	 */
	public static void validateCrmCaseId(CrmResponseBody body) throws USTIntegrationException {
		log.info("Inside validateCrmCaseId() in HealthTrioPCPValidator class");

		if (isBlank(body.getId())) {
			throw new USTIntegrationException("Record CaseId is missing in response from CRM");
		}
	}

	/**
	 * Validation of ReferenceId in CRM SubResponse2 - for FAILURE response.
	 * 
	 * @throws USTIntegrationException
	 */
	public static void validateReferenceId(String referenceId) throws USTIntegrationException {
		log.info("Inside validateReferenceId() in HealthTrioPCPValidator class");
		if (isBlank(referenceId)) {
			throw new USTIntegrationException("ReferenceId is missing in failure response from CRM");
		}
	}

	/**
	 * Validation of SubResponse2 of Composite Response from CRM, for failure
	 * scenario request.
	 */
	public static void validateCrmCompositeResponse(List<CrmResponseBody> bodylist) throws USTIntegrationException {
		log.info("Inside validateCrmCompositeResponse() in HealthTrioPCPValidator class");

		if (CollectionUtils.isEmpty(bodylist)) {
			throw new USTIntegrationException("Error details from CRM is Empty or Null");
		}
		if (Objects.isNull(bodylist.get(0))
				|| isAllBlank(bodylist.get(0).getErrorCode(), bodylist.get(0).getMessage())) {
			throw new USTIntegrationException("CRM subresponse error details is Empty or Null");
		}

	}

}
