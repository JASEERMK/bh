package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;

import javax.xml.datatype.DatatypeConfigurationException;
import java.text.ParseException;

public interface PcpService {

	public PcpChangeResponse submitPcpChangeRequest(PcpChangeRequest pcpRequest) throws DatatypeConfigurationException,
			ParseException;

}