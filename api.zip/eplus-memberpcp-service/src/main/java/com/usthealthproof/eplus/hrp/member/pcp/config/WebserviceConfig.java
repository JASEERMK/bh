package com.usthealthproof.eplus.hrp.member.pcp.config;

import com.usthealthproof.eplus.hrp.member.pcp.utils.CustomNamespacePrefixMapper;
import jakarta.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;

import java.time.Duration;
import java.util.Collections;


@Configuration
@Slf4j
public class WebserviceConfig {

    @Value("${pcp.service.address}")
    private String address;
    @Value("${pcp.service.connectionTimeout}")
    private String connectionTimeout;
    @Value("${pcp.service.readTimeout}")
    private String readTimeout;
    @Value("${pcp.service.contextPackage}")
    private String context;
    @Value("${pcp.service.responseContextPackage}")
    private String responseContext;
    @Value("${pcp.service.nameSpaceMapper}")
    private String nameSpaceMapper;

    @Autowired
    CustomNamespacePrefixMapper customNamespacePrefixMapper;

    @Bean
    public Jaxb2Marshaller marshaller() {

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPaths(context, responseContext);
        marshaller.setMarshallerProperties(Collections.singletonMap(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE));

        // Set the custom namespace prefix mapper
        marshaller.setMarshallerProperties(
                Collections.singletonMap(nameSpaceMapper, customNamespacePrefixMapper)
        );
        return marshaller;
    }

    @Bean
    public ClientInterceptor customLoggingInterceptor() {
        return new CustomLoggingInterceptor();
    }

    @Bean(name = "enrollmentSparsePortType")
    public WebServiceTemplate webServiceTemplate(Jaxb2Marshaller marshaller,MemberPCPServiceConfig memberPCPServiceConfig) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        try {
            webServiceTemplate.setMarshaller(marshaller);
            webServiceTemplate.setUnmarshaller(marshaller);
            webServiceTemplate.setDefaultUri(address);
            memberPCPServiceConfig.setReadTimeout(Duration.ofMillis(Long.parseLong(readTimeout)));
            memberPCPServiceConfig.setConnectionTimeout(Duration.ofMillis(Long.parseLong(connectionTimeout)));
            webServiceTemplate.setInterceptors(new ClientInterceptor[]{customLoggingInterceptor()});
            webServiceTemplate.setMessageSender(memberPCPServiceConfig);

        }catch (Exception e) {
            log.error("Exception in WebserviceConfig:: ", e);
        }
        return  webServiceTemplate;
    }

}