package com.usthealthproof.eplus.hrp.member.pcp.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.Valid;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * ProblemDetails
 */
@Data
@Schema(description = "Problem Details class")
public class ProblemDetails implements Serializable {
	@Schema(description = "Error informations")
	@Valid
	private List<String> errors;
	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status = "";

	public ProblemDetails errors(List<String> errors) {
		this.errors = errors;
		return this;
	}
}
