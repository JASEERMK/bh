package com.usthealthproof.eplus.hrp.member.pcp.dao;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparse.ObjectFactory;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import jakarta.xml.bind.JAXBElement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;
import java.util.Objects;

@Repository
@Slf4j
public class PcpChangeDAOImpl implements PcpChangeDAO {

	@Value("${pcp.service.nameSpaceUri}")
	private String nameSpace;
	@Autowired
	@Qualifier("enrollmentSparsePortType")
	WebServiceTemplate webServiceTemplate;

	public EnrollmentResponseType changePcp(
			EnrollmentType enrollmentType) {
		log.info("Inside changePcp() in DAO class");
		EnrollmentResponseType pcpChangeResponse = null;
		try {
			long startServiceRequestTime = System.currentTimeMillis();

			// Create the JAXBElement for the request
			JAXBElement<EnrollmentType> enrollmentTypeJAXBElement = new JAXBElement<>(
					new QName(nameSpace, "enrollment"),
					EnrollmentType.class,
					enrollmentType
			);
			// Send the SOAP request and receive the response
			JAXBElement<EnrollmentResponseType> changePcpResponse =
					(JAXBElement<EnrollmentResponseType>) webServiceTemplate.marshalSendAndReceive(
							enrollmentTypeJAXBElement,
							new SoapActionCallback("")
					);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the external service - HRP WS call in ms: {}",
					endServiceRequestTime - startServiceRequestTime);
			if(Objects.nonNull(changePcpResponse)){
				pcpChangeResponse = changePcpResponse.getValue();
			}
		} catch (SoapFaultClientException sfex) {
			log.error("SOAP fault during PCP change request: {}", sfex.getMessage(), sfex);
			throw sfex;
		} catch (IllegalArgumentException iae) {
			log.error("Invalid argument during PCP change request: {}", iae.getMessage(), iae);
			throw iae;
		} catch (Exception e) {
			log.error("Exception during PCP change request: {}", e.getMessage(), e);
			throw e;
		}
		return pcpChangeResponse;
	}
}
