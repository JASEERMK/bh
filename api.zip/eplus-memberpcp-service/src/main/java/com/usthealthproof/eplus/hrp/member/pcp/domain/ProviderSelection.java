package com.usthealthproof.eplus.hrp.member.pcp.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(description = "Wrapper Object for holding the PCP information")
public class ProviderSelection {

	@Schema(description = "StartDate of PCP relationship, expected format is yyyy-MM-dd", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "yyyy-MM-dd")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: startDate is not in valid format")
	private String startDate;

	@Schema(description = "End date of PCP relationship, expected format is yyyy-MM-dd, mandatory for PCP termination", defaultValue = "yyyy-MM-dd")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: endDate is not in valid format")
	private String endDate;

	@Schema(description = "Practitioner HCC ID, mandatory for Medicaid", defaultValue = "practitionerId")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: practitionerId is not in valid format")
	private String practitionerId;

	@Schema(description = "Practitioner RoleName in HRP, mandatory for Medicaid", defaultValue = "practitionerRoleName")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: practitionerRoleName is not in valid format")
	private String practitionerRoleName;

	@Schema(description = "Supplier Location HCC ID in HRP, mandatory for Medicare", defaultValue = "supplierLocationId")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: supplierLocationId is not in valid format")
	private String supplierLocationId;

	@Schema(description = "Affiliated Supplier Network Hcc ID", defaultValue = "affiliatedSupplierNetwork")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: affiliatedSupplierNetwork is not in valid format")
	private String affiliatedSupplierNetwork;

	@Schema(description = "Line of Business: 'PA Medicare Assured', 'PA Medicaid' , used for portal service", hidden = true)
	private String lineOfBusiness;

}
