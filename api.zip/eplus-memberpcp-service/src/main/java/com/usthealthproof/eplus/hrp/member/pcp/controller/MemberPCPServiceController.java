package com.usthealthproof.eplus.hrp.member.pcp.controller;

import com.usthealthproof.eplus.hrp.member.pcp.service.HealthTrioPcpService;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.hrp.member.pcp.domain.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.service.PcpService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
@RequestMapping("/v1/member")
@RestController
@Slf4j
@Tag(name = "Member PCP Update Service")
@SecurityRequirement(name = "Member PCP Service")
public class MemberPCPServiceController {

	@Autowired
	private PcpService pcpService;

	@Autowired
	private HealthTrioPcpService htPcpService;

	@PostMapping(value = "/pcp/change", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "Member PCP Update Service", description = "Member PCP Service is used to update a member's current PCP with a new PCP. This service enables the provision to provide existing and new PCP information, where the existing PCP in HRP will be terminated and updated with the new PCP. In addition, the service supports the PCP update with only new PCP details in the request. The mandatory fields required in input request are member ID and start date, however other fields may also be required depending on the request nature. If updating a PCP with practitioner role, then practitioner ID and practitioner role name are the required fields. And if the PCP is updating with the supplier location, then only supplier location is required along with the mandatory fields. If the practitioner ID, practitioner role name, and supplier location ID are all null or empty, a validation error will result. Also, the affiliated supplier network parameter is entirely optional, and it is applicable only if updating the PCP with practitioner role.", method = "POST", responses = {
			@ApiResponse(responseCode = "200", description = "PCP Change Response", content = {
					@Content(schema = @Schema(implementation = PcpChangeResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "408", description = "Request Timeout", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public PcpChangeResponse changePCP(
			@Parameter(description = "PCP Info with Member details", required = true) @Valid @RequestBody PcpChangeRequest pcpRequest,
			HttpServletRequest httpRequest, HttpServletResponse httpResponse) throws Exception {
		log.info("Inside changePCP() of controller class");
		log.debug("Request received in changePCP() of controller class: {}", pcpRequest);
		return pcpService.submitPcpChangeRequest(pcpRequest);
	}


	@Hidden
	@PostMapping(value = "/pcpupdate", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "Member PCP Service is used to change the Member PCP in HRP.", description = "This method changes the PCP of given member. API checks all the necessary business validations before changing the PCP.", method = "POST", responses = {
			@ApiResponse(responseCode = "200", description = "PCP Change Response", content = {
					@Content(schema = @Schema(implementation = PcpChangeResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public PcpChangeResponse pcpUpdate(
			@Parameter(name = "PCP Info with Member details", required = true) @RequestBody PcpChangeRequest pcpRequest, HttpServletResponse httpResponse) {
		log.info("Inside pcpUpdate() of controller class");
		log.debug("Request received in pcpUpdate() in controller class: {}", pcpRequest);
		return htPcpService.createCaseInCRM(pcpRequest);
	}
}
