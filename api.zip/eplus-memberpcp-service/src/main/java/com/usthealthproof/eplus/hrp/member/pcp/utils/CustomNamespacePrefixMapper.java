package com.usthealthproof.eplus.hrp.member.pcp.utils;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jaxb.runtime.marshaller.NamespacePrefixMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CustomNamespacePrefixMapper extends NamespacePrefixMapper {

    @Value("${pcp.service.nameSpacePrefix}")
    private String nameSpacePrefix;
    @Value("${pcp.service.nameSpaceUri}")
    private String nameSpace;
    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        if (StringUtils.equalsIgnoreCase(nameSpace,namespaceUri)) {
            return nameSpacePrefix;
        }
        return suggestion;
    }
}