package com.usthealthproof.eplus.hrp.member.pcp.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
@Schema(description = "Object wrapping Response of Member PCP Change API call")
public class PcpChangeResponse {

	@Schema(description = "Structure for error details, if any",hidden = true)
	private ProblemDetails problemDetails;

	@Schema(description = "Request Id")
	private String requestId;

	@Schema(description = "Unique Reference Id from CRM,used for portal service",hidden = true)
	private String crmReferenceId;

	@Schema(description = "Error code sent from CRM,used for portal service",hidden = true)
	private String crmErrorCode;

	@Schema(description = "Response Status: SUCCESS/FAILURE/ERROR,used for portal service",hidden = true)
	private String status;

	@Schema(description = "Record Case Id created in CRM,used for portal service",hidden = true)
	private String crmCaseId;

}
