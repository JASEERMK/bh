
package com.usthealthproof.eplus.hrp.member.pcp.dao;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;

public interface PcpChangeDAO {
	EnrollmentResponseType changePcp(EnrollmentType enrollmentType);
}