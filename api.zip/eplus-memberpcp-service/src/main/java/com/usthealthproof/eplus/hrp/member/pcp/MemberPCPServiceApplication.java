package com.usthealthproof.eplus.hrp.member.pcp;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.TimeZone;

@SpringBootApplication
@SecurityScheme(name = "Member PCP Service", scheme = "bearer", type = SecuritySchemeType.HTTP , in = SecuritySchemeIn.HEADER)
public class MemberPCPServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemberPCPServiceApplication.class, args);
	}

	@Value("${application.timeZone}")
	private String timeZone;

	@PostConstruct
	public void init() {
		// Setting Spring Boot SetTimeZone
		TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
	}
}