package com.usthealthproof.eplus.hrp.member.pcp.exception;

public class USTIntegrationException extends Exception {

	private static final long serialVersionUID = 1L;

	public USTIntegrationException() {

	}

	public USTIntegrationException(String message) {
		super(message);

	}

	public USTIntegrationException(Throwable cause) {
		super(cause);

	}

	public USTIntegrationException(String message, Throwable cause) {
		super(message, cause);
	}

}
