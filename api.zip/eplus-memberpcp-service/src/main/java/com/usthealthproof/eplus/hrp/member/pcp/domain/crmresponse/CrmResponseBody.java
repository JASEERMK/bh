package com.usthealthproof.eplus.hrp.member.pcp.domain.crmresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CrmResponseBody {

	private String id;
	private String errorCode;
	private String message;
	private List<Object> fields;
}