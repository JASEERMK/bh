package com.usthealthproof.eplus.hrp.member.pcp.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data
@Schema(description = "Request object wrapping Info for Member PCP Change. For member matching need to pass the info according to the HRP implementation using")
public class PcpChangeRequest {

	@Schema(description = "Member Hcc ID",requiredMode = Schema.RequiredMode.REQUIRED,defaultValue = "memberId")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: memberId is not in valid format")
	private String memberId;

	@Valid
	@Schema(description = "Details related to the current and updated PCP")
	private List<ProviderSelection> providerSelections;

	@Schema(hidden = true)
	private String memberMatchDefinition;

	@Schema(description = "Reason for PCP Change, used for portal service",hidden = true)
	private String reasonForPcpChange;
	@Schema(description = "Correlation Id",hidden = true)
	@JsonProperty("correlationId")
	private String correlationId;

	/**
	 * toString() provided by the @Data wont be this detailed.
	 */
	@Override
	public String toString() {
		StringBuilder toStringBuilder = new StringBuilder();
		toStringBuilder.append("PcpChangeRequest [memberId=").append(this.memberId);

		if (CollectionUtils.isEmpty(providerSelections)) {
			return toStringBuilder.toString() + ", providerSelections=[] ]";
		}
		StringBuilder builder = new StringBuilder();
		for (ProviderSelection selection : providerSelections) {
			if (builder.length() > 0) {
				builder.append(", ");
			}
			builder.append(selection.toString());
		}
		builder.append(" ]");
		toStringBuilder.append(", providerSelections=").append(builder);
		return toStringBuilder.toString();
	}
}
