package com.usthealthproof.eplus.hrp.member.pcp.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.healthedge.connector.schema.basetypes.ErrorInfoType;
import com.healthedge.connector.schema.basetypes.ErrorType;
import com.healthedge.connector.schema.basetypes.ErrorsType;
import com.healthedge.connector.schema.basetypes.TransactionExceptionType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.healthedge.connector.schema.enrollmentsparseresponse.MemberResponseType;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import com.usthealthproof.eplus.hrp.member.pcp.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.pcp.exception.ResponseValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections4.CollectionUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.*;

/**
 * Class to validate PCP change request and response.
 * 
 * @author 146291
 *
 */
@Slf4j
public class PCPChangeValidator {

	private PCPChangeValidator() {

	}
	/**
	 * Validate request.
	 * 
	 * @param pcpRequest
	 * @throws RequestValidationException
	 * @throws JsonProcessingException
	 */
	public static void validatePcpChangeRequest(PcpChangeRequest pcpRequest) throws RequestValidationException {
		log.info("Inside validatePcpChangeRequest() in PCPChangeValidator class");

		validateBasicRequest(pcpRequest);
		DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		for (ProviderSelection selection : pcpRequest.getProviderSelections()) {
			validateProviderSelection(selection, dateTimeFormat);
		}
	}
	private static void validateBasicRequest(PcpChangeRequest pcpRequest) throws RequestValidationException {

		if (Objects.isNull(pcpRequest) || CollectionUtils.isEmpty(pcpRequest.getProviderSelections())) {
			throw new RequestValidationException("Request Fields are Empty or Null");
		}
		if (isBlank(pcpRequest.getMemberId())) {
			throw new RequestValidationException("MemberId cannot be Empty or Null");
		}
	}
	private static void validateProviderSelection(ProviderSelection selection, DateTimeFormatter dateTimeFormat)
			throws RequestValidationException {

		if (isBlank(selection.getStartDate())) {
			throw new RequestValidationException("Request Provider 'startDate' Field is mandatory and is Empty or Null");
		}

		try {
			if (isNotBlank(selection.getEndDate())) {
				LocalDate.parse(selection.getEndDate(), dateTimeFormat);
			}
			LocalDate.parse(selection.getStartDate(), dateTimeFormat);// already empty checked
		} catch ( Exception e) {
			throw new RequestValidationException(
					"Enter valid date format for startDate and endDate, Format should be 'yyyy-MM-dd'");
		}

		validateProviderFields(selection);
	}
	private static void validateProviderFields(ProviderSelection selection) throws RequestValidationException {

		if (isAllBlank(selection.getPractitionerId(), selection.getPractitionerRoleName(),
				selection.getSupplierLocationId())) {
			throw new RequestValidationException("Provider value fields are Empty or Null");
		} else if ((isNotBlank(selection.getPractitionerId()) && isBlank(selection.getPractitionerRoleName()))
				|| (isBlank(selection.getPractitionerId()) && isNotBlank(selection.getPractitionerRoleName()))) {
			throw new RequestValidationException(
					"Either Practitioner HCC Id or Practitioner Role name is Empty or Null");
		}
	}

	/**
	 * Validate response.
	 * 
	 * @param enrollmentSparseResponseType
	 * @throws ResponseValidationException
	 */
	public static void validatePcpChangeResponse(EnrollmentResponseType enrollmentSparseResponseType)
			throws ResponseValidationException {
		log.info("Inside validatePcpChangeResponse() in PCPChangeValidator class");

//		Checking for the status of the transaction is SUCCESS or not
		if (!StringUtils.equalsIgnoreCase("SUCCESS", enrollmentSparseResponseType.getStatus().value())) {
			log.info("The transaction status from HRP is not SUCCESS, but it is : {}",
					enrollmentSparseResponseType.getStatus().value());
			ErrorsType errors = enrollmentSparseResponseType.getErrors();
			if (errors != null && CollectionUtils.isNotEmpty(errors.getError())) {
				ErrorInfoType error = errors.getError().get(0);
				ErrorType errorType = error.getErrorType();
				throw new ResponseValidationException(
						"Error Type: " + errorType + ", Error Message: " + error.getMessage());
			}
			if (isExceptionsAvailable(enrollmentSparseResponseType)) {
				List<TransactionExceptionType> exceptionTypes = enrollmentSparseResponseType.getMember().get(0)
						.getTransactionInformation().getExceptions();
				for (TransactionExceptionType transactionExceptionType : exceptionTypes) {
					if (!equalsIgnoreCase("Warn", transactionExceptionType.getExceptionType().value())) {
						log.info("Exception Type is: {}", transactionExceptionType.getExceptionType().value());
						throw new ResponseValidationException("Error Type: " + transactionExceptionType.getPolicyName()
								+ ", Error Message: " + transactionExceptionType.getMessageDescription());
					}
				}
			}
		}
		log.info("The transaction status from HRP is: {}", enrollmentSparseResponseType.getStatus().value());
	}

	/**
	 * Check if any exceptions are available under member tag.
	 * 
	 * @param enrollmentSparseResponseType
	 * @return boolean
	 */
	private static boolean isExceptionsAvailable(EnrollmentResponseType enrollmentSparseResponseType) {

		if (CollectionUtils.isEmpty(enrollmentSparseResponseType.getMember())) {
			return false;
		}
		MemberResponseType member = enrollmentSparseResponseType.getMember().get(0);
		if (member == null || member.getTransactionInformation() == null) {
			return false;
		}
        return !CollectionUtils.isEmpty(member.getTransactionInformation().getExceptions())
                && member.getTransactionInformation().getExceptions().get(0) != null;
    }
}
