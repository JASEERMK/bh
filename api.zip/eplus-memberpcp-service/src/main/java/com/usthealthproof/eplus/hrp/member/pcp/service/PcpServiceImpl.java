package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.healthedge.connector.schema.enrollmentsparse.EnrollmentType;
import com.healthedge.connector.schema.enrollmentsparseresponse.EnrollmentResponseType;
import com.usthealthproof.eplus.hrp.member.pcp.builder.PcpChangeRequestBuilder;
import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.dao.PcpChangeDAO;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;
import com.usthealthproof.eplus.hrp.member.pcp.validator.PCPChangeValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.xml.datatype.DatatypeConfigurationException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Service
@Slf4j
public class PcpServiceImpl implements PcpService {

	@Autowired
	private PcpChangeDAO pcpChangeDAO;
	@Autowired
	private PcpChangeRequestBuilder pcpChangeRequestBuilder;
	@Value("${pcp.memberMatchDefinition}")
	private String memberMatchDefinition;

	@Override
	public PcpChangeResponse submitPcpChangeRequest(PcpChangeRequest pcpRequest)
			throws DatatypeConfigurationException, ParseException {
		log.info("Inside submitPcpChangeRequest() in PcpServiceImpl class");

		PcpChangeResponse pcpChangeResponse = new PcpChangeResponse();

		DateFormat dateFormat = new SimpleDateFormat("-ddMMyyyy-HHmmssSSS-");
		String reqId = "PcpChange " + dateFormat.format(new Date()) + UUID.randomUUID();
		try {
			PCPChangeValidator.validatePcpChangeRequest(pcpRequest);
			pcpRequest.setMemberMatchDefinition(memberMatchDefinition);
			EnrollmentType enrollmentType = pcpChangeRequestBuilder.createEnrollmentRequest(pcpRequest);
			long startServiceRequestTime = System.currentTimeMillis();
			EnrollmentResponseType enrollmentSparseResponseType = pcpChangeDAO.changePcp(enrollmentType);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the external service - HRP WS call, in ms: {}",
					endServiceRequestTime - startServiceRequestTime);
			log.debug(MemberPcpConstants.RESPONSE, enrollmentSparseResponseType);
			PCPChangeValidator.validatePcpChangeResponse(enrollmentSparseResponseType);
			pcpChangeResponse.setRequestId(reqId);
		} catch (ParseException parseException) {
			log.error("ParseException caught in PcpServiceImpl class");
			throw parseException;
		} catch (DatatypeConfigurationException dataTypeConfigException) {
			log.error("DatatypeConfigurationException caught in PcpServiceImpl class");
			throw dataTypeConfigException;
		}
		log.info("Successfully updated the PCP");
		return pcpChangeResponse;
	}
}
