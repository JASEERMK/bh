package com.usthealthproof.eplus.hrp.member.pcp.service;

import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeResponse;

public interface HealthTrioPcpService {

	public PcpChangeResponse createCaseInCRM(PcpChangeRequest pcpRequest);

}
