package com.usthealthproof.eplus.hrp.member.pcp.exception;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProblemDetails;
import com.usthealthproof.eplus.hrp.member.pcp.utils.APIUtils;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class PcpUpdateExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	private APIUtils apiUtils;

	/**
	 * Exception Handler for invalid request types
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> requestValidationHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException Caught : {} {} {}", ex.getLocalizedMessage(), ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getLocalizedMessage(), MemberPcpConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * handle specific exception
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ResponseValidationException.class)
	public final ResponseEntity<ErrorResponse> entityNotFoundHandler(ResponseValidationException ex, WebRequest request) {
		log.error("ResponseValidationException Caught : {} {} {}", ex.getLocalizedMessage(), ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getMessage(), MemberPcpConstants.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);

	}

	/**
	 * handle global exception
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : {} {}", ex.getMessage(), ex);

		if (StringUtils.containsAnyIgnoreCase(ex.getMessage(), "Could not receive Message", "Could not send Message",
				"Connection reset", "Read timed out")
				|| StringUtils.containsAnyIgnoreCase(ex.toString(), "Connection reset", "Read timed out")) {
			return new ResponseEntity<>(setErrorDetails(MemberPcpConstants.TIMEOUT_EXCEPTION_MESSAGE, MemberPcpConstants.FAILURE),
					HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<>(setErrorDetails(MemberPcpConstants.EXCEPTION_MESSAGE, MemberPcpConstants.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Exception Handler to handle Method Argument Validation exception
	 *
	 * @param ex
	 * @param headers
	 * @param status
	 * @param request
	 * @return
	 */
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		log.error("MethodArgumentNotValidException Caught : {} {}", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetailsAsList(ex.getBindingResult().getFieldErrors(), MemberPcpConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Common Method for the error details
	 * 
	 * @param fieldErrors
	 * @param status
	 */
	public ErrorResponse setErrorDetailsAsList(List<FieldError> fieldErrors, String status) {
		log.info("Inside setErrorDetailsAsList()");
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		ArrayList<String> errorList = new ArrayList<>();
		for (FieldError fieldError : fieldErrors) {
			errorList.add(fieldError.getDefaultMessage());
		}
		problemDetails.setErrors(errorList);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

	/**
	 * Common Method for the Util function for setting the error details
	 */
	private ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(message, status));
		return errorResponse;
	}
}
