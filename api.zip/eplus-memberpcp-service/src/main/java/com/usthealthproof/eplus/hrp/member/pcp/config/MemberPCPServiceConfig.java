package com.usthealthproof.eplus.hrp.member.pcp.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.ws.transport.http.HttpUrlConnectionMessageSender;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Configuration
@Data
@Slf4j
public class MemberPCPServiceConfig extends HttpUrlConnectionMessageSender {

	@Value("${pcp.service.address}")
	private String address;
	@Value("${pcp.service.username}")
	private String username;
	@Value("${pcp.service.password}")
	private String password;
	@Value("${pcp.service.wsdl}")
	private String wsdl;
	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	@Override
	protected void prepareConnection(HttpURLConnection connection) throws IOException {
		Base64.Encoder enc = Base64.getEncoder();
		String userNameAndPassword = username + ":" + password;
		String encodedAuthorization = enc.encodeToString(userNameAndPassword.getBytes());
		connection.setRequestProperty("Authorization", "Basic " + encodedAuthorization);
		super.prepareConnection(connection);
	}

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-memberpcp-service/api-docs
	 * Swagger UI: http://localhost:8080/eplus/eplus-memberpcp-service/index.html
	 */
	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("Member PCP Update Service").description("\"PCP\" stands for Primary Care Physician. A Primary Care Physician is a healthcare professional who practices general medicine and serves as the first point of contact for patients within the healthcare system. Member will have a PCP assigned during enrolment. It is possible to update a member's current PCP with the updated PCP through the Member PCP update service. This service is invoked after all the necessary business validations were performed from the consumer system.\n\n"
						+ "The consumers are provided with a url and credentials to get the access token. The service calls are made with valid access token in the header as Bearer Token.\n\n"
						+ "For every failure a problemDetails object with error message and status will be available in the response."
				)
				.version("5.5.0"));
	}
	@Bean
	public WebClient webClient(){
		final ExchangeStrategies strategies = ExchangeStrategies.builder()
				.codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient()))
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies).build();
	}
	private HttpClient getHttpClient() {
		ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(500).maxIdleTime(Duration.ofSeconds(20))
				.maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
				.evictInBackground(Duration.ofSeconds(120)).build();
		return HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 20000).doOnConnected(
				conn -> conn.addHandlerLast(new ReadTimeoutHandler(20)).addHandlerLast(new WriteTimeoutHandler(20)));
	}
}
