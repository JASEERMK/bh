package com.usthealthproof.eplus.hrp.member.pcp.domain.crm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompositeRequest {

	private String method;
	private String url;
	private String referenceId;
	private Body body;
}
