package com.usthealthproof.eplus.hrp.member.pcp.builder;

import com.usthealthproof.eplus.hrp.member.pcp.constant.MemberPcpConstants;
import com.usthealthproof.eplus.hrp.member.pcp.domain.PcpChangeRequest;
import com.usthealthproof.eplus.hrp.member.pcp.domain.ProviderSelection;
import com.usthealthproof.eplus.hrp.member.pcp.domain.crm.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class HealthTrioPcpRequestBuilder {

	@Value("${salesforce.url.login.getRequest}")
	private String subRequestGetUrl;
	@Value("${salesforce.url.login.postRequest}")
	private String subRequestPostUrl;
	@Value("${salesforce.url.login.referenceId}")
	private String referenceId;
	@Value("${salesforce.url.login.type}")
	private String type;
	@Value("${salesforce.url.login.subject}")
	private String subject;
	@Value("${salesforce.url.login.origin}")
	private String origin;
	@Value("${salesforce.url.login.priority}")
	private String priority;
	@Value("${salesforce.url.login.department}")
	private String department;
	@Value("${pcp.medicareDesc}")
	private String medicareDesc;
	@Value("${pcp.medicaidDesc}")
	private String medicaidDesc;

	public CrmRequest createCRMRequest(PcpChangeRequest pcpRequest) {
		log.info("Inside createCRMRequest() in HealthTrioPcpRequestBuilder class");

		CrmRequest crmRequest = new CrmRequest();
		crmRequest.setAllOrNone(true);

		List<CompositeRequest> compositeRequestList = new ArrayList<>();
		CompositeRequest subRequestGet = new CompositeRequest();
		subRequestGet.setMethod(MemberPcpConstants.HTTPMETHOD_GET);
		subRequestGet.setUrl(subRequestGetUrl);
		subRequestGet.setReferenceId(referenceId);
		compositeRequestList.add(subRequestGet);

		CompositeRequest subRequestPost = new CompositeRequest();
		subRequestPost.setMethod(MemberPcpConstants.HTTPMETHOD_POST);
		subRequestPost.setUrl(subRequestPostUrl);
		subRequestPost.setReferenceId(String.format("%s%s%s%s%s", StringUtils.replace(pcpRequest.getCorrelationId(),"-",""), "_", StringUtils.replace(pcpRequest.getMemberId(),"-",""), "_",
				LocalDateTime.now().format(DateTimeFormatter.ofPattern(MemberPcpConstants.DATEFORMAT2))));
		subRequestPost.setBody(createBodyDetails(pcpRequest.getProviderSelections().get(0), pcpRequest.getMemberId(),
				pcpRequest.getReasonForPcpChange()));
		compositeRequestList.add(subRequestPost);
		crmRequest.setCompositeRequest(compositeRequestList);

		return crmRequest;

	}

	private Body createBodyDetails(ProviderSelection providerSelection, String memberId, String pcpChangeReason) {

		Body body = new Body();
		PcpDetails pcpDetails = new PcpDetails();
		if (StringUtils.containsIgnoreCase(medicaidDesc, providerSelection.getLineOfBusiness().strip())) {
			body.setDescription(
					String.format("%s%s%s%s", MemberPcpConstants.DESCRIPTION, providerSelection.getPractitionerRoleName(),
							MemberPcpConstants.REASON, StringUtils.defaultIfBlank(pcpChangeReason, " ")));
			pcpDetails.setProviderKey(providerSelection.getPractitionerId());
		} else if (StringUtils.containsIgnoreCase(medicareDesc, providerSelection.getLineOfBusiness().strip())) {
			body.setDescription(
					String.format("%s%s%s%s", MemberPcpConstants.DESCRIPTION, providerSelection.getSupplierLocationId(),
							MemberPcpConstants.REASON, StringUtils.defaultIfBlank(pcpChangeReason, " ")));
			pcpDetails.setProviderKey(providerSelection.getSupplierLocationId());
		}

		body.setType(type);
		body.setSubject(subject);
		body.setOrigin(origin);
		body.setPriority(priority);
		body.setRecordTypeId(MemberPcpConstants.RECORD_TYPE_ID);
		body.setStartDate(providerSelection.getStartDate());
		body.setDepartment(department);
		body.setPcpName(pcpDetails);

		Account account = new Account();
		account.setMemberKey(memberId);
		body.setAccount(account);

		return body;
	}
}
