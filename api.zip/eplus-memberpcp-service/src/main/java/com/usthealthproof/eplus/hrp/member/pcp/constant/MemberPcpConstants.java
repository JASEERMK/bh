package com.usthealthproof.eplus.hrp.member.pcp.constant;

public class MemberPcpConstants {

	private MemberPcpConstants() {

	}

	public static final String FAILURE = "FAILURE";

	public static final String SUCCESS = "SUCCESS";
	public static final String RESPONSE = "Response";
	public static final String DATEFORMAT1 = "-ddMMyyyy-HHmmssSSS-";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details.";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String HTTPMETHOD_GET = "GET";
	public static final String HTTPMETHOD_POST = "POST";
	public static final String DATEFORMAT2 = "yyyyMMdd_HHmmss";
	public static final String DESCRIPTION = "Update PCP to ";
	public static final String REASON = ",\nReason For PCP Change: ";
	public static final String RECORD_TYPE_ID = "@{EPLUS_Service_Case_RT.records[0].Id}";
	public static final String CORRELATIONID = "ust-correlation-id";
}
