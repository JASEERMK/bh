package com.usthealthproof.eplus.hrp.member.idcard.validator;

import com.jayway.jsonpath.internal.path.PathCompiler;
import com.usthealthproof.eplus.hrp.member.idcard.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import static com.jayway.jsonpath.internal.path.PathCompiler.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class ValidatorTest {
    @Test
    public void testValidateMemberIDCardRequest() {
        MemberIDCardRequest mockRequest = Mockito.mock(MemberIDCardRequest.class);

        // Set up the mock values
        Mockito.when(mockRequest.getHccId()).thenReturn("123");
        Mockito.when(mockRequest.getCorrespondenceDefinition()).thenReturn("def");
        Mockito.when(mockRequest.getCorrespondenceDescription()).thenReturn("description");
        Mockito.when(mockRequest.getAsOfDate()).thenReturn("2025-01-01");

        Validator validator = new Validator();
        ReflectionTestUtils.setField(validator, "dateFormat", "yyyy-MM-dd");

        try {
            validator.validateMemberIDCardRequest(mockRequest);
        } catch (RequestValidationException e) {
            fail("No exception should be thrown for valid input.");
        }
        assertThrows(RequestValidationException.class, () -> validator.validateMemberIDCardRequest(null));

        Mockito.when(mockRequest.getHccId()).thenReturn("");
        RequestValidationException idException = assertThrows(RequestValidationException.class,
                () -> validator.validateMemberIDCardRequest(mockRequest));
        assertEquals("HccId cannot be NULL or Empty", idException.getMessage());

        // Test with blank CorrespondenceDefinition
        Mockito.when(mockRequest.getHccId()).thenReturn("123");
        Mockito.when(mockRequest.getCorrespondenceDefinition()).thenReturn("");
        RequestValidationException definitionException = assertThrows(RequestValidationException.class,
                () -> validator.validateMemberIDCardRequest(mockRequest));
        assertEquals("CorrespondenceDefinition cannot be NULL or Empty", definitionException.getMessage());

        // Test with blank CorrespondenceDescription
        Mockito.when(mockRequest.getCorrespondenceDefinition()).thenReturn("def");
        Mockito.when(mockRequest.getCorrespondenceDescription()).thenReturn("");
        RequestValidationException descriptionException = assertThrows(RequestValidationException.class,
                () -> validator.validateMemberIDCardRequest(mockRequest));
        assertEquals("Description cannot be empty", descriptionException.getMessage());

        //blank asOfDate
        Mockito.when(mockRequest.getCorrespondenceDescription()).thenReturn("description");
        Mockito.when(mockRequest.getAsOfDate()).thenReturn("invalid-date");
        RequestValidationException dateException = assertThrows(RequestValidationException.class,
                () -> validator.validateMemberIDCardRequest(mockRequest));
        assertEquals("Enter valid date format, Format should be 'yyyy-MM-dd' or its an invalid date.", dateException.getMessage());
    }
}

