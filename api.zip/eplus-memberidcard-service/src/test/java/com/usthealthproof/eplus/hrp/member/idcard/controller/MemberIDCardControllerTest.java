package com.usthealthproof.eplus.hrp.member.idcard.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.hrp.member.idcard.config.SpringSecurityConfig;
import com.usthealthproof.eplus.hrp.member.idcard.constants.MemberIDCardConstantsTest;
import com.usthealthproof.eplus.hrp.member.idcard.exception.NotFoundException;
import com.usthealthproof.eplus.hrp.member.idcard.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import com.usthealthproof.eplus.hrp.member.idcard.service.MemberIDCardServiceImpl;
import com.usthealthproof.eplus.hrp.member.idcard.utils.APIUtils;
import com.usthealthproof.eplus.hrp.member.idcard.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@ExtendWith(SpringExtension.class)
@WebMvcTest(MemberIDCardController.class)
public class MemberIDCardControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    MemberIDCardServiceImpl memberIDCardService;
    @MockBean
    private Validator validator;
    @MockBean
    private APIUtils apiUtils;
    @Autowired
    private ObjectMapper objectMapper;

    MemberIDCardResponse memberIDCardResponse = new MemberIDCardResponse();
    MemberIDCardRequest memberIDCardRequest = new MemberIDCardRequest();

    @BeforeEach
    void setUp() {
        memberIDCardResponse.setId("123456");
        memberIDCardRequest.setHccId("12345");
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getMemberIdCardResponse - ValidInput")
    void testValidInputOtherInsuranceDetailsList() throws Exception {
        // given - precondition or setup
        given(memberIDCardService.getMemberIDCard(any(), any())).willReturn(memberIDCardResponse);
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/member/idcard/request")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(memberIDCardRequest)));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isOk());
    }
    @Test
    @DisplayName("JUnit test for Validating memberId")
    void testValidatingMemberId() throws Exception {
        // when - action or the behaviour
        doThrow(NotFoundException.class).when(validator).validateMemberIDCardRequest(null);
        // then - verify the output
        assertThrows(NotFoundException.class, () -> validator.validateMemberIDCardRequest(null));
    }
    @Test
    @DisplayName("JUnit test for getMemberIdCardResponse - Spring security Authentication Validation")
    void testAuthentication() throws Exception {
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/member/idcard/request")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(memberIDCardRequest)));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isUnauthorized());
    }
    @Test
    @DisplayName("JUnit test for getMemberIdCardDetails - Spring security Authentication Validation")
    void testAuthenticationOfID() throws Exception {
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(MemberIDCardConstantsTest.ENDPOINT_MEMBER_ID_CARD)
                .param("id", MemberIDCardConstantsTest.ID));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isUnauthorized());
    }
    @Test
    @DisplayName("JUnit test for Validating id")
    void testValidatingId() throws Exception {
        // when - action or the behaviour
        doThrow(RequestValidationException.class).when(validator).validateMemberIDCardRequest(null);
        // then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberIDCardRequest(null));
    }
    @Test
    @DisplayName("JUnit test for getMemberIdCardResponse - Invalid Pattern")
    @WithMockUser(value = "user")
    void testInvalidPatternValidation() throws Exception {
        memberIDCardRequest.setHccId("12345>");
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/member/idcard/request")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(memberIDCardRequest)));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isBadRequest());
    }
}
