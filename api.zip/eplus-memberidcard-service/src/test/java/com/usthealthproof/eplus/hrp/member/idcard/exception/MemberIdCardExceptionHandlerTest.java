package com.usthealthproof.eplus.hrp.member.idcard.exception;

import com.usthealthproof.eplus.hrp.member.idcard.constants.MemberIDCardConstants;
import com.usthealthproof.eplus.hrp.member.idcard.controller.MemberIDCardController;
import com.usthealthproof.eplus.hrp.member.idcard.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.idcard.model.ProblemDetails;
import com.usthealthproof.eplus.hrp.member.idcard.utils.APIUtils;
import org.springframework.http.HttpMethod;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MemberIdCardExceptionHandlerTest {
    @Mock
    APIUtils apiUtils;
    @InjectMocks
    MemberIdCardExceptionHandler memberIdCardExceptionHandler;
    @Mock
    WebRequest webRequest;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MemberIdCardExceptionHandler memberIdCardExceptionHandler1 = new MemberIdCardExceptionHandler();
    }

    @Test
    void testResponseValidationExceptionHandler() {
        when(apiUtils.createProblemDetails(anyString(), anyString())).thenReturn(new ProblemDetails());

        ResponseEntity<ErrorResponse> result = memberIdCardExceptionHandler.responseValidationHandler(new ResponseValidationException("message"), null);
        assertThat(result).isNotNull();
    }

    @Test
    public void testRequestValidationHandler() {
        // Mocking RequestValidationException
        RequestValidationException ex = new RequestValidationException("Validation failed");

        // Mocking WebRequest
        WebRequest request = mock(WebRequest.class);

        // Calling the method under test
        ResponseEntity<ErrorResponse> responseEntity = memberIdCardExceptionHandler.requestValidationHandler(ex, request);

        // Asserting the response
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

    }

    @Test
    public void testDataNotFoundHandler() {

        ResponseValidationException ex = new ResponseValidationException("Data not found");

        // Mocking WebRequest
        WebRequest request = mock(WebRequest.class);

        // Calling the method under test
        ResponseEntity<ErrorResponse> responseEntity = memberIdCardExceptionHandler.dataNotFoundHandler(ex, request);

        // Asserting the response
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
    }


    @Test
    public void testGlobalHandler_TimeoutException() {
        // Arrange
        Exception ex = new Exception("Connection reset");
        MockHttpServletRequest servletRequest = new MockHttpServletRequest();
        WebRequest webRequest = new ServletWebRequest(servletRequest);

        // Act
        ResponseEntity<ErrorResponse> response = memberIdCardExceptionHandler.globalHandler(ex, webRequest);

        // Assert
        assertEquals(HttpStatus.REQUEST_TIMEOUT, response.getStatusCode());


    }

    @Test
    @ExtendWith(MockitoExtension.class)
    public void testGlobalHandler_GeneralException() {

        Exception ex = new Exception("Some error");
        MockHttpServletRequest servletRequest = new MockHttpServletRequest();
        WebRequest webRequest = new ServletWebRequest(servletRequest);

        ResponseEntity<ErrorResponse> response = memberIdCardExceptionHandler.globalHandler(ex, webRequest);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testHandleMethodArgumentNotValid_NullMessage() {

        MethodArgumentNotValidException exception = mock(MethodArgumentNotValidException.class);
        when(exception.getMessage()).thenReturn(null);

        BindingResult bindingResult = mock(BindingResult.class);
        List<FieldError> fieldErrors = new ArrayList<>();
        fieldErrors.add(new FieldError("objectName", "fieldName", "error message"));
        when(bindingResult.getFieldErrors()).thenReturn(fieldErrors);
        when(exception.getBindingResult()).thenReturn(bindingResult);

        MemberIdCardExceptionHandler memberIdCardExceptionHandler = new MemberIdCardExceptionHandler();
        HttpHeaders headers = new HttpHeaders();
        HttpStatus status = HttpStatus.BAD_REQUEST;
        WebRequest request = mock(WebRequest.class);

        ResponseEntity<Object> responseEntity = memberIdCardExceptionHandler.handleMethodArgumentNotValid(exception, headers, status, request);

        // Verify the response
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void testSetErrorDetailsAsList() throws Exception {

        List<FieldError> fieldErrors = new ArrayList<>();
        fieldErrors.add(new FieldError("objectName", "fieldName1", "Error message 1"));
        fieldErrors.add(new FieldError("objectName", "fieldName2", "Error message 2"));

        String status = "500";

        // Creating instance of the class containing the method
        MemberIdCardExceptionHandler memberIdCardExceptionHandler = new MemberIdCardExceptionHandler();

        // Accessing the private method
        Method method = MemberIdCardExceptionHandler.class.getDeclaredMethod("setErrorDetailsAsList", List.class, String.class);
        method.setAccessible(true);

        // Invoking the private method
        ErrorResponse errorResponse = (ErrorResponse) method.invoke(memberIdCardExceptionHandler, fieldErrors, status);

        // Verifying problem details status
        assertEquals("500", errorResponse.getProblemDetails().getStatus());

        // Verifying error list
        List<String> expectedErrors = new ArrayList<>();
        expectedErrors.add("Error message 1");
        expectedErrors.add("Error message 2");
        assertEquals(expectedErrors, errorResponse.getProblemDetails().getErrors());
    }
}



