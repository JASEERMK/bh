package com.usthealthproof.eplus.hrp.member.idcard.utils;

import com.usthealthproof.eplus.hrp.member.idcard.model.ProblemDetails;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class APIUtilsTest {
    @Test
    public void testCreateProblemDetails() {
        // Create an instance of APIUtils
        APIUtils apiUtils = new APIUtils();

        // Call the method to test
        String errorMsg = "Test error message";
        String status = "400";
        ProblemDetails problemDetails = apiUtils.createProblemDetails(errorMsg, status);

        // Assert that problemDetails is not null
        assertNotNull(problemDetails);

        // Assert that the errors list contains the expected error message
        assertEquals(1, problemDetails.getErrors().size());
        assertEquals(errorMsg, problemDetails.getErrors().get(0));

        // Assert that the status is set correctly
        assertEquals(status, problemDetails.getStatus());
    }
}
