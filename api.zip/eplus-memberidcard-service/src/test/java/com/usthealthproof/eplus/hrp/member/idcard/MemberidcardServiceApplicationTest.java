package com.usthealthproof.eplus.hrp.member.idcard;

import com.usthealthproof.eplus.hrp.member.idcard.MemberidcardServiceApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class MemberidcardServiceApplicationTest {
    @Test
    void testMainClass() {
        MemberidcardServiceApplication.main(new String[]{"args"});
        assertTrue(true);
    }

}
