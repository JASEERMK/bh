package com.usthealthproof.eplus.hrp.member.idcard.service;

import com.healthedge.Recipient;
import com.usthealthproof.eplus.hrp.member.idcard.dao.MemberIDCardDAO;
import com.usthealthproof.eplus.hrp.member.idcard.dao.MemberIDCardDAOImpl;
import com.usthealthproof.eplus.hrp.member.idcard.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import com.usthealthproof.eplus.hrp.member.idcard.validator.Validator;
import io.micrometer.core.instrument.config.validate.ValidationException;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MemberIDCardServiceImplTest {
    @Mock
    private Validator validator;

    @Mock
    private MemberIDCardDAO memberIDCardDAO;

    @InjectMocks
    private MemberIDCardServiceImpl memberIDCardService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        try {
            Field daoField = MemberIDCardServiceImpl.class.getDeclaredField("memberIDCardDAO");
            daoField.setAccessible(true);
            daoField.set(memberIDCardService, memberIDCardDAO);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }


    @Test
    public void testGetMemberIDCard() throws Exception {

        MemberIDCardRequest request = new MemberIDCardRequest();
        request.setHccId("123456");
        request.setCorrespondenceDefinition("Definition");
        request.setCorrespondenceDescription("Description");

        when(memberIDCardDAO.getMemberIDCardResponse(request)).thenReturn(new MemberIDCardResponse());

        MemberIDCardResponse response = memberIDCardService.getMemberIDCard(request, null);

        // Verify the result
        assertNotNull(response);
    }

    @Test
    void testExceptionHandling() throws Exception {
        MemberIDCardRequest request = new MemberIDCardRequest();

        Method method = MemberIDCardServiceImpl.class.getDeclaredMethod("getMemberIDCard", MemberIDCardRequest.class, HttpServletRequest.class);
        method.setAccessible(true);

        assertThrows(Exception.class, () -> method.invoke(memberIDCardService, request));
    }
    @Test
    public void testGetMemberIDCard_InvalidRequest() throws Exception {
        MemberIDCardRequest request = new MemberIDCardRequest();
        assertThrows(Exception.class, () -> memberIDCardService.getMemberIDCard(request, null));
    }
}
