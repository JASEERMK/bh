package com.usthealthproof.eplus.hrp.member.idcard.dao;

import com.healthedge.*;
import com.usthealthproof.eplus.hrp.member.idcard.exception.NotFoundException;
import com.usthealthproof.eplus.hrp.member.idcard.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import jakarta.xml.bind.JAXBElement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;
import java.lang.reflect.Field;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
public class MemberIDCardDAOImplTest {
    @Mock
    private CorrespondenceServiceStronglyTypedType correspondenceServiceStronglyTypedType;
    @InjectMocks
    private MemberIDCardDAOImpl memberIDCardDAO;
    private MemberIDCardRequest validRequest;

    @Mock
    private MemberIDCardResponse validResponse;
    @Mock
    JdbcTemplate jdbcTemplate;
    @Value("${addcorrospondenceid.insertion-query}")
    private String insertionQuery;

    @Mock
    WebServiceTemplate webServiceTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        validRequest = new MemberIDCardRequest();
        validRequest.setHccId("123456");
        validResponse.setId("1234");
        // Mock the behavior of jdbcTemplate.update to return 1 row affected
        when(jdbcTemplate.update(anyString(), any(), any(), any(), any(), any(), any())).thenReturn(1);
        // Use ReflectionTestUtils to set the private field productQuery
        ReflectionTestUtils.setField(memberIDCardDAO, "insertionQuery", insertionQuery);
    }

    @Test
    void testMemberIDCardResponse_Exception() throws IllegalServiceArgumentException, UpdateFailedException,SoapFaultClientException {
        // Given
        CreateOrUpdateCorrespondenceResponse createOrUpdateCorrespondenceResponse = new CreateOrUpdateCorrespondenceResponse();
        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenThrow(new ResponseValidationException("Invalid response"));
        // then - verify the output
        assertThatThrownBy(()-> memberIDCardDAO.getMemberIDCardResponse(new MemberIDCardRequest()))
                .isInstanceOf(ResponseValidationException.class);

    }

    @Test
    void testGetMemberIDCardResponse_ValidResponse() throws Exception {

        long startServiceRequestTime = System.currentTimeMillis();
        ReflectionTestUtils.setField(memberIDCardDAO, "dateFormatter", "MM/dd/yyyy");
        CreateOrUpdateCorrespondenceResponse createOrUpdateCorrespondenceResponse = new CreateOrUpdateCorrespondenceResponse();
        JAXBElement<CreateOrUpdateCorrespondenceResponse> jaxbElement = new JAXBElement<>(
                new QName("http://healthedge.com", "createOrUpdateCorrespondenceResponse"),
                CreateOrUpdateCorrespondenceResponse.class,
                createOrUpdateCorrespondenceResponse
        );
        ResponseInfo responseInfo = new ResponseInfo();
        responseInfo.setErrorMessage("Sample error message");
        responseInfo.setId("12345");
        createOrUpdateCorrespondenceResponse.setResponse(responseInfo);

        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class))).thenReturn(jaxbElement);

        MemberIDCardRequest memberIDCardRequest = new MemberIDCardRequest();
        memberIDCardRequest.setCorrespondenceDescription("Sample Description");
        memberIDCardRequest.setCorrespondenceDefinition("Sample Definition");
        memberIDCardRequest.setHccId("12345");
        memberIDCardRequest.setAsOfDate("02/14/2025");
        MemberIDCardResponse response = memberIDCardDAO.getMemberIDCardResponse(memberIDCardRequest);

        // Assert
        assertNotNull(response);
        assertEquals("12345", response.getId());
        //assertEquals("Sample error message", response.getErrorMessage());


        responseInfo = null;
        createOrUpdateCorrespondenceResponse.setResponse(responseInfo);
        JAXBElement<CreateOrUpdateCorrespondenceResponse> jaxbElementFailObj = new JAXBElement<>(
                new QName("http://healthedge.com", "createOrUpdateCorrespondenceResponse"),
                CreateOrUpdateCorrespondenceResponse.class,
                createOrUpdateCorrespondenceResponse
        );

        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class))).thenReturn(jaxbElementFailObj);
        assertThrows(Exception.class, () -> memberIDCardDAO.getMemberIDCardResponse(memberIDCardRequest));
    }




    //Following 4 test cases are for jdbc method
    @Test
    public void testInsertCorrespondenceId() {

        MemberIDCardResponse idCardResponse = new MemberIDCardResponse();
        idCardResponse.setId("1234567890");

        MemberIDCardRequest memberIDCardRequest = new MemberIDCardRequest();
        memberIDCardRequest.setHccId("1234567");

        memberIDCardDAO.insertCorrespondenceId(idCardResponse, memberIDCardRequest);
        // Verify that jdbcTemplate.update was called with correct parameters
        verify(jdbcTemplate).update(eq(insertionQuery), eq("1234567890"), eq("1234567"), eq("Member Id Card Service"),
                anyString(), eq(""), eq("t"));
    }


    @Test
    void testGetMemberIDCardResponse_NullRequest() throws Exception {
        assertThrows(NullPointerException.class, () -> {
            memberIDCardDAO.getMemberIDCardResponse(null);
        });
    }

}
