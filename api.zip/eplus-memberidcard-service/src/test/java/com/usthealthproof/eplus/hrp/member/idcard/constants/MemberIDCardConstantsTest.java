package com.usthealthproof.eplus.hrp.member.idcard.constants;

import org.springframework.stereotype.Component;

@Component
public class MemberIDCardConstantsTest {
    public static final String ID = "9360001";
    public static final String HCCID = "323054758";
    public static final String ENDPOINT_MEMBER_ID_CARD = "/v1/member/idcard/request";
}
