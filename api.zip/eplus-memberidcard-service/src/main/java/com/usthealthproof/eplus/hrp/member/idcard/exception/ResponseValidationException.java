package com.usthealthproof.eplus.hrp.member.idcard.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = 8900398116821943151L;

	public ResponseValidationException(String message) {
		super(message);

	}

}
