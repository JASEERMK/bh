package com.usthealthproof.eplus.hrp.member.idcard.dao;

import com.healthedge.IllegalServiceArgumentException;
import com.healthedge.UpdateFailedException;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import org.springframework.ws.soap.client.SoapFaultClientException;

@Component
public interface MemberIDCardDAO {
	MemberIDCardResponse getMemberIDCardResponse(MemberIDCardRequest memberIDCardRequest) throws Exception;

	void insertCorrespondenceId(MemberIDCardResponse idCardResponse, MemberIDCardRequest idCardRequest);

}
