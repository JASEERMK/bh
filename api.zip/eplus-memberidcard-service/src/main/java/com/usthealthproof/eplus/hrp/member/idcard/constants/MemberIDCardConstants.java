package com.usthealthproof.eplus.hrp.member.idcard.constants;

public class MemberIDCardConstants {

	private MemberIDCardConstants() {

	}
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details.";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";

}
