package com.usthealthproof.eplus.hrp.member.idcard.config;

import com.usthealthproof.eplus.hrp.member.idcard.utils.CustomNamespacePrefixMapper;
import jakarta.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import java.time.Duration;
import java.util.Collections;


@Configuration
@Slf4j
public class WebServiceConfig {

    @Value("${member.service.address}")
    private String address;
    @Value("${member.service.connectionTimeout}")
    private String connectionTimeout;
    @Value("${member.service.readTimeout}")
    private String readTimeout;
    @Value("${member.service.contextPackage}")
    private String context;
    @Value("${member.service.nameSpaceMapper}")
    private String nameSpaceMapper;

    @Autowired
    CustomNamespacePrefixMapper customNamespacePrefixMapper;

    @Bean
    public Jaxb2Marshaller marshaller() {

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(context);
        marshaller.setMarshallerProperties(Collections.singletonMap(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE));

        // Set the custom namespace prefix mapper
        marshaller.setMarshallerProperties(
                Collections.singletonMap(nameSpaceMapper, customNamespacePrefixMapper)
        );
        return marshaller;
    }

    @Bean
    public ClientInterceptor customLoggingInterceptor() {
        return new CustomLoggingInterceptor();
    }

    @Bean(name = "correspondenceServiceStronglyTypedType")
    public WebServiceTemplate webServiceTemplate(Jaxb2Marshaller marshaller,MemberIDCardConfig memberIDCardConfig) {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
        try {
            webServiceTemplate.setMarshaller(marshaller);
            webServiceTemplate.setUnmarshaller(marshaller);
            webServiceTemplate.setDefaultUri(address);
            memberIDCardConfig.setReadTimeout(Duration.ofMillis(Long.parseLong(readTimeout)));
            memberIDCardConfig.setConnectionTimeout(Duration.ofMillis(Long.parseLong(connectionTimeout)));
            webServiceTemplate.setInterceptors(new ClientInterceptor[]{customLoggingInterceptor()});
            webServiceTemplate.setMessageSender(memberIDCardConfig);

        }catch (Exception e) {
            log.error("Exception in MemberIDCardServiceConfiguration:: ", e);
        }
        return  webServiceTemplate;
    }

}
