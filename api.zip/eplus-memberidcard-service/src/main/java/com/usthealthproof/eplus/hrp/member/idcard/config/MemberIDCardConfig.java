package com.usthealthproof.eplus.hrp.member.idcard.config;

import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ws.transport.http.HttpUrlConnectionMessageSender;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Configuration
@Slf4j
public class MemberIDCardConfig extends HttpUrlConnectionMessageSender{

	@Value("${member.service.username}")
	private String username;
	@Value("${member.service.password}")
	private String password;
	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	@Override
	protected void prepareConnection(HttpURLConnection connection) throws IOException {
		Base64.Encoder enc = Base64.getEncoder();
		String userNameAndPassword = username + ":" + password;
		String encodedAuthorization = enc.encodeToString(userNameAndPassword.getBytes());
		connection.setRequestProperty("Authorization", "Basic " + encodedAuthorization);
		super.prepareConnection(connection);
	}

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-memberidcard-service/api-docs
	 * Swagger UI: http://localhost:8080/eplus/eplus-memberidcard-service/index.html
	 */
	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("Member ID Card Service")
				.description("The ID Card Service initiates a correspondence trigger in HRP for every requested ID cards. Once the correspondence is triggered, the ID card will be delivered to the appropriate member, by the fulfilment-vendor.\n\n"
						+ "The consumers are provided with a url and credentials to get the access token. The service calls are made with valid access token in the header as Bearer Token.\n\n"
						+ "For every failure a problemDetails object with error message and status will be available in the response.")
				.version("5.5.1"));

	}

}
