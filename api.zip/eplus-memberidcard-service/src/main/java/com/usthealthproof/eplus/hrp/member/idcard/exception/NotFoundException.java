package com.usthealthproof.eplus.hrp.member.idcard.exception;

public class NotFoundException extends RuntimeException {

	private static final long serialVersionUID = 8900398116821943151L;

	public NotFoundException(String message) {
		super(message);

	}
}
