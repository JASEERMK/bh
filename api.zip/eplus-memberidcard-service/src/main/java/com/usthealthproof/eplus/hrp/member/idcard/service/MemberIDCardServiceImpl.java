package com.usthealthproof.eplus.hrp.member.idcard.service;


import com.healthedge.IllegalServiceArgumentException;
import com.healthedge.UpdateFailedException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.hrp.member.idcard.dao.MemberIDCardDAO;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import com.usthealthproof.eplus.hrp.member.idcard.validator.Validator;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemberIDCardServiceImpl implements MemberIDCardService {

	@Autowired
	private MemberIDCardDAO memberIDCardDAO;

	@Autowired
	private Validator validator;

	@Value("${correspondence-definition.definition}")
	private String definition;

	@Value("${correspondence-definition.description}")
	private String description;

	@Value("${application.dbJobRequiredFlag}")
	private String dbJobRequiredFlag;

	@Override
	public MemberIDCardResponse getMemberIDCard(MemberIDCardRequest memberIDCardRequest, HttpServletRequest request) throws Exception {
		log.info("Inside getMemberIDCard() in the MemberIDCardServiceImpl class");
		
		MemberIDCardResponse memberIDCardResponse = null;

			if (StringUtils.isBlank(memberIDCardRequest.getCorrespondenceDefinition())) {
				memberIDCardRequest.setCorrespondenceDefinition(definition);
			}
			if (StringUtils.isBlank(memberIDCardRequest.getCorrespondenceDescription())) {
				memberIDCardRequest.setCorrespondenceDescription(description);
			}
			validator.validateMemberIDCardRequest(memberIDCardRequest);
			memberIDCardResponse = memberIDCardDAO.getMemberIDCardResponse(memberIDCardRequest);

			// insert correspondence id only if the request is from CRM
			if (memberIDCardResponse.getId() != null
					&& StringUtils.isBlank(memberIDCardRequest.getIsPortal())
					&& StringUtils.equalsIgnoreCase("true", dbJobRequiredFlag)) {
				memberIDCardDAO.insertCorrespondenceId(memberIDCardResponse, memberIDCardRequest);
			}
		return memberIDCardResponse;
	}
}
