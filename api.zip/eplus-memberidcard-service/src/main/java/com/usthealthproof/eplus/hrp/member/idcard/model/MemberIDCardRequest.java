package com.usthealthproof.eplus.hrp.member.idcard.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Request object wrapping Member HCC Id")
public class MemberIDCardRequest implements Serializable {

	private static final long serialVersionUID = 5916973052102595355L;

	@Schema(description = "Member Hcc Id", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "Member Hcc Id")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Hcc id is not in valid format")
	private String hccId;

	@Schema(description = "Description of the Member Id Card Request", defaultValue = "Correspondence Description")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: description is not in valid format")
	private String correspondenceDescription;

	@Schema(description = "Correspondence Definition" , defaultValue = "Correspondence Definition")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: correspondenceDefinition is not in valid format")
	private String correspondenceDefinition;

	@Schema(description = "As Of Date", defaultValue = "As Of Date")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: asOfDate is not in valid format")
	private String asOfDate;

	@Schema(description = "Is portal",hidden = true, defaultValue = "Is portal")
	private String isPortal;
}
