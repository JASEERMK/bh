package com.usthealthproof.eplus.hrp.member.idcard.utils;

import java.util.Arrays;

import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.member.idcard.model.ProblemDetails;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class APIUtils {

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		log.info("Inside createProblemDetails() in APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setErrors(Arrays.asList(errorMsg));
		problemDetails.setStatus(status);
		return problemDetails;
	}

}
