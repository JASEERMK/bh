package com.usthealthproof.eplus.hrp.member.idcard.service;


import com.healthedge.IllegalServiceArgumentException;
import com.healthedge.UpdateFailedException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;

@Component
public interface MemberIDCardService {
	public MemberIDCardResponse getMemberIDCard(MemberIDCardRequest memberIDCardRequest, HttpServletRequest request) throws Exception;

}