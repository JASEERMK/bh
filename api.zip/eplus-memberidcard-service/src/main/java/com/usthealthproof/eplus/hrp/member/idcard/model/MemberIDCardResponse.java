package com.usthealthproof.eplus.hrp.member.idcard.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response class for correspondence triggering Api call")
public class MemberIDCardResponse {

	@Schema(description = "Generated unique Correspondence id in HRP")
	private String id;

	//@Schema(description = "Error messge, if any error happens", hidden = true)
	//private String errorMessage;


}
