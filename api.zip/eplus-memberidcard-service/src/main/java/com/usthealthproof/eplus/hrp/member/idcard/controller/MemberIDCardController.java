package com.usthealthproof.eplus.hrp.member.idcard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.hrp.member.idcard.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import com.usthealthproof.eplus.hrp.member.idcard.service.MemberIDCardService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Tag(name = "Member ID Card Service")
@SecurityRequirement(name = "Member Id Card Service")
public class MemberIDCardController {

	@Autowired
	private MemberIDCardService memberIDCardService;

	@PostMapping(value = "/v1/member/idcard/request", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "Creates a correspondence trigger in HRP for specific ID card request from the member", description = "The service will initiate a correspondence trigger in the HRP, for every ID card that the member requests. The request field that can be used to create a correspondence are the member HCC ID, correspondence description, correspondence definition and as of date. The member HCC ID is the only required field among these. Furthermore we can use correspondence description, correspondence definition and as of date however we see appropriate; it is entirely optional.", method = "POST", responses = {
			@ApiResponse(responseCode = "200", description = "MemberID Card Response", content = {
					@Content(schema = @Schema(implementation = MemberIDCardResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "408", description = "Request Timeout", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public MemberIDCardResponse getMemberIDCardResponse(@Valid @RequestBody MemberIDCardRequest memberIDCardRequest,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getMemberIDCardResponse() of Controller class");
		log.debug("Request received inside getMemberIDCardResponse() of Controller class and the request : {}",
				memberIDCardRequest);

		MemberIDCardResponse getMemberIDCardResponse = memberIDCardService.getMemberIDCard(memberIDCardRequest,
				httpServletRequest);
		log.debug("Successfully created Member ID Card for the request and the response received is: {}",
				getMemberIDCardResponse);
		log.info("Successfully created Member ID Card for the request");
		return getMemberIDCardResponse;
	}

}
