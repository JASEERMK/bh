package com.usthealthproof.eplus.hrp.member.idcard.validator;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.usthealthproof.eplus.hrp.member.idcard.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class Validator {

    @Value("${correspondence-definition.dateFormatter}")
    private String dateFormat;

    public void validateMemberIDCardRequest(MemberIDCardRequest memberIDCardRequest) {
        log.info("Inside validateMemberIDCardRequest() in Validator class");

        if (Objects.isNull(memberIDCardRequest)) {
            throw new RequestValidationException("Request fields are NULL");
        } else if (StringUtils.isBlank(memberIDCardRequest.getHccId())) {
            throw new RequestValidationException("HccId cannot be NULL or Empty");
        } else if (StringUtils.isBlank(memberIDCardRequest.getCorrespondenceDefinition())) {
            throw new RequestValidationException("CorrespondenceDefinition cannot be NULL or Empty");
        } else if (StringUtils.isBlank(memberIDCardRequest.getCorrespondenceDescription())) {
            throw new RequestValidationException("Description cannot be empty");
        } else if (StringUtils.isNotBlank(memberIDCardRequest.getAsOfDate())) {
            validateAsOfDate(memberIDCardRequest);
        }

    }

    /**
     * Method to validate the date format as part of API-1992
     **/
    private void validateAsOfDate(MemberIDCardRequest memberIDCardRequest) {
        log.info("Inside validateDateFormat() in Validator class");
        try {
            DateTimeFormatter dateFormatter = new DateTimeFormatterBuilder()
                    .appendPattern(dateFormat) // dateFormat holds "MM/dd/yyyy"
                    .parseDefaulting(ChronoField.ERA, 1) // Default to 1 (which corresponds to CE)
                    .toFormatter()
                    .withResolverStyle(ResolverStyle.STRICT);

            LocalDate.parse(memberIDCardRequest.getAsOfDate().strip(), dateFormatter);

        } catch (DateTimeParseException e) {
            throw new RequestValidationException("Enter valid date format, Format should be '" + dateFormat + "' or its an invalid date.");
        }
    }

}
