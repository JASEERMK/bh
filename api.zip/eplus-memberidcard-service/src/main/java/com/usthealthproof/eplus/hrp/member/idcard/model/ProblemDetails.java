package com.usthealthproof.eplus.hrp.member.idcard.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Problem Details class")
public class ProblemDetails implements Serializable {

	private static final long serialVersionUID = -2107006351369357133L;

	@Schema(description = "Error informations")
	private List<String> errors;
	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status;

	public ProblemDetails addErrorsItem(String errorsItem) {
		if (this.errors == null) {
			this.errors = new ArrayList<>();
		}
		this.errors.add(errorsItem);
		return this;
	}

}
