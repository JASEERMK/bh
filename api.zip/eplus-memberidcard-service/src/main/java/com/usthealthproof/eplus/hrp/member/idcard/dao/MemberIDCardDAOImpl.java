package com.usthealthproof.eplus.hrp.member.idcard.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.healthedge.*;
import com.usthealthproof.eplus.hrp.member.idcard.constants.MemberIDCardConstants;
import io.micrometer.common.util.StringUtils;
import jakarta.xml.bind.JAXBElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.usthealthproof.eplus.hrp.member.idcard.exception.NotFoundException;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardRequest;
import com.usthealthproof.eplus.hrp.member.idcard.model.MemberIDCardResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;

@Component
@Slf4j
public class MemberIDCardDAOImpl implements MemberIDCardDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${addcorrospondenceid.insertion-query}")
    private String insertionQuery;

    @Value("${member.service.nameSpaceUri}")
    private String nameSpaceUri;

    @Value("${correspondence-definition.dateFormatter}")
    private String dateFormatter;

    @Autowired
    @Qualifier("correspondenceServiceStronglyTypedType")
    WebServiceTemplate webServiceTemplate;


    @Override
    public MemberIDCardResponse getMemberIDCardResponse(MemberIDCardRequest memberIDCardRequest) throws
            Exception {
        log.info("Inside getMemberIDCardResponse() in the MemberIDCardDAOImpl class");
        MemberIDCardResponse memberIDCardResponse = new MemberIDCardResponse();
        long startServiceRequestTime = System.currentTimeMillis();
        CreateOrUpdateCorrespondence createOrUpdateCorrespondence = new CreateOrUpdateCorrespondence();
        createOrUpdateCorrespondence.setDescription(memberIDCardRequest.getCorrespondenceDescription());
        createOrUpdateCorrespondence.setDefinition(memberIDCardRequest.getCorrespondenceDefinition());
        Recipient recipient = createRecipient(memberIDCardRequest);
        createOrUpdateCorrespondence.setRecipient(recipient);

        if (StringUtils.isNotBlank(memberIDCardRequest.getAsOfDate())) {
            List<CorrespondenceFieldValue> manuallyEnteredFields = getManuallyEnteredFields(memberIDCardRequest);
            createOrUpdateCorrespondence.getManuallyEnteredFields().addAll(manuallyEnteredFields);
        }

        Subject subject = createSubject(memberIDCardRequest);
        createOrUpdateCorrespondence.setSubject(subject);
        // Create the JAXBElement for the request
        JAXBElement<CreateOrUpdateCorrespondence> getCreateOrUpdateCorrespondenceJAXBElement = new JAXBElement<>(new QName(nameSpaceUri, "createOrUpdateCorrespondence"),
                CreateOrUpdateCorrespondence.class,
                createOrUpdateCorrespondence
        );
        // Send the SOAP request and receive the response
        JAXBElement<CreateOrUpdateCorrespondenceResponse> createOrUpdateCorrespondenceResponseJAXBElement = (JAXBElement<CreateOrUpdateCorrespondenceResponse>) webServiceTemplate.marshalSendAndReceive(
                getCreateOrUpdateCorrespondenceJAXBElement,
                new SoapActionCallback("") // Adjust the SOAP action as necessary
        );
        long endServiceRequestTime = System.currentTimeMillis();
        log.info("Execution time of the Member-Id-Card service : {} ms", endServiceRequestTime - startServiceRequestTime);

        if (Objects.isNull(createOrUpdateCorrespondenceResponseJAXBElement.getValue().getResponse())) {
            log.error("The Received Response from HRP is null");
            throw new Exception(MemberIDCardConstants.EXCEPTION_MESSAGE);


        } else {
            memberIDCardResponse.setId(createOrUpdateCorrespondenceResponseJAXBElement.getValue().getResponse().getId());
        }

        return memberIDCardResponse;
    }

    private List<CorrespondenceFieldValue> getManuallyEnteredFields(MemberIDCardRequest memberIDCardRequest) {
        List<CorrespondenceFieldValue> manuallyEnteredFields = new ArrayList<>(1);

        //correspondenceFieldValue for asOfDate
        CorrespondenceFieldValue correspondenceFieldDate = new CorrespondenceFieldValue();
        correspondenceFieldDate.setName("As Of Date (" + dateFormatter.toLowerCase() + ")");
        correspondenceFieldDate.setValue(memberIDCardRequest.getAsOfDate());
        manuallyEnteredFields.add(correspondenceFieldDate);

        return manuallyEnteredFields;
    }

    /**
     * Create Recipient
     *
     * @param memberIDCardRequest
     * @return
     */
    private com.healthedge.Recipient createRecipient(MemberIDCardRequest memberIDCardRequest) {
        com.healthedge.Recipient recipient = new Recipient();
        recipient.setHccId(memberIDCardRequest.getHccId());
        recipient.setRecipientType(ReciepientType.MEMBERSHIP);
        return recipient;
    }

    /**
     * Create Subject
     *
     * @param memberIDCardRequest
     * @return
     */
    private Subject createSubject(MemberIDCardRequest memberIDCardRequest) {
        Subject subject = new Subject();
        subject.setHccId(memberIDCardRequest.getHccId());
        subject.setSubjectType(SubjectType.MEMBERSHIP);
        return subject;
    }

    @Override
    public void insertCorrespondenceId(MemberIDCardResponse idCardResponse, MemberIDCardRequest memberIDCardRequest) {
        log.info("Inside insertCorrespondenceId() in the MemberIDCardDAOImpl class");
        String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        jdbcTemplate.update(insertionQuery, idCardResponse.getId(), memberIDCardRequest.getHccId(), "Member Id Card Service",
                currentDate, "", "t");
    }

}
