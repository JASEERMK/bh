package com.usthealthproof.eplus.hrp.feeschedule.dao;

import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;

@Component
public interface FeeScheduleDao {
	FeeScheduleResponse getFeeDetails(FeeDetailLookupRequest request) throws ResponseValidationException;
}
