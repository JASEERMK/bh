package com.usthealthproof.eplus.hrp.feeschedule.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Configurable
@Slf4j
public class CustomLoggingInterceptor implements ClientInterceptor {
    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        log.info("**** Webservice Request **** ");
        logPayload(messageContext.getRequest(), "SOAP request");
        return true;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        log.info("**** Webservice Response **** ");
        logPayload(messageContext.getResponse(), "SOAP response");
        return true;
    }
    @Override
    public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
        log.info("**** Webservice Fault ****");
        logPayload(messageContext.getResponse(), "SOAP fault");
        return true;
    }

    @Override
    public void afterCompletion(MessageContext messageContext, Exception e) throws WebServiceClientException {
        // Do nothing
    }

    private void logPayload(org.springframework.ws.WebServiceMessage message, String logType) throws WebServiceClientException {
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            message.writeTo(buffer);
            String payload = buffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());
            log.info(payload);
        } catch (IOException e) {
            throw new WebServiceClientException("Cannot write the " + logType + " into the output stream", e) {
                private static final long serialVersionUID = -7118480620416458069L;
            };
        }
    }
}
