package com.usthealthproof.eplus.hrp.feeschedule.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.transport.http.HttpUrlConnectionMessageSender;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Configuration
public class FeeScheduleConfig extends HttpUrlConnectionMessageSender {

	@Value("${fee.service.username}")
	private String username;

	@Value("${fee.service.password}")
	private String password;

	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;


	@Override
	protected void prepareConnection(HttpURLConnection connection) throws IOException {
		Base64.Encoder enc = Base64.getEncoder();
		String userNameAndPassword = username + ":" + password;
		String encodedAuthorization = enc.encodeToString(userNameAndPassword.getBytes());
		connection.setRequestProperty("Authorization", "Basic " + encodedAuthorization);
		super.prepareConnection(connection);
	}


	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-feeschedule-service/api-docs
	 * Swagger UI: http://localhost:8080/eplus/eplus-feeschedule-service/index.html
	 */
	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("Fee Schedule Service").description(
				"The Fee Schedule service provides a comprehensive solution for retrieving accurate and up-to-date fee details for a wide range of services.\n "
						+ "The consumers are provided with a url and credentials to get the access token . The service calls are made with valid access token in the header as Bearer Token.\n\n"
						+ "For every failure a problemDetails object with error message and status will be available in the response. \n \n")
				.version("5.3.0"));
	}

}
