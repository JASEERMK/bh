package com.usthealthproof.eplus.hrp.feeschedule.util;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.model.ProblemDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
@Slf4j
public class CommonUtils {

	CommonUtils() {
	}

	public static FeeDetailLookupRequest getFeeScheduleRequest(String scheduleName, String placeOfServiceCode,
			String serviceCode, String modifierCode, String revenueCode) {
		log.info("Inside getFeeScheduleRequest() in CommonUtils class");
		
		var request = new FeeDetailLookupRequest();
		request.setScheduleName(scheduleName);

		if (isNotBlank(placeOfServiceCode))
			request.setPlaceOfServiceCode(placeOfServiceCode);
		if (isNotBlank(serviceCode))
			request.setServiceCode(serviceCode);
		if (isNotBlank(modifierCode))
			request.setModifierCode(modifierCode);
		if (isNotBlank(revenueCode))
			request.setRevenueCode(revenueCode);

		return request;
	}

	public ProblemDetails createProblemDetails(String errorMsg,String status) {
		log.info("Inside createProblemDetails() in CommonUtils class");
		
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setErrors(Arrays.asList(errorMsg));
		problemDetails.setStatus(status);
		return problemDetails;
	}

}
