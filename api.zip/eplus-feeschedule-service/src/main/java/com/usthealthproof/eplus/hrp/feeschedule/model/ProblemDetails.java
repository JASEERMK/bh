package com.usthealthproof.eplus.hrp.feeschedule.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Problem Details class")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProblemDetails implements Serializable {

	private static final long serialVersionUID = -6052856364719654188L;
	@Schema(description = "Error informations")
	private List<String> errors;

	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status;

}
