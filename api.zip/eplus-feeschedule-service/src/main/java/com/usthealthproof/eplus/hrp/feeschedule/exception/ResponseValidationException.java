package com.usthealthproof.eplus.hrp.feeschedule.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = 1745448975450898911L;


	public ResponseValidationException(String message) {
		super(message);
	}

}
