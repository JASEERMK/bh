package com.usthealthproof.eplus.hrp.feeschedule.dao;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupResponse;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailType;
import com.usthealthproof.eplus.hrp.feeschedule.constant.FeeScheduleConstant;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeDetail;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;
import jakarta.xml.bind.JAXBElement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Repository
@Slf4j
public class FeeScheduleDaoImpl implements FeeScheduleDao {

	@Value("${fee.service.nameSpaceUri}")
	private String nameSpace;

	@Autowired
	WebServiceTemplate webServiceTemplate;
	
	public FeeScheduleResponse getFeeDetails(FeeDetailLookupRequest request) throws ResponseValidationException {
		log.info("Inside getFeeDetails() in DAO class");
		
		FeeDetailLookupResponse feeDetailLookupResponse = null;
		try {
			long startServiceRequestTime = System.currentTimeMillis();

            // Create the JAXBElement for the request
			JAXBElement<FeeDetailLookupRequest> getFeeDetailsJAXBElement = new JAXBElement<>(
					new QName(nameSpace, "feeDetailLookupRequest"),
					FeeDetailLookupRequest.class,
					request
			);

			// Send the SOAP request and receive the response
			JAXBElement<FeeDetailLookupResponse> getFeeDetailsResponse=
					(JAXBElement<FeeDetailLookupResponse>) webServiceTemplate.marshalSendAndReceive(
							getFeeDetailsJAXBElement,
							new SoapActionCallback("")
					);

			long endServiceRequestTime = System.currentTimeMillis();
			if (Objects.nonNull(getFeeDetailsResponse)) {
				feeDetailLookupResponse = getFeeDetailsResponse.getValue();
			}

			log.info("Execution time of the external service : {}", endServiceRequestTime - startServiceRequestTime);
		} catch (Exception ex) {
			log.error("Failed to receive the FeeSchedule service for the request. Exception caught in the FeeScheduleDaoImpl class.");
			throw ex;
		}

		return getFeeDetailResponse(feeDetailLookupResponse, request.getScheduleName());
	}

	FeeScheduleResponse getFeeDetailResponse(FeeDetailLookupResponse feeDetailLookupResponse,
											 String scheduleName) {
		var feeScheduleResponse = new FeeScheduleResponse();
		if (!ObjectUtils.isEmpty(feeDetailLookupResponse)
				&& !ObjectUtils.isEmpty(feeDetailLookupResponse.getFeeDetails())) {
			var feeDetailListType = feeDetailLookupResponse.getFeeDetails();
			List<FeeDetailType> feeDetailTypeList = feeDetailListType.getFeeDetail();
			if (!feeDetailTypeList.isEmpty()) {
				List<FeeDetail> feeDetailsList = new ArrayList<>();
				for (FeeDetailType feeDetailType : feeDetailTypeList) {
					var feeDetail = new FeeDetail();
					feeDetail.setScheduleName(scheduleName);
					feeDetail.setEffectiveStartDate(feeDetailType.getEffectiveStartDate());
					feeDetail.setFee(String.valueOf(feeDetailType.getFee()));
					feeDetail.setPlaceOfService(feeDetailType.getPlaceOfService());
					feeDetail.setServiceCode(feeDetailType.getServiceCode());
					feeDetail.setModifier(feeDetailType.getModifier1());
					feeDetail.setRevenueCode(feeDetailType.getRevenueCode());
					feeDetailsList.add(feeDetail);
				}
				feeScheduleResponse.setFeeDetails(feeDetailsList);
			}

		} else {
			log.error("No data found for the FeeSchedule service in DAO for the request");
			throw new ResponseValidationException(FeeScheduleConstant.NO_MATCH_FOUND);

		}
		log.info("Successfully retrieved the Fee Details");
		return feeScheduleResponse;
	}
}