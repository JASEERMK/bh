package com.usthealthproof.eplus.hrp.feeschedule.exception;

public class RequestValidationException extends RuntimeException {

	private static final long serialVersionUID = 1745448975450898911L;


	public RequestValidationException(String message) {
		super(message);
	}

}
