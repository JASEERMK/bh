package com.usthealthproof.eplus.hrp.feeschedule.service;

import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;

@Component
public interface FeeScheduleService {
	FeeScheduleResponse getFeeDetails(FeeDetailLookupRequest request) throws ResponseValidationException;
}
