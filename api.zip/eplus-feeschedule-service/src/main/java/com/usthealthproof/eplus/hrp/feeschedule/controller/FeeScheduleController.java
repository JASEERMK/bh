package com.usthealthproof.eplus.hrp.feeschedule.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;
import com.usthealthproof.eplus.hrp.feeschedule.service.FeeScheduleService;
import com.usthealthproof.eplus.hrp.feeschedule.util.CommonUtils;
import com.usthealthproof.eplus.hrp.feeschedule.validator.FeeScheduleValidator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@RestController
@Validated
@Slf4j
@Tag(name = "Fee Schedule Service")
@SecurityRequirement(name = "Fee Schedule Service")
public class FeeScheduleController {

	@Autowired
	private FeeScheduleService feeScheduleService;

	@Autowired
	private FeeScheduleValidator feeScheduleValidator;

	@Operation(summary = "Retrieve the Fee details", description = "Service to obtain the detailed fee information for a specific service. The following parameters can be used to get the fee details of a service: schedule name, service code, place of service code, modifier code and revenue code. The schedule name and service code are the required felds among these. Furthermore, we can use the place of service code, modifier code and revenue code as parameters however we see appropriate; it is entirely optional.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Fee Schedule Response", content = {
					@Content(schema = @Schema(implementation = FeeScheduleResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/v1/feelookup/fee", produces = { MediaType.APPLICATION_JSON_VALUE })
	public FeeScheduleResponse getFeeSchedule(
			@Parameter(description = "Schedule Name", required = true) @RequestParam(value = "scheduleName") @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: scheduleName is not in valid format") String scheduleName,
			@Parameter(description = "Place of service code") @RequestParam(value = "placeOfServiceCode", required = false) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: placeOfServiceCode is not in valid format") String placeOfServiceCode,
			@Parameter(description = "Service code") @RequestParam(value = "serviceCode") @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: serviceCode is not in valid format") String serviceCode,
			@Parameter(description = "Modifier code") @RequestParam(value = "modifierCode", required = false) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: modifierCode is not in valid format") String modifierCode,
			@Parameter(description = "Revenue code") @RequestParam(value = "revenueCode", required = false) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: revenueCode is not in valid format") String revenueCode)
			throws ResponseValidationException {
		log.info("Inside getFeeSchedule() of Controller class");
		log.debug(
				"Inside getFeeSchedule() of Controller class and the requests are : scheduleName : {}, placeOfServiceCode : {}, serviceCode : {}, modifierCode : {}, revenueCode : {}",
				scheduleName, placeOfServiceCode, serviceCode, modifierCode, revenueCode);

		feeScheduleValidator.validateFeeScheduleRequest(scheduleName, serviceCode);
		return feeScheduleService
				.getFeeDetails(CommonUtils.getFeeScheduleRequest(scheduleName, placeOfServiceCode, serviceCode, modifierCode, revenueCode));
	}

}
