package com.usthealthproof.eplus.hrp.feeschedule.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "scheduleName", "effectiveStartDate", "fee", "placeOfService", "serviceCode", "modifier",
		"revenueCode" })
@Data
@Schema(description = "Wrapper class for fee details")
public class FeeDetail implements Serializable {

	private static final long serialVersionUID = 2450611145199225767L;
	@Schema(description = "Schedule Name")
	@JsonProperty("scheduleName")
	private String scheduleName;

	@Schema(description = "Effective Start Date")
	@JsonProperty("effectiveStartDate")
	private String effectiveStartDate;

	@Schema(description = "Fee")
	@JsonProperty("fee")
	private String fee;

	@Schema(description = "Place of Service")
	@JsonProperty("placeOfService")
	private String placeOfService;

	@Schema(description = "Service Code")
	@JsonProperty("serviceCode")
	private String serviceCode;

	@Schema(description = "Modifier")
	@JsonProperty("modifier")
	private String modifier;

	@Schema(description = "Revenue Code")
	@JsonProperty("revenueCode")
	private String revenueCode;

}
