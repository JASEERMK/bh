package com.usthealthproof.eplus.hrp.feeschedule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@JsonPropertyOrder({ "feeDetails", "problemDetails", "requestId" })
@Data
@Schema(description = "Response class containing fee schedule details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FeeScheduleResponse implements Serializable {

	private static final long serialVersionUID = -6056535150082018357L;
	@Schema(description = "Fee details")
	@JsonProperty("feeDetails")
	private List<FeeDetail> feeDetails = null;

}
