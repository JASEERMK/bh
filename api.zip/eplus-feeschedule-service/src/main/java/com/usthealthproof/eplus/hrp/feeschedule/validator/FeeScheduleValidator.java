package com.usthealthproof.eplus.hrp.feeschedule.validator;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.hrp.feeschedule.constant.FeeScheduleConstant;
import com.usthealthproof.eplus.hrp.feeschedule.exception.RequestValidationException;

@Component
@Slf4j
public class FeeScheduleValidator {

	public void validateFeeScheduleRequest(String scheduleName, String serviceCode) throws RequestValidationException {
		log.info("Inside validateFeeScheduleRequest() of FeeScheduleValidator class");
		
		if (StringUtils.isBlank(scheduleName)) {
			throw new RequestValidationException(FeeScheduleConstant.SCHEDULE_NAME_MANDATORY);
		}
		if (StringUtils.isBlank(serviceCode)) {
			throw new RequestValidationException(FeeScheduleConstant.SERVICE_CODE_MANDATORY);
		}
	}
}
