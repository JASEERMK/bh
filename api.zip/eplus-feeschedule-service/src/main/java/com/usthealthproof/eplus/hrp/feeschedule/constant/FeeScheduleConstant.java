package com.usthealthproof.eplus.hrp.feeschedule.constant;

public class FeeScheduleConstant {

	private FeeScheduleConstant() {
	}

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String SCHEDULE_NAME_MANDATORY = "ScheduleName cannot be Null or Empty";
	public static final String SERVICE_CODE_MANDATORY = "ServiceCode cannot be Null or Empty";
	public static final String NO_MATCH_FOUND = "No data found";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";


}
