package com.usthealthproof.eplus.hrp.feeschedule.exception;

import com.usthealthproof.eplus.hrp.feeschedule.constant.FeeScheduleConstant;
import com.usthealthproof.eplus.hrp.feeschedule.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.feeschedule.model.ProblemDetails;
import com.usthealthproof.eplus.hrp.feeschedule.util.CommonUtils;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
@Slf4j
public class FeeScheduleExceptionHandler {

	@Autowired
	private CommonUtils commonUtils;


	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> invalidRequestHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException  Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getMessage(), FeeScheduleConstant.FAILURE), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ResponseValidationException.class)
	public final ResponseEntity<ErrorResponse> notFoundException(ResponseValidationException ex, WebRequest request) {
		log.error("ResponseValidationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getMessage(), FeeScheduleConstant.SUCCESS), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(FeeScheduleConstant.EXCEPTION_MESSAGE, FeeScheduleConstant.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Exception Handler for ConstraintViolationException types
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse> handleconstraintViolationException(ConstraintViolationException ex, WebRequest request) {
		log.error("ConstraintViolationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		List<String> errorMessage = new ArrayList<>();
		ex.getConstraintViolations().forEach(cv -> errorMessage.add(cv.getMessage()));
		return new ResponseEntity<>(setErrorDetailsAsList(errorMessage, FeeScheduleConstant.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling Missing mandatory fields in the request
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<ErrorResponse> missingServletRequestParameterException(MissingServletRequestParameterException ex,
																					   WebRequest request) {
		log.error("MissingServletRequestParameterException Caught. Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(setErrorDetails(ex.getMessage(),FeeScheduleConstant.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling the invalid URL's
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoResourceFoundException.class)
	public final ResponseEntity<ErrorResponse> noResourceFoundException(NoResourceFoundException ex, WebRequest request) {
		log.error("NoResourceFoundException Caught.  Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(setErrorDetails(FeeScheduleConstant.INVALID_REQUEST_URL, FeeScheduleConstant.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Common Method for the Util function for setting the error details
	 */
	private ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(commonUtils.createProblemDetails(message, status));
		return errorResponse;
	}

	/**
	 * Common Method for the error details having list of error messages
	 * 
	 * @param list
	 * @param status
	 * @return
	 */
	private ErrorResponse setErrorDetailsAsList(List<String> list, String status) {
		log.info("Inside setErrorDetailsAsList() in FeeScheduleExceptionHandler class");
		
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(list);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}
}
