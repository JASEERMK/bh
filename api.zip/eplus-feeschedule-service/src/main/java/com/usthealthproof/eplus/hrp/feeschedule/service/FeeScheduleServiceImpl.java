package com.usthealthproof.eplus.hrp.feeschedule.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.dao.FeeScheduleDao;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;

@Service
public class FeeScheduleServiceImpl implements FeeScheduleService {

	@Autowired
	private FeeScheduleDao feeScheduleDao;

	@Override
	public FeeScheduleResponse getFeeDetails(FeeDetailLookupRequest request) throws ResponseValidationException {
		return feeScheduleDao.getFeeDetails(request);
	}

}
