package com.usthealthproof.eplus.hrp.feeschedule.util;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.model.ProblemDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
@ExtendWith(MockitoExtension.class)
public class CommonUtilsTest {
    @Mock
    Logger log;
    @InjectMocks
    CommonUtils commonUtils;
    ProblemDetails problemDetails = new ProblemDetails();


    @Test
    void testCreateProblemDetails() {
        // given
        String scheduleName = "Schedule1";
        String placeOfServiceCode = "POS1";
        String serviceCode = "Service1";
        String modifierCode = "Modifier1";
        String revenueCode="0450";

        // when
        FeeDetailLookupRequest result = CommonUtils.getFeeScheduleRequest(scheduleName, placeOfServiceCode, serviceCode, modifierCode,revenueCode);

        // then
        assertEquals(scheduleName, result.getScheduleName());
        assertEquals(placeOfServiceCode, result.getPlaceOfServiceCode());
        assertEquals(serviceCode, result.getServiceCode());
        assertEquals(modifierCode, result.getModifierCode());
        assertEquals(revenueCode, result.getRevenueCode());

        //test for serviceCode is blank
        serviceCode ="";
        result = CommonUtils.getFeeScheduleRequest(scheduleName, placeOfServiceCode, serviceCode, modifierCode,revenueCode);

        assertEquals(scheduleName, result.getScheduleName());
        assertEquals(placeOfServiceCode, result.getPlaceOfServiceCode());
        assertNull(result.getServiceCode()); // Expecting null as serviceCode is blank
        assertEquals(modifierCode, result.getModifierCode());
        assertEquals(revenueCode, result.getRevenueCode());
    }

    @BeforeEach
    void setUp() {
        problemDetails.setErrors(Arrays.asList("Error message"));
        problemDetails.setStatus("");

    }

    @Test
    void testCreateProblemDetails1() {
        ProblemDetails result = commonUtils.createProblemDetails("Error message","");
        // then - verify the output
        Assertions.assertEquals(problemDetails.getErrors(), result.getErrors());
        Assertions.assertEquals(problemDetails.getStatus(), result.getStatus());
    }

}
