package com.usthealthproof.eplus.hrp.feeschedule.constant;
import org.springframework.stereotype.Component;

@Component
public class FeeScheduleConstantTest {
    public static final String SCHEDULE_NAME = "Ambulance";
    public static final String EFFECTIVE_START_DATE = "2019-01-01";
    public static final String FEE = "352.78";
    public static final String PLACE_OF_SERVICE = null;
    public static final String SERVICE_CODE = "A0426";
    public static final String MODIFIER = null;
    public static final String REVENUE_CODE = null;
    public static final String ENDPOINT_FEE_SCHEDULE = "/v1/feelookup/fee";
}
