package com.usthealthproof.eplus.hrp.feeschedule.controller;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeDetail;
import com.usthealthproof.eplus.hrp.feeschedule.service.FeeScheduleService;
import com.usthealthproof.eplus.hrp.feeschedule.util.CommonUtils;
import com.usthealthproof.eplus.hrp.feeschedule.validator.FeeScheduleValidator;
import com.usthealthproof.eplus.hrp.feeschedule.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;
import com.usthealthproof.eplus.hrp.feeschedule.constant.FeeScheduleConstantTest;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(FeeScheduleController.class)
public class FeeScheduleControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private FeeScheduleService feeScheduleService;
    @MockBean
    private FeeScheduleValidator feeScheduleValidator;
    @MockBean
    CommonUtils commonUtils;
    FeeScheduleResponse feeScheduleResponse = new FeeScheduleResponse();
    List<FeeDetail> feeDetails = new ArrayList<>();
    FeeDetailLookupRequest feeDetailLookupRequest = new FeeDetailLookupRequest();

    @BeforeEach
    void setUp() {
        FeeDetail feeDetail = new FeeDetail();
        feeDetail.setScheduleName(FeeScheduleConstantTest.SCHEDULE_NAME);
        feeDetail.setEffectiveStartDate(FeeScheduleConstantTest.EFFECTIVE_START_DATE);
        feeDetail.setFee(FeeScheduleConstantTest.FEE);
        feeDetail.setPlaceOfService(FeeScheduleConstantTest.PLACE_OF_SERVICE);
        feeDetail.setServiceCode(FeeScheduleConstantTest.SERVICE_CODE);
        feeDetail.setModifier(FeeScheduleConstantTest.MODIFIER);
        feeDetail.setRevenueCode(FeeScheduleConstantTest.REVENUE_CODE);

        feeDetails = List.of(feeDetail);
        feeScheduleResponse.setFeeDetails(feeDetails);
    }

    @AfterEach
    void tearDown() {
        feeScheduleResponse = null;
    }

    @Test
    @DisplayName("JUnit test for RequestValidationException")
    void testRequestValidationException() throws Exception {
        // when - action or the behaviour
        doThrow(RequestValidationException.class).when(feeScheduleValidator).validateFeeScheduleRequest(FeeScheduleConstantTest.SCHEDULE_NAME, FeeScheduleConstantTest.SERVICE_CODE);
        // then - verify the output
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(FeeScheduleConstantTest.SCHEDULE_NAME, FeeScheduleConstantTest.SERVICE_CODE));
    }

    @Test
    @DisplayName("JUnit test for Validating Schedule name and Service code")
    void testValidatingScheduleNameAndServiceCode() throws Exception {
        // when - action or the behaviour
        doThrow(RequestValidationException.class).when(feeScheduleValidator).validateFeeScheduleRequest(null, null);
        // then - verify the output
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(null, null));
    }

    @Test
    @WithMockUser(value = "user")
    public void testValidInputFeeDetail1() throws Exception {
        // Given
        String scheduleName = "Ambulance";
        String serviceCode = "A0426";

        // Mocking service response
        FeeScheduleResponse mockResponse = new FeeScheduleResponse();
        // Populate mockResponse with mock data

        given(feeScheduleService.getFeeDetails(any())).willReturn(mockResponse);

        // When
        ResultActions result = mockMvc.perform(get("/v1/feelookup/fee")
                .param("scheduleName", scheduleName)
                .param("serviceCode", serviceCode));

        // Then
        result.andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getFeeScheduleResponse - ValidInput")
    void testValidInputFeeDetail() throws Exception {
        // given - precondition or setup
        feeDetailLookupRequest.setScheduleName(FeeScheduleConstantTest.SCHEDULE_NAME);
        feeDetailLookupRequest.setServiceCode(FeeScheduleConstantTest.SERVICE_CODE);
        given(feeScheduleService.getFeeDetails(feeDetailLookupRequest)).willReturn(feeScheduleResponse);
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(FeeScheduleConstantTest.ENDPOINT_FEE_SCHEDULE)
                .param("scheduleName", FeeScheduleConstantTest.SCHEDULE_NAME).param("serviceCode", FeeScheduleConstantTest.SERVICE_CODE));
        System.out.println(response.andDo(print()));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isOk());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getProviderContracts - Invalid Input Param")
    void testInvalidInputParam() throws Exception {
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(FeeScheduleConstantTest.ENDPOINT_FEE_SCHEDULE));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getFeeSchedule - Invalid Pattern")
    void testInvalidPattern() throws Exception {
        // Given - Setup
        String invalidServiceCode = "A0426>"; // Invalid service code pattern
        String invalidScheduleName = "Ambulancee"; // Invalid schedule name pattern

        // When - Action
        ResultActions response = mockMvc.perform(get(FeeScheduleConstantTest.ENDPOINT_FEE_SCHEDULE)
                .param("scheduleName", invalidScheduleName)
                .param("serviceCode", invalidServiceCode));

        // Then - Verification
        response.andDo(print())
                .andExpect(status().isBadRequest());// Assuming invalid pattern results in a Bad Request status


    }

    @Test
    @WithMockUser(value = "user")
    public void testValidInputFeeDetail11() throws Exception {
        // Given
        String scheduleName = "Ambulance";
        String serviceCode = "A0426";

        FeeScheduleResponse mockResponse = new FeeScheduleResponse();
        List<FeeDetail> feeDetails = new ArrayList<>();
        feeDetails.add(new FeeDetail()); // dummy fee detail
        mockResponse.setFeeDetails(feeDetails);

        given(feeScheduleService.getFeeDetails(any())).willReturn(mockResponse);

        // When
        ResultActions result = mockMvc.perform(get("/v1/feelookup/fee")
                .param("scheduleName", scheduleName)
                .param("serviceCode", serviceCode));

        // Then
        result.andExpect(status().isOk())
                .andExpect(jsonPath("$.feeDetails", hasSize(1))); // Assert that the response contains one fee detail
    }

    @Test
    @DisplayName("Test with null values for required parameters")
    public void testNullParameters() {

        assertThrows(NullPointerException.class, () -> {
            FeeScheduleController feeScheduleController = new FeeScheduleController();
            feeScheduleController.getFeeSchedule(null, "validPlace", "validService", "validModifier", "validRevenue");
        });
    }
}