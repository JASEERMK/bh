package com.usthealthproof.eplus.hrp.feeschedule.exception;

import com.usthealthproof.eplus.hrp.feeschedule.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.feeschedule.util.CommonUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class FeeScheduleExceptionHandlerTest {

    @InjectMocks
    FeeScheduleExceptionHandler handler;

    @Mock
    WebRequest webRequest;

    @Mock
    private CommonUtils commonUtils;

    @Mock
    HttpMethod httpMethod;


    @Test
    void testInvalidRequestHandler()
    {
        ResponseEntity<ErrorResponse> errorResponse = handler.invalidRequestHandler(new RequestValidationException("message"), webRequest);
        assertThat(errorResponse).isNotNull();
    }

    @Test
    void testNotFoundExceptionHandler()
    {
        ResponseEntity<ErrorResponse> errorResponse = handler.notFoundException(new ResponseValidationException("message"), webRequest);
        assertThat(errorResponse).isNotNull();
    }

    @Test
    void testNoResourceFoundExceptionHandler()
    {
        ResponseEntity<ErrorResponse> errorResponse = handler.noResourceFoundException(new NoResourceFoundException(httpMethod,"/v1/feelookup/f"), webRequest);
        assertThat(errorResponse).isNotNull();
    }


}