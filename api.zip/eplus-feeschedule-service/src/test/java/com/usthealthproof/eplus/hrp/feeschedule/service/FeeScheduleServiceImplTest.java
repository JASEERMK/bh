package com.usthealthproof.eplus.hrp.feeschedule.service;

import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.usthealthproof.eplus.hrp.feeschedule.dao.FeeScheduleDao;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class FeeScheduleServiceImplTest {
    @Mock
    FeeScheduleDao feeScheduleDao;
    @InjectMocks
    FeeScheduleServiceImpl feeScheduleServiceImpl;
    FeeScheduleResponse feeScheduleResponse = new FeeScheduleResponse();


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFeeDetails() {
        when(feeScheduleDao.getFeeDetails(any())).thenReturn(new FeeScheduleResponse());

        FeeScheduleResponse result = feeScheduleServiceImpl.getFeeDetails(new FeeDetailLookupRequest());
        Assertions.assertEquals(new FeeScheduleResponse(), result);
    }

}