package com.usthealthproof.eplus.hrp.feeschedule.dao;

import com.healthedge.FeeDetailLookupPortType;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailListType;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupRequest;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailLookupResponse;
import com.healthedge.connector.schema.feedetaillookup.FeeDetailType;
import com.usthealthproof.eplus.hrp.feeschedule.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.feeschedule.model.FeeScheduleResponse;
import jakarta.xml.bind.JAXBElement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import javax.xml.namespace.QName;
import java.math.BigDecimal;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class FeeScheduleDaoImplTest {
    @Mock
    private FeeDetailLookupPortType feeDetailLookupPortType;
    @InjectMocks
    private FeeScheduleDaoImpl feeScheduleDao;

    private FeeDetailLookupRequest validRequest;

    @Mock
    private FeeDetailLookupResponse feeDetailLookupResponse;

    @Mock
    WebServiceTemplate webServiceTemplate;

    @BeforeEach
    void setUp() {
        validRequest = new FeeDetailLookupRequest();
        validRequest.setScheduleName("ScheduleName");
    }
    
    @Test
    void testGetFeeDetails_NullRequest() throws IllegalArgumentException {
        // Given
        // Null request

        // When
        assertThrows(NullPointerException.class, () -> {
            feeScheduleDao.getFeeDetails(null); // Pass a null request
        });
    }

    @Test
    public void testGetFeeDetailResponse_WithEmptyResponse() {
        when(feeDetailLookupResponse.getFeeDetails()).thenReturn(null);

        // Assert
        assertThrows(ResponseValidationException.class, () -> {
            // Act
            feeScheduleDao.getFeeDetailResponse(feeDetailLookupResponse, "ScheduleName");
        });
    }


    @Test
    void testGetFeeDetails()
    {

        JAXBElement<FeeDetailLookupResponse> jaxbElement = new JAXBElement<>(
                new QName("http://www.healthedge.com/connector/schema/feedetaillookup", "getBenefits"),
                FeeDetailLookupResponse.class,
                feeDetailLookupResponse
        );


        FeeDetailListType feeDetailListType = mock(FeeDetailListType.class);
        FeeDetailType feeDetailType = mock(FeeDetailType.class);
        when(feeDetailType.getRevenueCode()).thenReturn("ScheduleName");
        when(feeDetailType.getEffectiveStartDate()).thenReturn("2024-05-14");
        when(feeDetailType.getFee()).thenReturn(BigDecimal.valueOf(100.0));
        when(feeDetailType.getPlaceOfService()).thenReturn("Place");
        when(feeDetailType.getServiceCode()).thenReturn("ServiceCode");
        when(feeDetailType.getModifier1()).thenReturn("Modifier");
        when(feeDetailType.getRevenueCode()).thenReturn("RevenueCode");
        when(feeDetailListType.getFeeDetail()).thenReturn(Collections.singletonList(feeDetailType));
        when(feeDetailLookupResponse.getFeeDetails()).thenReturn(feeDetailListType);

        when(webServiceTemplate.marshalSendAndReceive(
                any(JAXBElement.class),
                any(SoapActionCallback.class)))
                .thenReturn(jaxbElement);

        FeeScheduleResponse result=feeScheduleDao.getFeeDetails(validRequest);
        assertNotNull(result);
        assertEquals(1, result.getFeeDetails().size());
        assertEquals("ScheduleName", result.getFeeDetails().get(0).getScheduleName());

    }

}
