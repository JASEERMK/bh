package com.usthealthproof.eplus.hrp.feeschedule.validator;

import com.usthealthproof.eplus.hrp.feeschedule.constant.FeeScheduleConstantTest;
import com.usthealthproof.eplus.hrp.feeschedule.exception.RequestValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class FeeScheduleValidatorTest {
    @Mock
    Logger log;
    @InjectMocks
    FeeScheduleValidator feeScheduleValidator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Junit Test case to validate Request param")
    void testValidateFeeScheduleRequest() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(null, null));
    }

    @Test
    void testValidateFeeScheduleRequest_NullScheduleName() {
        // Given
        String scheduleName = null;
        String serviceCode = "A0426";

        // When and Then
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(scheduleName, serviceCode));
    }

    @Test
    void testValidateFeeScheduleRequest_NullServiceCode() {
        // Given
        String scheduleName = "Ambulance";
        String serviceCode = null;

        // When and Then
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(scheduleName, serviceCode));
    }

    @Test
    void testValidateFeeScheduleRequest_No() {
        // When and Then
        assertThrows(RequestValidationException.class, () -> feeScheduleValidator.validateFeeScheduleRequest(null, ""));
    }

    @Test
    void testValidateFeeScheduleRequest_WithValues() {

        String expectedScheduleName = "Ambulance";
        String expectedServiceCode = "A0426";

        // Then

        assertEquals(expectedScheduleName, FeeScheduleConstantTest.SCHEDULE_NAME);
        assertEquals(expectedServiceCode, FeeScheduleConstantTest.SERVICE_CODE);
    }

    @Test
    public void testValidateFeeScheduleRequest_blankServiceCode() {
        // Given
        FeeScheduleValidator validator = new FeeScheduleValidator();

        // When serviceCode is blank
        String ScheduleName = "TestSchedule";
        String ServiceCode = "";

        // Then
        assertThrows(RequestValidationException.class, () -> {
            validator.validateFeeScheduleRequest(ScheduleName, ServiceCode);
        });
    }
}
