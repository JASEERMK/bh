package com.usthealthproof.eplus.hrp.feeschedule.util;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomNamespacePrefixMapperTest {

    @Test
    void testGetPreferredPrefix()
    {
        CustomNamespacePrefixMapper mapper = new CustomNamespacePrefixMapper();
        ReflectionTestUtils.setField(mapper, "nameSpacePrefix", "feed");
        ReflectionTestUtils.setField(mapper, "nameSpace", "http://www.healthedge.com/connector/schema/feedetaillookup");

        String prefix = mapper.getPreferredPrefix("http://www.healthedge.com/connector/schema/feedetaillookup", "default", true);
        assertEquals("feed", prefix);

         // Test unknown namespace
         prefix = mapper.getPreferredPrefix("http://www.healthedge.com/", "default", true);
         assertEquals("default", prefix);
    }

}