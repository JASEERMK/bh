package com.usthealthproof.eplus.ext.documentsearch.controller;

import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import com.usthealthproof.eplus.ext.documentsearch.service.MLEInvoiceDocumentSearchService;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
@Slf4j
@SecurityRequirement(name = "Document Zelis Service")
public class MLEInvoiceDocumentSearchController {

	@Autowired
	private Validator validator;
	@Autowired
	private MLEInvoiceDocumentSearchService mleInvoiceDocumentSearchService;
	@Operation(summary = "MLE Invoice Document Search", method = "GET", description =
			"The service fetches the MLE Invoice document from Print-Vendor's repository and returns it as a Base64 encoded string. The request fields are document index, start date and end date; all should be filled out as required.", responses = {
			@ApiResponse(responseCode = "200", description = "Document details", content = {
					@Content(schema = @Schema(implementation = DocumentViewResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid DocumentId", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/v1/member/document/mleinvoice", produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<MLEInvoiceDocumentResponse>> mleInvoiceDocument(
			@Parameter(description = "Document Index") @RequestParam(value = "documentIndex", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: documentIndex is not in valid format") String documentIndex,
			@Parameter(description = "Starting date range of searching documents") @RequestParam(value = "startDate", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: startDate is not in valid format") String startDate,
			@Parameter(description = "Ending date range of searching documents") @RequestParam(value = "endDate", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: endDate is not in valid format") String endDate){
		log.info("Inside documentSearch() in Controller class");
		log.debug("Received the request with documentIndex: {}, startDate: {}, endDate: {}",documentIndex, startDate, endDate );
		validator.validateMLEInvoiceDocumentRequest(startDate, endDate, documentIndex);
		HttpHeaders headers = createResponseHeaders();
		return new ResponseEntity<>(mleInvoiceDocumentSearchService.mleInvoiceDocumentCall(documentIndex,startDate, endDate), headers, HttpStatus.OK);
	}
	private HttpHeaders createResponseHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		return headers;
	}
}
