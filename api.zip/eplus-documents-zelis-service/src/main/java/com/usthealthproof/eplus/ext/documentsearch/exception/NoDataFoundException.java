package com.usthealthproof.eplus.ext.documentsearch.exception;

public class NoDataFoundException extends RuntimeException {

	private static final long serialVersionUID = -618451776883790496L;

	public NoDataFoundException(String message) {
		super(message);
	}
	public NoDataFoundException(Throwable cause) {
		super(cause);}
	public NoDataFoundException(String message, Throwable cause) {
		super(message, cause);
	}}