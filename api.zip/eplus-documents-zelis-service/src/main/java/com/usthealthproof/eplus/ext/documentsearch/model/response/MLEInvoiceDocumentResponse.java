package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MLEInvoiceDocumentResponse {
	@Schema(description = "DocID assigned to document in print vendor's repository")
	private String docID;
	@Schema(description = "PdfFileKey assigned to document in print vendor's repository")
	private String pdfFileKey;


}
