package com.usthealthproof.eplus.ext.documentsearch.service;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public interface MLEInvoiceDocumentSearchService {
	List<MLEInvoiceDocumentResponse> mleInvoiceDocumentCall(String documentIndex, String startDate, String endDate)throws
			ResponseValidationException;

}
