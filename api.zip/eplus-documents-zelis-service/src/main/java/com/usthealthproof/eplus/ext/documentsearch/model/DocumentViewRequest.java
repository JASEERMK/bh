package com.usthealthproof.eplus.ext.documentsearch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentViewRequest {

	@JsonProperty("pdfFileKey")
	private String pdfFileKey;

}
