package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response objects containing list of documents pertaining to a member")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentEOBResponse {

	@Schema(description = "The type provided when the document was created. eg: 'application/pdf'")
	private String type;

	@Schema(description = "EOB data or details returned in response")
	private String file;
	
	@Schema(description = "Response Status: SUCCESS/FAILURE/ERROR")
	private String status;


}
