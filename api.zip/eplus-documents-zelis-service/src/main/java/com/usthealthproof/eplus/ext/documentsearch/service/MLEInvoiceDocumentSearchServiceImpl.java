package com.usthealthproof.eplus.ext.documentsearch.service;

import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisRequestBuilder;
import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisResponseBuilder;
import com.usthealthproof.eplus.ext.documentsearch.dao.MLEInvoiceDocumentSearchDao;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import lombok.extern.slf4j.Slf4j;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.tempuri.DocumentSearchDocumentFormat001V1;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class MLEInvoiceDocumentSearchServiceImpl implements MLEInvoiceDocumentSearchService{
	@Autowired
	private DocumentZelisRequestBuilder documentZelisRequestBuilder;

	@Autowired
	private DocumentZelisResponseBuilder documentZelisResponseBuilder;
	@Autowired
	MLEInvoiceDocumentSearchDao mleInvoiceDocumentSearchDao;
	@Override
	public List<MLEInvoiceDocumentResponse> mleInvoiceDocumentCall(String documentIndex, String startDate, String endDate) throws
			ResponseValidationException {
		log.info("Inside mleInvoiceDocumentCall() in Service class");
		List<MLEInvoiceDocumentResponse> documentmleInvoiceResponseList = new ArrayList<>();
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1 = documentZelisRequestBuilder.mleInvoiceDocumentCall(
					documentIndex,startDate, endDate);
			DocSearchFormat001ResultList docSearchFormat001ResultList = mleInvoiceDocumentSearchDao.mleInvoiceDocumentResultResponse(documentSearchDocumentFormat001V1);
			documentmleInvoiceResponseList = documentZelisResponseBuilder.getMLEInvoiceDocsZelisResponse(
					docSearchFormat001ResultList);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("mleInvoiceDocumentCall service Execution time of external service: {}ms",
					endServiceRequestTime - startServiceRequestTime);
		} catch (NoDataFoundException e) {
			log.error("NoDataFoundException occurred for the mleInvoiceDocumentCall service");
			throw e;
		} catch (Exception e) {
			log.info("Exception occurred for the mleInvoiceDocumentCall service");
			throw new ResponseValidationException(e);
		}
		log.info("Successfully received the mleInvoiceDocumentCall");
		return documentmleInvoiceResponseList;
	}
}
