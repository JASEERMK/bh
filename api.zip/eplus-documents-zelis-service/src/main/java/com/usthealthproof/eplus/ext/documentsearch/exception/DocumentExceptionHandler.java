package com.usthealthproof.eplus.ext.documentsearch.exception;

import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class DocumentExceptionHandler {

	@Autowired
	private APIUtils apiUtils;

	/**
	 * Exception Handler for invalid requests exception
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> requestValidationHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(apiUtils.setErrorDetails(ex.getMessage(), DocumentConstants.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler to handle NoDataFound exception
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoDataFoundException.class)
	public ResponseEntity<ErrorResponse> noDataFoundExcpHandler(NoDataFoundException ex, WebRequest request) {
		log.error("NoDataFoundException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(apiUtils.setErrorDetails(ex.getMessage(), DocumentConstants.SUCCESS), HttpStatus.NOT_FOUND);
	}

	/**
	 * Exception Handler to handle global exception
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(apiUtils.setErrorDetails(DocumentConstants.EXCEPTION_OCCURRED, DocumentConstants.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Exception Handler for invalid response exception
	 * @param ex
	 * @param request
	 * @return
	 */

	@ExceptionHandler(ResponseValidationException.class)
	public ResponseEntity<ErrorResponse> responseValidationHandler(ResponseValidationException ex, HttpServletRequest request) {
		log.error("ResponseValidationException Caught : Error Message: {} and Exception: ", ex.getMessage(), ex);
		return new ResponseEntity<>(apiUtils.setErrorDetails(DocumentConstants.EXCEPTION_OCCURRED, DocumentConstants.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
