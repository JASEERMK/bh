package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response objects containing list of documents pertaining to a member")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentViewResponse {

	@Schema(description = "Unique identifier associated to document in print vendor's repository")
	private String documentId;

	@Schema(description = "EOB data or details returned in response")
	private String pdfFileString;
	
	@Schema(description = "Response Status: SUCCESS/FAILURE/ERROR")
	private String status;


}
