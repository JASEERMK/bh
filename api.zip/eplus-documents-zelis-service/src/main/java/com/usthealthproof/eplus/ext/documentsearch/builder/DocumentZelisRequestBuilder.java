package com.usthealthproof.eplus.ext.documentsearch.builder;

import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import jakarta.xml.bind.JAXBElement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.GetClaimsPdfV1;
import org.tempuri.ObjectFactory;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

@Component
@Slf4j
public class DocumentZelisRequestBuilder {

	public GetClaimsPdfV1 getPDFFileKey(String documentId) {
		log.info("Inside getPDFFileKey()");
		ObjectFactory fact = new ObjectFactory();
		GetClaimsPdfV1 getGetClaimsPdfV1 = new GetClaimsPdfV1();
		JAXBElement<String> getPDFKey = fact.createGetClaimsPdfV1TnsPdfFileKey(documentId);
		getGetClaimsPdfV1.setTnsPdfFileKey(getPDFKey);
		return getGetClaimsPdfV1;
	}

	public DocumentSearchCheckFormat001V6 documentSearch(String memberId, String uid, String documentType,String startDate, String endDate) {
		log.info("Inside documentSearch()");
		ObjectFactory fact = new ObjectFactory();
		DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6 = new DocumentSearchCheckFormat001V6();
		try {
			if(null == memberId){
				documentSearchCheckFormat001V6.setTnsEnrolleeId(
						fact.createDocumentSearchCheckFormat001V6TnsEnrolleeId(""));
			}else {
				documentSearchCheckFormat001V6.setTnsEnrolleeId(
						fact.createDocumentSearchCheckFormat001V6TnsEnrolleeId(memberId));
			}
			if(null == documentType){
				documentSearchCheckFormat001V6.setTnsDocumentType(
						fact.createDocumentSearchCheckFormat001V6TnsDocumentType(""));
			}else {
				documentSearchCheckFormat001V6.setTnsDocumentType(
						fact.createDocumentSearchCheckFormat001V6TnsEnrolleeId(documentType));
			}
			if(null == uid){
				documentSearchCheckFormat001V6.setTnsClaimNumber(
						fact.createDocumentSearchCheckFormat001V6TnsClaimNumber(""));
			}else {
				documentSearchCheckFormat001V6.setTnsClaimNumber(
						fact.createDocumentSearchCheckFormat001V6TnsEnrolleeId(uid));
			}
			documentSearchCheckFormat001V6.setTnsEndDateReleased(
					DatatypeFactory.newInstance().newXMLGregorianCalendar(endDate));
			documentSearchCheckFormat001V6.setTnsStartDateReleased(
					DatatypeFactory.newInstance().newXMLGregorianCalendar(startDate));

		} catch (DatatypeConfigurationException e) {
			throw new RequestValidationException(e);
		}
		return documentSearchCheckFormat001V6;
	}

	public DocumentSearchDocumentFormat001V1 mleInvoiceDocumentCall(String documentIndex,String startDate, String endDate) {
		log.info("Inside mleInvoiceDocumentCall()");
		ObjectFactory fact = new ObjectFactory();
		DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1 = new DocumentSearchDocumentFormat001V1();
		try {
			if(null == documentIndex){
				documentSearchDocumentFormat001V1.setTnsDocumentIndex1(
						fact.createDocumentSearchDocumentFormat001V1TnsDocumentIndex1(""));
			}else {
				documentSearchDocumentFormat001V1.setTnsDocumentIndex1(
						fact.createDocumentSearchDocumentFormat001V1TnsDocumentIndex1(documentIndex));
			}
			documentSearchDocumentFormat001V1.setTnsEndDateReleased(
					DatatypeFactory.newInstance().newXMLGregorianCalendar(endDate));
			documentSearchDocumentFormat001V1.setTnsStartDateReleased(
					DatatypeFactory.newInstance().newXMLGregorianCalendar(startDate));

		} catch (DatatypeConfigurationException e) {
			throw new RequestValidationException(e);
		}
		return documentSearchDocumentFormat001V1;
	}
}
