package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentSearchResponse {
	@Schema(description = "DocID assigned to document in print vendor's repository")
	private String docID;

	@Schema(description = "Status assigned to document in print vendor's repository")
	private String status;

	@Schema(description = "Enrolled name assigned to document in print vendor's repository")
	private String name;

	@Schema(description = "PdfFileKey assigned to document in print vendor's repository")
	private String pdfFileKey;

	@Schema(description = "Descriptive name of the Document ID extension")
	private String documentExtension;

	@Schema(description = "Descriptive name of the Document ID extension")
	private String[] claimNumbers;

}
