package com.usthealthproof.eplus.ext.documentsearch.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class EopDocumentRequest {

	@Schema(description = "Payer Claim Number", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "claimNumber")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Payer Claim Number is not in valid format")
	private String claimNumber;

	@Schema(description = "Provider TIN/EIN/SSN for EPP/Draft/ANSI835 requests", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "providerTaxId")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: taxId is not in valid format")
	private String providerTaxId;

}
