package com.usthealthproof.eplus.ext.documentsearch.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Request object wrapping Claim Document Request")
public class DocumentEOBRequest implements Serializable {

	private static final long serialVersionUID = 5916973052102595355L;

	@Schema(description = "Claim Id")
	private String claimId;
	@Schema(description = "Member Id")
	private String memberId;

}
