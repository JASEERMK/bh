package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response objects containing IdCard details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IdCardResponse {

	@Schema(description = "MIME Type")
	private String mimeType;

	@Schema(description = "Data")
	private String data;

	@Schema(description = "Response Status: SUCCESS/FAILURE/ERROR")
	private String status;

}
