package com.usthealthproof.eplus.ext.documentsearch.dao;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.springframework.stereotype.Component;
import org.tempuri.DocumentSearchCheckFormat001V6;

@Component
public interface DocumentZelisDao {
	GetPdfResult getPdfResultResponse(String pdfFileKey) throws ResponseValidationException;

	DocSearchFormat001ResultListV6 documentSearchResultResponse(DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6) throws ResponseValidationException;
}

