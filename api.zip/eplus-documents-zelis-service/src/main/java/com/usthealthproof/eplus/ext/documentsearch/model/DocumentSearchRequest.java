package com.usthealthproof.eplus.ext.documentsearch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentSearchRequest {
	@Schema(description = "Member Id")
	@JsonProperty("memberId")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: memberId is not in valid format")
	private String memberId;

	@Schema(description = "Claim number / Tax-id / unique ref number")
	@JsonProperty("uid")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: uid is not in valid format")
	private String uid;

	@Schema(description = "Type of UID passed")
	@JsonProperty("uidType")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: uidType is not in valid format")
	private String uidType;

	@Schema(description = "Three digit integer for the document type")
	@JsonProperty("documentType")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: documentType is not in valid format")
	private String documentType;

	@Schema(description = "Starting date range of searching documents", requiredMode = Schema.RequiredMode.REQUIRED)
	@JsonProperty("startDate")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: startDate is not in valid format")
	private String startDate;

	@Schema(description = "Ending date range of searching documents", requiredMode = Schema.RequiredMode.REQUIRED)
	@JsonProperty("endDate")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: endDate is not in valid format")
	private String endDate;
}
