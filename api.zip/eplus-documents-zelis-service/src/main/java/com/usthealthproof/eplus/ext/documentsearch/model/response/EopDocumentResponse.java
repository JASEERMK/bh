package com.usthealthproof.eplus.ext.documentsearch.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response object for get EOP Document Service")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EopDocumentResponse {
	@Schema(description = "Base64 encoded PDF content")
	private String pdfString;
}

