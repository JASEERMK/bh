package com.usthealthproof.eplus.ext.documentsearch.dao;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.IRedCardServices;

@Repository
@Slf4j
public class DocumentZelisDaoImpl implements DocumentZelisDao {
	@Value("${documentzelis.service.username}")
	private String username;
	@Value("${documentzelis.service.password}")
	private String password;
	@Autowired
	private IRedCardServices iRedCardServices;

	@Autowired
	private APIUtils apiUtils;

	public GetPdfResult getPdfResultResponse(String pdfFileKey) throws ResponseValidationException {
		log.info("Inside getPdfResultResponse()");
		GetPdfResult getPdfResultResponse = null;
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			getPdfResultResponse = iRedCardServices.getClaimsPdfV1(username, password, pdfFileKey);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info(DocumentConstants.EXECUTION_TIME,
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully retrieved PDF result for pdfFileKey");
		} catch (Exception ex) {
			log.error("Failed to receive the Zelis document view service in DAO");
			throw ex;
		}
		return getPdfResultResponse;
	}

	public DocSearchFormat001ResultListV6 documentSearchResultResponse(
			DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6) throws ResponseValidationException {
		log.info("Inside documentSearchResultResponse() in DAO class");
		DocSearchFormat001ResultListV6 docSearchFormat001ResultListV6 = null;
		apiUtils.updateDocumentSearchInputRequest(documentSearchCheckFormat001V6);
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			docSearchFormat001ResultListV6 = iRedCardServices.documentSearchCheckFormat001V6(username, password,
					documentSearchCheckFormat001V6.getSearchType(), documentSearchCheckFormat001V6.isTnsShowPurgedReleased(),
					documentSearchCheckFormat001V6.getTnsStartDateReleased(), documentSearchCheckFormat001V6.getTnsEndDateReleased(),
					documentSearchCheckFormat001V6.getTnsClaimNumber().getValue(),
					documentSearchCheckFormat001V6.getTnsDocumentType().getValue(),
					documentSearchCheckFormat001V6.getTnsEnrolleeId().getValue());
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the external service - HRP WS call in ms: {}",
					endServiceRequestTime - startServiceRequestTime);
		} catch (Exception ex) {
			log.error("Failed to receive the Document-Zelis service in DAO");
			throw ex;
		}
		log.info("Successfully generated documentSearchResultResponse service !!!");
		return docSearchFormat001ResultListV6;
	}
}
