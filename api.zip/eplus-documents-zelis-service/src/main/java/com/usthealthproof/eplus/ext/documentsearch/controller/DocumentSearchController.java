package com.usthealthproof.eplus.ext.documentsearch.controller;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.EopDocumentRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.IDcardViewRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentEOBResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentSearchResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.EopDocumentResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.IdCardResponse;
import com.usthealthproof.eplus.ext.documentsearch.service.DocumentSearchService;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Document Zelis Service")
@RestController
@Slf4j
@SecurityRequirement(name = "Document Zelis Service")
public class DocumentSearchController {

	@Autowired
	private DocumentSearchService documentSearchService;
	@Autowired
	private Validator validator;

	/**
	 * Rest service for getting EOB document by providing ClaimId
	 *
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Retrieves EOB Document", method = "POST", description = "The service fetches the Explanation of Benefits (EOB) letter and returns it as a Base64 encoded string. The request fields are claim ID and Member Id; both should be filled out as required.", responses = {
			@ApiResponse(responseCode = "200", description = "Explanation of Benefits(EOB) document details", content = {
					@Content(schema = @Schema(implementation = DocumentEOBResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid ClaimId", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/v1/docs/member/eob", produces = "application/json")
	@ResponseBody
	public ResponseEntity<DocumentEOBResponse> getEOBDocumentByClaimId(
			@Parameter(description = "Claim ID") @RequestParam(value = "claimId", required = true) final @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: claimId is not in valid format") String claimId,
			@Parameter(description = "Member ID") @RequestParam(value = "memberId", required = true) final @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: memberId is not in valid format") String memberId,
			@Parameter(hidden = true) HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getEOBDocumentByClaimId() in Controller class");
		log.debug("Received the request with claimId: {} and memberId: {}", claimId, memberId);
		validator.validateEOBDocumentRequest(claimId, memberId);
		HttpHeaders headers = createResponseHeaders();
		return new ResponseEntity<>(documentSearchService.getEOBDocumentByClaim(claimId, memberId.strip(), httpServletRequest),
				headers, HttpStatus.OK);
	}

	@Operation(summary = "Retrieves EOP Document", method = "POST", description = "This service fetches the Explanation of Payment (EOP) document and returns it as a Base64 encoded string.", responses = {
			@ApiResponse(responseCode = "200", description = "Base64 Encoded String of EOP Document", content = {
					@Content(schema = @Schema(implementation = EopDocumentResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid ClaimId", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@PostMapping(value = "/v1/docs/provider/eop", produces = "application/json")
	@ResponseBody
	public ResponseEntity<EopDocumentResponse> getEOPDocument(@Valid @RequestBody EopDocumentRequest eopDocumentRequestBody,
			HttpServletRequest httpServletRequest) throws ResponseValidationException, Exception {
		log.info("Inside getEOPDocument() in Controller class");
		log.debug("Received the request with {}", eopDocumentRequestBody);

		validator.validateEOPDocumentRequest(eopDocumentRequestBody.getClaimNumber(), eopDocumentRequestBody.getProviderTaxId());
		HttpHeaders headers = createResponseHeaders();
		return new ResponseEntity<>(documentSearchService.getEOPDocument(eopDocumentRequestBody.getClaimNumber(),
				eopDocumentRequestBody.getProviderTaxId().strip(), httpServletRequest), headers, HttpStatus.OK);
	}

	/**
	 * Rest service for getting Member IdCard by providing MemberId
	 *
	 * @param iDcardViewRequest
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Retrieves Member's ID Card", method = "POST", description = "This service fetches the Member Id Card details from Print-Vendor's repository and returns it as a Base64 encoded string. The following search parameters can be used to retrieve the ID card details: member ID, page and plan type. The member ID and page are the required fields among these. The remaining field is optional; based on their availability, they will be used as filters.", responses = {
			@ApiResponse(responseCode = "200", description = "Member's ID Card details", content = {
					@Content(schema = @Schema(implementation = IdCardResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid input", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@PostMapping(value = "/v1/docs/member/idcard", produces = "application/json")
	@ResponseBody
	public ResponseEntity<IdCardResponse> getIdCardById(@RequestBody IDcardViewRequest iDcardViewRequest,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getIdCardById() in Controller class");
		log.debug("Received the request with {}", iDcardViewRequest);

		validator.validateIdCardRequest(iDcardViewRequest.getMemberId(), iDcardViewRequest.getPage(),iDcardViewRequest.getPlanType());
		HttpHeaders headers = createResponseHeaders();
		return new ResponseEntity<>(documentSearchService.getDocumentByIdByZelisCall(iDcardViewRequest.getMemberId().strip(),
				iDcardViewRequest.getPage().toLowerCase().strip(),iDcardViewRequest.getPlanType(),iDcardViewRequest.getMaxMergeCount(),iDcardViewRequest.getDisplayOption(), httpServletRequest), headers, HttpStatus.OK);
	}

	//	Below two rest end points are not using for now, keeping for future scope

	/**
	 * Rest service for getting document by providing DocumentId
	 *
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Retrieves document", method = "GET", description = "This service fetches the document from Print-Vendor's repository and returns it as a Base64 encoded string. PDF file key is the only request field; thus, it must be supplied as a request.", responses = {
			@ApiResponse(responseCode = "200", description = "Document details", content = {
					@Content(schema = @Schema(implementation = DocumentViewResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid DocumentId", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/v1/member/document/view", produces = "application/json")
	@ResponseBody
	public ResponseEntity<DocumentViewResponse> getDocumentInfo(
			@Parameter(description = "PDF File Key to view the document") @RequestParam(value = "pdfFileKey", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: pdfFileKey is not in valid format") String pdfFileKey) {
		log.info("Inside getDocumentInfo() in Controller class");
		log.debug("Received the request with pdfFileKey: {}", pdfFileKey);
		validator.validateDocumentViewRequest(pdfFileKey);
		HttpHeaders headers = createResponseHeaders();

		return new ResponseEntity<>(documentSearchService.getDocumentView(pdfFileKey), headers, HttpStatus.OK);
	}

	private HttpHeaders createResponseHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		return headers;
	}


	@Operation(summary = "Document Lookup", method = "GET", description =
			"Service to retrieves and provide detailed information about documents. The following search parameters can be used to retrieve the details: member ID, document type, UID, UID Type, start date and end date. The member ID, document type, start date and end date are the required fields among these. The remaining fields are optional; based on their availability, they will be used as filters.", responses = {
			@ApiResponse(responseCode = "200", description = "Document details", content = {
					@Content(schema = @Schema(implementation = DocumentViewResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid DocumentId", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping (value = "/v1/member/document/lookup", produces = "application/json")
	@ResponseBody
	public ResponseEntity<List<DocumentSearchResponse>> documentSearch(
			@Parameter(description = "Member ID") @RequestParam(value = "memberId", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: memberId is not in valid format") String memberId,
			@Parameter(description = "Claim number/Tax-id/unique ref number") @RequestParam(value = "uid", required=false) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: uid is not in valid format") String uid,
			@Parameter(description = "Type of UID passed") @RequestParam(value = "uidType", required=false) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: uidType is not in valid format") String uidType,
			@Parameter(description = "Three digit integer for the document type") @RequestParam(value = "documentType", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: documentType is not in valid format") String documentType,
			@Parameter(description = "Starting date range of searching documents") @RequestParam(value = "startDate", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: startDate is not in valid format") String startDate,
			@Parameter(description = "Ending date range of searching documents") @RequestParam(value = "endDate", required=true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: endDate is not in valid format") String endDate){
		log.info("Inside documentSearch() in Controller class");
		log.debug("Received the request with memberId: {}, uid: {}, uidType: {}, documentType: {}, startDate: {}, endDate: {}", memberId, uid, uidType, documentType, startDate, endDate);
		validator.validateDocumentSearchRequest(startDate, endDate, documentType);
		HttpHeaders headers = createResponseHeaders();

		return new ResponseEntity<>(documentSearchService.documentSearch(memberId, uid, uidType, documentType,startDate, endDate), headers, HttpStatus.OK);
	}
}
