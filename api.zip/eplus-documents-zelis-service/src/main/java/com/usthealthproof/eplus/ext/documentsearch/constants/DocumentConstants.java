package com.usthealthproof.eplus.ext.documentsearch.constants;

import org.springframework.stereotype.Component;

@Component
public class DocumentConstants {

	private DocumentConstants() {
	}

	public static final String EXCEPTION_OCCURRED = "Something went wrong, please check the log for more details";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String PROVIDER_NO_DATA_FOUND = "no data found for the provided input";
	public static final String START_DATE = "Given Start Date is invalid date format, expected date format is yyyy-MM-dd'T'HH:mm:ss";
	public static final String END_DATE = "Given End Date is invalid date format, expected date format is yyyy-MM-dd'T'HH:mm:ss";
	public static final String NO_DATA_FOUND= "No Data Found";
	public static final String RESULT_SIZE_EXCEEDED = "Too many records returned, Please narrow down search";
	public static final String NULL_CHECK = null;
	public  static  final String EXECUTION_TIME = "Execution time of the external service - HRP WS call in ms: {}";
	public static final String START_DATE_MANDATORY = "StartDate is a mandatory field. Please provide valid StartDate.";
	public static final String END_DATE_MANDATORY = "EndDate is a mandatory field. Please provide valid EndDate.";
}
