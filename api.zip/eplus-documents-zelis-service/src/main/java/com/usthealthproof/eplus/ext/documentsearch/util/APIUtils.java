package com.usthealthproof.eplus.ext.documentsearch.util;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ProblemDetails;
import lombok.extern.slf4j.Slf4j;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchType;
import org.springframework.stereotype.Component;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.ObjectFactory;

import java.util.Arrays;

@Component
@Slf4j
public class APIUtils {

	/**
	 * Common Method for the Util function for setting the error details
	 */
	public ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(createProblemDetails(message, status));
		return errorResponse;
	}

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		log.info("Inside createProblemDetails() in APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setErrors(Arrays.asList(errorMsg));
		problemDetails.setStatus(status);
		return problemDetails;
	}

	public DocumentSearchCheckFormat001V6 updateDocumentSearchInputRequest(DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6){
		log.info("Inside updateDocumentSearchInputRequest()");
		ObjectFactory objectFactory = new ObjectFactory();
		documentSearchCheckFormat001V6.setSearchType(DocSearchType.RELEASED);
		documentSearchCheckFormat001V6.setTnsShowPurgedReleased(Boolean.FALSE);

		if(null==documentSearchCheckFormat001V6.getTnsClaimNumber()){
			documentSearchCheckFormat001V6.setTnsClaimNumber(objectFactory.createDocumentSearchCheckFormat001V6TnsClaimNumber(DocumentConstants.NULL_CHECK));
		}
		if(null==documentSearchCheckFormat001V6.getTnsDocumentType()){
			documentSearchCheckFormat001V6.setTnsDocumentType(objectFactory.createDocumentSearchCheckFormat001V6TnsDocumentType(DocumentConstants.NULL_CHECK));
		}
		updateDocumentSearchInputRequestMore(documentSearchCheckFormat001V6);
		return documentSearchCheckFormat001V6;
	}

	public DocumentSearchCheckFormat001V6 updateDocumentSearchInputRequestMore(DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6) {
		ObjectFactory objectFactory = new ObjectFactory();
		if (null == documentSearchCheckFormat001V6.getTnsEnrolleeId()) {
			documentSearchCheckFormat001V6.setTnsEnrolleeId(objectFactory.createDocumentSearchCheckFormat001V6TnsEnrolleeId(DocumentConstants.NULL_CHECK));
		}
		return documentSearchCheckFormat001V6;
	}
	public DocumentSearchDocumentFormat001V1 updateMLEInvoiceSearchInputRequest(DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1){
		log.info("Inside updateMLEInvoiceSearchInputRequest()");
		ObjectFactory objectFactory = new ObjectFactory();
		documentSearchDocumentFormat001V1.setSearchType(DocSearchType.RELEASED);
		documentSearchDocumentFormat001V1.setTnsShowPurgedReleased(Boolean.FALSE);

		if(null==documentSearchDocumentFormat001V1.getTnsDocumentIndex1()){
			documentSearchDocumentFormat001V1.setTnsDocumentIndex1(objectFactory.createDocumentSearchDocumentFormat001V1TnsDocumentIndex1(DocumentConstants.NULL_CHECK));
		}
		return documentSearchDocumentFormat001V1;
	}
}
