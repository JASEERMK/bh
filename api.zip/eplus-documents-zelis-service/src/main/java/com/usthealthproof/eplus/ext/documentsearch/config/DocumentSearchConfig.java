package com.usthealthproof.eplus.ext.documentsearch.config;

import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.ext.logging.LoggingOutInterceptor;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.addressing.WSAddressingFeature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import org.tempuri.IRedCardServices;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@Slf4j
@Data
public class DocumentSearchConfig {

	@Value("${documentzelis.service.address}")
	private String address;
	@Value("${documentzelis.service.username}")
	private String username;
	@Value("${documentzelis.service.password}")
	private String password;
	@Value("${documentzelis.service.wsdl}")
	private String wsdl = "wsdl";
	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	@Bean(name = "MetadataExchangeHttpsBinding_IRedCardServices")
	public IRedCardServices iRedCardServices() throws Exception {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		try {
			jaxWsProxyFactoryBean.setServiceClass(IRedCardServices.class);
			jaxWsProxyFactoryBean.setAddress(address);
			jaxWsProxyFactoryBean.setUsername(username);
			jaxWsProxyFactoryBean.setPassword(password);
			jaxWsProxyFactoryBean.setBindingId("http://www.w3.org/2003/05/soap/bindings/HTTP/");
			jaxWsProxyFactoryBean.getFeatures().add(new WSAddressingFeature());

			LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
			loggingInInterceptor.setPrettyLogging(true);
			LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
			loggingOutInterceptor.setPrettyLogging(true);

			jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor);
			jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor);
		} catch (Exception e) {
			log.error("Invalid configurations of Document service : ", e);
			throw new RequestValidationException("Invalid configurations of Document Zelis service");
		}
		IRedCardServices client = (IRedCardServices) jaxWsProxyFactoryBean.create();
		Map<String, String> nsMap = new HashMap<>();
		nsMap.put("tns", "http://tempuri.org/");
		Client proxy = ClientProxy.getClient(client);
		HTTPConduit conduit = (HTTPConduit) proxy.getConduit();
		HTTPClientPolicy httpclient = new HTTPClientPolicy();
		httpclient.setContentType("application/soap+xml;charset=UTF-8");
		proxy.getRequestContext().put("soap.env.ns.map", nsMap);
		conduit.setClient(httpclient);
		return client;
	}

	@Bean
	public WebClient webClient() {
		final ExchangeStrategies strategies = ExchangeStrategies.builder()
				.codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient()))
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies).build();
	}

	private HttpClient getHttpClient() {
		ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(500).maxIdleTime(Duration.ofSeconds(20))
				.maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
				.evictInBackground(Duration.ofSeconds(120)).build();
		return HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 20000).doOnConnected(
				conn -> conn.addHandlerLast(new ReadTimeoutHandler(20)).addHandlerLast(new WriteTimeoutHandler(20)));
	}

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-documents-zelis-service/api-docs
	 * Swagger_UI:http://localhost:8080/eplus/eplus-documents-zelis-service/index.html
	 */

	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("EOB - Zelis").description(
						"The Documents Service acts as a wrapper service to access and retrieve the following from the Print Vendor's repository.\n" +
								"1. Retrieves EOP Document\n" +
								"2. Retrieves Explanation of Benefits (EOB) letter\n" +
								"3. Retrieves Member's ID Card\n" +
								"4. Retrieves document\n" +
								"5. Document Lookup\n" +
								"6. MLE Invoice Document Search\n\n"
								+ "The consumers are provided with a url and credentials to get the access token. The service calls are made with valid access token in the header."
								+ "\n\nFor every failure a problemDetails object with error message and status will be available in the response.")
				.version("5.3.0"));
	}

}
