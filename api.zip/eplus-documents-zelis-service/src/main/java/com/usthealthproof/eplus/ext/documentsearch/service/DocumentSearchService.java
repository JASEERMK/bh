package com.usthealthproof.eplus.ext.documentsearch.service;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentEOBResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentSearchResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.EopDocumentResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.IdCardResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface DocumentSearchService {

	DocumentEOBResponse getEOBDocumentByClaim(String claimId, String memberId, HttpServletRequest httpServletRequest)
			throws ResponseValidationException;

	EopDocumentResponse getEOPDocument(String claimNumber, String providerTaxId, HttpServletRequest httpServletRequest)
			throws ResponseValidationException;

	DocumentViewResponse getDocumentView(String pdfFileKey) throws ResponseValidationException;

	IdCardResponse getDocumentByIdByZelisCall(String memberId, String page, String planType,String maxMergeCount,String displayOption,HttpServletRequest httpServletRequest)
			throws ResponseValidationException;

	List<DocumentSearchResponse> documentSearch(String memberId, String uid, String uidType, String documentType,String startDate, String endDate)throws ResponseValidationException;


}

