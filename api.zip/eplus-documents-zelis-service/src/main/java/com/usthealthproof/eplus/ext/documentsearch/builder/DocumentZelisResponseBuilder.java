package com.usthealthproof.eplus.ext.documentsearch.builder;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentSearchResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import jakarta.xml.bind.JAXBElement;
import lombok.extern.slf4j.Slf4j;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultReleased;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultReleasedV6;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.springframework.stereotype.Component;
import org.tempuri.ObjectFactory;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Component
@Slf4j
public class DocumentZelisResponseBuilder {

	public DocumentViewResponse getDocumentZelisResponse(GetPdfResult getClaimsPdfV1Response) {

		DocumentViewResponse getDocumentResponse = new DocumentViewResponse();
		ObjectFactory fact = new ObjectFactory();
		JAXBElement<GetPdfResult> getPDFKey = fact.createGetClaimsPdfV1ResponseGetClaimsPdfV1Result(getClaimsPdfV1Response);
		if(getPDFKey.getValue().getPdfFileBytes().isNil()){
			log.info("There is no records received as part of the documentView");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		}else {
			String encodedzelisDocumentViewResponse =
					Base64.getEncoder().encodeToString(getPDFKey.getValue().getPdfFileBytes().getValue());
			getDocumentResponse.setPdfFileString(encodedzelisDocumentViewResponse);

		}
		return getDocumentResponse;
	}

	public List<DocumentSearchResponse> getDocumentSearchZelisResponse(
			DocSearchFormat001ResultListV6 docSearchFormat001ResultListV6) {

		List<DocumentSearchResponse> responseList = new ArrayList<>();
		ObjectFactory fact = new ObjectFactory();
		JAXBElement<DocSearchFormat001ResultListV6> docSearchRes = fact.createDocumentSearchCheckFormat001V6ResponseDocumentSearchCheckFormat001V6Result(
				docSearchFormat001ResultListV6);
		List<DocSearchFormat001ResultReleasedV6> list1 = docSearchRes.getValue().getSearchResultsReleased().getValue()
				.getDocSearchFormat001ResultReleasedV6();
		log.info("list size is :" + list1.size());
		if(list1.isEmpty()){
			log.info("There is no records received as part of the documentSearch");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		} else if (!list1.isEmpty() && list1.size()>100) {
			log.info("Search results count exceeded the size limit");
			throw new RequestValidationException(DocumentConstants.RESULT_SIZE_EXCEEDED);
		}else{
			for (DocSearchFormat001ResultReleasedV6 i : list1) {
				DocumentSearchResponse documentSearchResponse = new DocumentSearchResponse();
				documentSearchResponse.setDocumentExtension(i.getDocumentExtension().getValue());
				documentSearchResponse.setName(i.getName().getValue());
				documentSearchResponse.setStatus(i.getStatus().getValue());
				documentSearchResponse.setDocID(i.getDocId().getValue());
				documentSearchResponse.setPdfFileKey(i.getPdfFileKey().getValue());
				responseList.add(documentSearchResponse);
			}
		}
		return responseList;
	}

	public List<MLEInvoiceDocumentResponse> getMLEInvoiceDocsZelisResponse(
			DocSearchFormat001ResultList docSearchFormat001ResultList) {

		List<MLEInvoiceDocumentResponse> responseList = new ArrayList<>();
		ObjectFactory fact = new ObjectFactory();
		JAXBElement<DocSearchFormat001ResultList> docSearchRes =
				fact.createDocumentSearchDocumentFormat001V1ResponseDocumentSearchDocumentFormat001V1Result(
						docSearchFormat001ResultList);
		List<DocSearchFormat001ResultReleased> list1 = docSearchRes.getValue().getSearchResultsReleased().
				getValue().getDocSearchFormat001ResultReleased();
		log.info("list size is :" + list1.size());
		if(list1.isEmpty()){
			log.info("There is no records received as part of the mleInvoiceDocumentSearch");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		} else if (!list1.isEmpty() && list1.size()>100) {
			log.info("Search results count exceeded the size limit");
			throw new RequestValidationException(DocumentConstants.RESULT_SIZE_EXCEEDED);
		}else{
			for (DocSearchFormat001ResultReleased i : list1) {
				MLEInvoiceDocumentResponse mleInvoiceDocumentResponse = new MLEInvoiceDocumentResponse();
				mleInvoiceDocumentResponse.setDocID(i.getDocId().getValue());
				mleInvoiceDocumentResponse.setPdfFileKey(i.getPdfFileKey().getValue());
				responseList.add(mleInvoiceDocumentResponse);
			}
		}
		return responseList;
	}
}
