package com.usthealthproof.eplus.ext.documentsearch.dao;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.springframework.stereotype.Component;
import org.tempuri.DocumentSearchDocumentFormat001V1;

@Component
public interface MLEInvoiceDocumentSearchDao {
	DocSearchFormat001ResultList mleInvoiceDocumentResultResponse(
			DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1) throws ResponseValidationException;

}
