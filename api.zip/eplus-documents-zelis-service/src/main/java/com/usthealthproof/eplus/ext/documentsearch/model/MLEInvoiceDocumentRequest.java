package com.usthealthproof.eplus.ext.documentsearch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MLEInvoiceDocumentRequest {
	@Schema(description = "document Index")
	@JsonProperty("documentIndex")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: documentIndex is not in valid format")
	private String documentIndex;

	@Schema(description = "Starting date range of searching documents", requiredMode = Schema.RequiredMode.REQUIRED)
	@JsonProperty("startDate")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: startDate is not in valid format")
	private String startDate;

	@Schema(description = "Ending date range of searching documents", requiredMode = Schema.RequiredMode.REQUIRED)
	@JsonProperty("endDate")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: endDate is not in valid format")
	private String endDate;
}
