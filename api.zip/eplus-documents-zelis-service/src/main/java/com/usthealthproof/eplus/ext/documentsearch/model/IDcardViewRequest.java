package com.usthealthproof.eplus.ext.documentsearch.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Request object wrapping ID card view Document Request")
public class IDcardViewRequest implements Serializable {

	private static final long serialVersionUID = 5916973052102595355L;

	@Schema(description = "Member Id", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "memberId")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Member Id is not in valid format")
	private String memberId;

	@Schema(description = "Page", requiredMode = Schema.RequiredMode.REQUIRED, defaultValue = "page", allowableValues = {"front", "back", "full"})
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Page is not in valid format")
	private String page;

	@Schema(description = "PlanType", defaultValue = "planType", allowableValues = {"M", "D", "V", "P"})
	private String planType;

	@Schema(description = "MaxMergeCount", hidden = true)
	private String maxMergeCount;

	@Schema(description = "DisplayOption", hidden = true)
	private String displayOption;

}