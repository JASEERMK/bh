package com.usthealthproof.eplus.ext.documentsearch.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class RequestValidationException extends RuntimeException {

	private static final long serialVersionUID = -4579912482375101659L;
	public RequestValidationException(String message) {
		super(message);
	}

	public RequestValidationException(Throwable cause) {
		super(cause);}}