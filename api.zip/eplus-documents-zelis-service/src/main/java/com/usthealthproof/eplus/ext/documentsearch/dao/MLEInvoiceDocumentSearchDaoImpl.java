package com.usthealthproof.eplus.ext.documentsearch.dao;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.IRedCardServices;

@Repository
@Slf4j
public class MLEInvoiceDocumentSearchDaoImpl implements MLEInvoiceDocumentSearchDao{
	@Autowired
	private APIUtils apiUtils;
	@Value("${documentzelis.service.username}")
	private String username;
	@Value("${documentzelis.service.password}")
	private String password;
	@Autowired
	private IRedCardServices iRedCardServices;
	@Override
	public DocSearchFormat001ResultList mleInvoiceDocumentResultResponse(
			DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1) throws ResponseValidationException {
		log.info("Inside mleInvoiceDocumentResultResponse() in DAO class");
		DocSearchFormat001ResultList docSearchFormat001ResultList = null;
		apiUtils.updateMLEInvoiceSearchInputRequest(documentSearchDocumentFormat001V1);
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			docSearchFormat001ResultList = iRedCardServices.documentSearchDocumentFormat001V1(username, password,
					documentSearchDocumentFormat001V1.getSearchType(), documentSearchDocumentFormat001V1.isTnsShowPurgedReleased(),
					documentSearchDocumentFormat001V1.getTnsStartDateReleased(), documentSearchDocumentFormat001V1.getTnsEndDateReleased(),
					documentSearchDocumentFormat001V1.getTnsDocumentIndex1().getValue());
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the external service - HRP WS call in ms: {}",
					endServiceRequestTime - startServiceRequestTime);
		} catch (Exception ex) {
			log.error("Failed to receive the Document-Zelis service in DAO");
			throw ex;
		}
		log.info("Successfully generated mleInvoiceDocumentResultResponse service !!!");
		return docSearchFormat001ResultList;
	}
}
