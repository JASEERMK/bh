package com.usthealthproof.eplus.ext.documentsearch.service;

import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisRequestBuilder;
import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisResponseBuilder;
import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.dao.DocumentZelisDao;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentEOBResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentSearchResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.EopDocumentResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.IdCardResponse;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.GetClaimsPdfV1;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class DocumentSearchServiceImpl implements DocumentSearchService {

	@Value("${documentzelis.service.username}")
	private String username;
	@Value("${documentzelis.service.password}")
	private String password;
	@Value("${idcard.description}")
	private String idCardDescription;
	@Value("${zelis.token}")
	private String token;
	@Value("${zelis.endpnt1}")
	private String endpnt1;
	@Value("${zelis.endpnt2}")
	private String endpnt2;
	@Value("${zelis.endpnt3}")
	private String endpnt3;

	@Value("${zelis.medicalid}")
	private String medicalid;
	@Value("${zelis.dentalid}")
	private String dentalid;
	@Value("${zelis.visionid}")
	private String visionid;
	@Value("${zelis.pharmacyId}")
	private String pharmacyId;

	@Autowired
	private WebClient webClient;

	@Autowired
	private DocumentZelisRequestBuilder documentZelisRequestBuilder;

	@Autowired
	private DocumentZelisResponseBuilder documentZelisResponseBuilder;

	@Autowired
	private DocumentZelisDao documentZelisDao;

	@Autowired
	private Validator validator;

	@Override
	public IdCardResponse getDocumentByIdByZelisCall(String memberId, String page, String planType,String maxMergeCount,String displayOption,HttpServletRequest httpServletRequest)
			throws ResponseValidationException {
		log.info("Inside getDocumentInfo() in Service class");

		IdCardResponse idCardResponse = new IdCardResponse();
		String zelisDocumentResponse1 = null;
		String memberid = "&memberid=";
		String riCode = "&RICODE=";
		String includeBytesInResponse = "&includeBytesInResponse=false";
		try {
			String endpoint1;
			if (StringUtils.isBlank(planType)) {
				endpoint1 = endpnt1 + token + memberid + memberId + includeBytesInResponse;
			} else {
				StringBuilder endpointBuilder = new StringBuilder(endpnt1 + token + memberid + memberId + includeBytesInResponse + riCode);

				switch (planType) {
					case "M":
						endpointBuilder.append(medicalid);
						break;
					case "D":
						endpointBuilder.append(dentalid);
						break;
					case "V":
						endpointBuilder.append(visionid);
						break;
					case "P":
						endpointBuilder.append(pharmacyId);
						break;
					default:
						break;
				}

				endpoint1 = endpointBuilder.toString();
			}
			zelisDocumentResponse1 = makeIdCardZelisAPICall(endpoint1);
			log.info("first endpoint to zelis call :" + endpoint1);
			log.debug("first zelis call response is :" + zelisDocumentResponse1);
			/***If document id is not found in zelis the response is a text like"Unable ......". In order to handle this,
			 * we send the same message as No Data found exception caught through array index OOB exception**/
			String url = (zelisDocumentResponse1.split("\""))[1];
			log.info("After split first endpoint to zelis call :" + url);
			String endpoint2 = endpnt2 + url;
			byte[] zelisDocumentResponse2 = makeIdCardZelisCall(endpoint2);
			log.info("Second endpoint to Zelis call :" + endpoint2);
			log.debug("Second Zelis call response is :" + zelisDocumentResponse2);
			String encodedzelisDocumentResponse = Base64.getEncoder().encodeToString(zelisDocumentResponse2);
			createIdCardResponseForZelisCall(idCardResponse, encodedzelisDocumentResponse);
			log.debug("EncodedZelisDocumentResponse is :" + encodedzelisDocumentResponse);
			log.debug("Id Card response is :" + idCardResponse);
		} catch (NoDataFoundException e) {
			log.error("NoDataFoundException occurred for the getDocumentByIdByZelisCall service");
			throw e;
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("NoDataFoundException occurred for the getDocumentByIdByZelisCall service");
			throw new NoDataFoundException(zelisDocumentResponse1);
		} catch (Exception e) {
			log.error("Exception occurred for the getDocumentByIdByZelisCall service");
			throw e;
		}
		log.info("Successfully received the documentByIdByZelisCall");
		return idCardResponse;
	}

	/**
	 * Method for getting EOB document by providing ClaimId
	 *
	 * @throws Exception
	 */
	@Override
	public DocumentEOBResponse getEOBDocumentByClaim(String claimId, String memberId, HttpServletRequest httpServletRequest)
			throws ResponseValidationException {
		log.info("Inside getEOBDocumentByClaim() in Service class");

		DocumentEOBResponse documentEOBResponse = new DocumentEOBResponse();
		String zelisEOBDocumentResponse1 = null;
		try {
			String endpoint1 = endpnt3 + token + "&recipientType=Insured" + "&claimNumber=" + claimId + "&memberid=" + memberId;
			zelisEOBDocumentResponse1 = makeEOBDocumentZelisAPICall(endpoint1);
			log.info("First endpoint to zelis call :" + endpoint1);
			log.debug("First zelis call response is :" + zelisEOBDocumentResponse1);
			/***If document id is not found in zelis the response is a text like"Unable ......". In order to handle this,
			 * we send the same message as No Data found exception caught through array index OOB exception**/
			String url = (zelisEOBDocumentResponse1.split("\""))[1];
			String endpoint2 = endpnt2 + url.replace("&amp;", "&");
			byte[] zelisDocumentResponse2 = makeEOBDocsZelisCall(endpoint2);
			log.info("Second endpoint to zelis call :" + endpoint2);
			log.debug("Second zelis call response is :" + zelisDocumentResponse2);
			String encodedzelisDocumentResponse = Base64.getEncoder().encodeToString(zelisDocumentResponse2);
			createEOBDocumentResponseForZelisCall(documentEOBResponse, encodedzelisDocumentResponse);
			log.debug("EncodedZelisDocumentResponse is :" + encodedzelisDocumentResponse);
			log.debug("Id card response is :" + documentEOBResponse);
		} catch (NoDataFoundException e) {
			log.error("NoDataFoundException occurred for the getEOBDocumentByIdByZelisCall service");
			throw e;
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("NoDataFoundException occurred for the getEOBDocumentByIdByZelisCall service");
			throw new NoDataFoundException(zelisEOBDocumentResponse1);
		} catch (Exception e) {
			log.error("Exception occurred for the getEOBDocumentByClaimIdByZelisCall service");
			throw e;
		}
		log.info("Successfully received the EOBDocumentByClaim");
		return documentEOBResponse;
	}

	@Override
	public EopDocumentResponse getEOPDocument(String claimNumber, String providerTaxId, HttpServletRequest httpServletRequest)
			throws ResponseValidationException {
		log.info("Inside getEOPDocument() in Service class");

		EopDocumentResponse eopDocumentResponse = new EopDocumentResponse();
		String zelisEOPDocumentResponse1 = null;
		try {
			String endpoint1 = endpnt3 + token + "&recipientType=Provider" + "&claimNumber=" + claimNumber + "&providerTaxId="
					+ providerTaxId;
			zelisEOPDocumentResponse1 = makeEOPDocumentZelisAPICall(endpoint1);
			log.info("First endpoint to EOP zelis call :" + endpoint1);
			log.debug("First EOP zelis call response is :" + zelisEOPDocumentResponse1);
			/***If document id is not found in zelis the response is a text like"Unable ......". In order to handle this,
			 * we send the same message as No Data found exception caught through array index OOB exception**/
			String url = (zelisEOPDocumentResponse1.split("\""))[1];
			String endpoint2 = endpnt2 + url.replace("&amp;", "&");
			byte[] zelisDocumentResponse2 = makeEOPDocsZelisCall(endpoint2);
			log.info("Second endpoint to EOP zelis call :" + endpoint2);
			log.debug("Second EOP zelis call response is :" + zelisDocumentResponse2);
			String encodedzelisDocumentResponse = Base64.getEncoder().encodeToString(zelisDocumentResponse2);
			createEOPDocumentResponseForZelisCall(eopDocumentResponse, encodedzelisDocumentResponse);
			log.debug("EncodedZelisDocumentResponse for EOP is :" + encodedzelisDocumentResponse);
			log.debug("EOP DOC response is :" + eopDocumentResponse);
		} catch (NoDataFoundException e) {
			log.error("NoDataFoundException occurred for the getEOPDocumentByZelisCall service");
			throw e;
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("NoDataFoundException occurred for the getEOPDocumentByZelisCall service");
			throw new NoDataFoundException(zelisEOPDocumentResponse1);
		} catch (Exception e) {
			log.error("Exception occurred for the getEOPDocumentByZelisCall service");
			throw e;
		}
		log.info("Successfully received the EOPDocumentByZelisCall");
		return eopDocumentResponse;
	}

	/**
	 * Method for getting document by providing DocumentId
	 *
	 * @throws Exception
	 */
	@Override
	public DocumentViewResponse getDocumentView(String pdfFileKey) throws ResponseValidationException {
		log.info("Inside getDocumentView() in Service class");
		DocumentViewResponse documentViewResponse = new DocumentViewResponse();
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			GetClaimsPdfV1 getClaimsPdfV1 = documentZelisRequestBuilder.getPDFFileKey(pdfFileKey);
			GetPdfResult getPdfResultResponse = documentZelisDao.getPdfResultResponse(getClaimsPdfV1.getTnsPdfFileKey().getValue());
			documentViewResponse = documentZelisResponseBuilder.getDocumentZelisResponse(getPdfResultResponse);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("DocumentView service - Execution time of external service: {}ms",
					endServiceRequestTime - startServiceRequestTime);
		} catch (Exception e) {
			log.info("Exception occurred for the DocumentView service");
			throw new ResponseValidationException(e);
		}
		log.info("Successfully received the DocumentView");
		return documentViewResponse;
	}

	@Override
	public List<DocumentSearchResponse> documentSearch(String memberId, String uid, String uidType, String documentType,String startDate, String endDate) throws ResponseValidationException {
		log.info("Inside documentSearch() in Service class");
		List<DocumentSearchResponse> documentSearchResponseList = new ArrayList<>();
		try {
			long startServiceRequestTime = System.currentTimeMillis();
			DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6 = documentZelisRequestBuilder.documentSearch(
					memberId, uid, documentType,startDate, endDate);
			DocSearchFormat001ResultListV6 docSearchFormat001ResultListV6 = documentZelisDao.documentSearchResultResponse(documentSearchCheckFormat001V6);
			documentSearchResponseList = documentZelisResponseBuilder.getDocumentSearchZelisResponse(
					docSearchFormat001ResultListV6);

			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of documentSearch external service: {}ms",
					endServiceRequestTime - startServiceRequestTime);
		} catch (NoDataFoundException e) {
			log.error("DocumentSearch service got NoDataFoundException");
			throw e;
		} catch (Exception e) {
			log.info("DocumentSearch service got an Exception");
			throw new ResponseValidationException(e);
		}
		log.info("Successfully received the DocumentSearch");
		return documentSearchResponseList;
	}

	private byte[] makeEOBDocsZelisCall(String endpoint) {
		log.info("Inside makeEOBDocsZelisCall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(byte[].class).block();
	}

	private byte[] makeEOPDocsZelisCall(String endpoint) {
		log.info("Inside makeEOPDocsZelisCall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(byte[].class).block();
	}

	private byte[] makeIdCardZelisCall(String endpoint) {
		log.info("Inside makeIdCardZelisCall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(byte[].class).block();

	}

	private String makeEOBDocumentZelisAPICall(String endpoint) {
		log.info("Inside makeEOBDocumentZelisAPICall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(String.class).block();
	}

	private String makeEOPDocumentZelisAPICall(String endpoint) {
		log.info("Inside makeEOPDocumentZelisAPICall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(String.class).block();
	}

	private String makeIdCardZelisAPICall(String endpoint) {
		log.info("Inside makeIdCardZelisAPICall()");
		return webClient.get().uri(endpoint).retrieve().onStatus(HttpStatusCode::is4xxClientError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.onStatus(HttpStatusCode::is5xxServerError,
						error -> Mono.error(new NoDataFoundException(DocumentConstants.PROVIDER_NO_DATA_FOUND)))
				.bodyToMono(String.class).block();
	}

	private void createIdCardResponseForZelisCall(IdCardResponse idCardResponse, String zelisDocumentResponse) {
		log.info("Inside createIdCardResponseForZelisCall()");
		if (Objects.nonNull(zelisDocumentResponse) && (!(zelisDocumentResponse.isEmpty()))) {
			idCardResponse.setMimeType("application/PDF");
			idCardResponse.setData(zelisDocumentResponse);
		} else {
			log.info("The IdCardData from the external service is NULL or Empty");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		}

	}

	private void createEOBDocumentResponseForZelisCall(DocumentEOBResponse documentEOBResponse, String zelisDocumentResponse) {
		log.info("Inside createEOBDocumentResponseForZelisCall()");
		if (Objects.nonNull(zelisDocumentResponse) && (!(zelisDocumentResponse.isEmpty()))) {
			documentEOBResponse.setType("application/pdf");
			documentEOBResponse.setFile(zelisDocumentResponse);
		} else {
			log.info("The EOBData from the external service is NULL or Empty");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		}

	}

	private void createEOPDocumentResponseForZelisCall(EopDocumentResponse eopDocumentResponse, String zelisDocumentResponse) {
		log.info("Inside createEOPDocumentResponseForZelisCall()");
		if (Objects.nonNull(zelisDocumentResponse) && (!(zelisDocumentResponse.isEmpty()))) {
			eopDocumentResponse.setPdfString(zelisDocumentResponse);
		} else {
			log.info("The EOBData from the external service is NULL or Empty");
			throw new NoDataFoundException(DocumentConstants.NO_DATA_FOUND);
		}

	}

}
