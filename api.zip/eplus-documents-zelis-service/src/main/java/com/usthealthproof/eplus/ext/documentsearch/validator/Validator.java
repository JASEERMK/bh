package com.usthealthproof.eplus.ext.documentsearch.validator;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Component
@Slf4j
public class Validator {

	public void validateEOBDocumentRequest(String claimId, String memberId) throws RequestValidationException {
		log.info("Inside validateEOBDocumentRequest()");

		if (StringUtils.isBlank(claimId)) {
			throw new RequestValidationException("ClaimId is empty. Please provide valid ClaimId.");
		}
		if (StringUtils.isBlank(memberId)) {
			throw new RequestValidationException("MemberId is empty. Please provide valid MemberId.");
		}
	}

	public void validateEOPDocumentRequest(String claimNumber, String providerTaxId) throws RequestValidationException {
		log.info("Inside validateEOPDocumentRequest()");

		if (StringUtils.isBlank(claimNumber)) {
			throw new RequestValidationException("claimNumber is empty. Please provide valid claimNumber.");
		}
		if (StringUtils.isBlank(providerTaxId)) {
			throw new RequestValidationException("providerTaxId is empty. Please provide valid providerTaxId.");
		}
	}

	public void validateDocumentViewRequest(String pdfFileKey) {
		log.info("Inside validateAllDocumentRequest()");

		if (StringUtils.isBlank(pdfFileKey)) {
			throw new RequestValidationException("pdfFileKey is empty. Please provide valid pdfFileKey.");
		}
	}

	public void validateIdCardRequest(String memberId, String page, String planType) throws RequestValidationException {
		log.info("Inside validateIdCardRequest()");

		if (StringUtils.isBlank(memberId)) {
			throw new RequestValidationException("Invalid request. Please provide valid MemberId.");
		}

		if (StringUtils.isBlank(page)) {
			throw new RequestValidationException("Invalid request. Please provide valid Page.");
		} else if (!page.toLowerCase().strip().matches("front|back|full")) {
			throw new RequestValidationException("Invalid page value. Page value must be one of: back, front, full.");
		}
		if (StringUtils.isNotBlank(planType) && !planType.matches("[MDVP]")) {
			throw new RequestValidationException("Invalid PlanType value. Please provide valid PlanType.");
		}
	}

	public void validateDocumentSearchRequest(String startDate, String endDate, String documentType) {
		log.info("Inside validateDocumentSearchRequest()");
		if (StringUtils.isBlank(startDate)) {
			log.info(DocumentConstants.START_DATE_MANDATORY);
			throw new RequestValidationException(DocumentConstants.START_DATE_MANDATORY);
		}else{
			validateDateFormat(DocumentConstants.START_DATE, startDate);
		}
		if (StringUtils.isBlank(endDate)) {
			log.info(DocumentConstants.END_DATE_MANDATORY);
			throw new RequestValidationException(DocumentConstants.END_DATE_MANDATORY);
		}else{
			validateDateFormat(DocumentConstants.END_DATE, endDate);
		}
		if (StringUtils.isBlank(documentType)) {
			log.info("DocumentType is a mandatory field. Please provide documentType.");
			throw new RequestValidationException("documentType is a mandatory field. Please provide documentType.");
		} else if (documentType.length()!=3) {
			log.info("DocumentType should be a three digit. Please provide valid documentType.");
			throw new RequestValidationException("documentType should be a three digit. Please provide valid documentType.");
		} else if (!documentType.matches("^[a-zA-Z0-9]{3}$")) {
			log.info("DocumentType should be alpha-numeric. Please provide valid documentType.");
			throw new RequestValidationException("documentType should be alpha-numeric. Please provide valid documentType.");
		}
	}
	private void validateDateFormat(String errorMessage, String date) {
		log.info("Inside validateDateFormat()");
		try {
			DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
			LocalDate.parse(date, f);
		} catch (DateTimeParseException e) {
			log.error("Exception occured while parsing date field : {} & Exception : {}", errorMessage, e);
			throw new RequestValidationException(errorMessage);
		}
	}



	public void validateMLEInvoiceDocumentRequest(String startDate, String endDate, String documentIndex) {
		log.info("Inside validateMLEInvoiceDocumentRequest()");
		if (StringUtils.isBlank(startDate)) {
			log.info("StartDate is a mandatory field. Please provide valid StartDate.");
			throw new RequestValidationException("StartDate is a mandatory field. Please provide valid StartDate.");
		}else{
			validateDateFormat(DocumentConstants.START_DATE, startDate);
		}
		if (StringUtils.isBlank(endDate)) {
			log.info("EndDate is a mandatory field. Please provide valid EndDate.");
			throw new RequestValidationException("EndDate is a mandatory field. Please provide valid EndDate.");
		}else{
			validateDateFormat(DocumentConstants.END_DATE, endDate);
		}
		if (StringUtils.isBlank(documentIndex)) {
			log.info("documentIndex is a mandatory field. Please provide documentIndex.");
			throw new RequestValidationException("documentIndex is a mandatory field. Please provide documentIndex.");
		}
	}
}
