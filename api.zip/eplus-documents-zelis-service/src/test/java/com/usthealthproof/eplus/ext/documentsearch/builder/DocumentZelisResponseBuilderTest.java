package com.usthealthproof.eplus.ext.documentsearch.builder;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentSearchResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.DocumentViewResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import org.datacontract.schemas._2004._07.ccp_docs.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import jakarta.xml.bind.JAXBElement;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import org.tempuri.ObjectFactory;

import javax.xml.namespace.QName;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DocumentZelisResponseBuilderTest {

    @Mock
    private ObjectFactory objectFactory;

    @Mock
    private Logger log;

    @InjectMocks
    private DocumentZelisResponseBuilder builder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Test getDocumentZelisResponse with non-null pdfFileBytes")
    void testGetDocumentZelisResponse_NonNullPdfFileBytes() {
        // given
        GetPdfResult getPdfResult = new GetPdfResult();
        byte[] pdfBytes = "Test PDF Data".getBytes();
        JAXBElement<byte[]> pdfBytesElement = new JAXBElement<>(new QName("PdfFileBytes"), byte[].class, pdfBytes);
        getPdfResult.setPdfFileBytes(pdfBytesElement); // Setting non-null pdfFileBytes
        JAXBElement<GetPdfResult> jaxbElement = new JAXBElement<>(new QName("GetPdfResult"), GetPdfResult.class, getPdfResult);

        // when
        when(objectFactory.createGetClaimsPdfV1ResponseGetClaimsPdfV1Result(any())).thenReturn(jaxbElement);

        // then
        DocumentViewResponse response = builder.getDocumentZelisResponse(getPdfResult);
        assertNotNull(response);
        assertEquals("VGVzdCBQREYgRGF0YQ==", response.getPdfFileString()); // Base64 encoded "Test PDF Data"
    }

@Test
public void testGetDocumentSearchZelisResponse_ValidResultList() {
    // given
    DocSearchFormat001ResultListV6 resultList = new DocSearchFormat001ResultListV6();
    List<DocSearchFormat001ResultReleasedV6> list = new ArrayList<>();
    DocSearchFormat001ResultReleasedV6 result = new DocSearchFormat001ResultReleasedV6();
    result.setDocumentExtension(new JAXBElement<>(new QName("documentExtension"), String.class, "pdf"));
    result.setName(new JAXBElement<>(new QName("name"), String.class, "Document1"));
    result.setStatus(new JAXBElement<>(new QName("status"), String.class, "Released"));
    result.setDocId(new JAXBElement<>(new QName("docId"), String.class, "123"));
    result.setPdfFileKey(new JAXBElement<>(new QName("pdfFileKey"), String.class, "pdf123"));
    list.add(result);

    ArrayOfDocSearchFormat001ResultReleasedV6 arrayOfResults = new ArrayOfDocSearchFormat001ResultReleasedV6();
    arrayOfResults.getDocSearchFormat001ResultReleasedV6().addAll(list);

    JAXBElement<ArrayOfDocSearchFormat001ResultReleasedV6> jaxbElement =
            new JAXBElement<>(new QName("searchResultsReleased"), ArrayOfDocSearchFormat001ResultReleasedV6.class, arrayOfResults);

    resultList.setSearchResultsReleased(jaxbElement);

    when(objectFactory.createDocumentSearchCheckFormat001V6ResponseDocumentSearchCheckFormat001V6Result(any()))
            .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultListV6.class, resultList));

    // when
    List<DocumentSearchResponse> responses = builder.getDocumentSearchZelisResponse(resultList);

    // then
    assertEquals(1, responses.size());

    DocumentSearchResponse response = responses.get(0);
    assertEquals("pdf", response.getDocumentExtension());
    assertEquals("Document1", response.getName());
    assertEquals("Released", response.getStatus());
    assertEquals("123", response.getDocID());
    assertEquals("pdf123", response.getPdfFileKey());
}


    @Test
    public void testGetDocumentSearchZelisResponse_ResultSizeExceeded() {
        // given
        DocSearchFormat001ResultListV6 resultList = new DocSearchFormat001ResultListV6();
        List<DocSearchFormat001ResultReleasedV6> list = new ArrayList<>();
        for (int i = 0; i < 101; i++) { // Simulating more than 100 results
            DocSearchFormat001ResultReleasedV6 result = new DocSearchFormat001ResultReleasedV6();
            result.setDocId(new JAXBElement<>(new QName("docId"), String.class, String.valueOf(i)));
            list.add(result);
        }

        ArrayOfDocSearchFormat001ResultReleasedV6 arrayOfResults = new ArrayOfDocSearchFormat001ResultReleasedV6();
        arrayOfResults.getDocSearchFormat001ResultReleasedV6().addAll(list);

        JAXBElement<ArrayOfDocSearchFormat001ResultReleasedV6> jaxbElement =
                new JAXBElement<>(new QName("searchResultsReleased"), ArrayOfDocSearchFormat001ResultReleasedV6.class, arrayOfResults);

        resultList.setSearchResultsReleased(jaxbElement);

        when(objectFactory.createDocumentSearchCheckFormat001V6ResponseDocumentSearchCheckFormat001V6Result(any()))
                .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultListV6.class, resultList));

        // then
        RequestValidationException exception = assertThrows(RequestValidationException.class, () ->
                builder.getDocumentSearchZelisResponse(resultList));

        assertEquals(DocumentConstants.RESULT_SIZE_EXCEEDED, exception.getMessage());
    }

    @Test
    public void testGetMLEInvoiceDocsZelisResponse_ValidResultList() {
        // given
        DocSearchFormat001ResultList resultList = new DocSearchFormat001ResultList();
        List<DocSearchFormat001ResultReleased> list = new ArrayList<>();
        DocSearchFormat001ResultReleased result = new DocSearchFormat001ResultReleased();
        result.setDocId(new JAXBElement<>(new QName("docId"), String.class, "123"));
        result.setPdfFileKey(new JAXBElement<>(new QName("pdfFileKey"), String.class, "pdf123"));
        list.add(result);

        JAXBElement<ArrayOfDocSearchFormat001ResultReleased> jaxbElement = new JAXBElement<>(
                new QName("searchResultsReleased"),
                ArrayOfDocSearchFormat001ResultReleased.class,
                new ArrayOfDocSearchFormat001ResultReleased()
        );
        jaxbElement.getValue().getDocSearchFormat001ResultReleased().addAll(list);

        resultList.setSearchResultsReleased(jaxbElement);

        when(objectFactory.createDocumentSearchDocumentFormat001V1ResponseDocumentSearchDocumentFormat001V1Result(any()))
                .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultList.class, resultList));

        // when
        List<MLEInvoiceDocumentResponse> responses = builder.getMLEInvoiceDocsZelisResponse(resultList);

        // then
        assertEquals(1, responses.size());

        MLEInvoiceDocumentResponse response = responses.get(0);
        assertEquals("123", response.getDocID());
        assertEquals("pdf123", response.getPdfFileKey());
    }



    @Test
    public void testGetMLEInvoiceDocsZelisResponse_ResultSizeExceeded() {
        // given
        DocSearchFormat001ResultList resultList = new DocSearchFormat001ResultList();
        List<DocSearchFormat001ResultReleased> list = new ArrayList<>();
        for (int i = 0; i < 101; i++) { // Simulating more than 100 results
            DocSearchFormat001ResultReleased result = new DocSearchFormat001ResultReleased();
            result.setDocId(new JAXBElement<>(new QName("docId"), String.class, String.valueOf(i)));
            result.setPdfFileKey(new JAXBElement<>(new QName("pdfFileKey"), String.class, "pdf" + i));
            list.add(result);
        }

        JAXBElement<ArrayOfDocSearchFormat001ResultReleased> jaxbElement = new JAXBElement<>(
                new QName("searchResultsReleased"),
                ArrayOfDocSearchFormat001ResultReleased.class,
                new ArrayOfDocSearchFormat001ResultReleased()
        );
        jaxbElement.getValue().getDocSearchFormat001ResultReleased().addAll(list);

        resultList.setSearchResultsReleased(jaxbElement);

        when(objectFactory.createDocumentSearchDocumentFormat001V1ResponseDocumentSearchDocumentFormat001V1Result(any()))
                .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultList.class, resultList));

        // then
        RequestValidationException exception = assertThrows(RequestValidationException.class, () ->
                builder.getMLEInvoiceDocsZelisResponse(resultList));

        assertEquals(DocumentConstants.RESULT_SIZE_EXCEEDED, exception.getMessage());
    }

    @Test
    @DisplayName("Test getDocumentZelisResponse with null pdfFileBytes")
    void testGetDocumentZelisResponse_NullPdfFileBytes() {
        // given
        GetPdfResult getPdfResult = new GetPdfResult();
        JAXBElement<byte[]> pdfBytesElement = new JAXBElement<>(new QName("PdfFileBytes"), byte[].class, null);
        getPdfResult.setPdfFileBytes(pdfBytesElement); // Setting null pdfFileBytes
        JAXBElement<GetPdfResult> jaxbElement = new JAXBElement<>(new QName("GetPdfResult"), GetPdfResult.class, getPdfResult);

        // when
        when(objectFactory.createGetClaimsPdfV1ResponseGetClaimsPdfV1Result(any())).thenReturn(jaxbElement);

        // then
        NoDataFoundException exception = assertThrows(NoDataFoundException.class, () -> {
            builder.getDocumentZelisResponse(getPdfResult);
        });

        assertEquals(DocumentConstants.NO_DATA_FOUND, exception.getMessage());
    }

    @Test
    public void testGetDocumentSearchZelisResponse_NoDataFound() {
        // given
        DocSearchFormat001ResultListV6 resultList = new DocSearchFormat001ResultListV6();
        JAXBElement<ArrayOfDocSearchFormat001ResultReleasedV6> jaxbElement =
                new JAXBElement<>(new QName("searchResultsReleased"), ArrayOfDocSearchFormat001ResultReleasedV6.class, new ArrayOfDocSearchFormat001ResultReleasedV6());

        resultList.setSearchResultsReleased(jaxbElement);

        when(objectFactory.createDocumentSearchCheckFormat001V6ResponseDocumentSearchCheckFormat001V6Result(any()))
                .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultListV6.class, resultList));

        // then
        NoDataFoundException exception = assertThrows(NoDataFoundException.class, () ->
                builder.getDocumentSearchZelisResponse(resultList));

        assertEquals(DocumentConstants.NO_DATA_FOUND, exception.getMessage());
    }

    @Test
    public void testGetMLEInvoiceDocsZelisResponse_NoDataFound() {
        // given
        DocSearchFormat001ResultList resultList = new DocSearchFormat001ResultList();
        JAXBElement<ArrayOfDocSearchFormat001ResultReleased> jaxbElement = new JAXBElement<>(
                new QName("searchResultsReleased"),
                ArrayOfDocSearchFormat001ResultReleased.class,
                new ArrayOfDocSearchFormat001ResultReleased()
        );

        resultList.setSearchResultsReleased(jaxbElement);

        when(objectFactory.createDocumentSearchDocumentFormat001V1ResponseDocumentSearchDocumentFormat001V1Result(any()))
                .thenReturn(new JAXBElement<>(new QName("result"), DocSearchFormat001ResultList.class, resultList));

        // then
        NoDataFoundException exception = assertThrows(NoDataFoundException.class, () ->
                builder.getMLEInvoiceDocsZelisResponse(resultList));

        assertEquals(DocumentConstants.NO_DATA_FOUND, exception.getMessage());
    }

}
