package com.usthealthproof.eplus.ext.documentsearch.builder;

import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.GetClaimsPdfV1;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

public class DocumentZelisRequestBuilderTest {
    @Mock
    Logger log;
    @InjectMocks
    DocumentZelisRequestBuilder documentZelisRequestBuilder;
    @Mock
    private DatatypeFactory datatypeFactory;
    MockedStatic<DatatypeFactory> mockedStatic;

    @Mock
    private DatatypeFactory datatypeFactoryMock;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        mockedStatic = mockStatic(DatatypeFactory.class);
    }

    @AfterEach
    void tearDown() {
        mockedStatic.close();
    }

    @Test
    @DisplayName("JUnit test for mleInvoiceDocumentCall with documentIndex not null")
    void testMleInvoiceDocumentCall_NotNullDocumentIndex() throws DatatypeConfigurationException {
        // given
        String documentIndex = "DOC123";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";

        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactoryMock);

        // when
        DocumentSearchDocumentFormat001V1 result = documentZelisRequestBuilder.mleInvoiceDocumentCall(documentIndex, startDate, endDate);

        // then
        assertNotNull(result);
        assertEquals(documentIndex, result.getTnsDocumentIndex1().getValue());
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("JUnit test for mleInvoiceDocumentCall with documentIndex null")
    void testMleInvoiceDocumentCall_NullDocumentIndex() throws DatatypeConfigurationException {
        // given
        String documentIndex = null;
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";

        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactoryMock);

        // when
        DocumentSearchDocumentFormat001V1 result = documentZelisRequestBuilder.mleInvoiceDocumentCall(documentIndex, startDate, endDate);

        // then
        assertNotNull(result);
        assertEquals("", result.getTnsDocumentIndex1().getValue()); // expecting empty string for null documentIndex
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("JUnit test for PDFFileKey request builder")
    void testGetPDFFileKey() {
        // given
        String documentId = "12345";
        // when
        GetClaimsPdfV1 result = documentZelisRequestBuilder.getPDFFileKey(documentId);
        // then
        assertNotNull(result);
        assertEquals(documentId, result.getTnsPdfFileKey().getValue());
    }

    @Test
    @DisplayName("JUnit test for DocumentSearch request builder")
    void testDocumentSearch() throws DatatypeConfigurationException {
        // given
        String memberId = "M123";
        String uid = "UID123";
        String uidType = "TypeA";
        String documentType = "DOC";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";
        DatatypeFactory datatypeFactory = mock(DatatypeFactory.class);
        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactory);

        // when
        DocumentSearchCheckFormat001V6 result = documentZelisRequestBuilder.documentSearch(
                memberId, uid, documentType, startDate, endDate);
        // then
        assertNotNull(result);
        assertEquals(memberId, result.getTnsEnrolleeId().getValue());
        assertEquals(uid, result.getTnsClaimNumber().getValue());
        assertEquals(documentType, result.getTnsDocumentType().getValue());
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("JUnit test for documentSearch - Exception case")
    void testDocumentSearch_ExceptionCase() {
        // given
        String memberId = "M123";
        String uid = "UID123";
        String uidType = "TypeA";
        String documentType = "DOC";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";

        mockedStatic.when(DatatypeFactory::newInstance).thenThrow(new DatatypeConfigurationException("Test exception"));

        // when, then (expecting exception)
        assertThrows(RequestValidationException.class, () ->
                documentZelisRequestBuilder.documentSearch(memberId, uid, documentType, startDate, endDate)
        );
    }

    @Test
    @DisplayName("Test documentSearch with null memberId")
    void testDocumentSearch_NullMemberId() throws DatatypeConfigurationException {
        // given
        String memberId = null;
        String uid = "UID123";
        String uidType = "TypeA";
        String documentType = "DOC";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";
        DatatypeFactory datatypeFactory = mock(DatatypeFactory.class);
        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactory);

        // when
        DocumentSearchCheckFormat001V6 result = documentZelisRequestBuilder.documentSearch(
                null, uid, documentType, startDate, endDate);

        // then
        assertNotNull(result);
        assertEquals("", result.getTnsEnrolleeId().getValue()); // expecting empty string for memberId
        assertEquals(uid, result.getTnsClaimNumber().getValue());
        assertEquals(documentType, result.getTnsDocumentType().getValue());
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("Test documentSearch with null uid")
    void testDocumentSearch_NullUid() throws DatatypeConfigurationException {
        // given
        String memberId = "M123";
        String uid = null;
        String uidType = "TypeA";
        String documentType = "DOC";
        String startDate = "2023-01-01";
        String endDate = "2023-12-31";
        DatatypeFactory datatypeFactory = mock(DatatypeFactory.class);
        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactory);

        // when
        DocumentSearchCheckFormat001V6 result = documentZelisRequestBuilder.documentSearch(
                memberId, null, documentType, startDate, endDate);

        // then
        assertNotNull(result);
        assertEquals("", result.getTnsClaimNumber().getValue()); // expecting empty string for uid
        assertEquals(documentType, result.getTnsDocumentType().getValue());
        assertEquals(memberId, result.getTnsEnrolleeId().getValue());
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("Test documentSearch with null documentType")
    void testDocumentSearch_NullDocumentType() throws DatatypeConfigurationException {
        // given
        String memberId = "M123";
        String uid = "UID123";
        String uidType = "TypeA";
        String documentType = null;
        String startDate = "2023-01-01";
        String endDate = "2023-12-31";
        DatatypeFactory datatypeFactory = mock(DatatypeFactory.class);
        mockedStatic.when(DatatypeFactory::newInstance).thenReturn(datatypeFactory);

        // when
        DocumentSearchCheckFormat001V6 result = documentZelisRequestBuilder.documentSearch(
                memberId, uid, null, startDate, endDate);

        // then
        assertNotNull(result);
        assertEquals("", result.getTnsDocumentType().getValue()); // expecting empty string for documentType
        assertEquals(uid, result.getTnsClaimNumber().getValue());
        assertEquals(memberId, result.getTnsEnrolleeId().getValue());
        assertEquals(createXMLGregorianCalendar(startDate), result.getTnsStartDateReleased());
        assertEquals(createXMLGregorianCalendar(endDate), result.getTnsEndDateReleased());
    }

    @Test
    @DisplayName("JUnit test for mleInvoiceDocumentCall - DatatypeConfigurationException")
    void testMleInvoiceDocumentCall_DatatypeConfigurationException() throws DatatypeConfigurationException {
        // given
        String documentIndex = "DOC123";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-12-31T00:00:00";

        mockedStatic.when(DatatypeFactory::newInstance).thenThrow(new DatatypeConfigurationException("Test exception"));

        // when, then (expecting exception)
        assertThrows(RequestValidationException.class, () ->
                documentZelisRequestBuilder.mleInvoiceDocumentCall(documentIndex, startDate, endDate)
        );
    }

    private XMLGregorianCalendar createXMLGregorianCalendar(String date) throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(date);
    }
}
