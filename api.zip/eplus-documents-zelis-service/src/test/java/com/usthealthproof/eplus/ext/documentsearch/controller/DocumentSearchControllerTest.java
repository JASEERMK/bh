package com.usthealthproof.eplus.ext.documentsearch.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.DocumentEOBRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.DocumentViewRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.EopDocumentRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.IDcardViewRequest;
import com.usthealthproof.eplus.ext.documentsearch.model.response.*;
import com.usthealthproof.eplus.ext.documentsearch.service.DocumentSearchService;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



@ExtendWith(SpringExtension.class)
@WebMvcTest(DocumentSearchController.class)
public class DocumentSearchControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    DocumentSearchService documentSearchService;
    @MockitoBean
    private Validator validator;
    @MockitoBean
    private APIUtils apiUtils;
    @Autowired
    private ObjectMapper objectMapper;

    private List<DocumentSearchResponse> documentSearchResponses;

    EopDocumentResponse eopDocumentResponse  = new EopDocumentResponse();
    EopDocumentRequest eopDocumentRequest = new EopDocumentRequest();
    DocumentEOBResponse documentEOBResponse  = new DocumentEOBResponse();
    DocumentEOBRequest documentEOBRequest = new DocumentEOBRequest();
    IDcardViewRequest idCardViewRequest = new IDcardViewRequest();
    IdCardResponse idCardResponse = new IdCardResponse();
    DocumentViewResponse documentViewResponse = new DocumentViewResponse();
    DocumentViewRequest documentViewRequest = new DocumentViewRequest();


    @BeforeEach
    void setUp() {
        eopDocumentRequest.setClaimNumber("200000002-01");
        eopDocumentRequest.setProviderTaxId("12345");
        eopDocumentResponse.setPdfString("base64EncodedString");
        documentEOBRequest.setClaimId("200000002");
        documentEOBRequest.setMemberId("200000002445");
        documentEOBResponse.setType("sdfgh");
        documentEOBResponse.setFile("fffesedrftg");
        documentEOBResponse.setStatus("edddcff");
        idCardViewRequest.setMemberId("123456");
        idCardViewRequest.setPage("front");
        idCardViewRequest.setPlanType("basic");
        idCardViewRequest.setMaxMergeCount("1");
        idCardViewRequest.setDisplayOption("standard");
        idCardResponse.setMimeType("application/pdf");
        idCardResponse.setData("base64EncodedString");
        idCardResponse.setStatus("SUCCESS");
        documentViewResponse.setDocumentId("doc12345");
        documentViewResponse.setPdfFileString("base64EncodedString");
        documentViewResponse.setStatus("SUCCESS");
        documentSearchResponses = new ArrayList<>();
        DocumentSearchResponse response = new DocumentSearchResponse();
        response.setDocID("doc12345");
        response.setName("Sample Document");
        response.setDocumentExtension("EOB");
        documentSearchResponses.add(response);
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("JUnit test for Validating Accumulator Request Builder")
    void testValidation() throws Exception {
        // when - action or the behaviour
        doThrow(RequestValidationException.class).when(validator).validateEOPDocumentRequest(any(),any());
        // then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateEOPDocumentRequest(null,null));
    }

    @Test
    @DisplayName("JUnit test for getEopDocumentResponse - Spring security Authentication Validation")
    void testAuthentication() throws Exception {
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/docs/provider/eop")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(eopDocumentRequest)));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isUnauthorized());
    }

//    @Test
//    @DisplayName("JUnit test for invalid DocumentSearchRequest")
//    @WithMockUser(value = "user")
//    void testInvalidEopDocumentRequest() throws Exception {
//        EopDocumentRequest invalidRequest = new EopDocumentRequest();
//        invalidRequest.setProviderTaxId("12345<<");
//        invalidRequest.setClaimNumber("200000002-01<");
//
//        // Mock the validator to throw RequestValidationException for invalid input
//        doThrow(new RequestValidationException("Invalid Request")).when(validator).validateEOPDocumentRequest(anyString(), anyString());
//
//        // when - action or the behaviour
//        ResultActions response = mockMvc.perform(post("/v1/docs/provider/eop")
//                .contentType(MediaType.APPLICATION_JSON)
//                .with(csrf().asHeader())
//                .content(objectMapper.writeValueAsString(invalidRequest)));
//
//        // then - verify the output
//        response.andDo(print())
//                .andExpect(status().isBadRequest());
//    }


    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for EOP Document - Valid Input")
    void testValidInputEopDocument() throws Exception {
        // given - precondition or setup
        given(documentSearchService.getEOPDocument(any(), any(), any())).willReturn(eopDocumentResponse);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/docs/provider/eop")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(eopDocumentRequest)));

        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.pdfString", is(eopDocumentResponse.getPdfString())));
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for EOB Document - Valid Input")
    void testValidInputEOBDocument() throws Exception {
        // given - precondition or setup
        given(documentSearchService.getEOBDocumentByClaim(any(), any(), any())).willReturn(documentEOBResponse);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get("/v1/docs/member/eob")
                .param("claimId", documentEOBRequest.getClaimId())  // set the claimId parameter
                .param("memberId", documentEOBRequest.getMemberId())  // set the memberId parameter
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader()));

        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.type", is(documentEOBResponse.getType())))
                .andExpect(jsonPath("$.file", is(documentEOBResponse.getFile())))
                .andExpect(jsonPath("$.status", is(documentEOBResponse.getStatus())));
    }


    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getIdCardById - Valid Input")
    void testValidInputGetIdCardById() throws Exception {
        // given - precondition or setup
        given(documentSearchService.getDocumentByIdByZelisCall(anyString(), anyString(), anyString(), anyString(), anyString(), any(HttpServletRequest.class)))
                .willReturn(idCardResponse);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(post("/v1/docs/member/idcard")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .content(objectMapper.writeValueAsString(idCardViewRequest)));

        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.mimeType", is(idCardResponse.getMimeType())))
                .andExpect(jsonPath("$.data", is(idCardResponse.getData())))
                .andExpect(jsonPath("$.status", is(idCardResponse.getStatus())));
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getDocumentInfo - Valid Input")
    void testValidInputGetDocumentInfo() throws Exception {
        // given - precondition or setup
        given(documentSearchService.getDocumentView(anyString())).willReturn(documentViewResponse);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get("/v1/member/document/view")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .param("pdfFileKey", "validKey"));

        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$.documentId", is(documentViewResponse.getDocumentId())))
                .andExpect(jsonPath("$.pdfFileString", is(documentViewResponse.getPdfFileString())))
                .andExpect(jsonPath("$.status", is(documentViewResponse.getStatus())));
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for documentSearch - Valid Input")
    void testValidInputDocumentSearch() throws Exception {
        // given - precondition or setup
        given(documentSearchService.documentSearch(anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
                .willReturn(documentSearchResponses);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get("/v1/member/document/lookup")
                .contentType(MediaType.APPLICATION_JSON)
                .with(csrf().asHeader())
                .param("memberId", "12345")
                .param("uid", "67890")
                .param("uidType", "claim")
                .param("documentType", "EOB")
                .param("startDate", "2023-01-01")
                .param("endDate", "2023-12-31"));

        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$[0].docID", is(documentSearchResponses.get(0).getDocID())))
                .andExpect(jsonPath("$[0].name", is(documentSearchResponses.get(0).getName())))
                .andExpect(jsonPath("$[0].documentExtension", is(documentSearchResponses.get(0).getDocumentExtension())));
    }


}
