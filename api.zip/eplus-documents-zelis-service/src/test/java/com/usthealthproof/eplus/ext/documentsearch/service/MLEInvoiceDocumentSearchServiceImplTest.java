package com.usthealthproof.eplus.ext.documentsearch.service;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.tempuri.DocumentSearchDocumentFormat001V1;

import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisRequestBuilder;
import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisResponseBuilder;
import com.usthealthproof.eplus.ext.documentsearch.dao.MLEInvoiceDocumentSearchDao;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;

@ExtendWith(MockitoExtension.class)
public class MLEInvoiceDocumentSearchServiceImplTest {

    @Mock
    private DocumentZelisRequestBuilder documentZelisRequestBuilder;

    @Mock
    private DocumentZelisResponseBuilder documentZelisResponseBuilder;

    @Mock
    private MLEInvoiceDocumentSearchDao mleInvoiceDocumentSearchDao;

    @InjectMocks
    private MLEInvoiceDocumentSearchServiceImpl mleInvoiceDocumentSearchService;

    @Test
    public void testMleInvoiceDocumentcall_Success() throws Exception {
        // Mock data
        String documentIndex = "mockDocumentIndex";
        String startDate = "mockStartDate";
        String endDate = "mockEndDate";

        // Mock objects
        DocumentSearchDocumentFormat001V1 mockDocumentSearchDocument = new DocumentSearchDocumentFormat001V1();
        when(documentZelisRequestBuilder.mleInvoiceDocumentCall(any(), any(), any()))
                .thenReturn(mockDocumentSearchDocument);

        DocSearchFormat001ResultList mockDocSearchResultList = new DocSearchFormat001ResultList();
        when(mleInvoiceDocumentSearchDao.mleInvoiceDocumentResultResponse(any()))
                .thenReturn(mockDocSearchResultList);

        List<MLEInvoiceDocumentResponse> expectedResponse = new ArrayList<>();
        when(documentZelisResponseBuilder.getMLEInvoiceDocsZelisResponse(any()))
                .thenReturn(expectedResponse);

        // Call the method under test
        List<MLEInvoiceDocumentResponse> response = mleInvoiceDocumentSearchService.mleInvoiceDocumentCall(
                documentIndex, startDate, endDate);

        // Assertions
        assertNotNull(response);
        assertEquals(expectedResponse, response);

        // Verify method invocations
        verify(documentZelisRequestBuilder, times(1)).mleInvoiceDocumentCall(
                documentIndex, startDate, endDate);
        verify(mleInvoiceDocumentSearchDao, times(1)).mleInvoiceDocumentResultResponse(mockDocumentSearchDocument);
        verify(documentZelisResponseBuilder, times(1)).getMLEInvoiceDocsZelisResponse(mockDocSearchResultList);
    }

    @Test
    public void testMleInvoiceDocumentCall_NoDataFoundException() throws Exception {
        // Mock data
        String documentIndex = "mockDocumentIndex";
        String startDate = "mockStartDate";
        String endDate = "mockEndDate";

        // Mock exceptions
        when(documentZelisRequestBuilder.mleInvoiceDocumentCall(any(), any(), any()))
                .thenThrow(new NoDataFoundException("Mock NoDataFoundException"));

        // Call the method under test and assert exception
        try {
            mleInvoiceDocumentSearchService.mleInvoiceDocumentCall(documentIndex, startDate, endDate);
        } catch (NoDataFoundException e) {
            assertEquals("Mock NoDataFoundException", e.getMessage());
            verify(documentZelisRequestBuilder, times(1)).mleInvoiceDocumentCall(
                    documentIndex, startDate, endDate);
            return; // Test passed
        }

        // If NoDataFoundException is not thrown, fail the test
        fail("Expected NoDataFoundException was not thrown");
    }

    @Test
    public void testMleInvoiceDocumentCall_GeneralException() throws Exception {
        // Mock data
        String documentIndex = "mockDocumentIndex";
        String startDate = "mockStartDate";
        String endDate = "mockEndDate";

        // Mock exceptions
        when(documentZelisRequestBuilder.mleInvoiceDocumentCall(any(), any(), any()))
                .thenThrow(new RuntimeException("Mock RuntimeException"));

        // Call the method under test and assert exception
        try {
            mleInvoiceDocumentSearchService.mleInvoiceDocumentCall(documentIndex, startDate, endDate);
        } catch (ResponseValidationException e) {
            assertEquals("Mock RuntimeException", e.getCause().getMessage());
            verify(documentZelisRequestBuilder, times(1)).mleInvoiceDocumentCall(
                    documentIndex, startDate, endDate);
            return; // Test passed
        }

        // If ResponseValidationException is not thrown, fail the test
        fail("Expected ResponseValidationException was not thrown");
    }
}
