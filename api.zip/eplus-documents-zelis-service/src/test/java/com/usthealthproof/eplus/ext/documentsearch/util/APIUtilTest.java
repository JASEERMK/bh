package com.usthealthproof.eplus.ext.documentsearch.util;

import com.usthealthproof.eplus.ext.documentsearch.constants.DocumentConstants;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.model.response.ProblemDetails;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.ObjectFactory;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class APIUtilTest {

    @Mock
    Logger log;

    @InjectMocks
    APIUtils apiUtils;

    ProblemDetails problemDetails;
    ErrorResponse errorResponse;
    private DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6;

    @BeforeEach
    void setUp() {
        problemDetails = new ProblemDetails();
        problemDetails.setErrors(Arrays.asList("Data Not found"));
        problemDetails.setStatus("SUCCESS");

        errorResponse = new ErrorResponse();
        errorResponse.setProblemDetails(problemDetails);

        documentSearchCheckFormat001V6 = new ObjectFactory().createDocumentSearchCheckFormat001V6();
    }

    @Test
    void testSetErrorDetails() {
        // when - action or the behaviour
        ErrorResponse result = apiUtils.setErrorDetails("Data Not found", "SUCCESS");
        // then - verify the output
//        assertEquals(errorResponse, result);
    }

    @Test
    void testCreateProblemDetails() {
        // when - action or the behaviour
        ProblemDetails result = apiUtils.createProblemDetails("Data Not found", "SUCCESS");
        // then - verify the output
        assertEquals(problemDetails, result);
    }

    @Test
    void testUpdateDocumentSearchInputRequest() {
        // given
        documentSearchCheckFormat001V6.setTnsClaimNumber(null);
        documentSearchCheckFormat001V6.setTnsDocumentType(null);
        documentSearchCheckFormat001V6.setTnsEnrolleeId(null);

        // when
        DocumentSearchCheckFormat001V6 result = apiUtils.updateDocumentSearchInputRequest(documentSearchCheckFormat001V6);

        // then
        assertEquals(DocSearchType.RELEASED, result.getSearchType());
        assertFalse(result.isTnsShowPurgedReleased());
        assertNotNull(result.getTnsClaimNumber());
        assertNotNull(result.getTnsDocumentType());
        assertNotNull(result.getTnsEnrolleeId());
        assertEquals(DocumentConstants.NULL_CHECK, result.getTnsClaimNumber().getValue());
        assertEquals(DocumentConstants.NULL_CHECK, result.getTnsDocumentType().getValue());
        assertEquals(DocumentConstants.NULL_CHECK, result.getTnsEnrolleeId().getValue());
    }

    @Test
    void testUpdateMLEInvoiceSearchInputRequest() {
        // given
        DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1 = new ObjectFactory().createDocumentSearchDocumentFormat001V1();
        documentSearchDocumentFormat001V1.setTnsDocumentIndex1(null);

        // when
        DocumentSearchDocumentFormat001V1 result = apiUtils.updateMLEInvoiceSearchInputRequest(documentSearchDocumentFormat001V1);

        // then
        assertEquals(DocSearchType.RELEASED, result.getSearchType());
        assertFalse(result.isTnsShowPurgedReleased());
        assertNotNull(result.getTnsDocumentIndex1());
        assertEquals(DocumentConstants.NULL_CHECK, result.getTnsDocumentIndex1().getValue());
    }
}
