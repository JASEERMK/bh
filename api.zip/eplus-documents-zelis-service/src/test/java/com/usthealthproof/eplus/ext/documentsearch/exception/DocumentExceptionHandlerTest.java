package com.usthealthproof.eplus.ext.documentsearch.exception;

import com.usthealthproof.eplus.ext.documentsearch.model.response.ErrorResponse;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DocumentExceptionHandlerTest {

    @Mock
    private APIUtils apiUtils;

    @InjectMocks
    private DocumentExceptionHandler exceptionHandler;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    public void testRequestValidationHandler() {
        // Mock data
        String errorMessage = "Request validation error message";
        RequestValidationException ex = new RequestValidationException(errorMessage);
        WebRequest request = mock(WebRequest.class);

        // Mock behavior
        ErrorResponse mockErrorResponse = new ErrorResponse();
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(mockErrorResponse);

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.requestValidationHandler(ex, request);

        // Assertions
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(mockErrorResponse, responseEntity.getBody());
        // Add more assertions as needed based on your ErrorResponse structure
    }
    @Test
    public void testRequestValidationExceptionWithMessage() {
        // Test data
        String message = "This is the error message";

        // Instantiate the exception with the message
        RequestValidationException exception = new RequestValidationException(message);

        // Assertions
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testNoDataFoundExceptionHandler() {
        // Mock data
        NoDataFoundException ex = new NoDataFoundException("No data found message");

        // Mock behavior
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(new ErrorResponse());

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.noDataFoundExcpHandler(ex, null);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        // Add more assertions as needed based on your ErrorResponse structure
    }


    @Test
    public void testNoDataFoundExceptionHandler_Cause() {
        // Mock data
        Throwable cause = new RuntimeException("Underlying cause");
        NoDataFoundException ex = new NoDataFoundException(cause);

        // Mock behavior
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(new ErrorResponse());

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.noDataFoundExcpHandler(ex, null);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        // Add more assertions as needed based on your ErrorResponse structure
    }

    @Test
    public void testNoDataFoundExceptionHandler_MessageAndCause() {
        // Mock data
        String errorMessage = "No data found message";
        Throwable cause = new RuntimeException("Underlying cause");
        NoDataFoundException ex = new NoDataFoundException(errorMessage, cause);

        // Mock behavior
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(new ErrorResponse());

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.noDataFoundExcpHandler(ex, null);

        // Assertions
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        // Add more assertions as needed based on your ErrorResponse structure
    }

    @Test
    public void testNoDataFoundExceptionWithMessage() {
        // Test data
        String message = "No data found";

        // Instantiate the exception with the message
        NoDataFoundException exception = new NoDataFoundException(message);

        // Assertions
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }

    @Test
    public void testGlobalExceptionHandler() {
        // Mock data
        Exception ex = new Exception("Generic exception message");

        // Mock behavior
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(new ErrorResponse());

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.globalHandler(ex, null);

        // Assertions
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        // Add more assertions as needed based on your ErrorResponse structure
    }

    @Test
    public void testResponseValidationExceptionHandler() {
        // Mock data
        ResponseValidationException ex = new ResponseValidationException("Response validation error message");

        // Mock HttpServletRequest
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getRequestURI()).thenReturn("/test-uri");

        // Mock behavior
        when(apiUtils.setErrorDetails(anyString(), anyString())).thenReturn(new ErrorResponse());

        // Call exception handler method
        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.responseValidationHandler(ex, request);

        // Assertions
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        // Add more assertions as needed based on your ErrorResponse structure
    }
    @Test
    public void testResponseValidationExceptionWithCause() {
        // Create a mock Throwable cause
        Throwable cause = new Throwable("This is the cause");

        // Instantiate the exception with the cause
        ResponseValidationException exception = new ResponseValidationException(cause);

        // Assertions
        assertNotNull(exception);
        assertEquals("java.lang.Throwable: This is the cause", exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testRequestValidationExceptionWithCause() {
        // Create a mock Throwable cause
        Throwable cause = new Throwable("This is the cause");

        // Instantiate the exception with the cause
        RequestValidationException exception = new RequestValidationException(cause);

        // Assertions
        assertNotNull(exception);
        assertEquals("java.lang.Throwable: This is the cause", exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}
