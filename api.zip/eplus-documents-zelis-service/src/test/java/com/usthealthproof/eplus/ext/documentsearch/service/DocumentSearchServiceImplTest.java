package com.usthealthproof.eplus.ext.documentsearch.service;

import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisRequestBuilder;
import com.usthealthproof.eplus.ext.documentsearch.builder.DocumentZelisResponseBuilder;
import com.usthealthproof.eplus.ext.documentsearch.dao.DocumentZelisDao;
import com.usthealthproof.eplus.ext.documentsearch.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.model.response.*;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.xml.bind.JAXBElement;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.GetClaimsPdfV1;
import org.tempuri.IRedCardServices;
import org.tempuri.ObjectFactory;
import reactor.core.publisher.Mono;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SpringBootTest
public class DocumentSearchServiceImplTest {
    @MockitoBean
    private WebClient webClient;
    @Mock
    private DocumentZelisRequestBuilder documentZelisRequestBuilder;

    @Mock
    private DocumentZelisResponseBuilder documentZelisResponseBuilder;

    @Mock
    private DocumentZelisDao documentZelisDao;
    @Mock
    private Validator validator;
    @Mock
    private IRedCardServices iRedCardServices;

    @InjectMocks
    private DocumentSearchServiceImpl documentSearchService;
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;
    private WebClient.RequestHeadersSpec requestHeadersSpecMock;
    private WebClient.ResponseSpec responseSpecMock;
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(documentSearchService, "endpnt1", "mockEndpoint1");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "mockEndpoint2");
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "mockEndpoint3");
        ReflectionTestUtils.setField(documentSearchService, "token", "mockToken");
        ReflectionTestUtils.setField(documentSearchService, "medicalid", "mockMedicalId");
        ReflectionTestUtils.setField(documentSearchService, "dentalid", "mockDentalId");
        ReflectionTestUtils.setField(documentSearchService, "visionid", "mockVisionId");
        ReflectionTestUtils.setField(documentSearchService, "idCardDescription", "mockIdCardDescription");
        ReflectionTestUtils.setField(documentSearchService, "username", "testUsername");
        ReflectionTestUtils.setField(documentSearchService, "password", "testPassword");
        ReflectionTestUtils.setField(documentSearchService, "pharmacyId", "mockPharmacyId");

    }

    @Test
    void testGetDocumentByIdByZelisCall_Exception() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior to throw NullPointerException
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
        when(requestHeadersUriSpecMock.uri(anyString())).thenThrow(new NullPointerException("Simulated NPE"));

        // Call the service method and expect an exception
        assertThrows(NullPointerException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "M", "1", "option", request);
        });
    }

    @Test
    void testGetDocumentByIdByZelisCall_ExceptionForTypePharmacy() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior to throw NullPointerException
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
        when(requestHeadersUriSpecMock.uri(anyString())).thenThrow(new NullPointerException("Simulated NPE"));

        // Call the service method and expect an exception
        assertThrows(NullPointerException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "P", "1", "option", request);
        });
    }

    @Test
    void testGetDocumentByIdByZelisCall_NoDataFoundException_V() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior to throw NullPointerException
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
        when(requestHeadersUriSpecMock.uri(anyString())).thenThrow(new NullPointerException("Simulated NPE"));

        // Call the service method and expect an exception
        assertThrows(NullPointerException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "V", "1", "option", request);
        });
    }
    @Test
    void testGetDocumentByIdByZelisCall_NoDataFoundException_D() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior to throw NullPointerException
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
        when(requestHeadersUriSpecMock.uri(anyString())).thenThrow(new NullPointerException("Simulated NPE"));

        // Call the service method and expect an exception
        assertThrows(NullPointerException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "D", "1", "option", request);
        });
    }
    @Test
    void testGetDocumentByIdByZelisCall_NoDataFoundException_blank() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior to throw NullPointerException
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
        when(webClient.get()).thenReturn(requestHeadersUriSpecMock);
        when(requestHeadersUriSpecMock.uri(anyString())).thenThrow(new NullPointerException("Simulated NPE"));

        // Call the service method and expect an exception
        assertThrows(NullPointerException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "", "1", "option", request);
        });
    }

    @Test
    void testGetDocumentByIdByZelisCall_NoDataFoundException() {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior to throw NoDataFoundException
        given(responseSpecMock.bodyToMono(String.class)).willReturn(Mono.error(new NoDataFoundException("No data found")));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt1", "http://mock-endpoint");

        // Call the service method and expect an exception
        assertThrows(NoDataFoundException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "M", "1", "option", request);
        });
    }

    @Test
    void testGetDocumentByIdByZelisCall_ArrayIndexOutOfBoundsException() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to return a response that causes ArrayIndexOutOfBoundsException
        String zelisDocumentResponse1 = "invalid-response"; // Mocked response that will cause ArrayIndexOutOfBoundsException
        given(responseSpecMock.bodyToMono(String.class)).willReturn(Mono.just(zelisDocumentResponse1));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt1", "http://mock-endpoint");

        // Call the service method and expect an ArrayIndexOutOfBoundsException to be converted to NoDataFoundException
        assertThrows(NoDataFoundException.class, () -> {
            documentSearchService.getDocumentByIdByZelisCall("memberId", "1", "M", "1", "option", request);
        });
    }

    @Test
    void testGetEOBDocumentByClaim_Success() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to return a valid response
        String zelisEOBDocumentResponse1 = "{\"key\":\"value\"}";
        given(responseSpecMock.bodyToMono(String.class)).willReturn(Mono.just(zelisEOBDocumentResponse1));

        byte[] zelisDocumentResponse2 = "document-content".getBytes();
        given(responseSpecMock.bodyToMono(byte[].class)).willReturn(Mono.just(zelisDocumentResponse2));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method
        DocumentEOBResponse response = documentSearchService.getEOBDocumentByClaim("claimId", "memberId", request);

        // Assertions
        assertNotNull(response);
        // Add more assertions based on the expected behavior
    }

    @Test
    void testGetEOBDocumentByClaim_ArrayIndexOutOfBoundsException() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to return a response that causes NoDataFoundException
        String zelisEOBDocumentResponse1 = "invalid-response"; // Mocked response that will cause ArrayIndexOutOfBoundsException
        given(responseSpecMock.bodyToMono(String.class)).willReturn(Mono.just(zelisEOBDocumentResponse1));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method and expect an ArrayIndexOutOfBoundsException to be converted to NoDataFoundException
        assertThrows(NoDataFoundException.class, () -> {
            documentSearchService.getEOBDocumentByClaim("claimId", "memberId", request);
        });
    }

    @Test
    void testGetEOBDocumentByClaim_NoDataFoundExceptionHandling() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior to throw NoDataFoundException
        given(responseSpecMock.bodyToMono(String.class)).willThrow(new NoDataFoundException("No data found"));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method and expect a NoDataFoundException
        assertThrows(NoDataFoundException.class, () -> {
            documentSearchService.getEOBDocumentByClaim("claimId", "memberId", request);
        });
    }
    @Test
    void testGetEOBDocumentByClaim_GenericException() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior to throw a generic exception
        given(responseSpecMock.bodyToMono(String.class)).willThrow(new RuntimeException("Generic exception"));

        // Manually specify endpoint
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method and expect a RuntimeException
        assertThrows(RuntimeException.class, () -> {
            documentSearchService.getEOBDocumentByClaim("claimId", "memberId", request);
        });
    }
    @Test
    void testGetEOPDocument_Success() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to return a valid response
        String zelisEOPDocumentResponse1 = "{\"key\":\"value\"}";
        given(responseSpecMock.bodyToMono(String.class)).willReturn(Mono.just(zelisEOPDocumentResponse1));

        byte[] zelisDocumentResponse2 = "document-content".getBytes();
        given(responseSpecMock.bodyToMono(byte[].class)).willReturn(Mono.just(zelisDocumentResponse2));

        // Manually specify endpoint and token
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method
        EopDocumentResponse response = documentSearchService.getEOPDocument("claimNumber", "providerTaxId", request);

        // Assertions
        assertNotNull(response);
        // Add more assertions based on the expected behavior
    }
    @Test
    void testGetEOPDocument_NoDataFoundException() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to throw NoDataFoundException
        given(responseSpecMock.bodyToMono(String.class)).willThrow(new NoDataFoundException("No data found"));

        // Manually specify endpoint and token
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method and expect a NoDataFoundException
        assertThrows(NoDataFoundException.class, () -> {
            documentSearchService.getEOPDocument("claimNumber", "providerTaxId", request);
        });
    }


    @Test
    void testGetEOPDocument_GenericException() throws Exception {
        HttpServletRequest request = mock(HttpServletRequest.class);

        // Mock behavior for WebClient
        WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = Mockito.mock(WebClient.RequestHeadersUriSpec.class);
        WebClient.RequestHeadersSpec requestHeadersSpecMock = Mockito.mock(WebClient.RequestHeadersSpec.class);
        WebClient.ResponseSpec responseSpecMock = Mockito.mock(WebClient.ResponseSpec.class);

        // Set up the WebClient mock behavior
        given(webClient.get()).willReturn(requestHeadersUriSpecMock);
        given(requestHeadersUriSpecMock.uri(any(String.class))).willReturn(requestHeadersSpecMock);
        given(requestHeadersSpecMock.retrieve()).willReturn(responseSpecMock);
        given(responseSpecMock.onStatus(any(), any())).willReturn(responseSpecMock);

        // Mock behavior for bodyToMono to throw a generic exception
        given(responseSpecMock.bodyToMono(String.class)).willThrow(new RuntimeException("Generic exception"));

        // Manually specify endpoint and token
        ReflectionTestUtils.setField(documentSearchService, "endpnt3", "http://mock-endpoint3");
        ReflectionTestUtils.setField(documentSearchService, "endpnt2", "http://mock-endpoint2");
        ReflectionTestUtils.setField(documentSearchService, "token", "mock-token");

        // Call the service method and expect a RuntimeException
        assertThrows(RuntimeException.class, () -> {
            documentSearchService.getEOPDocument("claimNumber", "providerTaxId", request);
        });
    }


    @Test
    public void testGetDocumentView_Success() throws ResponseValidationException {
        // Mock data
        String pdfFileKey = "testPdfFileKey";

        // Create mock objects
        GetClaimsPdfV1 mockGetClaimsPdfV1 = new GetClaimsPdfV1();
        ObjectFactory objectFactory = new ObjectFactory();

        // Set TnsPdfFileKey using JAXBElement
        JAXBElement<String> pdfFileKeyElement = objectFactory.createGetClaimsPdfV1TnsPdfFileKey(pdfFileKey);
        mockGetClaimsPdfV1.setTnsPdfFileKey(pdfFileKeyElement);

        GetPdfResult mockGetPdfResult = new GetPdfResult();
        byte[] mockPdfBytes = "mockPdfBytes".getBytes();
        // Mock interactions
        when(documentZelisRequestBuilder.getPDFFileKey(pdfFileKey)).thenReturn(mockGetClaimsPdfV1);
        when(documentZelisDao.getPdfResultResponse(pdfFileKey)).thenReturn(mockGetPdfResult);
        when(documentZelisResponseBuilder.getDocumentZelisResponse(mockGetPdfResult)).thenReturn(new DocumentViewResponse());
    }

    @Test
    public void testGetDocumentView_ExceptionThrown() {
        // Mock data
        String pdfFileKey = "testPdfFileKey";

        // Mock interactions to throw exception
        when(documentZelisRequestBuilder.getPDFFileKey(pdfFileKey)).thenReturn(new GetClaimsPdfV1());
        when(documentZelisDao.getPdfResultResponse(any())).thenThrow(new ResponseValidationException("Test exception"));

        // Assertions
        assertThrows(ResponseValidationException.class, () -> {
            documentSearchService.getDocumentView(pdfFileKey);
        });
    }

    @Test
    public void testDocumentSearch_Success() throws Exception {
        // Mock data
        String memberId = "34567";
        String uid = "234567";
        String uidType = "mockUidType";
        String documentType = "mockDocumentType";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-06-01T00:00:00";
        // Mock objects
        DocumentSearchCheckFormat001V6 mockDocumentSearchCheck = new DocumentSearchCheckFormat001V6();
        when(documentZelisRequestBuilder.documentSearch(any(), any(), any(), any(), any()))
                .thenReturn(mockDocumentSearchCheck);

        DocSearchFormat001ResultListV6 mockDocSearchResultList = new DocSearchFormat001ResultListV6();
        when(documentZelisDao.documentSearchResultResponse(any()))
                .thenReturn(mockDocSearchResultList);

        List<DocumentSearchResponse> expectedResponse = new ArrayList<>();
        when(documentZelisResponseBuilder.getDocumentSearchZelisResponse(any()))
                .thenReturn(expectedResponse);
    }
    @Test
    public void testDocumentSearch_NoDataFoundException() throws Exception {
        // Mock data
        String memberId = "34567";
        String uid = "234567";
        String uidType = "mockUidType";
        String documentType = "mockDocumentType";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-06-01T00:00:00";

        // Mock objects
        DocumentSearchCheckFormat001V6 mockDocumentSearchCheck = new DocumentSearchCheckFormat001V6();
        when(documentZelisRequestBuilder.documentSearch(any(), any(), any(), any(), any()))
                .thenReturn(mockDocumentSearchCheck);

        when(documentZelisDao.documentSearchResultResponse(any()))
                .thenThrow(new NoDataFoundException("No Data Found"));
    }

    @Test
    public void testDocumentSearch_ResponseValidationException() throws Exception {
        // Mock data
        String memberId = "34567";
        String uid = "234567";
        String uidType = "mockUidType";
        String documentType = "mockDocumentType";
        String startDate = "2023-01-01T00:00:00";
        String endDate = "2023-06-01T00:00:00";

        // Mock objects
        DocumentSearchCheckFormat001V6 mockDocumentSearchCheck = new DocumentSearchCheckFormat001V6();
        when(documentZelisRequestBuilder.documentSearch(any(), any(), any(), any(), any()))
                .thenReturn(mockDocumentSearchCheck);

        when(documentZelisDao.documentSearchResultResponse(any()))
                .thenThrow(new RuntimeException("General Exception"));

        // Assert exception
        assertThrows(ResponseValidationException.class, () -> {
            documentSearchService.documentSearch(memberId, uid, uidType, documentType, startDate, endDate);
        });
    }
        @Test
    public void testCreateIdCardResponseForZelisCall_Success() {
        IdCardResponse idCardResponse = new IdCardResponse();
        String zelisDocumentResponse = "mockedData";

        assertDoesNotThrow(() -> invokePrivateMethod(documentSearchService, "createIdCardResponseForZelisCall", idCardResponse, zelisDocumentResponse));

        assertEquals("application/PDF", idCardResponse.getMimeType());
        assertEquals(zelisDocumentResponse, idCardResponse.getData());
    }


    @Test
    public void testCreateIdCardResponseForZelisCall_EmptyResponse() {
        IdCardResponse idCardResponse = new IdCardResponse();
        String mockResponse = "";

        assertThrows(NoDataFoundException.class, () ->
                invokePrivateMethod1(documentSearchService, "createIdCardResponseForZelisCall", idCardResponse, mockResponse));
    }

    @Test
    public void testCreateEOBDocumentResponseForZelisCall_Success() throws Exception {
        DocumentEOBResponse documentEOBResponse = new DocumentEOBResponse();
        String mockResponse = "mockPdfContent";

        invokePrivateMethod(documentSearchService, "createEOBDocumentResponseForZelisCall", documentEOBResponse, mockResponse);

        assertEquals("application/pdf", documentEOBResponse.getType());
        assertEquals(mockResponse, documentEOBResponse.getFile());
    }


    @Test
    public void testCreateEOBDocumentResponseForZelisCall_EmptyResponse() {
        DocumentEOBResponse documentEOBResponse = new DocumentEOBResponse();
        String mockResponse = "";

        assertThrows(NoDataFoundException.class, () ->
                invokePrivateMethod1(documentSearchService, "createEOBDocumentResponseForZelisCall", documentEOBResponse, mockResponse));
    }



    @Test
    public void testCreateEOPDocumentResponseForZelisCall_Success() throws Exception {
        EopDocumentResponse eopDocumentResponse = new EopDocumentResponse();
        String mockResponse = "mockPdfContent";

        invokePrivateMethod(documentSearchService, "createEOPDocumentResponseForZelisCall", eopDocumentResponse, mockResponse);

        assertEquals(mockResponse, eopDocumentResponse.getPdfString());
    }
    @Test
    public void testCreateEOPDocumentResponseForZelisCall_EmptyResponse() {
        EopDocumentResponse eopDocumentResponse = new EopDocumentResponse();
        String mockResponse = "";

        assertThrows(NoDataFoundException.class, () ->
                invokePrivateMethod1(documentSearchService, "createEOPDocumentResponseForZelisCall", eopDocumentResponse, mockResponse));
    }
    private void invokePrivateMethod1(Object instance, String methodName, Object... args) throws Exception {
        Method method = instance.getClass().getDeclaredMethod(methodName, args[0].getClass(), args[1].getClass());
        method.setAccessible(true);
        try {
            method.invoke(instance, args);
        } catch (Exception e) {
            if (e.getCause() instanceof Exception) {
                throw (Exception) e.getCause();
            } else {
                throw e;
            }
        }
    }
    private byte[] invokePrivateMethod(DocumentSearchServiceImpl instance, String methodName, Object... args) {
        try {
            return (byte[]) invokeMethod(instance, methodName, args);
        } catch (Exception e) {
            throw new RuntimeException("Failed to invoke private method: " + methodName, e);
        }
    }

    private Object invokeMethod(Object instance, String methodName, Object... args) throws Exception {
        Class<?>[] parameterTypes = new Class<?>[args.length];
        for (int i = 0; i < args.length; i++) {
            parameterTypes[i] = args[i].getClass();
        }
        java.lang.reflect.Method method = instance.getClass().getDeclaredMethod(methodName, parameterTypes);
        method.setAccessible(true);
        return method.invoke(instance, args);
    }





}
