package com.usthealthproof.eplus.ext.documentsearch.dao;

import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultListV6;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchType;
import org.datacontract.schemas._2004._07.ccp_docs.GetPdfResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.tempuri.DocumentSearchCheckFormat001V6;
import org.tempuri.IRedCardServices;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import jakarta.xml.bind.JAXBElement;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class DocumentZelisDaoImplTest {

    @Mock
    private IRedCardServices iRedCardServices;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private Logger log;

    @InjectMocks
    private DocumentZelisDaoImpl documentZelisDao;

    @BeforeEach
    void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        setPrivateField(documentZelisDao, "username", "testUsername");
        setPrivateField(documentZelisDao, "password", "testPassword");
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    @DisplayName("Test getPdfResultResponse with valid response")
    void testGetPdfResultResponse_ValidResponse() throws Exception {
        // given
        String pdfFileKey = "testKey";
        GetPdfResult getPdfResult = new GetPdfResult();
        when(iRedCardServices.getClaimsPdfV1(anyString(), anyString(), anyString())).thenReturn(getPdfResult);

        // when
        GetPdfResult result = documentZelisDao.getPdfResultResponse(pdfFileKey);

        // then
        assertNotNull(result);
        assertEquals(getPdfResult, result);
        verify(iRedCardServices).getClaimsPdfV1(anyString(), anyString(), anyString());

    }

    @Test
    @DisplayName("Test getPdfResultResponse with exception")
    void testGetPdfResultResponse_Exception() {
        // given
        String pdfFileKey = "testKey";
        when(iRedCardServices.getClaimsPdfV1(anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Service Exception"));

        // when
        Exception exception = assertThrows(RuntimeException.class, () -> {
            documentZelisDao.getPdfResultResponse(pdfFileKey);
        });

        // then
        assertEquals("Service Exception", exception.getMessage());
        verify(iRedCardServices).getClaimsPdfV1(anyString(), anyString(), anyString());

    }

    @Test
    @DisplayName("Test documentSearchResultResponse with valid response")
    void testDocumentSearchResultResponse_ValidResponse() throws Exception {
        // given
        DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6 = mock(DocumentSearchCheckFormat001V6.class);

        // Mock JAXBElement values
        JAXBElement<String> mockClaimNumber = new JAXBElement<>(new QName("claimNumber"), String.class, "claimNumber");
        JAXBElement<String> mockDocumentType = new JAXBElement<>(new QName("documentType"), String.class, "documentType");
        JAXBElement<String> mockEnrolleeId = new JAXBElement<>(new QName("enrolleeId"), String.class, "enrolleeId");

        when(documentSearchCheckFormat001V6.getSearchType()).thenReturn(DocSearchType.UNRELEASED);
        when(documentSearchCheckFormat001V6.isTnsShowPurgedReleased()).thenReturn(true);
        when(documentSearchCheckFormat001V6.getTnsStartDateReleased()).thenReturn(createXMLGregorianCalendar("2023-01-01"));
        when(documentSearchCheckFormat001V6.getTnsEndDateReleased()).thenReturn(createXMLGregorianCalendar("2023-12-31"));
        when(documentSearchCheckFormat001V6.getTnsClaimNumber()).thenReturn(mockClaimNumber);
        when(documentSearchCheckFormat001V6.getTnsDocumentType()).thenReturn(mockDocumentType);
        when(documentSearchCheckFormat001V6.getTnsEnrolleeId()).thenReturn(mockEnrolleeId);

        // Mock response
        DocSearchFormat001ResultListV6 docSearchFormat001ResultListV6 = new DocSearchFormat001ResultListV6();
        when(iRedCardServices.documentSearchCheckFormat001V6(anyString(), anyString(), any(DocSearchType.class), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString(), anyString(), anyString()))
                .thenReturn(docSearchFormat001ResultListV6);

        // Mock apiUtils update method behavior
        doReturn(documentSearchCheckFormat001V6) // Return the mock object itself
                .when(apiUtils).updateDocumentSearchInputRequest(any(DocumentSearchCheckFormat001V6.class));

        // when
        DocSearchFormat001ResultListV6 result = documentZelisDao.documentSearchResultResponse(documentSearchCheckFormat001V6);

        // then
        assertNotNull(result);
        assertEquals(docSearchFormat001ResultListV6, result);
        verify(apiUtils).updateDocumentSearchInputRequest(any(DocumentSearchCheckFormat001V6.class));
        verify(iRedCardServices).documentSearchCheckFormat001V6(anyString(), anyString(), any(DocSearchType.class), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString(), anyString(), anyString());
    }


    @Test
    @DisplayName("Test documentSearchResultResponse with service exception")
    void testDocumentSearchResultResponse_ServiceException() {
        // given
        DocumentSearchCheckFormat001V6 documentSearchCheckFormat001V6 = mock(DocumentSearchCheckFormat001V6.class);

        // Mock JAXBElement values
        JAXBElement<String> mockClaimNumber = new JAXBElement<>(new QName("claimNumber"), String.class, "claimNumber");
        JAXBElement<String> mockDocumentType = new JAXBElement<>(new QName("documentType"), String.class, "documentType");
        JAXBElement<String> mockEnrolleeId = new JAXBElement<>(new QName("enrolleeId"), String.class, "enrolleeId");

        when(documentSearchCheckFormat001V6.getSearchType()).thenReturn(DocSearchType.UNRELEASED);
        when(documentSearchCheckFormat001V6.isTnsShowPurgedReleased()).thenReturn(true);
        when(documentSearchCheckFormat001V6.getTnsStartDateReleased()).thenReturn(createXMLGregorianCalendar("2023-01-01"));
        when(documentSearchCheckFormat001V6.getTnsEndDateReleased()).thenReturn(createXMLGregorianCalendar("2023-12-31"));
        when(documentSearchCheckFormat001V6.getTnsClaimNumber()).thenReturn(mockClaimNumber);
        when(documentSearchCheckFormat001V6.getTnsDocumentType()).thenReturn(mockDocumentType);
        when(documentSearchCheckFormat001V6.getTnsEnrolleeId()).thenReturn(mockEnrolleeId);

        // Mock service to throw exception
        when(iRedCardServices.documentSearchCheckFormat001V6(anyString(), anyString(), any(DocSearchType.class), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("Service Exception"));

        // when & then
        Exception exception = assertThrows(RuntimeException.class, () -> {
            documentZelisDao.documentSearchResultResponse(documentSearchCheckFormat001V6);
        });

        assertEquals("Service Exception", exception.getMessage());
          }

    private XMLGregorianCalendar createXMLGregorianCalendar(String date) {
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(date);
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException(e);
        }
    }
}
