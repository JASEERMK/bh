package com.usthealthproof.eplus.ext.documentsearch.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.ext.documentsearch.model.response.MLEInvoiceDocumentResponse;
import com.usthealthproof.eplus.ext.documentsearch.service.MLEInvoiceDocumentSearchService;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;
import com.usthealthproof.eplus.ext.documentsearch.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.http.MediaType;

@ExtendWith(SpringExtension.class)
@WebMvcTest(MLEInvoiceDocumentSearchController.class)
public class MLEInvoiceDocumentSearchControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private MLEInvoiceDocumentSearchService mleInvoiceDocumentSearchService;
    @MockitoBean
    private Validator validator;
    @MockitoBean
    private APIUtils apiUtils;
    @Autowired
    private ObjectMapper objectMapper;

    private List<MLEInvoiceDocumentResponse> mleInvoiceDocumentResponses;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mleInvoiceDocumentResponses = new ArrayList<>();
        MLEInvoiceDocumentResponse response = new MLEInvoiceDocumentResponse();
        response.setDocID("doc12345");
        response.setPdfFileKey("pdfKey12345");
        mleInvoiceDocumentResponses.add(response);
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for mleInvoiceDocument - Valid Input")
    void testValidInputMleInvoiceDocument() throws Exception {
        // given - precondition or setup
        given(mleInvoiceDocumentSearchService.mleInvoiceDocumentCall(anyString(), anyString(), anyString()))
                .willReturn(mleInvoiceDocumentResponses);

        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get("/v1/member/document/mleinvoice")
                .contentType(MediaType.APPLICATION_JSON)
                        .param("documentIndex", "12345")
                        .param("startDate", "2023-01-01")
                        .param("endDate", "2023-12-31"));



        // then - verify the output
        response.andExpect(status().isOk())
                .andExpect(jsonPath("$[0].docID", is(mleInvoiceDocumentResponses.get(0).getDocID())))
                .andExpect(jsonPath("$[0].pdfFileKey", is(mleInvoiceDocumentResponses.get(0).getPdfFileKey())));
    }

}
