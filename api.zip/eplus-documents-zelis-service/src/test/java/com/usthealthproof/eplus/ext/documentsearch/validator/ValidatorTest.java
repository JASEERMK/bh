package com.usthealthproof.eplus.ext.documentsearch.validator;

import com.usthealthproof.eplus.ext.documentsearch.exception.RequestValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidatorTest {

    @Mock
    Logger log;
    @InjectMocks
    Validator validator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testValidateEOBDocumentRequest_WithBlankClaimId_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateEOBDocumentRequest("", "memberId")
        );
    }

    @Test
    void testValidateEOBDocumentRequest_WithBlankMemberId_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateEOBDocumentRequest("claimId", "")
        );
    }

    @Test
    void testValidateEOPDocumentRequest_WithBlankClaimNumber_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateEOPDocumentRequest("", "providerTaxId")
        );
    }

    @Test
    void testValidateEOPDocumentRequest_WithBlankProviderTaxId_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateEOPDocumentRequest("claimNumber", "")
        );
    }

    @Test
    void testValidateDocumentViewRequest_WithBlankPdfFileKey_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentViewRequest("")
        );
    }

    @Test
    void testValidateIdCardRequest_WithBlankMemberId_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateIdCardRequest("", "page", "planType")
        );
    }

    @Test
    void testValidateIdCardRequest_WithInvalidPage_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateIdCardRequest("memberId", ">>>y", "planType")
        );
    }
    @Test
    void testValidateIdCardRequest_WithBlankPage_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateIdCardRequest("memberId", "", "planType")
        );
    }
    @Test
    void testValidateIdCardRequest_WithInvalidPlanType_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateIdCardRequest("memberId", "front", "invalidPlanType")
        );
    }

    @Test
    void testValidateDocumentSearchRequest_WithBlankStartDate_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentSearchRequest("", "2023-12-31T00:00:00", "ABC")
        );
    }

    @Test
    void testValidateDocumentSearchRequest_WithBlankEndDate_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentSearchRequest("2023-01-01T00:00:00", "", "ABC")
        );
    }

    @Test
    void testValidateDocumentSearchRequest_WithBlankDocumentType_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentSearchRequest("2023-01-01T00:00:00", "2023-12-31T00:00:00", "")
        );
    }

    @Test
    void testValidateDocumentSearchRequest_WithInvalidDocumentTypeLength_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentSearchRequest("2023-01-01T00:00:00", "2023-12-31T00:00:00", "ABCD")
        );
    }

    @Test
    void testValidateDocumentSearchRequest_WithInvalidDocumentTypeFormat_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateDocumentSearchRequest("2023-01-01T00:00:00", "2023-12-31T00:00:00", "AB@")
        );
    }


    @Test
    void testValidateMLEInvoiceDocumentRequest_WithValidParameters_ShouldNotThrowException() {
        assertDoesNotThrow(() ->
                validator.validateMLEInvoiceDocumentRequest("2023-01-01T00:00:00", "2023-12-31T00:00:00", "123")
        );
    }


    @Test
    void testValidateMLEInvoiceDocumentRequest_WithBlankStartDate_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateMLEInvoiceDocumentRequest("", "2023-12-31T00:00:00", "123")
        );
    }

    @Test
    void testValidateMLEInvoiceDocumentRequest_WithBlankEndDate_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateMLEInvoiceDocumentRequest("2023-01-01T00:00:00", "", "123")
        );
    }
    @Test
    void testValidateMLEInvoiceDocumentRequest_WithBlankDocumentIndex_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateMLEInvoiceDocumentRequest("2023-01-01T00:00:00", "2023-12-31T00:00:00", "")
        );
    }


    @Test
    void testValidateMLEInvoiceDocumentRequest_WithInvalidStartDate_ShouldThrowException() {
        assertThrows(RequestValidationException.class, () ->
                validator.validateMLEInvoiceDocumentRequest("2023-01-01T00:00:0>", "2023-12-31T00:00:00", "123")
        );
    }



}