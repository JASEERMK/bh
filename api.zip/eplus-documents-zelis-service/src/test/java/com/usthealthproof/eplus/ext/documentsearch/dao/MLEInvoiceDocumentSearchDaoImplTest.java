package com.usthealthproof.eplus.ext.documentsearch.dao;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import jakarta.xml.bind.JAXBElement;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchFormat001ResultList;
import org.datacontract.schemas._2004._07.ccp_docs.DocSearchType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.tempuri.DocumentSearchDocumentFormat001V1;
import org.tempuri.IRedCardServices;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import com.usthealthproof.eplus.ext.documentsearch.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.documentsearch.util.APIUtils;

import java.util.GregorianCalendar;

public class MLEInvoiceDocumentSearchDaoImplTest {

    @Mock
    private APIUtils apiUtils;

    @Mock
    private IRedCardServices iRedCardServices;

    @InjectMocks
    private MLEInvoiceDocumentSearchDaoImpl dao;

    private final String username = "testUsername";
    private final String password = "testPassword";
    private final QName usernameQName = new QName("username");
    private final QName passwordQName = new QName("password");

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMleInvoiceDocumentResultResponse_Success() throws ResponseValidationException, DatatypeConfigurationException {
        // Mock data
        DocumentSearchDocumentFormat001V1 mockDocument = createMockDocument(DocSearchType.RELEASED);

        // Mock behaviors
        DocSearchFormat001ResultList expectedResult = new DocSearchFormat001ResultList();
        when(iRedCardServices.documentSearchDocumentFormat001V1(anyString(), anyString(), eq(DocSearchType.RELEASED), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString()))
                .thenReturn(expectedResult);

        // Call the method under test
        DocSearchFormat001ResultList result = dao.mleInvoiceDocumentResultResponse(mockDocument);
  }

    @Test
    public void testMleInvoiceDocumentResultResponse_Exception() throws DatatypeConfigurationException {
        // Mock data
        DocumentSearchDocumentFormat001V1 mockDocument = createMockDocument(DocSearchType.UNRELEASED);

        // Mock behavior to throw an exception
        RuntimeException simulatedException = new RuntimeException("Simulated exception");
        when(iRedCardServices.documentSearchDocumentFormat001V1(anyString(), anyString(), eq(DocSearchType.UNRELEASED), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString()))
                .thenThrow(simulatedException);
    }


    @Test
    @DisplayName("Test mleInvoiceDocumentResultResponse with service exception")
    void testMLEInvoiceDocumentResultResponse_ServiceException() throws Exception {
        // given
        DocumentSearchDocumentFormat001V1 documentSearchDocumentFormat001V1 = mock(DocumentSearchDocumentFormat001V1.class);

        // Mock JAXBElement values
        JAXBElement<String> mockDocumentIndex1 = new JAXBElement<>(new QName("documentIndex1"), String.class, "documentIndex1");

        when(documentSearchDocumentFormat001V1.getSearchType()).thenReturn(DocSearchType.UNRELEASED);
        when(documentSearchDocumentFormat001V1.isTnsShowPurgedReleased()).thenReturn(true);
        when(documentSearchDocumentFormat001V1.getTnsDocumentIndex1()).thenReturn(mockDocumentIndex1);

        // Throw a RuntimeException to simulate service exception
        NullPointerException exception = new NullPointerException("Service Exception");
        doThrow(exception).when(iRedCardServices).documentSearchDocumentFormat001V1(
                anyString(), anyString(), any(DocSearchType.class), anyBoolean(),
                any(XMLGregorianCalendar.class), any(XMLGregorianCalendar.class), anyString());

        // when & then
        Exception nullPointerExceptionexception = assertThrows(NullPointerException.class, () -> {
            dao.mleInvoiceDocumentResultResponse(null);
        });

    }
    private DocumentSearchDocumentFormat001V1 createMockDocument(DocSearchType searchType) throws DatatypeConfigurationException {
        DocumentSearchDocumentFormat001V1 mockDocument = new DocumentSearchDocumentFormat001V1();
        mockDocument.setSearchType(searchType);
        mockDocument.setTnsShowPurgedReleased(true);

        JAXBElement<String> usernameElement = new JAXBElement<>(usernameQName, String.class, username);
        JAXBElement<String> passwordElement = new JAXBElement<>(passwordQName, String.class, password);
        mockDocument.setTnsUsername(usernameElement);
        mockDocument.setTnsPassword(passwordElement);

        XMLGregorianCalendar startDate = createXMLGregorianCalendar("2024-01-01T00:00:00");
        XMLGregorianCalendar endDate = createXMLGregorianCalendar("2024-12-31T00:00:00");

        mockDocument.setTnsStartDateReleased(startDate);
        mockDocument.setTnsEndDateReleased(endDate);

        JAXBElement<String> mockTnsDocumentIndex1 = new JAXBElement<>(new QName("tnsDocumentIndex1"), String.class, "mockDocumentIndex1");
        mockDocument.setTnsDocumentIndex1(mockTnsDocumentIndex1);

        return mockDocument;
    }

    private XMLGregorianCalendar createXMLGregorianCalendar(String dateStr) throws DatatypeConfigurationException {
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTimeInMillis(System.currentTimeMillis());
        XMLGregorianCalendar xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
        return xmlGregorianCalendar;
    }
}
