package com.usthealthproof.eplus.hrp.issue.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.healthedge.IssuePortType;
import com.healthedge.connector.schema.issue.IssueResponseType;
import com.healthedge.connector.schema.issue.IssueType;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
@Component
public class IssueServiceDAOImpl implements IssueServiceDAO {

	@Autowired
	private IssuePortType issuePortType;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${application.getIssueDetailsQuery}")
	private String getIssueDetailsQuery;

	@Value("${application.insertIssueQuery}")
	private String insertIssueQuery;

	@Value("${application.updateIssueQuery}")
	private String updateIssueQuery;

	@Override
	public IssueResponseType submitIssue(IssueType issueType) {
		log.info("Inside submitIssue() of DAO class");

		return issuePortType.submit(issueType);
	}

	@Override
	public void insertIssueId(String issueId, IssueServiceRequest issueServiceRequest) {
		log.info("Inside insertIssueId() of DAO class");

		String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		try {
//            Checking Issue id is already existing or not
			jdbcTemplate.queryForObject(getIssueDetailsQuery, String.class, issueId);
//            Updating already existing Issue id
			jdbcTemplate.update(updateIssueQuery, issueServiceRequest.getIssueSummary(), currentDate, "Open", issueId);
		} catch (EmptyResultDataAccessException ex) {
//            Inserting a new issue, if there is no response from getIssueDetailsQuery
			jdbcTemplate.update(insertIssueQuery, issueId, issueServiceRequest.getIssueSummary(), currentDate, "", "Open");
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error("Error occurred for the CorrespondenceSearch service request and the CannotGetJdbcConnectionException is: ",
					jdbcException);
			throw jdbcException;
		}
	}
}
