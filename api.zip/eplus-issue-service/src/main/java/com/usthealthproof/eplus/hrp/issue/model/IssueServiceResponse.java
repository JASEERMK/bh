package com.usthealthproof.eplus.hrp.issue.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
@Schema(description = "Issue service response class")
public class IssueServiceResponse {

	@Schema(description = "Issue Id")
	private Long issueId;

}
