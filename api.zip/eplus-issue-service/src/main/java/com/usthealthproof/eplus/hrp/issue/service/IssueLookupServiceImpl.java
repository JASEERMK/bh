package com.usthealthproof.eplus.hrp.issue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.healthedge.connector.schema.issue.IssueLookupResponseType;
import com.usthealthproof.eplus.hrp.issue.builder.IssueLookupRequestBuilder;
import com.usthealthproof.eplus.hrp.issue.builder.IssueLookupResponseBuilder;
import com.usthealthproof.eplus.hrp.issue.dao.IssueLookupDAO;
import com.usthealthproof.eplus.hrp.issue.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;
import com.usthealthproof.eplus.hrp.issue.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Service

public class IssueLookupServiceImpl implements IssueLookupService {
	@Autowired
	private Validator validator;
	@Autowired
	private IssueLookupDAO issueLookupDAO;
	@Autowired
	private IssueLookupRequestBuilder issueLookupRequestBuilder;
	@Autowired
	private IssueLookupResponseBuilder issueLookupResponseBuilder;

	public IssueLookupResponse getIssueDetails(String issueId) throws ResponseValidationException {
		log.info("Inside getIssueDetails() of Service class");

		IssueLookupResponse issueLookupResponse = null;
		try {
			validator.validateIssueLookupRequest(issueId);
			IssueLookupResponseType issueLookupResponseType = issueLookupDAO
					.getIssueLookupResponse(issueLookupRequestBuilder.issueLookupRequestBuilder(Long.valueOf(issueId)));
			issueLookupResponse = issueLookupResponseBuilder.issueLookupResponseBuilder(issueLookupResponseType);
			issueLookupResponse.setIssueLookupStatus(issueLookupResponseType.getStatus().value());
			validator.validateIssueLookupResponse(issueLookupResponse);
		} catch (Exception ex) {
			log.error("Error occured for the IssueLookup service request: {} and the Exception is: {}", issueId, ex);
			throw ex;
		}
		return issueLookupResponse;

	}
}
