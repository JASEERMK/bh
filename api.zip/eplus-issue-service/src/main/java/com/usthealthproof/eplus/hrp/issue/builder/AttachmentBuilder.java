package com.usthealthproof.eplus.hrp.issue.builder;

import java.util.Base64;

import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.attachment.AttachmentActionType;
import com.healthedge.connector.schema.attachment.AttachmentType;
import com.healthedge.connector.schema.attachment.EntityType;
import com.healthedge.connector.schema.basetypes.CodeEntryInputType;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AttachmentBuilder {
	public AttachmentType attachmentRequestBuilder(String issueId, IssueServiceRequest issueRequest) {
		log.info("Inside attachmentRequestBuilder() of Builder class");

		AttachmentType attachmentType = new AttachmentType();
		attachmentType.setEntityType(EntityType.ISSUE);
		attachmentType.setEntityId(issueId);
		CodeEntryInputType codeEntryInputType = new CodeEntryInputType();
		codeEntryInputType.setCodeEntry("1");
		codeEntryInputType.setCodeSetName("AttachmentCreateReason");
		attachmentType.setMaintenanceReasonCode(codeEntryInputType);
		CodeEntryInputType codeEntryInputType1 = new CodeEntryInputType();
		codeEntryInputType1.setCodeSetName("AttachmentTypeCode");
		codeEntryInputType1.setCodeEntry("9");
		attachmentType.setAttachmentTypeCode(codeEntryInputType1);
		attachmentType.setFilename(issueRequest.getAttachment().getFileName());
		String pdfString = issueRequest.getAttachment().getContent();
		attachmentType.setContent(Base64.getDecoder().decode(pdfString));
		attachmentType.setAction(AttachmentActionType.ADD);
		return attachmentType;
	}
}
