package com.usthealthproof.eplus.hrp.issue.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.hrp.issue.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.issue.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceResponse;
import com.usthealthproof.eplus.hrp.issue.service.IssueLookupService;
import com.usthealthproof.eplus.hrp.issue.service.IssueService;
import com.usthealthproof.eplus.hrp.issue.validator.Validator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Issue Service")
@RequestMapping("/v1")
@RestController
@Slf4j
@SecurityRequirement(name = "IssueService")
public class IssueServiceController {
	@Autowired
	IssueService issueService;
	@Autowired
	Validator validator;
	@Autowired
	IssueLookupService issueLookupService;

	@PostMapping(value = "/issue")
	@Operation(summary = "Create or Update an Issue", method = "POST", description = "Service to create or update an issue in the Payor service", responses = {
			@ApiResponse(responseCode = "200", description = "Issue Created or Updated successfully", content = {
					@Content(schema = @Schema(implementation = IssueServiceResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No Data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "408", description = "Request Timeout", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }), })
	public IssueServiceResponse createOrUpdateissue(@Valid @RequestBody IssueServiceRequest issueServiceRequest,
			HttpServletRequest httpRequest) throws Exception {
		log.info("Inside createOrUpdateissue() of Controller class");

		validator.validateCreateOrUpdateIssueRequest(issueServiceRequest);
		return issueService.submitIssue(issueServiceRequest);

	}

	@GetMapping(value = "/issue/details")
	@Operation(summary = "To view the Issue details", method = "POST", description = "Service to get the details of an issue by providing the issue Id", responses = {
			@ApiResponse(responseCode = "200", description = "Issue Details Response", content = {
					@Content(schema = @Schema(implementation = IssueLookupResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No Data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "408", description = "Request Timeout", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }), })
	public IssueLookupResponse getIssueDetails(
			@Parameter(description = "Issue Identifier", required = true) @RequestParam(value = "issueId") @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: issueId is not in valid format") String issueId)
			throws ResponseValidationException {
		log.info("Inside getIssueDetails() of Controller class");

		return issueLookupService.getIssueDetails(issueId);

	}

}