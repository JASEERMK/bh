package com.usthealthproof.eplus.hrp.issue.configuration;

import io.swagger.v3.oas.models.servers.Server;
import org.apache.cxf.ext.logging.LoggingInInterceptor;
import org.apache.cxf.ext.logging.LoggingOutInterceptor;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.healthedge.IssueLookupPortType;
import com.healthedge.IssuePortType;
import com.healthedge.connector.service.attachment.AttachmentServicePortType;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Data
@Configuration
@Slf4j
public class IssueServiceConfiguration {

	@Value("${issueSubmit.service.address}")
	private String address;

	@Value("${issueSubmit.service.username}")
	private String username;

	@Value("${issueSubmit.service.password}")
	private String password;

	@Value("${issueLookUp.service.address}")
	private String issueLookUpaddress;

	@Value("${issueLookUp.service.username}")
	private String issueLookUpusername;

	@Value("${issueLookUp.service.password}")
	private String issueLookUppassword;

	@Value("${attachment.service.address}")
	private String attachmentaddress;

	@Value("${attachment.service.username}")
	private String attachmentusername;

	@Value("${attachment.service.password}")
	private String attachmentpassword;

	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	@Bean(name = "issuePortType")
	public IssuePortType issuePortType() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		try {
			jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
			jaxWsProxyFactoryBean.setServiceClass(IssuePortType.class);
			jaxWsProxyFactoryBean.setAddress(address);
			jaxWsProxyFactoryBean.setUsername(username);
			jaxWsProxyFactoryBean.setPassword(password);
			LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
			loggingInInterceptor.setPrettyLogging(true);
			LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
			loggingOutInterceptor.setPrettyLogging(true);
			jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor);
			jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor);
		} catch (Exception e) {
			log.error("Exception in the issuePortType ", e);
		}
		return (IssuePortType) jaxWsProxyFactoryBean.create();
	}

	@Bean(name = "attachmentServicePortType")
	public AttachmentServicePortType attachmentServicePortType() {

		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		try {
			jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
			jaxWsProxyFactoryBean.setServiceClass(AttachmentServicePortType.class);
			jaxWsProxyFactoryBean.setAddress(attachmentaddress);
			jaxWsProxyFactoryBean.setUsername(attachmentusername);
			jaxWsProxyFactoryBean.setPassword(attachmentpassword);

			LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
			loggingInInterceptor.setPrettyLogging(true);
			LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
			loggingOutInterceptor.setPrettyLogging(true);
			jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor);
			jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor);

		} catch (Exception e) {
			log.error("Exception in attachmentServicePortType:: ", e);
		}
		AttachmentServicePortType attachmentServicePortType = (AttachmentServicePortType) jaxWsProxyFactoryBean.create();
		HTTPConduit conduit = (HTTPConduit) ClientProxy.getClient(attachmentServicePortType).getConduit();
		HTTPClientPolicy policy = new HTTPClientPolicy();
		policy.setReceiveTimeout(5000);
		conduit.setClient(policy);

		return attachmentServicePortType;

	}

	@Bean(name = "issueLookupPortType")
	public IssueLookupPortType issueLookupPortType() {
		JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
		try {
			jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
			jaxWsProxyFactoryBean.setServiceClass(IssueLookupPortType.class);
			jaxWsProxyFactoryBean.setAddress(issueLookUpaddress);
			jaxWsProxyFactoryBean.setUsername(issueLookUpusername);
			jaxWsProxyFactoryBean.setPassword(issueLookUppassword);
			LoggingInInterceptor loggingInInterceptor = new LoggingInInterceptor();
			loggingInInterceptor.setPrettyLogging(true);
			LoggingOutInterceptor loggingOutInterceptor = new LoggingOutInterceptor();
			loggingOutInterceptor.setPrettyLogging(true);
			jaxWsProxyFactoryBean.getInInterceptors().add(loggingInInterceptor);
			jaxWsProxyFactoryBean.getOutInterceptors().add(loggingOutInterceptor);
		} catch (Exception e) {
			log.error("Exception in issueLookupPortType:: ", e);
		}
		return (IssueLookupPortType) jaxWsProxyFactoryBean.create();
	}

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-issue-service/api-docs Swagger UI:
	 * http://localhost:8080/eplus/eplus-issue-service/index.html
	 */
	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("Issue Service").description(
				"The Issue Service will supports the consumer to create and update an issue in the Payor system. It also supports to attach a PDF while creating or updating an issue.\n"
						+ "Along with the create/update feature, the Issue service provides the capability to view the details of any issue created or updated by passing the corresponding issue id. \n\n"
						+ "The consumers are provided with a url and credentials to get the access and refresh token. The service calls are made with valid access token in the header as Bearer Token. \n\n"
						+ "For every failure a problemDetails object with error message and status will be available in the response.")
				.version("5.0.0"));
	}

}
