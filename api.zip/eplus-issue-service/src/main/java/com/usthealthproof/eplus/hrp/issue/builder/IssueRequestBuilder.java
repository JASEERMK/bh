package com.usthealthproof.eplus.hrp.issue.builder;

import java.text.ParseException;

import javax.xml.datatype.DatatypeConfigurationException;

//import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.basetypes.CodeEntryInputType;
import com.healthedge.connector.schema.issue.CommentsType;
import com.healthedge.connector.schema.issue.IssueDetailsType;
import com.healthedge.connector.schema.issue.IssueType;
import com.healthedge.connector.schema.issue.IssueTypeList;
import com.healthedge.connector.schema.issue.LinkToType;
import com.healthedge.connector.schema.issue.LinkType;
import com.healthedge.connector.schema.issue.LinksTransactionType;
import com.healthedge.connector.schema.issue.TypeOfIssue;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class IssueRequestBuilder {

	public IssueType issueRequestBuilder(IssueServiceRequest issueServiceRequest)
			throws ParseException, DatatypeConfigurationException {
		log.info("Inside issueRequestBuilder() of Builder class");

		IssueType issueType = new IssueType();
		IssueDetailsType issueDetails = new IssueDetailsType();

		if (null != issueServiceRequest) {
			if (null != issueServiceRequest.getIssueId()) {
				issueDetails.setIssueIdentifier(issueServiceRequest.getIssueId());
			}
			setPriority(issueServiceRequest, issueDetails);
			setIssueType(issueServiceRequest, issueDetails);
			setSummaryAndDescription(issueServiceRequest, issueDetails);
			setIssueHistory(issueServiceRequest, issueDetails);
			setLinksTo(issueServiceRequest, issueDetails);
		}
		issueType.setIssue(issueDetails);
		return issueType;
	}

	public static void setPriority(IssueServiceRequest issueServiceRequest, IssueDetailsType issueDetails) {
		CodeEntryInputType codeEntryInputType = new CodeEntryInputType();
		if (issueServiceRequest.getPriority() != null && !issueServiceRequest.getPriority().toString().isEmpty()) {
			codeEntryInputType.setCodeSetName("IssuePrority");
			codeEntryInputType.setShortName(issueServiceRequest.getPriority().toString());
			issueDetails.setPriority(codeEntryInputType);

		}
	}

	public static void setIssueType(IssueServiceRequest issueServiceRequest, IssueDetailsType issueDetails) {
		if (null != issueServiceRequest.getIssueTypeList()) {
			IssueTypeList issueTypeList = new IssueTypeList();
			issueServiceRequest.getIssueTypeList().stream().forEach(issue -> {
				TypeOfIssue typeOfIssue = new TypeOfIssue();
				typeOfIssue.setCodeSetName(issue.getTypeName().codesetname);
				typeOfIssue.setShortName(issue.getTypeName().shortname);
				issueTypeList.getTypeOfIssue().add(typeOfIssue);
			});
			issueDetails.setIssueTypeList(issueTypeList);
		}
	}

	public static void setSummaryAndDescription(IssueServiceRequest issueServiceRequest, IssueDetailsType issueDetails) {

		if (StringUtils.isNotBlank(issueServiceRequest.getIssueSummary())) {
			issueDetails.setSummary(issueServiceRequest.getIssueSummary());
		}
		if (StringUtils.isNotBlank(issueServiceRequest.getIssueDescription())) {
			issueDetails.setDescription(issueServiceRequest.getIssueDescription());
		}
	}

	public static void setIssueHistory(IssueServiceRequest issueServiceRequest, IssueDetailsType issueDetails) {
		if (null != issueServiceRequest.getIssueHistory() && !issueServiceRequest.getIssueHistory().isEmpty()) {
			CommentsType issueHistory = new CommentsType();
			issueHistory.getComment().addAll(issueServiceRequest.getIssueHistory());
			issueDetails.setIssueHistory(issueHistory);
		}
	}

	public static void setLinksTo(IssueServiceRequest issueServiceRequest, IssueDetailsType issueDetails) {
		if (null != issueServiceRequest.getLinksTo()) {
			com.healthedge.connector.schema.issue.LinksToType linksToType = new com.healthedge.connector.schema.issue.LinksToType();
			issueServiceRequest.getLinksTo().stream().forEach(links -> {
				LinkToType linkToType = new LinkToType();
				linkToType.setTransactionType(LinksTransactionType.CREATE);
				linkToType.setLinkType(LinkType.valueOf(links.getEntityType().toString()));
				linkToType.setEntityHccId(links.getEntityHccId());
				if (null != links.getCommentHistory() && !links.getCommentHistory().isEmpty()) {
					CommentsType commentsType = new CommentsType();
					commentsType.getComment().addAll(links.getCommentHistory());
					linkToType.setCommentsHistory(commentsType);
				}
				linksToType.getLinkTo().add(linkToType);
			});
			issueDetails.setLinksTo(linksToType);
		}
	}
}
