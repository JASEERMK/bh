package com.usthealthproof.eplus.hrp.issue.builder;

import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.issue.IssueLookupCriteriaType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class IssueLookupRequestBuilder {

	public IssueLookupCriteriaType issueLookupRequestBuilder(Long issueId) {
		log.info("Inside issueLookupRequestBuilder() of Builder class");

		IssueLookupCriteriaType issueLookupCriteriaType = new IssueLookupCriteriaType();
		issueLookupCriteriaType.setIssueIdentifier(issueId);
		return issueLookupCriteriaType;

	}
}