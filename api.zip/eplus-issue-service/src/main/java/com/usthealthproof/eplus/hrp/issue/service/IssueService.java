package com.usthealthproof.eplus.hrp.issue.service;

import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceResponse;

public interface IssueService {
	public IssueServiceResponse submitIssue(IssueServiceRequest issueRequest) throws Exception;

}
