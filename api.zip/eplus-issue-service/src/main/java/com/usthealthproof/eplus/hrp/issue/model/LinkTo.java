package com.usthealthproof.eplus.hrp.issue.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(description = "Model to link type properties")
@JsonInclude(value = Include.NON_NULL)
public class LinkTo {

	@Schema(description = "Entity Type")
	private linkTypeEnum entityType;

	@Schema(description = "Comments related to linksTo")
	private List<String> commentHistory;

	@Schema(description = "Entity ID")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: Entity id is not in valid format")
	private String entityHccId;

	public enum linkTypeEnum {
		ACCOUNT("Account"), BENEFITPLAN("BenefitPlan"), BILL("Bill"),

		CLAIM("Claim"), MEMBER("Member"), PRACTITIONER("Practitioner"), PREMIUMPAYMENT("Premium Payment"),

		SUBSCRIPTION("Subscription"), SUPPLIER("Supplier"), SUPPLIERCONTRACT("SupplierContract"),
		SUPPLIERLOCATION("SupplierLocation"), SUPPLIERNETWORK("SupplierNetwork");

		private String value;

		linkTypeEnum(String value) {
			this.value = value;
		}

		public static linkTypeEnum fromValue(String text) {
			for (linkTypeEnum b : linkTypeEnum.values()) {
				if (String.valueOf(b.value).equals(text)) {
					return b;
				}
			}
			throw new IllegalArgumentException("Unexpected value '" + text + "'");
		}
	}

}
