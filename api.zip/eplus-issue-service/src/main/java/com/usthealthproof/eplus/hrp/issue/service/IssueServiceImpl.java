package com.usthealthproof.eplus.hrp.issue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.healthedge.connector.schema.attachment.AttachmentResponseType;
import com.healthedge.connector.schema.issue.IssueResponseType;
import com.usthealthproof.eplus.hrp.issue.builder.AttachmentBuilder;
import com.usthealthproof.eplus.hrp.issue.builder.IssueRequestBuilder;
import com.usthealthproof.eplus.hrp.issue.dao.AttachmentDAO;
import com.usthealthproof.eplus.hrp.issue.dao.IssueServiceDAO;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceResponse;
import com.usthealthproof.eplus.hrp.issue.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class IssueServiceImpl implements IssueService {

	@Autowired
	private IssueServiceDAO issueServiceDAO;
	@Autowired
	private AttachmentDAO attachmentDAO;
	@Autowired
	private Validator validator;
	@Autowired
	private AttachmentBuilder attachmentBuilder;
	@Autowired
	private IssueRequestBuilder issueRequestBuilder;
	@Autowired
	private IssueLookupServiceImpl issueLookupServiceImpl;

	@Override
	public IssueServiceResponse submitIssue(IssueServiceRequest issueServiceRequest) throws Exception {
		log.info("Inside submitIssue() of Service class");

		IssueServiceResponse issueServiceResponse = new IssueServiceResponse();
		try {
			if (null != issueServiceRequest.getIssueId()) {
				IssueLookupResponse issueLookupResponse = issueLookupServiceImpl
						.getIssueDetails(String.valueOf(issueServiceRequest.getIssueId()));
				validator.validateIssueLookupResponse(issueLookupResponse);
			}
			IssueResponseType issueResponseType = issueServiceDAO
					.submitIssue(issueRequestBuilder.issueRequestBuilder(issueServiceRequest));
			validator.validateIssueSubmitResponse(issueResponseType);
			long issueId = issueResponseType.getIssueIdentifier();

			getAttachmentResponseType(issueId, issueServiceRequest);
			String issueIdConverted = String.valueOf(issueId);
			issueServiceDAO.insertIssueId(issueIdConverted, issueServiceRequest);
			issueServiceResponse.setIssueId(issueResponseType.getIssueIdentifier());
			log.info("Issue submitted successfully");
		} catch (Exception ex) {
			log.error("Error occurred for the IssueSubmit/Attachment service request: {} and the Exception is: {}",
					issueServiceRequest, ex);
			throw ex;

		}

		return issueServiceResponse;
	}

	private String getAttachmentResponseType(Long issueId, IssueServiceRequest issueServiceRequest) {
		log.info("Inside getAttachmentResponseType()");

		AttachmentResponseType attachmentResponseType = new AttachmentResponseType();
		try {
			attachmentResponseType = attachmentDAO
					.setAttachmentContents(attachmentBuilder.attachmentRequestBuilder(issueId.toString(), issueServiceRequest));
			validator.validateAttachmentSubmitResponse(attachmentResponseType);
		} catch (Exception ex) {
			log.error("Error occured for the Attachment service request: {} and the Exception is: {}", issueServiceRequest, ex);
			throw ex;
		}
		return attachmentResponseType.getStatus().value();
	}

}
