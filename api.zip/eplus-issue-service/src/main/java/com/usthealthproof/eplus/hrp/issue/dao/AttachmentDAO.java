package com.usthealthproof.eplus.hrp.issue.dao;

import com.healthedge.connector.schema.attachment.AttachmentResponseType;
import com.healthedge.connector.schema.attachment.AttachmentType;

public interface AttachmentDAO {
	public AttachmentResponseType setAttachmentContents(AttachmentType attachmentType);

}
