package com.usthealthproof.eplus.hrp.issue.exception;

public class ResponseValidationException extends RuntimeException {
	private static final long serialVersionUID = 7189916314871714163L;

	public ResponseValidationException() {
	}

	public ResponseValidationException(String message) {
		super(message);
	}

	public ResponseValidationException(Throwable cause) {
		super(cause);
	}

	public ResponseValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
