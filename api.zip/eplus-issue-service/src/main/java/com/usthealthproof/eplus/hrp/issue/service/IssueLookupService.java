package com.usthealthproof.eplus.hrp.issue.service;

import com.usthealthproof.eplus.hrp.issue.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;

public interface IssueLookupService {
	public IssueLookupResponse getIssueDetails(String issueId) throws ResponseValidationException;

}
