package com.usthealthproof.eplus.hrp.issue;

import java.time.ZonedDateTime;
import java.util.TimeZone;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
@SecurityScheme(name = "IssueService", scheme = "bearer", type = SecuritySchemeType.HTTP , in = SecuritySchemeIn.HEADER)
public class IssueServiceApplication {
	@Value("${application.timeZone}")
	private String timeZone;
	private static final Logger log = LoggerFactory.getLogger(IssueServiceApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(IssueServiceApplication.class, args);
	}

	@PostConstruct
	public void init() {
		// Setting Spring Boot SetTimeZone
		TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
		log.info("Application timezone is {}. Today = {} ", TimeZone.getDefault().toZoneId(), ZonedDateTime.now());

	}
}
