package com.usthealthproof.eplus.hrp.issue.validator;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

//import com.usthealthproof.eplus.hrp.issue.model.IssueLookupRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;

import com.healthedge.connector.schema.attachment.AttachmentResponseType;
import com.healthedge.connector.schema.issue.IssueResponseType;
import com.usthealthproof.eplus.hrp.issue.constant.IssueConstant;
import com.usthealthproof.eplus.hrp.issue.exception.RequestValidationException;
import com.usthealthproof.eplus.hrp.issue.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Component
@Slf4j
public class Validator {

	@Value("${application.charactersToReplace}")
	private String charactersToReplace;

	public void validateCreateOrUpdateIssueRequest(IssueServiceRequest issueRequest) throws RequestValidationException {
		log.info("Inside validateCreateOrUpdateIssueRequest()");

		if (null == issueRequest) {
			throw new RequestValidationException("Invalid request: Request Fields are NULL");
		}

		if (StringUtils.isBlank(issueRequest.getIssueSummary())) {
			throw new RequestValidationException("Invalid request: Issue Summary is mandatory");
		}

		if (Objects.isNull(issueRequest.getIssueTypeList())) {
			throw new RequestValidationException("Invalid request: Issue Type is mandatory");
		}

	}

	public void validateIssueSubmitResponse(IssueResponseType issueResponseType) throws ResponseValidationException {
		log.info("Inside validateIssueSubmitResponse()");

		if (null == issueResponseType) {
			log.info("Issue submit response is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_SUBMIT_FAILURE_MESSAGE);
		}

		if (null == issueResponseType.getStatus()) {
			log.info("Issue submit status is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_SUBMIT_FAILURE_MESSAGE);
		}

		if (null == issueResponseType.getIssueIdentifier()) {
			log.info("Issue ID is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_SUBMIT_FAILURE_MESSAGE);

		}

		String issueSubmitStatus = issueResponseType.getStatus().value();
		if (StringUtils.isNotBlank(issueSubmitStatus) && !StringUtils.equalsIgnoreCase("SUCCESS", issueSubmitStatus)) {
			log.error("Status received from Issue Submit Service is not success, but it is {}", issueSubmitStatus);
			if (null != issueResponseType.getErrors() && null != issueResponseType.getErrors().getError()
					&& !issueResponseType.getErrors().getError().isEmpty()
					&& StringUtils.isNotBlank(issueResponseType.getErrors().getError().get(0).getMessage())) {
				String issueErrorMsg = issueResponseType.getErrors().getError().get(0).getMessage();
				String formattedErrorMsg = formatErrorMessage(issueErrorMsg);

				throw new ResponseValidationException(formattedErrorMsg);
			}
		}
	}

	public void validateAttachmentSubmitResponse(AttachmentResponseType attachmentResponseType)
			throws ResponseValidationException {
		log.info("Inside validateAttachmentSubmitResponse()");

		if (null == attachmentResponseType) {
			log.info("Attachment service response is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_SUBMIT_FAILURE_MESSAGE);
		}

		if (null == attachmentResponseType.getStatus()) {
			log.info("Attachment service status is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_SUBMIT_FAILURE_MESSAGE);
		}

		String attachmentServiceStatus = attachmentResponseType.getStatus().value();
		if (StringUtils.isNotBlank(attachmentServiceStatus)
				&& !StringUtils.equalsIgnoreCase("SUCCESS", attachmentServiceStatus)) {
			log.error("Status received from Attachment Service is not success, but it is {}", attachmentServiceStatus);
			if (null != attachmentResponseType.getErrors() && null != attachmentResponseType.getErrors().getError()
					&& !attachmentResponseType.getErrors().getError().isEmpty()
					&& StringUtils.isNotBlank(attachmentResponseType.getErrors().getError().get(0).getMessage())) {
				String attachmentErrorMsg = attachmentResponseType.getErrors().getError().get(0).getMessage();
				String formattedErrorMsg = formatErrorMessage(attachmentErrorMsg);
				throw new ResponseValidationException(formattedErrorMsg);
			}
		}

	}

	private String formatErrorMessage(String errorMsg) {
		log.info("Inside formatErrorMessage() and the error message is: {}", errorMsg);

		List<String> CharactersToReplaceList = Arrays.asList(StringUtils.split(charactersToReplace, ","));
		String delimiter = "";
		errorMsg = Pattern.compile(delimiter).splitAsStream(errorMsg).filter(s -> !CharactersToReplaceList.contains(s))
				.collect(Collectors.joining(delimiter));
		if (StringUtils.containsIgnoreCase(errorMsg, ": null")) {
			errorMsg = StringUtils.replaceIgnoreCase(errorMsg, ": null", delimiter);
		}
		if (StringUtils.containsIgnoreCase(errorMsg, "null")) {
			errorMsg = StringUtils.replaceIgnoreCase(errorMsg, "null", delimiter);
		}
		return errorMsg;
	}

	public void validateIssueLookupRequest(String issueId) throws RequestValidationException {
		log.info("Inside validateIssueLookupRequest()");
		if (StringUtils.isBlank(issueId)) {
			throw new RequestValidationException("Invalid request: issueId is mandatory");
		}

	}

	public void validateIssueLookupResponse(IssueLookupResponse issueLookupResponse) throws ResponseValidationException {
		log.info("Inside validateIssueLookupResponse()");
		if (null == issueLookupResponse) {
			log.info("issueLookupResponse is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_LOOKUP_FAILURE_MESSAGE);

		}

		if (StringUtils.isBlank(issueLookupResponse.getIssueLookupStatus())
				|| !StringUtils.equalsIgnoreCase("MATCH FOUND", issueLookupResponse.getIssueLookupStatus())) {
			log.info("issueLookupResponse LookupStatus  is: {}", issueLookupResponse.getIssueLookupStatus());
			throw new ResponseValidationException(IssueConstant.ISSUE_LOOKUP_FAILURE_MESSAGE);
		}

	}

}