package com.usthealthproof.eplus.hrp.issue.dao;

import com.healthedge.connector.schema.issue.IssueLookupCriteriaType;
import com.healthedge.connector.schema.issue.IssueLookupResponseType;

public interface IssueLookupDAO {

	public IssueLookupResponseType getIssueLookupResponse(IssueLookupCriteriaType createLookupRequest);

}
