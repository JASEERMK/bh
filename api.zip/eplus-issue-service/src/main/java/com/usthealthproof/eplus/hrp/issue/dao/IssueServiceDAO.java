package com.usthealthproof.eplus.hrp.issue.dao;

import com.healthedge.connector.schema.issue.IssueResponseType;
import com.healthedge.connector.schema.issue.IssueType;
import com.usthealthproof.eplus.hrp.issue.model.IssueServiceRequest;

public interface IssueServiceDAO {
	public IssueResponseType submitIssue(IssueType issueType);

	public void insertIssueId(String issueId, IssueServiceRequest issueRequest);

}
