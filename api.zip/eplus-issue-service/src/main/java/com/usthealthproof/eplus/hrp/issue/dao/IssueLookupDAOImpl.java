package com.usthealthproof.eplus.hrp.issue.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healthedge.IssueLookupPortType;
import com.healthedge.connector.schema.issue.IssueLookupCriteriaType;
import com.healthedge.connector.schema.issue.IssueLookupResponseType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class IssueLookupDAOImpl implements IssueLookupDAO {
	@Autowired
	private IssueLookupPortType issueLookupPortType;

	@Override
	public IssueLookupResponseType getIssueLookupResponse(IssueLookupCriteriaType createLookupRequest) {
		log.info("Inside getIssueLookupResponse");

		return issueLookupPortType.getIssue(createLookupRequest);
	}

}
