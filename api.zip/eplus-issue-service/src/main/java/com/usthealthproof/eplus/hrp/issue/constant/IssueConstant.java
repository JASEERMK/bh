package com.usthealthproof.eplus.hrp.issue.constant;

public class IssueConstant {

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details";
	public static final String JDBC_EXCEPTION = "Error occurred during Search. Please contact your supervisor";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String ISSUE_SUBMIT_FAILURE_MESSAGE = "Submitting Issue service failed";
	public static final String ISSUE_LOOKUP_FAILURE_MESSAGE = "There is no issue associated with the given Issue Id";

}
