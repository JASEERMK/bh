package com.usthealthproof.eplus.hrp.issue.exception;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.usthealthproof.eplus.hrp.issue.constant.IssueConstant;
import com.usthealthproof.eplus.hrp.issue.model.ErrorResponse;
import com.usthealthproof.eplus.hrp.issue.model.ProblemDetails;
import com.usthealthproof.eplus.hrp.issue.util.APIUtils;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class IssueServiceExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	private APIUtils apiUtils;

	/**
	 * For handling the invalid requests
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> invalidRequestHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException Occured: {} , Error Details: {} ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getMessage(), IssueConstant.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * For handling the response validations
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ResponseValidationException.class)
	public final ResponseEntity<ErrorResponse> entityNotFoundHandler(ResponseValidationException ex, WebRequest request) {
		log.error("ResponseValidationException Occured: {} , Error Details: {} ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetails(ex.getMessage(), IssueConstant.FAILURE), HttpStatus.NOT_FOUND);
	}

	/**
	 * Exception Handler for JDBC connection problems
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(CannotGetJdbcConnectionException.class)
	public final ResponseEntity<ErrorResponse> jdbcExceptionHandler(CannotGetJdbcConnectionException ex, WebRequest request) {
		log.error("CannotGetJdbcConnectionException Caught : {} {} ", ex.getMessage(), ex);
		if (StringUtils.containsIgnoreCase(ex.getMessage(), "Failed to obtain JDBC Connection")) {
			return new ResponseEntity<>(setErrorDetails(IssueConstant.JDBC_EXCEPTION, IssueConstant.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			return new ResponseEntity<>(setErrorDetails(IssueConstant.EXCEPTION_MESSAGE, IssueConstant.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * For handling the the general exceptions
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Occured: {} , Error Details: {} ", ex.getMessage(), ex);

		if (StringUtils.containsAnyIgnoreCase(ex.getMessage(), "Could not receive Message", "Could not send Message",
				"Connection reset", "Read timed out")
				|| StringUtils.containsAnyIgnoreCase(ex.toString(), "Connection reset", "Read timed out")) {
			return new ResponseEntity<>(setErrorDetails(IssueConstant.TIMEOUT_EXCEPTION_MESSAGE, IssueConstant.FAILURE),
					HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<>(setErrorDetails(IssueConstant.EXCEPTION_MESSAGE, IssueConstant.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * For handling the pattern validations
	 */
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		log.error("MethodArgumentNotValidException Caught : {} {} ", ex.getMessage(), ex);
		return new ResponseEntity<>(setErrorDetailsAsList(ex.getBindingResult().getFieldErrors(), IssueConstant.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Method to setting the Error Details into ErrorResponse
	 * 
	 * @param message
	 * @param status
	 * @return
	 */
	private ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(message, status));
		return errorResponse;
	}

	/**
	 * Common Method for the error details
	 */
	private ErrorResponse setErrorDetailsAsList(List<FieldError> fieldErrors, String status) {
		log.info("Inside setErrorDetailsAsList()");
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		ArrayList<String> errorList = new ArrayList<>();
		for (FieldError fieldError : fieldErrors) {
			errorList.add(fieldError.getDefaultMessage());
		}
		problemDetails.setErrors(errorList);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}
}
