package com.usthealthproof.eplus.hrp.issue.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Component
@JsonInclude(value = Include.NON_NULL)
@Schema(description = "Model to hold the Issue related informations")
public class IssueLookupResponse {

	@Schema(description = "Issue Lookup status")
	private String issueLookupStatus;

	@Schema(description = "Issue status")
	private String status;

	@Schema(description = "Type of Issue")
	private List<TypeOfIssue> issueTypeList;

	@Schema(description = "Issue Summary")
	private String issueSummary;

	@Schema(description = "Issue assigned group")
	private String assignedToGroup;

	@Schema(description = "Description about the issue")
	private String description;

	@Schema(description = "Issue priority")
	private String priority;

	@Schema(description = "Assigned to Owner")
	private String assignedToOwner;

	@Schema(description = "Issue linksTo")
	private List<LinkTo> linksTo;

	@Schema(description = "Issue History Comments")
	private List<String> issueHistory;

}
