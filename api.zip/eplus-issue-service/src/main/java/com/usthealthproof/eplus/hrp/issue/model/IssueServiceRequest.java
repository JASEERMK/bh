package com.usthealthproof.eplus.hrp.issue.model;

import java.util.List;

import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Component
@Schema(description = "Issue Service request model")
public class IssueServiceRequest {

	@Schema(description = "Issue Id, required for updating an issue")
	private Long issueId;

	@Schema(description = "Issue Summary", requiredMode = Schema.RequiredMode.REQUIRED)
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: issueSummary is not in valid format")
	private String issueSummary;

	@Schema(description = "Issue Priority")
	private PriorityEnum priority;

	@Schema(description = "Issue Description")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: issueDescription is not in valid format")
	private String issueDescription;

	@Valid
	@Schema(description = "Issue linksTo")
	private List<LinkTo> linksTo;

	@Valid
	@Schema(description = "Issue Type Lists")
	private List<TypeOfIssue> issueTypeList;

	@Valid
	@Schema(description = "Object to hold the attachment details")
	private Attachment attachment;

	@Schema(description = "Issue History")
	private List<String> issueHistory;

	public enum PriorityEnum {
		LOW("Low"),

		MEDIUM("Medium"),

		HIGH("High");

		private String value;

		PriorityEnum(String value) {
			this.value = value;
		}
	}

}
