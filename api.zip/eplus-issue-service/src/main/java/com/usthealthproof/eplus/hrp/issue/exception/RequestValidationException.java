package com.usthealthproof.eplus.hrp.issue.exception;

public class RequestValidationException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public RequestValidationException() {
	}

	public RequestValidationException(String message) {
		super(message);
	}

	public RequestValidationException(Throwable cause) {
		super(cause);
	}

	public RequestValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
