package com.usthealthproof.eplus.hrp.issue.builder;

import static org.apache.commons.lang.StringUtils.defaultString;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.healthedge.connector.schema.issue.IssueLookupResponseType;
import com.usthealthproof.eplus.hrp.issue.constant.IssueConstant;
import com.usthealthproof.eplus.hrp.issue.exception.ResponseValidationException;
import com.usthealthproof.eplus.hrp.issue.model.IssueLookupResponse;
import com.usthealthproof.eplus.hrp.issue.model.LinkTo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class IssueLookupResponseBuilder {
	public IssueLookupResponse issueLookupResponseBuilder(IssueLookupResponseType issueLookupResponseType) {
		log.info("Inside issueLookupResponseBuilder() of Builder class");

		IssueLookupResponse issueLookupResponse = new IssueLookupResponse();
		if (null != issueLookupResponseType.getIssue()) {
			if (StringUtils.isNotBlank(issueLookupResponseType.getIssue().getStatus().value())) {
				issueLookupResponse.setStatus(issueLookupResponseType.getIssue().getStatus().value());
			}
			if (StringUtils.isNotBlank(issueLookupResponseType.getIssue().getSummary())) {
				issueLookupResponse.setIssueSummary(issueLookupResponseType.getIssue().getSummary());
			}
			if (null != issueLookupResponseType.getIssue().getPriority().toString()) {
				issueLookupResponse.setPriority(issueLookupResponseType.getIssue().getPriority().getShortName());
			}
			if (StringUtils.isNotBlank(issueLookupResponseType.getIssue().getAssignedToGroup())) {
				issueLookupResponse.setAssignedToGroup(issueLookupResponseType.getIssue().getAssignedToGroup());
			}
			if (StringUtils.isNotBlank(issueLookupResponseType.getIssue().getAssignedToOwner())) {
				issueLookupResponse.setAssignedToOwner((issueLookupResponseType.getIssue().getAssignedToOwner()));
			}
			if (StringUtils.isNotBlank(issueLookupResponseType.getIssue().getDescription())) {
				issueLookupResponse.setDescription(defaultString(issueLookupResponseType.getIssue().getDescription()));
			}

			if (null != (issueLookupResponseType.getIssue().getLinksTo().toString())) {
				List<LinkTo> linkToResponse = new ArrayList<>();
				issueLookupResponseType.getIssue().getLinksTo().getLinkTo().stream().forEach(linktype -> {
					LinkTo linkToType = new LinkTo();
					if (null != linktype.getLinkType().value()) {
						linkToType.setEntityType(LinkTo.linkTypeEnum.fromValue(linktype.getLinkType().value()));
					}
					if (null != linktype.getEntityHccId()) {
						linkToType.setEntityHccId(linktype.getEntityHccId());
					}
					if (null != linktype.getCommentsHistory() && null != linktype.getCommentsHistory().getComment()) {
						linkToType.setCommentHistory(linktype.getCommentsHistory().getComment());
					}
					linkToResponse.add(linkToType);
				});

				issueLookupResponse.setLinksTo(linkToResponse);
			}

			List<String> issueHistories;
			if (null != issueLookupResponseType.getIssue().getIssueHistory()
					&& null != issueLookupResponseType.getIssue().getIssueHistory().getComment()) {
				issueHistories = issueLookupResponseType.getIssue().getIssueHistory().getComment().stream()
						.collect(Collectors.toList());
				issueLookupResponse.setIssueHistory(issueHistories);
			}

			return issueLookupResponse;
		} else {
			log.info("issueLookupResponseType.getIssue() is NULL");
			throw new ResponseValidationException(IssueConstant.ISSUE_LOOKUP_FAILURE_MESSAGE);
		}
	}
}