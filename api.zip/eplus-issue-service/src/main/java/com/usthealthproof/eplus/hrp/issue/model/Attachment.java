package com.usthealthproof.eplus.hrp.issue.model;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(description = "Model to hold the Attachment details")
public class Attachment implements Serializable {

	private static final long serialVersionUID = 7575353493481964506L;
	@Schema(description = "File Name")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: fileName is not in valid format")
	private String fileName;

	@Schema(description = "PDF string in Base64 encoded format")
	private String content;

}
