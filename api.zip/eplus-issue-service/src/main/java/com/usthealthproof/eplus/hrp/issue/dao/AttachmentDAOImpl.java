package com.usthealthproof.eplus.hrp.issue.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.healthedge.connector.schema.attachment.AttachmentResponseType;
import com.healthedge.connector.schema.attachment.AttachmentType;
import com.healthedge.connector.service.attachment.AttachmentServicePortType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class AttachmentDAOImpl implements AttachmentDAO {
	@Autowired
	private AttachmentServicePortType attachmentServicePortType;

	@Override
	public AttachmentResponseType setAttachmentContents(AttachmentType attachmentType) {
		log.info("Inside setAttachmentContents() of DAO class");

		return attachmentServicePortType.process(attachmentType);
	}

}
