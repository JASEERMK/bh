package com.usthealthproof.eplus.hrp.issue.model;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Issue type class")
@Data
@Component
public class TypeOfIssue {

	public typeName typeName;

	public enum typeName {

		MEMBER("IssueType", "Member"),

		ENROLLMENT("MemberIssue", "Enrollment"), PREMIUMPAYMENT("EnrollmentIssue", "Premium Payment"),
		ADDRESSCHANGE("EnrollmentIssue", "Address Change"), TERMINATIONREQUEST("EnrollmentIssue", "Termination Request"),
		BENEFITS("EnrollmentIssue", "Benefits"),

		CLAIMMEMBER("MemberIssue", "Claim"), DENIEDSERVICE("ClaimMemberIssue", "Denied Service"),
		QUESTIONONSERVICESREPORTED("ClaimMemberIssue", "Question on Services Reported"),

		PROVIDER("IssueType", "Provider"),

		CLAIM("ProviderIssue", "Claim Issue"), PRICING("ClaimIssue", "Pricing"), PROVIDERENROLLMENT("ClaimIssue", "Enrollment"),
		DATAENTRY("ClaimIssue", "Data Entry"),

		ELIGIBILITY("ProviderIssue", "Eligibility"), VERIFICATION("EligibilityIssue", "Verification"),
		DISCREPANCY("EligibilityIssue", "Discrepancy"),

		AUTHORIZATION("ProviderIssue", "Authorization"), AUTHORIZATIONISSUE("AuthorizationIssue", "Issue"),
		AUTHORIZATIONREQUEST("AuthorizationIssue", "Request"), AUTHORIZATIONVERIFICATION("AuthorizationIssue", "Verification"),

		// BROKER("IssueType", "Broker"),

		ACCOUNT("IssueType", "Account"),

		PREMIUMBILLING("AccountIssue", "Premium Billing"),
		MEMBERRETROACTIVETERMINATION("PremiumBillingIssue", "Member Retroactive Termination"),
		QUESTIONONBILLINGSTATEMENT("PremiumBillingIssue", "Question on Billing Statement"),

		MEMBERENROLLMENT("AccountIssue", "Member Enrollment"),
		REQUESTMEMBERTERMINATION("MemberEnrollmentIssue", "Request Member Termination"),
		REQUESTMEMBERADDTOSUBSCRIPTION("MemberEnrollmentIssue", "Request Member add to Subscription"),
		REQUESTBENEFITPLANCHANGE("MemberEnrollmentIssue", "Request Benefit Plan Change"),

		GRIEVANCEANDAPPEALS("IssueType", "Grievance and Appeals"),

		EFFECTUATION("GrievanceandAppealsIssue", "Effectuation"), CAREFFECTUATIONTASK("Effectuation", "CAR Effectuation Task"),
		OTHERTASK("Effectuation", "Other Task"), MDDECISIONTASK("Effectuation", "MD Decision Task"),
		ISSUEFORCSCCLAIM("Effectuation", "Issue for CSC Claim");

		public final String codesetname;
		public final String shortname;

		private typeName(String codesetname, String shortname) {
			this.codesetname = codesetname;
			this.shortname = shortname;

		}

		private static Map<String, typeName> BY_LABEL = new HashMap<String, typeName>();

		static {
			for (typeName e : values()) {

				BY_LABEL.put(e.shortname.concat(e.codesetname), e);
			}
		}

		public static typeName valueByLabel(String labelName) {
			return BY_LABEL.get(labelName);
		}
	}

}
