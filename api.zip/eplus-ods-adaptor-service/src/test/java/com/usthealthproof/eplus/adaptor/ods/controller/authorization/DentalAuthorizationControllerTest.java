package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.service.auth.DentalAuthService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {DentalAuthorizationController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class DentalAuthorizationControllerTest {
    @MockitoBean
    private DentalAuthService dentalAuthService;

    @Autowired
    private DentalAuthorizationController dentalAuthorizationController;

    /**
     * Method under test:
     * {@link DentalAuthorizationController#getDentalAuthorizationDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetDentalAuthorizationDetails() throws Exception {
        // Arrange
        DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse = new DentalAuthorizationDetailsResponse();
        dentalAuthorizationDetailsResponse.setAuthorizationAge("JaneDoe");
        dentalAuthorizationDetailsResponse.setAuthorizationComments("JaneDoe");
        dentalAuthorizationDetailsResponse.setAuthorizationId("42");
        dentalAuthorizationDetailsResponse.setAuthorizationOwner("JaneDoe");
        dentalAuthorizationDetailsResponse.setAuthorizationReason("Just cause");
        dentalAuthorizationDetailsResponse.setAuthorizationType("JaneDoe");
        dentalAuthorizationDetailsResponse.setDeterminationDate("2020-03-01");
        dentalAuthorizationDetailsResponse.setDeterminationDueDate("2020-03-01");
        dentalAuthorizationDetailsResponse.setDeterminationTurnAroundTime("Determination Turn Around Time");
        dentalAuthorizationDetailsResponse.setMemberId("42");
        dentalAuthorizationDetailsResponse.setPerformingProviderId("42");
        dentalAuthorizationDetailsResponse.setPerformingProviderName("Performing Provider Name");
        dentalAuthorizationDetailsResponse.setRequestDate("2020-03-01");
        dentalAuthorizationDetailsResponse.setRequestingProviderId("42");
        dentalAuthorizationDetailsResponse.setRequestingProviderName("Requesting Provider Name");
        dentalAuthorizationDetailsResponse.setRequestor("Requestor");
        dentalAuthorizationDetailsResponse.setServiceComments("Service Comments");
        dentalAuthorizationDetailsResponse.setServiceExceptionComments("Service Exception Comments");
        dentalAuthorizationDetailsResponse.setServiceType("Service Type");
        dentalAuthorizationDetailsResponse.setSource("Source");
        dentalAuthorizationDetailsResponse.setStatus("Status");
        dentalAuthorizationDetailsResponse.setStatusReason("Just cause");
        dentalAuthorizationDetailsResponse.setUrgency("Urgency");
        when(dentalAuthService.getDentalAuthorizationDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(dentalAuthorizationDetailsResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/dental")
                .param("authorizationId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"authorizationId\":\"42\",\"memberId\":\"42\",\"requestingProviderId\":\"42\",\"requestingProviderName\":\"Requesting"
                                        + " Provider Name\",\"status\":\"Status\",\"requestDate\":\"2020-03-01\",\"authorizationReason\":\"Just cause\","
                                        + "\"determinationDate\":\"2020-03-01\",\"determinationTurnAroundTime\":\"Determination Turn Around Time\","
                                        + "\"statusReason\":\"Just cause\",\"requestor\":\"Requestor\",\"performingProviderId\":\"42\",\"performingProviderName"
                                        + "\":\"Performing Provider Name\",\"urgency\":\"Urgency\",\"authorizationType\":\"JaneDoe\",\"serviceType\":\"Service"
                                        + " Type\",\"source\":\"Source\",\"determinationDueDate\":\"2020-03-01\",\"authorizationOwner\":\"JaneDoe\","
                                        + "\"authorizationAge\":\"JaneDoe\",\"authorizationComments\":\"JaneDoe\",\"serviceComments\":\"Service Comments\","
                                        + "\"serviceExceptionComments\":\"Service Exception Comments\"}"));
    }

    /**
     * Method under test:
     * {@link DentalAuthorizationController#getDentalAuthorizationLines(String, HttpServletRequest)}
     */
    @Test
    void testGetDentalAuthorizationLines() throws Exception {
        // Arrange
        DentalAuthorizationLinesResponseList dentalAuthorizationLinesResponseList = new DentalAuthorizationLinesResponseList();
        dentalAuthorizationLinesResponseList.setDentalAuthorizationLines(new ArrayList<>());
        when(dentalAuthService.getDentalAuthorizationLines(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(dentalAuthorizationLinesResponseList);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/dental/authlines")
                .param("authorizationId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{}"));
    }

    /**
     * Method under test:
     * {@link DentalAuthorizationController#getDentalAuthorizationLineDetails(String, String, HttpServletRequest)}
     */
    @Test
    void testGetDentalAuthorizationLineDetails() throws Exception {
        // Arrange
        DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse = new DentalAuthorizationLineDetailsResponse();
        dentalAuthorizationLineDetailsResponse.setAuthorizationComments("JaneDoe");
        dentalAuthorizationLineDetailsResponse.setDeterminationStatus("Determination Status");
        dentalAuthorizationLineDetailsResponse.setPlaceOfService("Place Of Service");
        dentalAuthorizationLineDetailsResponse.setServiceCode("Service Code");
        dentalAuthorizationLineDetailsResponse.setServiceComments("Service Comments");
        dentalAuthorizationLineDetailsResponse.setServiceEndDate("2020-03-01");
        dentalAuthorizationLineDetailsResponse.setServiceExceptionComments("Service Exception Comments");
        dentalAuthorizationLineDetailsResponse.setServiceLineId("42");
        dentalAuthorizationLineDetailsResponse.setServiceStartDate("2020-03-01");
        dentalAuthorizationLineDetailsResponse.setStatusReason("Just cause");
        dentalAuthorizationLineDetailsResponse.setToothNo("Tooth No");
        dentalAuthorizationLineDetailsResponse.setUnitType("Unit Type");
        dentalAuthorizationLineDetailsResponse.setUnits("Units");
        when(dentalAuthService.getDentalAuthorizationLineDetails(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(dentalAuthorizationLineDetailsResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/dental/authline")
                .param("authorizationId", "foo")
                .param("serviceLineId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"serviceLineId\":\"42\",\"serviceCode\":\"Service Code\",\"toothNo\":\"Tooth No\",\"placeOfService\":\"Place Of"
                                        + " Service\",\"units\":\"Units\",\"unitType\":\"Unit Type\",\"serviceStartDate\":\"2020-03-01\",\"serviceEndDate\":"
                                        + "\"2020-03-01\",\"determinationStatus\":\"Determination Status\",\"statusReason\":\"Just cause\",\"authorizationComments"
                                        + "\":\"JaneDoe\",\"serviceComments\":\"Service Comments\",\"serviceExceptionComments\":\"Service Exception"
                                        + " Comments\"}"));
    }
}
