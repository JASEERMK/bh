package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.DentalClaimService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {DentalClaimAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class DentalClaimAdaptorServiceControllerTest {
    @Autowired
    private DentalClaimAdaptorServiceController dentalClaimAdaptorServiceController;

    @MockitoBean
    private DentalClaimService dentalClaimService;

    /**
     * Method under test:
     * {@link DentalClaimAdaptorServiceController#getDentalClaimDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetDentalClaimDetails() throws Exception {
        // Arrange
        DentalClaimDetails dentalClaimDetails = new DentalClaimDetails();
        dentalClaimDetails.setAllowed("Allowed");
        dentalClaimDetails.setBilledAmount("10");
        dentalClaimDetails.setCheckCleared("Check Cleared");
        dentalClaimDetails.setClaimEnteredDate("2020-03-01");
        dentalClaimDetails.setClaimReceivedDate("2020-03-01");
        dentalClaimDetails.setCoPay("Co Pay");
        dentalClaimDetails.setCobAmount("10");
        dentalClaimDetails.setCoinsuranceAmount("10");
        dentalClaimDetails.setCreatedBy("Jan 1, 2020 8:00am GMT+0100");
        dentalClaimDetails.setDeductible("Deductible");
        dentalClaimDetails.setEftAccount("3");
        dentalClaimDetails.setEftFlag("Eft Flag");
        dentalClaimDetails.setErrors(new ArrayList<>());
        dentalClaimDetails.setHttpStatusCode(1);
        dentalClaimDetails.setInsurerId("42");
        dentalClaimDetails.setInsurerName("Doe");
        dentalClaimDetails.setLastModifiedBy("Jan 1, 2020 9:00am GMT+0100");
        dentalClaimDetails.setLocationId("42");
        dentalClaimDetails.setLocationName("Location Name");
        dentalClaimDetails.setMemberId("42");
        dentalClaimDetails.setMemberName("Member Name");
        dentalClaimDetails.setMissingTeeth("Missing Teeth");
        dentalClaimDetails.setNetPaidAmount("10");
        dentalClaimDetails.setNetworkId("42");
        dentalClaimDetails.setNetworkName("Network Name");
        dentalClaimDetails.setOverMax("Over Max");
        dentalClaimDetails.setPaidAmount("10");
        dentalClaimDetails.setPayMember("Pay Member");
        dentalClaimDetails.setPayeeOtherId("42");
        dentalClaimDetails.setPayeeOtherName("Payee Other Name");
        dentalClaimDetails.setPaymentDate("2020-03-01");
        dentalClaimDetails.setPaymentNotes("Payment Notes");
        dentalClaimDetails.setPaymentNumber("42");
        dentalClaimDetails.setPaymentStatus("Payment Status");
        dentalClaimDetails.setProviderId("42");
        dentalClaimDetails.setProviderName("Provider Name");
        dentalClaimDetails.setServiceEndDate("2020-03-01");
        dentalClaimDetails.setServiceStartDate("2020-03-01");
        when(dentalClaimService.getDentalClaimDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(dentalClaimDetails);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/dental")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"memberId\":\"42\",\"payMember\":\"Pay Member\",\"insurerId\":\"42\",\"insurerName\":\"Doe\",\"providerId\":\"42\","
                                        + "\"providerName\":\"Provider Name\",\"serviceStartDate\":\"2020-03-01\",\"serviceEndDate\":\"2020-03-01\",\"locationId"
                                        + "\":\"42\",\"locationName\":\"Location Name\",\"payeeOtherId\":\"42\",\"payeeOtherName\":\"Payee Other Name\",\"networkId"
                                        + "\":\"42\",\"networkName\":\"Network Name\",\"claimReceivedDate\":\"2020-03-01\",\"claimEnteredDate\":\"2020-03-01\""
                                        + ",\"missingTeeth\":\"Missing Teeth\",\"paymentDate\":\"2020-03-01\",\"paymentNumber\":\"42\",\"netPaidAmount\":\"10\""
                                        + ",\"billedAmount\":\"10\",\"allowed\":\"Allowed\",\"paidAmount\":\"10\",\"deductible\":\"Deductible\",\"coPay\":\"Co"
                                        + " Pay\",\"coinsuranceAmount\":\"10\",\"overMax\":\"Over Max\",\"cobAmount\":\"10\",\"paymentStatus\":\"Payment"
                                        + " Status\",\"paymentNotes\":\"Payment Notes\",\"eftFlag\":\"Eft Flag\",\"eftAccount\":\"3\",\"checkCleared\":\"Check"
                                        + " Cleared\",\"createdBy\":\"Jan 1, 2020 8:00am GMT+0100\",\"lastModifiedBy\":\"Jan 1, 2020 9:00am GMT+0100\","
                                        + "\"memberName\":\"Member Name\",\"httpStatusCode\":1}"));
    }

    /**
     * Method under test:
     * {@link DentalClaimAdaptorServiceController#getDentalClaimLines(String, HttpServletRequest)}
     */
    @Test
    void testGetDentalClaimLines() throws Exception {
        // Arrange
        DentalClaimLinesResponse dentalClaimLinesResponse = new DentalClaimLinesResponse();
        dentalClaimLinesResponse.setDentalClaimLines(new ArrayList<>());
        dentalClaimLinesResponse.setErrors(new ArrayList<>());
        dentalClaimLinesResponse.setHttpStatusCode(1);
        when(dentalClaimService.getDentalClaimLines(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(dentalClaimLinesResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/dental/claimlines")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"httpStatusCode\":1}"));
    }

    /**
     * Method under test:
     * {@link DentalClaimAdaptorServiceController#getDentalClaimLineDetails(String, String, HttpServletRequest)}
     */
    @Test
    void testGetDentalClaimLineDetails() throws Exception {
        // Arrange
        DentalClaimLineDetailResponse dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
        dentalClaimLineDetailResponse.setDentalClaimLineDetailsList(new ArrayList<>());
        dentalClaimLineDetailResponse.setErrors(new ArrayList<>());
        dentalClaimLineDetailResponse.setHttpStatusCode(1);
        when(dentalClaimService.getDentalClaimLineDetails(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(dentalClaimLineDetailResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/dental/claimline")
                .param("claimHccId", "foo")
                .param("claimLineHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(dentalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"httpStatusCode\":1}"));
    }
}
