package com.usthealthproof.eplus.adaptor.ods;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class OdsAdaptorServiceApplicationTest {
    /**
     * Method under test: {@link OdsAdaptorServiceApplication#init()}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testInit() {
        // TODO: Diffblue Cover was only able to create a partial test for this method:
        //   Reason: No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "String.length()" because "id" is null
        //       at java.base/java.util.TimeZone.parseCustomTimeZone(TimeZone.java:827)
        //       at java.base/java.util.TimeZone.getTimeZone(TimeZone.java:611)
        //       at java.base/java.util.TimeZone.getTimeZone(TimeZone.java:549)
        //       at com.usthealthproof.eplus.adaptor.ods.OdsAdaptorServiceApplication.init(OdsAdaptorServiceApplication.java:34)
        //   See https://diff.blue/R013 to resolve this issue.

        // Arrange and Act
        (new OdsAdaptorServiceApplication()).init();
    }

}
