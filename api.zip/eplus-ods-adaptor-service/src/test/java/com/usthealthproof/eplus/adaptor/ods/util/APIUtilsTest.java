package com.usthealthproof.eplus.adaptor.ods.util;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.ProblemDetails;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;
import jakarta.servlet.http.HttpServletRequest;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class APIUtilsTest {

    @InjectMocks
    APIUtils apiUtils;
    @Mock
    private Validator validator;
    @Mock
    private WebClientResponseException ex;

    ProblemDetails problemDetails = new ProblemDetails();

    @BeforeEach
    void setUp() {
        problemDetails.setErrors(Arrays.asList("Data Not found"));
        problemDetails.setStatus("No data");
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Method under test:
     * {@link APIUtils#createErrorResponse(WebClientResponseException)}
     */
    @Test
    void testCreateErrorResponse() {

        ErrorResponse response = APIUtils.createErrorResponse(new WebClientResponseException(503, "Error message", null, null, null));
        // Assert
        assertNotNull(response);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        response = APIUtils.createErrorResponse(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));
        assertNotNull(response);
        responseBody.clear();

        responseBody.put("problemDetails", "Resource not found");
        response = APIUtils.createErrorResponse(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));
        assertNotNull(response);

        responseBody.clear();
        response = APIUtils.createErrorResponse(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));
        assertNotNull(response);
    }

    @Test
    void testCreateProblemDetails() {
        // when - action or the behaviour
        ProblemDetails result = apiUtils.createProblemDetails("Data Not found", "No data");
        // then - verify the output
        Assertions.assertEquals(problemDetails, result);
    }

    @Test
    void testGetBearerToken() {
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        String expectedToken = "sampleBearerToken";

        when(validator.validateBearerToken(mockRequest)).thenReturn(expectedToken);
        String actualToken = apiUtils.getBearerToken(mockRequest);

        assertEquals("sampleBearerToken", expectedToken, actualToken);
    }

}



