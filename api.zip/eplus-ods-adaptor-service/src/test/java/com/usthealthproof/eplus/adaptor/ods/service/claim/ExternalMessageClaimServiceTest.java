package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.ExternalMessageClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessagesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class ExternalMessageClaimServiceTest {

    @InjectMocks
    ExternalMessageClaimService externalMessageClaimService;
    @Mock
    private ExternalMessageClaimData externalMessageClaimData;
    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetExternalMessageDetails_Success() throws Exception {

        MedicalExternalMessagesResponse response = new MedicalExternalMessagesResponse();
        MedicalExternalMessage model = new MedicalExternalMessage();
        response.setExternalMessages(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<MedicalExternalMessagesResponse> future = CompletableFuture.completedFuture(response);
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        MedicalExternalMessagesResponse result = externalMessageClaimService.getExternalmessageDetails("123", "345", "456",
                "accessToken");

        assertNotNull(result);
    }

    @Test
    void testGetExternalMessageDetails_WebClientResponseException() throws Exception {

        MedicalExternalMessagesResponse response = new MedicalExternalMessagesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<MedicalExternalMessagesResponse> future = CompletableFuture.completedFuture(response);
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            externalMessageClaimService.getExternalmessageDetails("123", "345", "456",
                    "accessToken");
        });
    }

    @Test
    void testGetExternalMessageDetails_Exception() throws Exception {
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            externalMessageClaimService.getExternalmessageDetails("123", "345", "456",
                    "accessToken");
        });
    }


    @Test
    void testGetExternalMessageDetails_ODSAdaptorException() throws Exception {

        MedicalExternalMessagesResponse response = new MedicalExternalMessagesResponse();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<MedicalExternalMessagesResponse> future = CompletableFuture.completedFuture(response);
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            externalMessageClaimService.getExternalmessageDetails("123", "345", "456",
                    "accessToken");
        });
    }

    @Test
    void testGetMspExternalMessageDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        MedicalExternalMessagesResponse response = new MedicalExternalMessagesResponse();
        MedicalExternalMessage model = new MedicalExternalMessage();
        response.setExternalMessages(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<MedicalExternalMessagesResponse> future = CompletableFuture.completedFuture(response);
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        MedicalExternalMessagesResponse result = externalMessageClaimService.getMspExternalmessageDetails("123", "345", "456",
                "SC:Medicare:Medicare HMO Individual","accessToken");

        assertNotNull(result);
    }

    @Test
    void testGetMspExternalMessageDetails_WebClientResponseException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        MedicalExternalMessagesResponse response = new MedicalExternalMessagesResponse();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error");
        response.setErrors(errors);
        CompletableFuture<MedicalExternalMessagesResponse> future = CompletableFuture.completedFuture(response);
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            externalMessageClaimService.getMspExternalmessageDetails("123", "345", "456",
                    "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspExternalMessageDetails_Exception() throws Exception {
        when(externalMessageClaimData.getExternalMessageDetails(any(), any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            externalMessageClaimService.getMspExternalmessageDetails("123", "345", "456",
                    "SC:Medicare:Medicare HMO Individual",  "accessToken");
        });
    }
}
