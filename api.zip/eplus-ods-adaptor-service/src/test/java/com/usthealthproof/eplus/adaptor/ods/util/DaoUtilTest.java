package com.usthealthproof.eplus.adaptor.ods.util;

import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DaoUtilTest {

    @InjectMocks
    private DaoUtil daoUtil;

    @Mock
    Validator validator;

    @BeforeEach
    void setUp() {
        daoUtil = new DaoUtil();
        // Initialize the MSPConfigUtils.mspConfigMap with some values for testing
        MSPConfigUtils.mspConfigMap = new HashMap<>();
        MSPConfigUtils.mspConfigMap.put("user1", "config1");
        MSPConfigUtils.mspConfigMap.put("user2", "config2");
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Method under test: {@link DaoUtil#getMspConfigDetails(String)}
     */
    @Test
    void testGetMspConfigDetails() {
        // Arrange, Act and Assert
        assertTrue(daoUtil.getMspConfigDetails("").isEmpty());
    }

    @Test
    void testGetMspConfigDetails_ValidIdentities() {
        String userIdentities = "user1;user2";
        Map<String, String> result = daoUtil.getMspConfigDetails(userIdentities);

        assertEquals(2, result.size());
        assertEquals("config1", result.get("user1"));
        assertEquals("config2", result.get("user2"));
    }

    /**
     * Method under test: {@link DaoUtil#getMspConfigMap(String)}
     */
    @Test
    void testGetMspConfigMap() throws RequestValidationException {
        String userIdentities = "user1;user2";
        Map<String, String> result = daoUtil.getMspConfigMap(userIdentities);
        assertNotNull(result);
    }
}
