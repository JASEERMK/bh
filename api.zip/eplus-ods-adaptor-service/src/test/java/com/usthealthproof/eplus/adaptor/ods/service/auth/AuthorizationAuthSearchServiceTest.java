package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthorizationAuthSearchServiceTest {
    @Mock
    private AuthorizationData authorizationData;

    @InjectMocks
    private AuthorizationService authorizationService;

    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String authorizationId = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspMemberAuthMedicalSearchDetails_Success() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setIsMatchingUserRole("Is Matching User Role");
        authorizationSearchRequest.setLob("Lob");
        authorizationSearchRequest.setMemberNumber("42");
        authorizationSearchRequest.setProduct("Product");
        authorizationSearchRequest.setProviderId("42");
        authorizationSearchRequest.setSearchEndDate("2020-03-01");
        authorizationSearchRequest.setSearchStartDate("2020-03-01");
        authorizationSearchRequest.setState("MD");
        authorizationSearchRequest.setStatus("Status");
        authorizationSearchRequest.setType("Medical");
        authorizationSearchRequest.setUserIdentities("user123");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspMemberAuthSearchDetails_Success() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setIsMatchingUserRole("Is Matching User Role");
        authorizationSearchRequest.setLob("Lob");
        authorizationSearchRequest.setMemberNumber("42");
        authorizationSearchRequest.setProduct("Product");
        authorizationSearchRequest.setProviderId("42");
        authorizationSearchRequest.setSearchEndDate("2020-03-01");
        authorizationSearchRequest.setSearchStartDate("2020-03-01");
        authorizationSearchRequest.setState("MD");
        authorizationSearchRequest.setStatus("Status");
        authorizationSearchRequest.setType("Dental");
        authorizationSearchRequest.setUserIdentities("user123");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspMemberAuthSearchDetails_WebClientResponseException() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setType("pharmacy");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetMspMemberAuthSearchDetails_Exception() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetMemberAuthSearchDetails_Success() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getMemberAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMemberAuthSearchDetailsODSException_Success() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            authorizationService.getMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetMemberAuthSearchDetails_WebClientResponseException() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getMemberAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetMspProviderAuthMedicalSearchDetails_Success() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setIsMatchingUserRole("Is Matching User Role");
        authorizationSearchRequest.setLob("Lob");
        authorizationSearchRequest.setMemberNumber("42");
        authorizationSearchRequest.setProduct("Product");
        authorizationSearchRequest.setProviderId("42");
        authorizationSearchRequest.setSearchEndDate("2020-03-01");
        authorizationSearchRequest.setSearchStartDate("2020-03-01");
        authorizationSearchRequest.setState("MD");
        authorizationSearchRequest.setStatus("Status");
        authorizationSearchRequest.setType("Medical");
        authorizationSearchRequest.setUserIdentities("user123");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspProviderAuthSearchDetails_Success() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setIsMatchingUserRole("Is Matching User Role");
        authorizationSearchRequest.setLob("Lob");
        authorizationSearchRequest.setMemberNumber("42");
        authorizationSearchRequest.setProduct("Product");
        authorizationSearchRequest.setProviderId("42");
        authorizationSearchRequest.setSearchEndDate("2020-03-01");
        authorizationSearchRequest.setSearchStartDate("2020-03-01");
        authorizationSearchRequest.setState("MD");
        authorizationSearchRequest.setStatus("Status");
        authorizationSearchRequest.setType("Dental");
        authorizationSearchRequest.setUserIdentities("user123");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspProviderAuthSearchDetails_WebClientResponseException() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetMspProviderAuthSearchDetails_Exception() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testGetProviderAuthSearchDetails_Success() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.getProviderAuthSearchDetails(authorizationSearchRequest, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetClaimAdjustment_Exception() throws Exception {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getProviderAuthSearchDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
        });
    }
}
