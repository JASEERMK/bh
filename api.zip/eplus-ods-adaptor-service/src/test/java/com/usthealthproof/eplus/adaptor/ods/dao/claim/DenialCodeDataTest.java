package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCodes;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class DenialCodeDataTest {

    @InjectMocks
    private DenialCodeData denialCodeData;

    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;


    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        when(webClientBuilder.build()).thenReturn(webClient);
    }

    @Test
    void testGetDenialCodesWithOAuthToken() throws Exception {
        ReflectionTestUtils.setField(denialCodeData, "isOAuthTokenRequired", "true");

        DenialCodes mockResponse = new DenialCodes();
        DenialCode denialCode = new DenialCode();
        denialCode.setCode("DEN123");
        denialCode.setDescription("Denial due to incomplete information");
        mockResponse.setDenialCodes(Collections.singletonList(denialCode));

        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DenialCodes.class)).thenReturn(Mono.just(mockResponse));

        CompletableFuture<DenialCodes> futureResponse = denialCodeData.getDenialCodes(
                "https://example.org/example", "/contextPath", "12345", "NY", "Health", "Product1", "Bearer token123");

        DenialCodes response = futureResponse.get();
        assertNotNull(response);
        assertEquals(1, response.getDenialCodes().size());
        assertEquals("DEN123", response.getDenialCodes().get(0).getCode());
        assertEquals("Denial due to incomplete information", response.getDenialCodes().get(0).getDescription());
    }

    @Test
    void testGetDenialCodesWithoutOAuthToken() throws Exception {
        ReflectionTestUtils.setField(denialCodeData, "isOAuthTokenRequired", "false");

        DenialCodes mockResponse = new DenialCodes();
        DenialCode denialCode = new DenialCode();
        denialCode.setCode("DEN123");
        denialCode.setDescription("Denial due to incomplete information");
        mockResponse.setDenialCodes(Collections.singletonList(denialCode));

        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DenialCodes.class)).thenReturn(Mono.just(mockResponse));

        CompletableFuture<DenialCodes> futureResponse = denialCodeData.getDenialCodes(
                "https://example.org/example", "/contextPath", "12345", "NY", "Health", "Product1", "Bearer token123");

        DenialCodes response = futureResponse.get();
        assertNotNull(response);
        assertEquals(1, response.getDenialCodes().size());
        assertEquals("DEN123", response.getDenialCodes().get(0).getCode());
        assertEquals("Denial due to incomplete information", response.getDenialCodes().get(0).getDescription());
    }

    @Test
    void testGetDenialCodesWithWebClientException() {
        // Mocking the WebClient and its fluent API behavior
        when(webClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        WebClientResponseException webClientException = new WebClientResponseException(
                404,
                "Not Found",
                null,
                null,
                null
        );
        when(responseSpec.bodyToMono(DenialCodes.class)).thenThrow(webClientException);

        CompletableFuture<DenialCodes> futureResponse = denialCodeData.getDenialCodes(
                "https://example.org/example",
                "/contextPath",
                "12345",
                "NY",
                "Health",
                "Product1",
                "Bearer token123"
        );

        DenialCodes response = futureResponse.join();
        assertNotNull(response);
        assertEquals(404, response.getHttpStatusCode());

        assertNotNull(response.getErrors());
        assertFalse(response.getErrors().isEmpty());


        assertTrue(response.getErrors().contains("Resource not found") ||
                response.getErrors().contains(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE));
    }


}
