package com.usthealthproof.eplus.adaptor.ods.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ODSAdaptorExceptionTest {


    @Test
    void testODSAdaptorException() {
        ODSAdaptorException exception = new ODSAdaptorException();
        assertNotNull(exception);
    }

    @Test
    void testODSAdaptorExceptionMessage() {
        String message = "This is an error message";
        ODSAdaptorException exception = new ODSAdaptorException(message);
        assertNotNull(exception);
    }

    @Test
    void testODSAdaptorExceptionCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        ODSAdaptorException exception = new ODSAdaptorException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    void ODSAdaptorExceptionTestMessageAndThrowable() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        ODSAdaptorException exception = new ODSAdaptorException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }
}
