package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetails;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {MemberPOAData.class, OdsAdaptorServiceConfig.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class MemberPOADataTest {

    @InjectMocks
    private MemberPOAData memberPOAData;

    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @Mock
    private WebClient.Builder webClientBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testMemberPOADetails() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(memberPOAData, "isOAuthTokenRequired", "true");
        MemberPOADetails mockResponse = new MemberPOADetails();
        Mono<MemberPOADetails> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MemberPOADetails.class)).thenReturn(monoResponse);

        CompletableFuture<MemberPOADetails> future = memberPOAData.getMemberPoaDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "kl");

        MemberPOADetails response = future.join();
        assertNotNull(response);
    }

    @Test
    void testMemberPOADetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        MemberPOADetails mockResponse = new MemberPOADetails();
        Mono<MemberPOADetails> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MemberPOADetails.class)).thenReturn(monoResponse);

        CompletableFuture<MemberPOADetails> futureResponse = memberPOAData.getMemberPoaDetails("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status");

        assertNotNull(futureResponse);
        MemberPOADetails response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testMemberPOADetailsWebClientException() throws InterruptedException {

        MemberPOADetails mockResponse = new MemberPOADetails();
        Mono<MemberPOADetails> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MemberPOADetails.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<MemberPOADetails> futureResponse = memberPOAData.getMemberPoaDetails("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status");

    }

    @Test
    void testGetMemberPoaDetails() {
        //   Diffblue Cover was unable to create a Spring-specific test for this Spring method.

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> (new MemberPOAData()).getMemberPoaDetails("", "Context Path", "42", "MD", "Lob", "Product", "ABC123"));
    }

}
