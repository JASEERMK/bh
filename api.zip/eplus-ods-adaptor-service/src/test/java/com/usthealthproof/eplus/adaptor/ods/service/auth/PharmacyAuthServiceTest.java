package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PharmacyAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PrescriberInformation;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class PharmacyAuthServiceTest {

    @InjectMocks
    PharmacyAuthService pharmacyAuthService;
    @Mock
    private AuthorizationData authorizationData;

    @Mock
    HttpServletRequest httpServletRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetPharmacyAuthorizationDetails_Success() throws Exception {

        PharmacyAuthorizationDetailsResponse response = new PharmacyAuthorizationDetailsResponse();
        response.setAuthId("123");
        response.setAuthStatus("open");
        PrescriberInformation prescriberInformation = new PrescriberInformation();
        prescriberInformation.setFirstName("john");
        response.setPrescriberInfo(prescriberInformation);
        CompletableFuture<PharmacyAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getPharmacyAuthorizationDetails(any(), any(), any(), any(), any()))
                .thenReturn(future);

        PharmacyAuthorizationDetailsResponse result = pharmacyAuthService.getPharmacyAuthorizationDetails("123", httpServletRequest, "123");

        assertNotNull(result);
    }


    @Test
    void testGetPharmacyAuthorizationDetails_OdsAdaptorException() throws Exception {

        PharmacyAuthorizationDetailsResponse response = new PharmacyAuthorizationDetailsResponse();
        List<String> errors = List.of(
                "Error: No data found"
        );
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<PharmacyAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getPharmacyAuthorizationDetails(any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            pharmacyAuthService.getPharmacyAuthorizationDetails("123", httpServletRequest, "123");
        });
    }

    @Test
    void testGetPharmacyAuthorizationDetails_WebClientResponseException() throws Exception {

        PharmacyAuthorizationDetailsResponse response = new PharmacyAuthorizationDetailsResponse();
        CompletableFuture<PharmacyAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getPharmacyAuthorizationDetails(any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            pharmacyAuthService.getPharmacyAuthorizationDetails("123", httpServletRequest, "123");
        });
    }

    @Test
    void testGetPharmacyAuthorizationDetails_Exception() throws Exception {

        when(authorizationData.getPharmacyAuthorizationDetails(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            pharmacyAuthService.getPharmacyAuthorizationDetails("123", httpServletRequest, "123");
        });
    }
}
