package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.mapper.AuthorizationSearchRequestMapper;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ContextConfiguration(classes = {AuthorizationSearchController.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(AuthorizationSearchController.class)
@DisabledInAotMode
class AuthorizationSearchControllerTest {

    @Autowired
    private AuthorizationSearchController authorizationSearchController;
    @MockitoBean
    private AuthorizationSearchRequestMapper authorizationSearchRequestMapper;
    @InjectMocks
    AuthorizationSearchController authorizationSearchController2;

    @MockitoBean
    private AuthorizationService authorizationService;
    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(authorizationSearchController2).build();
    }

    /**
     * Method under test:
     * {@link AuthorizationSearchController#getMemberAuthSearchDetails(String, String, String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetMemberAuthSearchDetails() throws Exception {
        // Arrange
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getMemberAuthSearchDetails(Mockito.<AuthorizationSearchRequest>any(),
                Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/member/search")
                .param("memberNumber", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(authorizationSearchController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetMemberAuthSearchDetails_WithUserIdentities() throws Exception {
        String accessToken = "token";


        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        ResponseEntity<AuthorizationSearchResponseList> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/member/search")
                        .param("memberNumber", "123")
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, authorizationSearchRequest.getUserIdentities())
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    /**
     * Method under test:
     * {@link AuthorizationSearchController#getProviderAuthSearchDetails(String, String, String, String, String, String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetProviderAuthSearchDetails() throws Exception {
        // Arrange
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getProviderAuthSearchDetails(Mockito.<AuthorizationSearchRequest>any(),
                Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/provider/search")
                .param("providerId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(authorizationSearchController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetProviderAuthSearchDetails_WithUserIdentities() throws Exception {
        String accessToken = "token";


        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        ResponseEntity<AuthorizationSearchResponseList> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/provider/search")
                        .param("providerId", "2123")
                        .param("memberNumber", "123")
                        .param("selectedSlp", "PA")
                        .param("isMatchingUserRole", "true")
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, authorizationSearchRequest.getUserIdentities())
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetProviderAuthSearchDetails_WithUserIdentitiesUserRoleFalse() throws Exception {
        String accessToken = "token";

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        ResponseEntity<AuthorizationSearchResponseList> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/provider/search")
                        .param("providerId", "2123")
                        .param("memberNumber", "123")
                        .param("selectedSlp", "PA")
                        .param("isMatchingUserRole", "false")
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, authorizationSearchRequest.getUserIdentities())
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetProviderAuthSearchDetails_WithUserIdentitiesWithoutUserRole() throws Exception {
        String accessToken = "token";

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        ResponseEntity<AuthorizationSearchResponseList> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        AuthorizationSearchRequest authorizationSearchRequest = getAuthorizationSearchRequest();
        when(authorizationSearchRequestMapper.authorizationSearchRequestMapper(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(authorizationSearchRequest);
        when(authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/provider/search")
                        .param("providerId", "2123")
                        .param("memberNumber", "123")
                        .param("selectedSlp", "PA")
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, authorizationSearchRequest.getUserIdentities())
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    private static AuthorizationSearchRequest getAuthorizationSearchRequest() {
        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setAuthorizationId("42");
        authorizationSearchRequest.setIsMatchingUserRole("Is Matching User Role");
        authorizationSearchRequest.setLob("Lob");
        authorizationSearchRequest.setMemberNumber("42");
        authorizationSearchRequest.setProduct("Product");
        authorizationSearchRequest.setProviderId("42");
        authorizationSearchRequest.setSearchEndDate("2020-03-01");
        authorizationSearchRequest.setSearchStartDate("2020-03-01");
        authorizationSearchRequest.setState("MD");
        authorizationSearchRequest.setStatus("Status");
        authorizationSearchRequest.setType("Type");
        authorizationSearchRequest.setUserIdentities("User Identities");
        return authorizationSearchRequest;
    }
}
