package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.MedicalClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class MedicalClaimServiceTest {

    @InjectMocks
    MedicalClaimService medicalClaimService;

    @Mock
    private MedicalClaimData medicalClaimData;

    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspClaimDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimDetails response = new MedicalClaimDetails();
        response.setClaimReceiptDate("123");
        response.setMemberId("234");
        CompletableFuture<MedicalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimDetails> result = medicalClaimService.getMspClaimDetails("223", "345", userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspClaimDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimDetails response = new MedicalClaimDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<MedicalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getMspClaimDetails("223", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspClaimAdjustment_Exception() throws Exception {

        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            medicalClaimService.getMspClaimDetails("223", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetClaimDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimDetails response = new MedicalClaimDetails();
        response.setMemberId("123");
        CompletableFuture<MedicalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimDetails> result = medicalClaimService.getClaimDetails("123", "234", accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetClaimDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimDetails response = new MedicalClaimDetails();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<MedicalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            medicalClaimService.getClaimDetails("123", "234", accessToken);
        });
    }

    @Test
    void testGetClaimDetails_WebException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getClaimDetails("123", "234", accessToken);
        });
    }

    @Test
    void testGetClaimDetails_Exception() throws Exception {

        when(medicalClaimData.findClaimId(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            medicalClaimService.getClaimDetails("223", "345", accessToken);
        });
    }

    @Test
    void testGetMspClaimLines_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLinesResponse response = new MedicalClaimLinesResponse();
        MedicalClaimLines model = new MedicalClaimLines();
        response.setMedicalClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<MedicalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimLinesResponse> result = medicalClaimService.getMspClaimLines("223", "345", userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspClaimLines_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLinesResponse response = new MedicalClaimLinesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<MedicalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getMspClaimLines("223", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspClaimLines_Exception() throws Exception {

        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            medicalClaimService.getMspClaimLines("223", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetClaimLines_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLinesResponse response = new MedicalClaimLinesResponse();
        MedicalClaimLines model = new MedicalClaimLines();
        response.setMedicalClaimLines(Collections.singletonList(model));
        CompletableFuture<MedicalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimLinesResponse> result = medicalClaimService.getClaimLines("123", "234", accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetClaimLines_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLinesResponse response = new MedicalClaimLinesResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<MedicalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            medicalClaimService.getClaimLines("123", "234", accessToken);
        });
    }

    @Test
    void testGetClaimLines_WebException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(medicalClaimData.getClaimLines(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getClaimLines("123", "234", accessToken);
        });
    }


    @Test
    void testGetMspClaimLineDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLineDetailsResponse response = new MedicalClaimLineDetailsResponse();
        MedicalClaimLineDetails model = new MedicalClaimLineDetails();
        response.setMedicalClaimLineDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<MedicalClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimLineDetailsResponse> result = medicalClaimService.getMspClaimLineDetails("123", "234", "345", userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspClaimLineDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLineDetailsResponse response = new MedicalClaimLineDetailsResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<MedicalClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getMspClaimLineDetails("123", "234", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspClaimLineDetails_Exception() throws Exception {

        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            medicalClaimService.getMspClaimLineDetails("123", "234", "345", userIdentities, accessToken);
        });
    }

    @Test
    void testGetClaimLineDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLineDetailsResponse response = new MedicalClaimLineDetailsResponse();
        MedicalClaimLineDetails model = new MedicalClaimLineDetails();
        response.setMedicalClaimLineDetailsList(Collections.singletonList(model));
        CompletableFuture<MedicalClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MedicalClaimLineDetailsResponse> result = medicalClaimService.getClaimLineDetails("123", "234", "123", accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetClaimLineDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MedicalClaimLineDetailsResponse response = new MedicalClaimLineDetailsResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<MedicalClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            medicalClaimService.getClaimLineDetails("123", "234", "123", accessToken);
        });
    }

    @Test
    void testGetClaimLineDetails_WebException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(medicalClaimData.getClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            medicalClaimService.getClaimLineDetails("123", "234", "123", accessToken);
        });
    }
}
