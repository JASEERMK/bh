package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLinesResponse;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {DentalClaimData.class, OdsAdaptorServiceConfig.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class DentalClaimDataTest {

    @InjectMocks
    private DentalClaimData dentalClaimData;

    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;
    @Mock
    private WebClient.Builder webClientBuilder;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindDentalClaimIdWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(dentalClaimData, "isOAuthTokenRequired", "true");
        DentalClaimDetails mockResponse = new DentalClaimDetails();
        Mono<DentalClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimDetails> future = dentalClaimData.findDentalClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "PA","lob","product","42");

        DentalClaimDetails response = future.join();
        assertNotNull(response);
    }

    @Test
    void testFindDentalClaimIdWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalClaimDetails mockResponse = new DentalClaimDetails();
        Mono<DentalClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimDetails> futureResponse = dentalClaimData.findDentalClaimId("https://example.org/example", "Context Path", "Claim Types", "PA","lob","product","42");

        assertNotNull(futureResponse);
        DentalClaimDetails response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testFindDentalClaimId() {

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> (new DentalClaimData()).findDentalClaimId("", "Context Path", "42", "PA","lob","product","ABC123"));
    }

    @Test
    void testFindDentalClaimIdWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalClaimDetails> futureResponse = dentalClaimData.findDentalClaimId("https://example.org/example", "Context Path", "Claim Types", "PA","lob","product","42");

        assertNotNull(futureResponse);
    }

    @Test
    void testFindDentalClaimLinesWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(dentalClaimData, "isOAuthTokenRequired", "true");
        DentalClaimLinesResponse mockResponse = new DentalClaimLinesResponse();
        Mono<DentalClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimLinesResponse> future = dentalClaimData.getDentalClaimLines(
                "https://example.org/example", "Context Path", "Claim Types", "state","lob","product","42");

        DentalClaimLinesResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testDentalClaimLinesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalClaimLinesResponse mockResponse = new DentalClaimLinesResponse();
        Mono<DentalClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimLinesResponse> futureResponse = dentalClaimData.getDentalClaimLines("https://example.org/example", "Context Path", "Claim Types","state","lob","product", "42");

        assertNotNull(futureResponse);
        DentalClaimLinesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetDentalClaimLines() {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> (new DentalClaimData()).getDentalClaimLines("", "Context Path", "42", "state","lob","product","ABC123"));
    }

    @Test
    void testFindDentalClaimLinesWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalClaimLinesResponse> futureResponse = dentalClaimData.getDentalClaimLines("https://example.org/example", "Context Path", "Claim Types", "PA","lob","product","42");

        assertNotNull(futureResponse);
    }

    @Test
    void testFindDentalClaimLineDetailsWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(dentalClaimData, "isOAuthTokenRequired", "true");
        DentalClaimLineDetailResponse mockResponse = new DentalClaimLineDetailResponse();
        Mono<DentalClaimLineDetailResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimLineDetailResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimLineDetailResponse> future = dentalClaimData.getDentalClaimLineDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42", "state","lob","product","jkl");

        DentalClaimLineDetailResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testDentalClaimLineDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalClaimLineDetailResponse mockResponse = new DentalClaimLineDetailResponse();
        Mono<DentalClaimLineDetailResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalClaimLineDetailResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalClaimLineDetailResponse> futureResponse = dentalClaimData.getDentalClaimLineDetails("https://example.org/example", "Context Path", "Claim Types", "42","state","lob","product", "jkl");

        assertNotNull(futureResponse);
        DentalClaimLineDetailResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetDentalClaimLineDetails() {

        assertThrows(RequestValidationException.class,
                () -> (new DentalClaimData()).getDentalClaimLineDetails("", "Context Path", "42", "42", "state","lob","product","ABC123"));
    }

    @Test
    void testFindDentalClaimLineDetailsWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalClaimLineDetailResponse> futureResponse = dentalClaimData.getDentalClaimLineDetails("https://example.org/example", "Context Path", "Claim Types", "234","PA","lob","product","42");

        assertNotNull(futureResponse);
    }

}
