package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthorizationServiceTest {
    @Mock
    private AuthorizationData authorizationData;

    @InjectMocks
    private AuthorizationService authorizationService;

    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String authorizationId = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspAuthorizationDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationDetailsResponse response = new AuthorizationDetailsResponse();
        response.setMemberId("123");
        response.setAuthorizationId("234");
        CompletableFuture<AuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationDetailsResponse> result = authorizationService.getMspAuthorizationDetails(authorizationId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationDetailsResponse response = new AuthorizationDetailsResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMspAuthorizationDetails(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getMspAuthorizationDetails(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetAuthorizationDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationDetailsResponse response = new AuthorizationDetailsResponse();
        response.setAuthorizationId("123");
        CompletableFuture<AuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationDetailsResponse> result = authorizationService.getAuthorizationDetails(authorizationId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetAuthorizationDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationDetailsResponse response = new AuthorizationDetailsResponse();
        response.setHttpStatusCode(504);
        response.setError("Invalid previous claim fact key");
        CompletableFuture<AuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            authorizationService.getAuthorizationDetails(authorizationId, accessToken);
        });
    }

    @Test
    void testGetAuthorizationDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getAuthorizationDetails(authorizationId, accessToken);
        });
    }

    @Test
    void testGetMsAuthorizationLines_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLinesResponseList response = new AuthorizationLinesResponseList();
        AuthorizationLinesResponse model = new AuthorizationLinesResponse();
        response.setAuthorizationLines(Collections.singletonList(model));
        CompletableFuture<AuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationLinesResponseList> result = authorizationService.getMspAuthorizationLines(authorizationId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationLines_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLinesResponseList response = new AuthorizationLinesResponseList();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMspAuthorizationLines(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationLines_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getMspAuthorizationLines(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetAuthorizationLines_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLinesResponseList response = new AuthorizationLinesResponseList();
        AuthorizationLinesResponse model = new AuthorizationLinesResponse();
        response.setAuthorizationLines(Collections.singletonList(model));
        CompletableFuture<AuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationLinesResponseList> result = authorizationService.getAuthorizationLines(authorizationId, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetAuthorizationLines_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLinesResponseList response = new AuthorizationLinesResponseList();
        response.setHttpStatusCode(504);
        response.setAuthorizationLines(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            authorizationService.getAuthorizationLines(authorizationId, accessToken);
        });
    }

    @Test
    void testGetAuthorizationLines_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getAuthorizationLines(authorizationId, accessToken);
        });
    }

    private final String serviceLineId = "123";
    private final String serviceStartDate = "12-23-30";
    private final String procedureCode = "open";

    @Test
    void testGetMspAuthorizationLineDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLineDetailsResponse response = new AuthorizationLineDetailsResponse();
        response.setHttpStatusCode(200);
        response.setAmount("123");
        response.setServiceLineId("234");
        response.setAuthorizationType("open");
        CompletableFuture<AuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationLineDetailsResponse> result = authorizationService.getMspAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationLineDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLineDetailsResponse response = new AuthorizationLineDetailsResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.getMspAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationLineDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getMspAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, userIdentities, accessToken);
        });
    }

    @Test
    void testGetAuthorizationLineDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLineDetailsResponse response = new AuthorizationLineDetailsResponse();
        CompletableFuture<AuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationLineDetailsResponse> result = authorizationService.getAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetAuthorizationLineDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationLineDetailsResponse response = new AuthorizationLineDetailsResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            authorizationService.getAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, accessToken);
        });
    }

    @Test
    void testGetAuthorizationLineDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationService.getAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, accessToken);
        });
    }

}
