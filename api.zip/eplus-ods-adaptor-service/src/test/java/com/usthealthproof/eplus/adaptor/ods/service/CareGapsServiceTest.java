package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.CareGapsData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetails;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CareGapsServiceTest {

    @InjectMocks
    private CareGapsService careGapsService;

    @Mock
    private DaoUtil daoUtil;

    @Mock
    private CareGapsData careGapsData;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String memberId = "123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspCareGapsDetails_success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareGapsDetails response = new CareGapsDetails();
        CareGapsDetailsList model = new CareGapsDetailsList();
        response.setCareGapsDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CareGapsDetails> future = CompletableFuture.completedFuture(response);
        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CareGapsDetails> result = careGapsService.getMspCareGapsDetails(memberId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspCareGapsDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareGapsDetails response = new CareGapsDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<CareGapsDetails> future = CompletableFuture.completedFuture(response);
        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            careGapsService.getMspCareGapsDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspCareGapsDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            careGapsService.getMspCareGapsDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetCareGapsDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareGapsDetails response = new CareGapsDetails();
        CareGapsDetailsList model = new CareGapsDetailsList();
        response.setCareGapsDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CareGapsDetails> future = CompletableFuture.completedFuture(response);
        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CareGapsDetails> result = careGapsService.getCareGapsDetails(memberId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetCareGapsDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareGapsDetails response = new CareGapsDetails();
        response.setHttpStatusCode(504);
        response.setCareGapsDetailsList(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<CareGapsDetails> future = CompletableFuture.completedFuture(response);
        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            careGapsService.getCareGapsDetails(memberId, accessToken);
        });
    }

    @Test
    void testGetCareGapsDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(careGapsData.getMemberCareGapsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            careGapsService.getCareGapsDetails(memberId, accessToken);
        });
    }
}
