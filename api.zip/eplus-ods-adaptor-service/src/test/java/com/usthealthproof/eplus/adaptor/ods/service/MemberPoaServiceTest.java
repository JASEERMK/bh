package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.MemberPOAData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentModel;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentResponse;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetails;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class MemberPoaServiceTest {

    @InjectMocks
    private MemberPoaService memberPoaService;
    @Mock
    private MemberPOAData memberPOAData;
    @Mock
    private DaoUtil daoUtil;
    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String claimNumber = "claim123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspMemberPoaDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MemberPOADetails response = new MemberPOADetails();
        MemberPOADetailsList model = new MemberPOADetailsList();
        response.setMemberPOADetailsList(Collections.singletonList(model));
        response.setMemberId("123");
        CompletableFuture<MemberPOADetails> future = CompletableFuture.completedFuture(response);
        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MemberPOADetails> result = memberPoaService.getMspMemberPoaDetails(claimNumber, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspMemberPoaDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MemberPOADetails response = new MemberPOADetails();
        response.setHttpStatusCode(504);
        CompletableFuture<MemberPOADetails> future = CompletableFuture.completedFuture(response);
        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            memberPoaService.getMspMemberPoaDetails(claimNumber, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspMemberPoaDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            memberPoaService.getMspMemberPoaDetails(claimNumber, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMemberPoaDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MemberPOADetails response = new MemberPOADetails();
        MemberPOADetailsList model = new MemberPOADetailsList();
        response.setMemberPOADetailsList(Collections.singletonList(model));
        response.setMemberId("123");
        CompletableFuture<MemberPOADetails> future = CompletableFuture.completedFuture(response);
        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<MemberPOADetails> result = memberPoaService.getMemberPoaDetails(claimNumber, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetMemberPoaDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        MemberPOADetails response = new MemberPOADetails();
        response.setHttpStatusCode(504);
        response.setMemberPOADetailsList(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<MemberPOADetails> future = CompletableFuture.completedFuture(response);
        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            memberPoaService.getMemberPoaDetails(claimNumber, accessToken);
        });
    }

    @Test
    void testGetMemberPoaDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(memberPOAData.getMemberPoaDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            memberPoaService.getMemberPoaDetails(claimNumber, accessToken);
        });
    }
}
