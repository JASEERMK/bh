package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalAuthorizationResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DentalAuthMspServiceTest {

    @InjectMocks
    private DentalAuthService dentalAuthService;
    @Mock
    private AuthorizationData authorizationData;
    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    DentalAuthorizationResponseMapper dentalAuthorizationResponseMapper;
    @Mock
    private DaoUtil daoUtil;
    @Mock
    DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse;
    @Mock
    CompletableFuture<DentalAuthorizationDetailsResponse> completableFuture;



    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspDentalAuthorizationDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationDetailsResponse response = new DentalAuthorizationDetailsResponse();
        response.setAuthorizationId("123");
        response.setMemberId("234");
        response.setAuthorizationAge("123");
        CompletableFuture<DentalAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);
        doCallRealMethod().when(dentalAuthorizationResponseMapper).dentalAuthDetailsResponseMapper(any(),any());

        DentalAuthorizationDetailsResponse result = dentalAuthService.getMspDentalAuthorizationDetails("123", "SC:Medicare:Medicare HMO Individual", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspDentalAuthorizationDetails_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getMspDentalAuthorizationDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspDentalAuthorizationDetails_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationDetailsResponse response = new DentalAuthorizationDetailsResponse();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<DentalAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getMspDentalAuthorizationDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspDentalAuthorizationLines_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationLinesResponseList response = new DentalAuthorizationLinesResponseList();
        DentalAuthorizationLinesResponse model = new DentalAuthorizationLinesResponse();
        response.setDentalAuthorizationLines(Collections.singletonList(model));
        CompletableFuture<DentalAuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);
        doCallRealMethod().when(dentalAuthorizationResponseMapper).dentalAuthDetailsResponseMapper(any(),any());

        DentalAuthorizationLinesResponseList result = dentalAuthService.getMspDentalAuthorizationLines("123", "SC:Medicare:Medicare HMO Individual", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspDentalAuthorizationLines_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getMspDentalAuthorizationLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testMspDentalAuthorizationLines_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationLinesResponseList response = new DentalAuthorizationLinesResponseList();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<DentalAuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getMspDentalAuthorizationLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspDentalAuthorizationLineDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationLineDetailsResponse response = new DentalAuthorizationLineDetailsResponse();
        response.setServiceLineId("123");
        response.setServiceCode("234");
        CompletableFuture<DentalAuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(), any(), any(),any(), any()))
                .thenReturn(future);
        doCallRealMethod().when(dentalAuthorizationResponseMapper).dentalAuthLineDetailsResponseMapper(any(),any());

        DentalAuthorizationLineDetailsResponse result = dentalAuthService.getMspDentalAuthorizationLineDetails("123", "123","SC:Medicare:Medicare HMO Individual", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspDentalAuthorizationLineDetails_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(), any(), any(),any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getMspDentalAuthorizationLineDetails("123", "123","SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testMspDentalAuthorizationLineDetails_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalAuthorizationLineDetailsResponse response = new DentalAuthorizationLineDetailsResponse();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<DentalAuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getMspDentalAuthorizationLineDetails("123", "123","SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }
}
