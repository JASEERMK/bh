package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalAuthorizationResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class DentalAuthServiceTest {

    @InjectMocks
    private DentalAuthService dentalAuthService;
    @Mock
    private AuthorizationData authorizationData;
    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    DentalAuthorizationResponseMapper dentalAuthorizationResponseMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetDentalAuthorizationDetails_Success() throws Exception {

        DentalAuthorizationDetailsResponse response = new DentalAuthorizationDetailsResponse();
        response.setAuthorizationId("123");
        response.setAuthorizationAge("123");
        CompletableFuture<DentalAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        DentalAuthorizationDetailsResponse result = dentalAuthService.getDentalAuthorizationDetails("123", "accessToken");

        assertNotNull(result);
    }

    @Test
    void testGetDentalAuthorizationDetails_WebClientResponseException() throws Exception {

        DentalAuthorizationDetailsResponse response = new DentalAuthorizationDetailsResponse();
        response.setAuthorizationId("123");
        CompletableFuture<DentalAuthorizationDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getDentalAuthorizationDetails("123", "accessToken");
        });
    }

    @Test
    void testGetDentalAuthorizationDetails_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationDetails(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getDentalAuthorizationDetails("123", "accessToken");
        });
    }

    @Test
    void testGetDentalAuthorizationLines_Success() throws Exception {

        DentalAuthorizationLinesResponseList response = new DentalAuthorizationLinesResponseList();
        DentalAuthorizationLinesResponse model = new DentalAuthorizationLinesResponse();
        response.setDentalAuthorizationLines(Collections.singletonList(model));
        CompletableFuture<DentalAuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        DentalAuthorizationLinesResponseList result = dentalAuthService.getDentalAuthorizationLines("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetDentalAuthorizationLines_WebClientResponseException() throws Exception {

        DentalAuthorizationLinesResponseList response = new DentalAuthorizationLinesResponseList();
        DentalAuthorizationLinesResponse model = new DentalAuthorizationLinesResponse();
        response.setDentalAuthorizationLines(Collections.singletonList(model));
        CompletableFuture<DentalAuthorizationLinesResponseList> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getDentalAuthorizationLines("123", "accessToken");
        });
    }

    @Test
    void testGetDentalAuthorizationLines_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationLines(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getDentalAuthorizationLines("123", "accessToken");
        });
    }

    @Test
    void testGetDentalAuthorizationLineDetails_Success() throws Exception {

        DentalAuthorizationLineDetailsResponse response = new DentalAuthorizationLineDetailsResponse();
        response.setServiceLineId("123");
        CompletableFuture<DentalAuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        DentalAuthorizationLineDetailsResponse result = dentalAuthService.getDentalAuthorizationLineDetails("123", "123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetDentalAuthorizationLineDetails_WebClientResponseException() throws Exception {

        DentalAuthorizationLineDetailsResponse response = new DentalAuthorizationLineDetailsResponse();
        response.setServiceLineId("123");
        CompletableFuture<DentalAuthorizationLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalAuthService.getDentalAuthorizationLineDetails("123", "123", "accessToken");
        });
    }

    @Test
    void testGetDentalAuthorizationLineDetails_Exception() throws Exception {

        when(authorizationData.getDentalAuthorizationLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalAuthService.getDentalAuthorizationLineDetails("123", "123", "accessToken");
        });
    }
}
