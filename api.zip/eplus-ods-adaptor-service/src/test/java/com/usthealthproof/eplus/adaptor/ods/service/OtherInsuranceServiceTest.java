package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.OtherInsuranceData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetails;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OtherInsuranceServiceTest {

    @InjectMocks
    private OtherInsuranceService otherInsuranceService;
    @Mock
    private OtherInsuranceData otherInsuranceData;

    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String memberId = "123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspOtherInsuranceDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        OtherInsuranceDetails response = new OtherInsuranceDetails();
        OtherInsuranceDetailsList model = new OtherInsuranceDetailsList();
        response.setOtherInsuranceDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<OtherInsuranceDetails> future = CompletableFuture.completedFuture(response);
        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<OtherInsuranceDetails> result = otherInsuranceService.getMspOtherInsuranceDetails(memberId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspOtherInsuranceDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        OtherInsuranceDetails response = new OtherInsuranceDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<OtherInsuranceDetails> future = CompletableFuture.completedFuture(response);
        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            otherInsuranceService.getMspOtherInsuranceDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspOtherInsuranceDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            otherInsuranceService.getMspOtherInsuranceDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetOtherInsuranceDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        OtherInsuranceDetails response = new OtherInsuranceDetails();
        OtherInsuranceDetailsList model = new OtherInsuranceDetailsList();
        response.setOtherInsuranceDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(123);
        CompletableFuture<OtherInsuranceDetails> future = CompletableFuture.completedFuture(response);
        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<OtherInsuranceDetails> result = otherInsuranceService.getOtherInsuranceDetails(memberId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetOtherInsuranceDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        OtherInsuranceDetails response = new OtherInsuranceDetails();
        response.setHttpStatusCode(504);
        response.setOtherInsuranceDetailsList(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<OtherInsuranceDetails> future = CompletableFuture.completedFuture(response);
        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            otherInsuranceService.getOtherInsuranceDetails(memberId, accessToken);
        });
    }

    @Test
    void testGetOtherInsuranceDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(otherInsuranceData.getOtherInsuranceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            otherInsuranceService.getOtherInsuranceDetails(memberId, accessToken);
        });
    }
}
