package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.DenialCodeData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCodes;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCode;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DenialCodeServiceTest {

    @InjectMocks
    private DenialCodeService denialCodeService;

    @Mock
    private DenialCodeData denialCodeData;

    @Mock
    private DaoUtil daoUtil;

    private final String claimNumber = "claim123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspDenialCodes_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "/contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        DenialCodes response = new DenialCodes();
        response.setClaimId(claimNumber);
        response.setDenialCodes(Collections.singletonList(new DenialCode()));
        CompletableFuture<DenialCodes> future = CompletableFuture.completedFuture(response);

        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<DenialCodes> result = denialCodeService.getMspDenialCodes(claimNumber, userIdentities, accessToken);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(claimNumber, Objects.requireNonNull(result.getBody()).getClaimId());
        assertFalse(result.getBody().getDenialCodes().isEmpty());
    }

    @Test
    void testGetMspDenialCodes_NoDenialCodes() {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "/contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        DenialCodes errorResponse = new DenialCodes();
        errorResponse.setHttpStatusCode(404);
        errorResponse.setErrors(Collections.singletonList("No denial codes found"));
        CompletableFuture<DenialCodes> future = CompletableFuture.completedFuture(errorResponse);

        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        WebClientResponseException exception = assertThrows(WebClientResponseException.class, () -> denialCodeService.getMspDenialCodes(claimNumber, userIdentities, accessToken));

        assertEquals("404 No denial codes found", exception.getMessage());
    }

    @Test
    void testGetMspDenialCodes_Exception() {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "/contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);
        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        Exception exception = assertThrows(Exception.class, () -> denialCodeService.getMspDenialCodes(claimNumber, userIdentities, accessToken));

        assertEquals("General error", exception.getMessage());
    }

    @Test
    void testGetDenialCodes_Success() throws Exception {
        DenialCodes response = new DenialCodes();
        response.setClaimId(claimNumber);
        response.setDenialCodes(Collections.singletonList(new DenialCode()));
        CompletableFuture<DenialCodes> future = CompletableFuture.completedFuture(response);

        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<DenialCodes> result = denialCodeService.getDenialCodes(claimNumber, accessToken);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(claimNumber, Objects.requireNonNull(result.getBody()).getClaimId());
        assertFalse(result.getBody().getDenialCodes().isEmpty());
    }

    @Test
    void testGetDenialCodes_NoDenialCodes() {
        DenialCodes response = new DenialCodes();
        response.setErrors(Collections.singletonList("No denial codes found"));
        CompletableFuture<DenialCodes> future = CompletableFuture.completedFuture(response);

        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> denialCodeService.getDenialCodes(claimNumber, accessToken));

        assertEquals("No denial codes found|null", exception.getMessage());
    }

    @Test
    void testGetDenialCodes_Exception() {
        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        Exception exception = assertThrows(Exception.class, () -> denialCodeService.getDenialCodes(claimNumber, accessToken));

        assertEquals("General error", exception.getMessage());
    }

    @Test
    void testGetDenialCodes_EmptyResponse_Error() {
        DenialCodes response = new DenialCodes();
        response.setClaimId(claimNumber);
        response.setDenialCodes(Collections.emptyList());
        response.setErrors(Collections.singletonList(null));

        CompletableFuture<DenialCodes> future = CompletableFuture.completedFuture(response);

        when(denialCodeData.getDenialCodes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> denialCodeService.getDenialCodes(claimNumber, accessToken));

        assertEquals(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500", exception.getMessage());

    }

    @Test
    void testHandleDenialCodeErrors_NullErrorList() {
        DenialCodes response = new DenialCodes();
        response.setErrors(null);
        response.setHttpStatusCode(500);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> {
            denialCodeService.handleDenialCodeErrors(response);
        });

        assertEquals(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500", exception.getMessage());
    }

    @Test
    void testHandleDenialCodeErrors_EmptyErrorList() {
        DenialCodes response = new DenialCodes();
        response.setErrors(Collections.emptyList());
        response.setHttpStatusCode(500);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> {
            denialCodeService.handleDenialCodeErrors(response);
        });

        assertEquals(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500", exception.getMessage());
    }

    @Test
    void testHandleDenialCodeErrors_ErrorMessageNull() {
        DenialCodes response = new DenialCodes();
        response.setErrors(Collections.singletonList(null)); // Simulate a null error message
        response.setHttpStatusCode(500);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> {
            denialCodeService.handleDenialCodeErrors(response);
        });

        assertEquals(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500", exception.getMessage());
    }

    @Test
    void testHandleDenialCodeErrors_ValidErrorMessage() {
        DenialCodes response = new DenialCodes();
        response.setErrors(Collections.singletonList("Specific error occurred"));
        response.setHttpStatusCode(404);

        ODSAdaptorException exception = assertThrows(ODSAdaptorException.class, () -> {
            denialCodeService.handleDenialCodeErrors(response);
        });

        assertEquals("Specific error occurred|404", exception.getMessage());
    }



}
