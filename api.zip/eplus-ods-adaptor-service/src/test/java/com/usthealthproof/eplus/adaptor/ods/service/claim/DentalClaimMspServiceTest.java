package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.DentalClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.when;

class DentalClaimMspServiceTest {

    @InjectMocks
    DentalClaimService dentalClaimService;
    @Mock
    private DentalClaimData dentalClaimData;
    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    DentalClaimsResponseMapper dentalClaimsResponseMapper;
    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspDentalClaimDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        DentalClaimDetails response = new DentalClaimDetails();
        response.setMemberId("123");
        response.setAllowed("123");
        response.setCobAmount("2000");
        CompletableFuture<DentalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.findDentalClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);
        doCallRealMethod().when(dentalClaimsResponseMapper).dentalClaimDetailsResponseMapper(any(),any());

        DentalClaimDetails result = dentalClaimService.getMspDentalClaimDetails("123","SC:Medicare:Medicare HMO Individual", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testMspDentalClaimDetails_Exception() throws Exception {

        when(dentalClaimData.findDentalClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getMspDentalClaimDetails("123","SC:Medicare:Medicare HMO Individual", "accessToken");
        });
    }

    @Test
    void testMspDentalClaimDetails_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        DentalClaimDetails response = new DentalClaimDetails();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<DentalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.findDentalClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getMspDentalClaimDetails("123","SC:Medicare:Medicare HMO Individual", "accessToken");
        });
    }

    @Test
    void testGetMspDentalClaimLines_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        DentalClaimLinesResponse response = new DentalClaimLinesResponse();
        DentalClaimLines model = new DentalClaimLines();
        response.setDentalClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        DentalClaimLinesResponse result = dentalClaimService.getMspDentalClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspDentalAuthorizationLines_Exception() throws Exception {

        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getMspDentalClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspDentalAuthorizationLines_WebClientResponseException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        DentalClaimLinesResponse response = new DentalClaimLinesResponse();
        DentalClaimLines model = new DentalClaimLines();
        response.setDentalClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getMspDentalClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspDentalClaimLineDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        DentalClaimLineDetailResponse response = new DentalClaimLineDetailResponse();
        DentalClaimLineDetails model = new DentalClaimLineDetails();
        response.setDentalClaimLineDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLineDetailResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        DentalClaimLineDetailResponse result = dentalClaimService.getMspDentalClaimLineDetails("123","qwe","SC:Medicare:Medicare HMO Individual",  "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspDentalAuthorizationLineDetails_WebClientResponseException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        DentalClaimLineDetailResponse response = new DentalClaimLineDetailResponse();
        DentalClaimLineDetails model = new DentalClaimLineDetails();
        response.setDentalClaimLineDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLineDetailResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getMspDentalClaimLineDetails("123","qwe","SC:Medicare:Medicare HMO Individual",  "accessToken");
        });
    }

    @Test
    void testGetMspDentalAuthorizationLineDetails_Exception() throws Exception {

        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getMspDentalClaimLineDetails("123","SC:Medicare:Medicare HMO Individual", "qwe", "accessToken");
        });
    }
}
