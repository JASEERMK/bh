package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimHeaderSearchResponse;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ClaimSearchDataTest {

    @InjectMocks
    ClaimSearchData claimSearchData;
    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @Mock
    private WebClient.Builder webClientBuilder;
    @Mock
    private WebClient webClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMemberClaimSearchWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(claimSearchData, "isOAuthTokenRequired", "true");
        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        CompletableFuture<ClaimHeaderSearchResponse> future = claimSearchData.getMemberClaimSearch(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code");

        ClaimHeaderSearchResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        CompletableFuture<ClaimHeaderSearchResponse> futureResponse = claimSearchData.getMemberClaimSearch("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code");

        assertNotNull(futureResponse);
        ClaimHeaderSearchResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationDetailsRequestException() throws InterruptedException {

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> claimSearchData.getMemberClaimSearch(null, "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code"));
    }

    @Test
    void testGetAuthorizationDetailsWebClientException() throws InterruptedException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<ClaimHeaderSearchResponse> futureResponse = claimSearchData.getMemberClaimSearch("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code");
    }

    @Test
    void testProviderClaimSearch() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(claimSearchData, "isOAuthTokenRequired", "true");
        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        CompletableFuture<ClaimHeaderSearchResponse> future = claimSearchData.getProviderClaimSearch(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "wer", "kjl");

        ClaimHeaderSearchResponse response = future.join();
        assertNotNull(response);

    }

    @Test
    void testProviderClaimSearchWithoutOAuthToken() throws InterruptedException, ExecutionException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        CompletableFuture<ClaimHeaderSearchResponse> futureResponse = claimSearchData.getProviderClaimSearch("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "ert", "ghj");

        assertNotNull(futureResponse);
        ClaimHeaderSearchResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testProviderClaimSearchRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> claimSearchData.getProviderClaimSearch(null, "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "asd", "jkl"));
    }

    @Test
    void testProviderClaimSearchWebClientException() throws InterruptedException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<ClaimHeaderSearchResponse> futureResponse = claimSearchData.getProviderClaimSearch("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "jkl", "hjk");
    }

    @Test
    void testProviderClaimDataAvailabilityCheck() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(claimSearchData, "isOAuthTokenRequired", "true");
        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        ClaimHeaderSearchResponse future = claimSearchData.providerClaimDataAvailabilityCheck(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "wer", "kjl");

        assertNotNull(future);
    }

    @Test
    void testProviderClaimDataAvailabilityCheckWithoutOAuthToken() throws InterruptedException, ExecutionException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenReturn(monoResponse);

        ClaimHeaderSearchResponse futureResponse = claimSearchData.providerClaimDataAvailabilityCheck("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "ert", "ghj");

        assertNotNull(futureResponse);
    }

    @Test
    void testProviderClaimDataAvailabilityCheckRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> claimSearchData.providerClaimDataAvailabilityCheck(null, "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "asd", "jkl"));
    }

    @Test
    void testProviderClaimDataAvailabilityCheckWebClientException() throws InterruptedException {

        ClaimHeaderSearchResponse mockResponse = new ClaimHeaderSearchResponse();
        Mono<ClaimHeaderSearchResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(ClaimHeaderSearchResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        ClaimHeaderSearchResponse futureResponse = claimSearchData.providerClaimDataAvailabilityCheck("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "MD", "Lob", "Product", "ABC123", "Service Code",
                "Diagnosis Code", "jkl", "hjk");
    }
}
