package com.usthealthproof.eplus.adaptor.ods.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class RequestValidationExceptionTest {

    @Test
    void testRequestValidationException() {
        RequestValidationException exception = new RequestValidationException();
        assertNotNull(exception);
    }

    @Test
    void testRequestValidationExceptionMessage() {
        String message = "This is an error message";
        RequestValidationException exception = new RequestValidationException(message);
        assertNotNull(exception);
    }

    @Test
    void testRequestValidationExceptionCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        RequestValidationException exception = new RequestValidationException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    void testRequestValidationExceptionMessageAndThrowable() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        RequestValidationException exception = new RequestValidationException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }
}
