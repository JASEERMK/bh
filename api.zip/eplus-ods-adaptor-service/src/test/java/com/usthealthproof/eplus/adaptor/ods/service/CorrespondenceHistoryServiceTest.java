package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.CorrespondenceHistoryData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CorrespondenceHistoryServiceTest {

    @InjectMocks
    private CorrespondenceHistoryService correspondenceHistoryService;

    @Mock
    private DaoUtil daoUtil;

    @Mock
    private CorrespondenceHistoryData correspondenceHistoryData;

    private final String correspondenceName = "claim123";
    private final String claimFactKey = "factKey123";
    private final String previousClaimFactKey = "prevFactKey123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";
    private final String memberId = "claim123";
    private final String claimId = "claim123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspCorrespondenceSearch_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceSearchResponseList response = new CorrespondenceSearchResponseList();
        CorrespondenceSearchResponse model = new CorrespondenceSearchResponse();
        response.setCorrespondenceList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CorrespondenceSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CorrespondenceSearchResponseList> result = correspondenceHistoryService.getMspCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspCorrespondenceSearch_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceSearchResponseList response = new CorrespondenceSearchResponseList();
        response.setHttpStatusCode(504);
        CompletableFuture<CorrespondenceSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            correspondenceHistoryService.getMspCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspCorrespondenceSearch_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            correspondenceHistoryService.getMspCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetCorrespondenceSearch_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceSearchResponseList response = new CorrespondenceSearchResponseList();
        CorrespondenceSearchResponse model = new CorrespondenceSearchResponse();
        response.setCorrespondenceList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CorrespondenceSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CorrespondenceSearchResponseList> result = correspondenceHistoryService.getCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetCorrespondenceSearch_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceSearchResponseList response = new CorrespondenceSearchResponseList();
        response.setHttpStatusCode(504);
        response.setCorrespondenceList(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<CorrespondenceSearchResponseList> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            correspondenceHistoryService.getCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, accessToken);
        });
    }

    @Test
    void testGetCorrespondenceSearch_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(correspondenceHistoryData.getCorrespondenceSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            correspondenceHistoryService.getCorrespondenceSearch(memberId, correspondenceName, claimFactKey, previousClaimFactKey, claimId, accessToken);
        });
    }

    @Test
    void testGetMspCorrespondenceDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceDetailsResponse response = new CorrespondenceDetailsResponse();
        response.setHttpStatusCode(200);
        response.setCorrespondenceId("123");
        response.setClaimId("claim123");
        response.setSupplierId("a123");
        CompletableFuture<CorrespondenceDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CorrespondenceDetailsResponse> result = correspondenceHistoryService.getMspCorrespondenceDetails(memberId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspCorrespondenceDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceDetailsResponse response = new CorrespondenceDetailsResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<CorrespondenceDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            correspondenceHistoryService.getMspCorrespondenceDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspCorrespondenceDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            correspondenceHistoryService.getMspCorrespondenceDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetCorrespondenceDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceDetailsResponse response = new CorrespondenceDetailsResponse();
        response.setHttpStatusCode(200);
        response.setCorrespondenceId("123");
        response.setClaimId("claim123");
        response.setSupplierId("a123");
        CompletableFuture<CorrespondenceDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CorrespondenceDetailsResponse> result = correspondenceHistoryService.getCorrespondenceDetails(memberId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetCorrespondenceDetails_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CorrespondenceDetailsResponse response = new CorrespondenceDetailsResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<CorrespondenceDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            correspondenceHistoryService.getCorrespondenceDetails(memberId, accessToken);
        });
    }

    @Test
    void testGetCorrespondenceDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(correspondenceHistoryData.getCorrespondenceDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            correspondenceHistoryService.getCorrespondenceDetails(memberId, accessToken);
        });
    }
}
