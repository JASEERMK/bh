package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.service.OtherInsuranceService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {OtherInsuranceAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class OtherInsuranceAdaptorServiceControllerTest {
    @Autowired
    private OtherInsuranceAdaptorServiceController otherInsuranceAdaptorServiceController;

    @MockitoBean
    private OtherInsuranceService otherInsuranceService;

    /**
     * Method under test:
     * {@link OtherInsuranceAdaptorServiceController#getOtherInsurance(String, HttpServletRequest)}
     */
    @Test
    void testGetOtherInsurance() throws Exception {
        // Arrange
        when(otherInsuranceService.getOtherInsuranceDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/member/otherinsurance/{memberId}",
                "42");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(otherInsuranceAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
