package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLinesResponse;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {VisionClaimData.class, OdsAdaptorServiceConfig.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class VisionClaimDataTest {

    @InjectMocks
    private VisionClaimData visionClaimData;

    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @Mock
    private WebClient.Builder webClientBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testfindVisionClaimIdWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(visionClaimData, "isOAuthTokenRequired", "true");
        VisionClaimDetails mockResponse = new VisionClaimDetails();
        Mono<VisionClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimDetails> future = visionClaimData.findVisionClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        VisionClaimDetails response = future.join();
        assertNotNull(response);
    }

    @Test
    void testfindVisionClaimIdWithoutOAuthToken() throws InterruptedException, ExecutionException {

        VisionClaimDetails mockResponse = new VisionClaimDetails();
        Mono<VisionClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimDetails> futureResponse = visionClaimData.findVisionClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        assertNotNull(futureResponse);
        VisionClaimDetails response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testFindVisionClaimId() {
        assertThrows(RequestValidationException.class,
                () -> (new VisionClaimData()).findVisionClaimId("", "Context Path", "42", "ABC123","lob","product","accessToken"));
    }

    @Test
    void testFindVisionClaimIdWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<VisionClaimDetails> futureResponse = visionClaimData.findVisionClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        assertNotNull(futureResponse);
    }


    @Test
    void testVisionClaimLinesWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(visionClaimData, "isOAuthTokenRequired", "true");
        VisionClaimLinesResponse mockResponse = new VisionClaimLinesResponse();
        Mono<VisionClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimLinesResponse> future = visionClaimData.getVisionClaimLines(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        VisionClaimLinesResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testVisionClaimLinesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        VisionClaimLinesResponse mockResponse = new VisionClaimLinesResponse();
        Mono<VisionClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimLinesResponse> futureResponse = visionClaimData.getVisionClaimLines(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        assertNotNull(futureResponse);
        VisionClaimLinesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testVisionClaimLines() {
        assertThrows(RequestValidationException.class,
                () -> visionClaimData.getVisionClaimLines("", "Context Path", "42", "ABC123","lob","product","accessToken"));
    }

    @Test
    void testFindVisionClaimLinesWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<VisionClaimLinesResponse> futureResponse = visionClaimData.getVisionClaimLines(
                "https://example.org/example", "Context Path", "Claim Types", "42","lob","product","accessToken");

        assertNotNull(futureResponse);
    }

    @Test
    void testVisionClaimLineDetailsWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(visionClaimData, "isOAuthTokenRequired", "true");
        VisionClaimLineDetailsResponse mockResponse = new VisionClaimLineDetailsResponse();
        Mono<VisionClaimLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimLineDetailsResponse> future = visionClaimData.getVisionClaimLineDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42", "jkl","lob","product","accessToken");

        VisionClaimLineDetailsResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testVisionClaimLineDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        VisionClaimLineDetailsResponse mockResponse = new VisionClaimLineDetailsResponse();
        Mono<VisionClaimLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(VisionClaimLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<VisionClaimLineDetailsResponse> futureResponse = visionClaimData.getVisionClaimLineDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42", "jkl","lob","product","accessToken");

        assertNotNull(futureResponse);
        VisionClaimLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testVisionClaimLineDetails() {
        assertThrows(RequestValidationException.class,
                () -> visionClaimData.getVisionClaimLineDetails("", "Context Path", "42", "ABC123", "jkl","lob","product","accessToken"));
    }

    @Test
    void testFindVisionClaimLineDetailsWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<VisionClaimLineDetailsResponse> futureResponse = visionClaimData.getVisionClaimLineDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42","PA","lob","product","accessToken");

        assertNotNull(futureResponse);
    }
}
