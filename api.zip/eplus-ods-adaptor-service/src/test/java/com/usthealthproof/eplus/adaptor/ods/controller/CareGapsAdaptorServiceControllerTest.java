package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.service.CareGapsService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {CareGapsAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class CareGapsAdaptorServiceControllerTest {
    @Autowired
    private CareGapsAdaptorServiceController careGapsAdaptorServiceController;

    @MockitoBean
    private CareGapsService careGapsService;

    /**
     * Method under test:
     * {@link CareGapsAdaptorServiceController#getCareGapsDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetCareGapsDetails() throws Exception {
        // Arrange
        when(careGapsService.getCareGapsDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/member/caregap/care/{memberId}",
                "42");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(careGapsAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
