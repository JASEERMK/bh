package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.service.claim.DenialCodeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {DenialCodeSearchController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class DenialCodeSearchControllerTest {

    @Autowired
    private DenialCodeSearchController denialCodeSearchController;

    @MockitoBean
    private DenialCodeService denialCodeService;

    /**
     * Test for retrieving denial codes by claim number with user identities (MSP enabled).
     */
    @Test
    void testGetDenialCodesByClaimMspEnabled() throws Exception {
        String claimHccId = "123456";
        String userIdentities = "user123"; // Simulate user identities provided
        String accessToken = "Bearer token123";

        when(denialCodeService.getMspDenialCodes(claimHccId, userIdentities, accessToken)).thenReturn(null);

        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/denialcodes")
                .param("claimHccId", claimHccId)
                .header("Authorization", accessToken)
                .header("UserIdentities", userIdentities);

        MockMvcBuilders.standaloneSetup(denialCodeSearchController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Test for retrieving denial codes by claim number without user identities (MSP disabled).
     */
    @Test
    void testGetDenialCodesByClaimMspDisabled() throws Exception {

        String claimHccId = "123456";
        String accessToken = "Bearer token123";

        when(denialCodeService.getDenialCodes(claimHccId, accessToken)).thenReturn(null);

        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/denialcodes")
                .param("claimHccId", claimHccId)
                .header("Authorization", accessToken)
                .header("UserIdentities", "");

        MockMvcBuilders.standaloneSetup(denialCodeSearchController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }


}
