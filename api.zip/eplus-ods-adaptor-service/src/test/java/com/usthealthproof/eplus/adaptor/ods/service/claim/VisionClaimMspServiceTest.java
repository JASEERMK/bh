package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.VisionClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.VisionClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLines;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.when;

public class VisionClaimMspServiceTest {

    @InjectMocks
    VisionClaimService visionClaimService;
    @Mock
    private VisionClaimData visionClaimData;
    @Mock
    private DaoUtil daoUtil;

    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    VisionClaimsResponseMapper visionClaimsResponseMapper;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspVisionClaimDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        VisionClaimDetails response = new VisionClaimDetails();
        response.setMemberId("234");
        response.setAllowedAmount("123");
        response.setCheckNumber("234");
        CompletableFuture<VisionClaimDetails> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.findVisionClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);
        doCallRealMethod().when(visionClaimsResponseMapper).visionClaimDetailsResponseMapper(any(),any());

        VisionClaimDetails result = visionClaimService.getMspVisionClaimDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        assertNotNull(result);
    }

    @Test
    void testMspVisionClaimDetails_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        VisionClaimDetails response = new VisionClaimDetails();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<VisionClaimDetails> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.findVisionClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getMspVisionClaimDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspVisionClaimDetails_Exception() throws Exception {

        when(visionClaimData.findVisionClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getMspVisionClaimDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetVisionClaimLines_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        VisionClaimLinesResponse response = new VisionClaimLinesResponse();
        VisionClaimLines model = new VisionClaimLines();
        response.setVisionClaimLines(Collections.singletonList(model));
        CompletableFuture<VisionClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLines(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        VisionClaimLinesResponse result = visionClaimService.getMspVisionClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        assertNotNull(result);
    }

    @Test
    void testMspDentalClaimLines_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        VisionClaimLinesResponse response = new VisionClaimLinesResponse();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<VisionClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLines(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getMspVisionClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetVisionClaimLines_Exception() throws Exception {

        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(), any(), any(),any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getMspVisionClaimLines("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetVisionClaimLineDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        VisionClaimLineDetailsResponse response = new VisionClaimLineDetailsResponse();
        VisionClaimLineDetails model = new VisionClaimLineDetails();
        response.setVisionClaimLineDetails(Collections.singletonList(model));
        CompletableFuture<VisionClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(),any(), any(), any(), any(), any()))
                .thenReturn(future);

        VisionClaimLineDetailsResponse result = visionClaimService.getMspVisionClaimLineDetails("123","123","SC:Medicare:Medicare HMO Individual","accessToken");
        assertNotNull(result);
    }

    @Test
    void testMspDentalClaimLineDetails_WebClientException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);
        VisionClaimLineDetailsResponse response = new VisionClaimLineDetailsResponse();
        response.setHttpStatusCode(504);
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        CompletableFuture<VisionClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(),any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getMspVisionClaimLineDetails("123", "234","SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetVisionClaimLineDetails_Exception() throws Exception {

        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(), any(), any(),any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getMspVisionClaimLineDetails("123", "234","SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }
}
