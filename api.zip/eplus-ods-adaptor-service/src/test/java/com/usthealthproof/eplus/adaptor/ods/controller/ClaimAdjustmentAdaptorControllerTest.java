package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.service.ClaimAdjustmentService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {ClaimAdjustmentAdaptorController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class ClaimAdjustmentAdaptorControllerTest {
    @Autowired
    private ClaimAdjustmentAdaptorController claimAdjustmentAdaptorController;

    @MockitoBean
    private ClaimAdjustmentService claimAdjustmentService;

    /**
     * Method under test:
     * {@link ClaimAdjustmentAdaptorController#getClaimAdjustment(String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetClaimAdjustment() throws Exception {
        // Arrange
        when(claimAdjustmentService.getClaimAdjustment(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/adjustment/claim")
                .param("claimNumber", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(claimAdjustmentAdaptorController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
