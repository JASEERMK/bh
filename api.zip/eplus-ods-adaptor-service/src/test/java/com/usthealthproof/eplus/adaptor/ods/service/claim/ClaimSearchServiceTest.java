package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.ClaimSearchData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimSearchModel;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class ClaimSearchServiceTest {

    @InjectMocks
    ClaimSearchService claimSearchService;
    @Mock
    private ClaimSearchData claimSearchData;

    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspMemberClaimSearch_MedicalSuccess() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getMemberClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getMspMemberClaimSearch("Medical", "123", "123", "123",
                "open", "234", "service", "diag", userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspMemberClaimSearch_NonMedicalSuccess() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getMemberClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getMspMemberClaimSearch("Dental", "123", "123", "123",
                "open", "234", "service", "diag", userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspMemberClaimSearch_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getMemberClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            claimSearchService.getMspMemberClaimSearch("Medical", "123", "123", "123",
                    "open", "234", "service", "diag", userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspMemberClaimSearch_Exception() throws Exception {

        assertThrows(Exception.class, () -> {
            claimSearchService.getMspMemberClaimSearch("Medical", "123", "123", "123",
                    "open", "234", "service", "diag", userIdentities, accessToken);
        });
    }

    @Test
    void testGetMemberClaimSearch_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getMemberClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getMemberClaimSearch("Dental", "123", "123", "123",
                "open", "234", "service", "diag", accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMemberClaimSearch_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getMemberClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            claimSearchService.getMemberClaimSearch("Medical", "123", "123", "123",
                    "open", "234", "service", "diag", accessToken);
        });
    }

    @Test
    void testGetMemberClaimSearch_Exception() throws Exception {

        assertThrows(Exception.class, () -> {
            claimSearchService.getMemberClaimSearch("Medical", "123", "123", "123",
                    "open", "234", "service", "diag", accessToken);
        });
    }

    @Test
    void testGetMspProviderClaimSearch_MedicalSuccess() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getProviderClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getMspProviderClaimSearch("Medical", "123", "Medical", "123", "123",
                "open", "234", "service", "diag", "123", userIdentities, "true", accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspProviderClaimSearch_NonMedicalSuccess() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getProviderClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getMspProviderClaimSearch("Medical", "123", "dental", "123", "123",
                "open", "234", "service", "diag", "123", userIdentities, "true", accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspProviderClaimSearch_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getProviderClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            claimSearchService.getMspProviderClaimSearch("Medical", "123", "dental", "123", "123",
                    "open", "234", "service", "diag", "123", userIdentities, "true", accessToken);
        });
    }

    @Test
    void testGetMspProviderClaimSearch_Exception() throws Exception {

        assertThrows(Exception.class, () -> {
            claimSearchService.getMspProviderClaimSearch("Medical", "123", "dental", "123", "123",
                    "open", "234", "service", "diag", "123", userIdentities, "true", accessToken);
        });
    }

    @Test
    void testGetProviderClaimSearch_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getProviderClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.getProviderClaimSearch("Medical", "123", "dental", "123", "123",
                "open", "234", "service", "diag", "123", accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetProviderClaimSearch_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<ClaimHeaderSearchResponse> future = CompletableFuture.completedFuture(response);
        when(claimSearchData.getProviderClaimSearch(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            claimSearchService.getProviderClaimSearch("Medical", "123", "dental", "123", "123",
                    "open", "234", "service", "diag", "123", accessToken);
        });
    }

    @Test
    void testGetProviderClaimSearch_Exception() throws Exception {

        assertThrows(Exception.class, () -> {
            claimSearchService.getProviderClaimSearch("Medical", "123", "dental", "123", "123",
                    "open", "234", "service", "diag", "123", accessToken);
        });
    }

    @Test
    void testProviderClaimDataAvailabilityCheck_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        model.setClaimStatus("open");
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        when(claimSearchData.providerClaimDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        ResponseEntity<ClaimHeaderSearchResponse> result = claimSearchService.providerClaimDataAvailabilityCheck("123", "medical", "medical", "123", "456", "234",
                "open", "234", "serv", "diag", userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testProviderClaimDataAvailabilityCheck_ResponseValidation() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        model.setClaimStatus("open");
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        when(claimSearchData.providerClaimDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(ResponseValidationException.class, () -> {
            claimSearchService.providerClaimDataAvailabilityCheck("123", "medical", "medical", "123", "456", "234",
                    "open", "234", "serv", "diag", userIdentities, accessToken);
        });
    }

    @Test
    void testProviderClaimDataAvailabilityCheck_withFlagSuccess() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel model = new ClaimSearchModel();
        model.setClaimStatus("open");

        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        response.setDataAvailabilityFlag("true");
        when(claimSearchData.providerClaimDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(ResponseValidationException.class, () -> {
            claimSearchService.providerClaimDataAvailabilityCheck("123", "medical", "medical", "123", "456", "234",
                    "open", "234", "serv", "diag", userIdentities, accessToken);
        });
    }

    @Test
    void testProviderClaimDataAvailabilityCheck_WebClient() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        response.setDataAvailabilityFlag("true");
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        when(claimSearchData.providerClaimDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(WebClientResponseException.class, () -> {
            claimSearchService.providerClaimDataAvailabilityCheck("123", "medical", "medical", "123", "456", "234",
                    "open", "234", "serv", "diag", userIdentities, accessToken);
        });
    }

}
