package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.service.claim.PharmacyClaimService;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PharmacyClaimAdaptorServiceController.class)
public class PharmacyClaimServiceControllerTest {

    @MockitoBean
    private APIUtils apiUtils;
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private PharmacyClaimService rxClaimDetailsService;
    @MockitoBean
    private Validator validator;

    @Test
    @WithMockUser(value = "user")
    public void testGetAuthorizationLines() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/claims/rx").param("claimHccId",
                "123"));
        // then - verify the output
        response.andDo(print()).andExpect(status().isOk());
    }
}
