package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PharmacyAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthorizationDataTest {

    @InjectMocks
    AuthorizationData authorizationData;

    @Mock
    private WebClient.Builder webClientBuilder;
    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

    }

    @Test
    void testGetAuthorizationDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationDetailsResponse mockResponse = new AuthorizationDetailsResponse();
        Mono<AuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationDetailsResponse> futureResponse = authorizationData.getAuthorizationDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken"
        );

        assertNotNull(futureResponse);
        AuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationDetailsResponse mockResponse = new AuthorizationDetailsResponse();
        Mono<AuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationDetailsResponse> futureResponse = authorizationData.getAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken");

        assertNotNull(futureResponse);
        AuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationDetailsRequestException() throws InterruptedException {

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> (new AuthorizationData()).getAuthorizationDetails("",
                "Context Path", "42", "MD", "Lob", "Product", "ABC123"));
    }

    @Test
    void testGetAuthorizationDetailsWebClientException() throws InterruptedException {

        AuthorizationDetailsResponse mockResponse = new AuthorizationDetailsResponse();
        Mono<AuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationDetailsResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationDetailsResponse> futureResponse = authorizationData.getAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken");
    }


    @Test
    void testgetAuthorizationLines() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationLinesResponseList mockResponse = new AuthorizationLinesResponseList();
        Mono<AuthorizationLinesResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLinesResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationLinesResponseList> futureResponse = authorizationData.getAuthorizationLines(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken"
        );

        assertNotNull(futureResponse);
        AuthorizationLinesResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationLinesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationLinesResponseList mockResponse = new AuthorizationLinesResponseList();
        Mono<AuthorizationLinesResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLinesResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationLinesResponseList> futureResponse = authorizationData.getAuthorizationLines("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken");

        assertNotNull(futureResponse);
        AuthorizationLinesResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationLinesRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> (new AuthorizationData()).getAuthorizationLines("",
                "Context Path", "42", "MD", "Lob", "Product", "ABC123"));
    }

    @Test
    void testGetAuthorizationLinesWebClientException() throws InterruptedException {

        AuthorizationLinesResponseList mockResponse = new AuthorizationLinesResponseList();
        Mono<AuthorizationLinesResponseList> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLinesResponseList.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationLinesResponseList> futureResponse = authorizationData.getAuthorizationLines("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken");
    }


    @Test
    void testgetAuthorizationLineDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationLineDetailsResponse mockResponse = new AuthorizationLineDetailsResponse();
        Mono<AuthorizationLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationLineDetailsResponse> futureResponse = authorizationData.getAuthorizationLineDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken", "lob", "product", "access token"
        );

        assertNotNull(futureResponse);
        AuthorizationLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationLineDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationLineDetailsResponse mockResponse = new AuthorizationLineDetailsResponse();
        Mono<AuthorizationLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationLineDetailsResponse> futureResponse = authorizationData.getAuthorizationLineDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token");

        assertNotNull(futureResponse);
        AuthorizationLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetAuthorizationLineDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getAuthorizationLineDetails(null, "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token"));

    }

    @Test
    void testGetAuthorizationLineDetailsWebClientException() throws InterruptedException {

        AuthorizationLineDetailsResponse mockResponse = new AuthorizationLineDetailsResponse();
        Mono<AuthorizationLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationLineDetailsResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationLineDetailsResponse> futureResponse = authorizationData.getAuthorizationLineDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token");
    }

    @Test
    void testMemberAuthSearchDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getMemberAuthSearchDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken", "lob", "product", "access token", "abc", "123"
        );

        assertNotNull(futureResponse);
        AuthorizationSearchResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testMemberAuthSearchDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getMemberAuthSearchDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "avd");

        assertNotNull(futureResponse);
        AuthorizationSearchResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testMemberAuthSearchDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getMemberAuthSearchDetails(null, "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "aws", "123"));

    }

    @Test
    void testMemberAuthSearchDetailsWebClientException() throws InterruptedException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getMemberAuthSearchDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "srert");
    }

    @Test
    void testProviderAuthSearchDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getProviderAuthSearchDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken", "lob", "product", "access token", "abc", "123", "klm"
        );

        assertNotNull(futureResponse);
        AuthorizationSearchResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testProviderAuthSearchDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getProviderAuthSearchDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "avd", "klm");

        assertNotNull(futureResponse);
        AuthorizationSearchResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testProviderAuthSearchDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getProviderAuthSearchDetails(null, "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "aws", "123", "klm"));

    }

    @Test
    void testProviderAuthSearchDetailsWebClientException() throws InterruptedException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationSearchResponseList> futureResponse = authorizationData.getProviderAuthSearchDetails("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "srert", "klm");
    }

    @Test
    void testAuthorizationNotesClinical() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotesClinical(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationNotesClinicalWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotesClinical("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationNotesClinicalRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getAuthorizationNotesClinical(null, "/context-path", "authorizationId", "state","lob","product","accessToken"));

    }

    @Test
    void testAuthorizationNotesClinicalWebClientException() throws InterruptedException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotesClinical("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");
    }

    @Test
    void testAuthorizationCallLogsNotes() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationCallLogsNotes(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationCallLogsNotesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationCallLogsNotes("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationCallLogsNotesRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getAuthorizationCallLogsNotes(null, "/context-path", "authorizationId", "state","lob","product","accessToken"));

    }

    @Test
    void testAuthorizationCallLogsNotesWebClientException() throws InterruptedException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationCallLogsNotes("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");
    }

    @Test
    void testAuthorizationNotes() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotes(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationNotesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotes("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
        AuthorizationNotesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testAuthorizationNotesRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getAuthorizationNotes(null, "/context-path", "authorizationId", "state","lob","product","accessToken"));

    }

    @Test
    void testAuthorizationNotesWebClientException() throws InterruptedException {

        AuthorizationNotesResponse mockResponse = new AuthorizationNotesResponse();
        Mono<AuthorizationNotesResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationNotesResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<AuthorizationNotesResponse> futureResponse = authorizationData.getAuthorizationNotes("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");
    }

    @Test
    void testDentalAuthorizationDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        DentalAuthorizationDetailsResponse mockResponse = new DentalAuthorizationDetailsResponse();
        Mono<DentalAuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        DentalAuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalAuthorizationDetailsResponse mockResponse = new DentalAuthorizationDetailsResponse();
        Mono<DentalAuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
        DentalAuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getDentalAuthorizationDetails(null, "/context-path", "authorizationId", "state","lob","product","accessToken"));

    }

    @Test
    void testDentalAuthorizationDetailsWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalAuthorizationDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
    }

    @Test
    void testDentalAuthorizationLines() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        DentalAuthorizationLinesResponseList mockResponse = new DentalAuthorizationLinesResponseList();
        Mono<DentalAuthorizationLinesResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationLinesResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationLinesResponseList> futureResponse = authorizationData.getDentalAuthorizationLines(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        DentalAuthorizationLinesResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationLinesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalAuthorizationLinesResponseList mockResponse = new DentalAuthorizationLinesResponseList();
        Mono<DentalAuthorizationLinesResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationLinesResponseList.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationLinesResponseList> futureResponse = authorizationData.getDentalAuthorizationLines("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
        DentalAuthorizationLinesResponseList response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationLinesRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getDentalAuthorizationLines(null, "/context-path", "authorizationId", "state","lob","product","accessToken"));

    }

    @Test
    void testDentalAuthorizationLinesWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalAuthorizationLinesResponseList> futureResponse = authorizationData.getDentalAuthorizationLines("http://service-url", "/context-path", "authorizationId", "state","lob","product","accessToken");

        assertNotNull(futureResponse);
    }


    @Test
    void testDentalAuthorizationLineDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        DentalAuthorizationLineDetailsResponse mockResponse = new DentalAuthorizationLineDetailsResponse();
        Mono<DentalAuthorizationLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationLineDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationLineDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state", "asd","lob","product","accessToken"
        );

        assertNotNull(futureResponse);
        DentalAuthorizationLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationLineDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        DentalAuthorizationLineDetailsResponse mockResponse = new DentalAuthorizationLineDetailsResponse();
        Mono<DentalAuthorizationLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(DentalAuthorizationLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<DentalAuthorizationLineDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationLineDetails("http://service-url", "/context-path", "authorizationId", "state", "yhj","lob","product","accessToken");

        assertNotNull(futureResponse);
        DentalAuthorizationLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testDentalAuthorizationLineDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getDentalAuthorizationLineDetails(null, "/context-path", "authorizationId", "state", "qwe","lob","product","accessToken"));

    }

    @Test
    void testDentalAuthorizationLineDetailsWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<DentalAuthorizationLineDetailsResponse> futureResponse = authorizationData.getDentalAuthorizationLineDetails("http://service-url", "/context-path", "authorizationId", "123","state","lob","product","accessToken");

        assertNotNull(futureResponse);
    }

    @Test
    void testPharmacyAuthorizationDetails() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        PharmacyAuthorizationDetailsResponse mockResponse = new PharmacyAuthorizationDetailsResponse();
        Mono<PharmacyAuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(PharmacyAuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<PharmacyAuthorizationDetailsResponse> futureResponse = authorizationData.getPharmacyAuthorizationDetails(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state", "asd"
        );

        assertNotNull(futureResponse);
        PharmacyAuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testPharmacyAuthorizationDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        PharmacyAuthorizationDetailsResponse mockResponse = new PharmacyAuthorizationDetailsResponse();
        Mono<PharmacyAuthorizationDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(PharmacyAuthorizationDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<PharmacyAuthorizationDetailsResponse> futureResponse = authorizationData.getPharmacyAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state", "yhj");

        assertNotNull(futureResponse);
        PharmacyAuthorizationDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testPharmacyAuthorizationDetailsRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.getPharmacyAuthorizationDetails(null, "/context-path", "authorizationId", "state", "qwe"));

    }

    @Test
    void testPharmacyAuthorizationDetailsWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<PharmacyAuthorizationDetailsResponse> futureResponse = authorizationData.getPharmacyAuthorizationDetails("http://service-url", "/context-path", "authorizationId", "state", "yhj");

        assertNotNull(futureResponse);
    }

    @Test
    void testProviderAuthDataAvailabilityCheck() throws InterruptedException, ExecutionException {

        ReflectionTestUtils.setField(authorizationData, "isOAuthTokenRequired", "true");

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        AuthorizationSearchResponseList futureResponse = authorizationData.providerAuthDataAvailabilityCheck(
                "http://service-url",
                "/context-path",
                "authorizationId",
                "state",
                "lob",
                "product",
                "accessToken", "lob", "product", "access token", "abc", "123", "klm"
        );

        assertNotNull(futureResponse);

    }

    @Test
    void testProviderAuthDataAvailabilityCheckWithoutOAuthToken() throws InterruptedException, ExecutionException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenReturn(monoResponse);

        AuthorizationSearchResponseList futureResponse = authorizationData.providerAuthDataAvailabilityCheck("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "avd", "klm");

        assertNotNull(futureResponse);
    }

    @Test
    void testProviderAuthDataAvailabilityCheckRequestException() throws InterruptedException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> authorizationData.providerAuthDataAvailabilityCheck(null, "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "aws", "123", "klm"));

    }

    @Test
    void testProviderAuthDataAvailabilityCheckWebClientException() throws InterruptedException {

        AuthorizationSearchResponseList mockResponse = new AuthorizationSearchResponseList();
        Mono<AuthorizationSearchResponseList> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(AuthorizationSearchResponseList.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        AuthorizationSearchResponseList futureResponse = authorizationData.providerAuthDataAvailabilityCheck("http://service-url", "/context-path", "authorizationId", "state", "lob", "product", "accessToken", "lob", "product", "access token", "123", "srert", "klm");
    }

}


