package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.service.claim.ClaimSearchService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {ClaimSearchAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class ClaimSearchAdaptorServiceControllerTest {
    @Autowired
    private ClaimSearchAdaptorServiceController claimSearchAdaptorServiceController;

    @MockitoBean
    private ClaimSearchService claimSearchService;

    /**
     * Method under test:
     * {@link ClaimSearchAdaptorServiceController#getClaimDetails(String, String, String, String, String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetClaimDetails() throws Exception {
        // Arrange
        when(claimSearchService.getMemberClaimSearch(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/member/claimSearch")
                .param("claimTypes", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(claimSearchAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Method under test:
     * {@link ClaimSearchAdaptorServiceController#getProviderClaimDetails(String, String, String, String, String, String, String, String, String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetProviderClaimDetails() throws Exception {
        // Arrange
        when(claimSearchService.getProviderClaimSearch(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/provider/claimSearch")
                .param("claimTypes", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(claimSearchAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
