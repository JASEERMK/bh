package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.ServiceUrlResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {ServiceUrlMapper.class})
@ExtendWith(SpringExtension.class)
class ServiceUrlMapperTest {
    @Autowired
    private ServiceUrlMapper serviceUrlMapper;

    /**
     * Method under test: {@link ServiceUrlMapper#mapRow(ResultSet, int)}
     */
    @Test
    void testMapRow() throws SQLException {
        // Arrange
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString(Mockito.<String>any())).thenReturn("String");
        // Act
        ServiceUrlResponse actualMapRowResult = serviceUrlMapper.mapRow(rs, 1);
        // Assert
        verify(rs, atLeast(1)).getString(Mockito.<String>any());
        assertEquals("String", actualMapRowResult.getServiceName());
        assertEquals("String", actualMapRowResult.getServiceUrl());
    }

    /**
     * Method under test: {@link ServiceUrlMapper#mapRow(ResultSet, int)}
     */
    @Test
    void testMapRow2() throws SQLException {
        // Arrange
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString(Mockito.<String>any())).thenThrow(new SQLException());
        // Act and Assert
        assertThrows(SQLException.class, () -> serviceUrlMapper.mapRow(rs, 1));
        verify(rs).getString(eq("service_name"));
    }
}
