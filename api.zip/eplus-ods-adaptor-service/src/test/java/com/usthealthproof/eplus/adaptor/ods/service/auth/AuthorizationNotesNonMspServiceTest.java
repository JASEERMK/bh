package com.usthealthproof.eplus.adaptor.ods.service.auth;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationClinicalNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;

public class AuthorizationNotesNonMspServiceTest {

    @InjectMocks
    private AuthorizationNotesNonMspService authorizationNotesNonMspService;

    //    @Mock
//    AuthorizationService authorizationService;
    @Mock
    private AuthorizationData authorizationData;

    @Mock
    private DaoUtil daoUtil;
    @Mock
    APIUtils apiUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    private final String authorizationId = "auth123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    
    @Test
    void testGetAuthorizationNotes_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationNotes model = new AuthorizationNotes();
        response.setAuthorizationNotes(Collections.singletonList(model));
        response.setHttpStatusCode(123);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesNonMspService.getAuthorizationNotes(authorizationId, accessToken);

        assertNotNull(result);
    }


    @Test
    void testGetAuthorizationNotes_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotes(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
        	authorizationNotesNonMspService.getAuthorizationNotes(authorizationId, accessToken);
        });
    }

    @Test
    void testAuthorizationNotes_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
        	authorizationNotesNonMspService.getAuthorizationNotes(authorizationId, accessToken);
        });
    }
    

    @Test
    void testGetAuthorizationCallLogsNotes_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationClinicalNotes model = new AuthorizationClinicalNotes();
        response.setAuthorizationClinicalNotes(Collections.singletonList(model));
        response.setHttpStatusCode(123);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesNonMspService.getAuthorizationCallLogsNotes(authorizationId, accessToken);

        assertNotNull(result);
    }


    @Test
    void testGetAuthorizationCallLogsNotes_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationNotesNonMspService.getAuthorizationCallLogsNotes(authorizationId, accessToken);
        });
    }

    @Test
    void testAuthorizationCallLogsNotes_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationNotesNonMspService.getAuthorizationCallLogsNotes(authorizationId, accessToken);
        });
    }
    
    @Test
    void testGetAuthorizationNotesClinicalReview_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationClinicalNotes model = new AuthorizationClinicalNotes();
        response.setAuthorizationClinicalNotes(Collections.singletonList(model));
        response.setHttpStatusCode(123);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesNonMspService.getAuthorizationNotesClinicalReview(authorizationId, accessToken);

        assertNotNull(result);
    }


    @Test
    void testGetAuthorizationNotesClinicalReview_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
        	authorizationNotesNonMspService.getAuthorizationNotesClinicalReview(authorizationId, accessToken);
        });
    }

    @Test
    void testAuthorizationNotesClinicalReview_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
        	authorizationNotesNonMspService.getAuthorizationNotesClinicalReview(authorizationId, accessToken);
        });
    }
}
