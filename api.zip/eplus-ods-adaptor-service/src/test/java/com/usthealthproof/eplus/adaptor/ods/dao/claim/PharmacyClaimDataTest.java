package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {PharmacyClaimData.class, OdsAdaptorServiceConfig.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class PharmacyClaimDataTest {

    @InjectMocks
    private PharmacyClaimData pharmacyClaimData;

    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @Mock
    private WebClient.Builder webClientBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testfindRxClaimIdWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(pharmacyClaimData, "isOAuthTokenRequired", "true");
        RxClaimDetails mockResponse = new RxClaimDetails();
        Mono<RxClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RxClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<RxClaimDetails> future = pharmacyClaimData.findRxClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "jkl","lob","product","accessToken");

        RxClaimDetails response = future.join();
        assertNotNull(response);
    }

    @Test
    void testfindRxClaimIdWithoutOAuthToken() throws InterruptedException, ExecutionException {

        RxClaimDetails mockResponse = new RxClaimDetails();
        Mono<RxClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(RxClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<RxClaimDetails> futureResponse = pharmacyClaimData.findRxClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "jkl","lob","product","accessToken");

        assertNotNull(futureResponse);
        RxClaimDetails response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testFindRxClaimId() {
        //   Diffblue Cover was unable to create a Spring-specific test for this Spring method.

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class,
                () -> (new PharmacyClaimData()).findRxClaimId("", "Context Path", "42", "ABC123","lob","product","accessToken"));
    }

    @Test
    void testFindRxClaimIdWebClientException() throws InterruptedException {

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<RxClaimDetails> futureResponse = pharmacyClaimData.findRxClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "jkl","lob","product","accessToken");

        assertNotNull(futureResponse);
    }


}
