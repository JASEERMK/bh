package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessagesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.ExternalMessageClaimService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {ExternalMessageAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class ExternalMessageAdaptorServiceControllerTest {
    @Autowired
    private ExternalMessageAdaptorServiceController externalMessageAdaptorServiceController;

    @MockitoBean
    private ExternalMessageClaimService externalMessageClaimService;

    /**
     * Method under test:
     * {@link ExternalMessageAdaptorServiceController#getExternalmessageDetails(String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetExternalmessageDetails() throws Exception {
        // Arrange
        MedicalExternalMessagesResponse medicalExternalMessagesResponse = new MedicalExternalMessagesResponse();
        medicalExternalMessagesResponse.setErrors(new ArrayList<>());
        medicalExternalMessagesResponse.setExternalMessages(new ArrayList<>());
        medicalExternalMessagesResponse.setHttpStatusCode(1);
        when(externalMessageClaimService.getExternalmessageDetails(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any())).thenReturn(medicalExternalMessagesResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/external/messages")
                .param("claimHccId", "foo")
                .param("claimLineHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(externalMessageAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"httpStatusCode\":1}"));
    }
}
