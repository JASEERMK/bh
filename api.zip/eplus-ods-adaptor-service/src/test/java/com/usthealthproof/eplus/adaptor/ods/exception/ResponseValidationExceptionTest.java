package com.usthealthproof.eplus.adaptor.ods.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ResponseValidationExceptionTest {

    @Test
    void testRequestValidationException() {
        ResponseValidationException exception = new ResponseValidationException();
        assertNotNull(exception);
    }

    @Test
    void testRequestValidationExceptionMessage() {
        String message = "This is an error message";
        ResponseValidationException exception = new ResponseValidationException(message);
        assertNotNull(exception);
    }

    @Test
    void testRequestValidationExceptionCause() {
        // Arrange
        Throwable cause = new Throwable("message");
        // Act
        ResponseValidationException exception = new ResponseValidationException(cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }

    @Test
    void testRequestValidationExceptionMessageAndThrowable() {
        // Arrange
        String message = "This is an error message";
        Throwable cause = new Throwable("message");
        // Act
        ResponseValidationException exception = new ResponseValidationException(message, cause);
        // Assert
        assertNotNull(exception);
        assertEquals(cause, exception.getCause());
        assertEquals("message", exception.getCause().getMessage());
    }
}
