package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationNotesNonMspService;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationNotesMspService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ContextConfiguration(classes = {AuthorizationNotesController.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(AuthorizationNotesController.class)
@DisabledInAotMode
class AuthorizationNotesControllerTest {
    @Autowired
    private AuthorizationNotesController authorizationNotesController;

    @MockitoBean
    private AuthorizationNotesMspService authorizationNotesMspService;
    @MockitoBean
    private AuthorizationNotesNonMspService authorizationNotesNonMspService;
    @Autowired
    private MockMvc mockMvc;

    /**
     * Method under test:
     * {@link AuthorizationNotesController#getAuthorizationNotesClinicalReview(String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationNotesClinicalReview() throws Exception {
        // Arrange
        when(authorizationNotesNonMspService.getAuthorizationNotesClinicalReview(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/notes/clinical");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(authorizationNotesController)
                .build()
                .perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationNotesClinicalReview_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        ResponseEntity<AuthorizationNotesResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationNotesMspService.getMspAuthorizationNotesClinicalReview(authorizationId, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/notes/clinical")
                        .param("authorizationId", authorizationId)
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test:
     * {@link AuthorizationNotesController#getAuthorizationCallLogsNotes(String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationCallLogsNotes() throws Exception {
        // Arrange
        when(authorizationNotesNonMspService.getAuthorizationCallLogsNotes(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/notes/calllogs");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(authorizationNotesController)
                .build()
                .perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationCallLogsNotes_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        ResponseEntity<AuthorizationNotesResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationNotesMspService.getMspAuthorizationCallLogsNotes(authorizationId, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/notes/calllogs")
                        .param("authorizationId", authorizationId)
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test:
     * {@link AuthorizationNotesController#getAuthorizationNotes(String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationNotes() throws Exception {
        // Arrange
        when(authorizationNotesNonMspService.getAuthorizationNotes(Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/notes/authnotes");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(authorizationNotesController)
                .build()
                .perform(requestBuilder)
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationNotes_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        ResponseEntity<AuthorizationNotesResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationNotesMspService.getMspAuthorizationNotes(authorizationId, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/notes/authnotes")
                        .param("authorizationId", authorizationId)
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
