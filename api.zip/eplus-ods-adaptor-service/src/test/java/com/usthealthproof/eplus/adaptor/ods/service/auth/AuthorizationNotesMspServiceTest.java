package com.usthealthproof.eplus.adaptor.ods.service.auth;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationCallLogNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationClinicalNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;

class AuthorizationNotesMspServiceTest {

    @InjectMocks
    private AuthorizationNotesMspService authorizationNotesMspService;

//    @Mock
//    AuthorizationService authorizationService;
    @Mock
    private AuthorizationData authorizationData;

    @Mock
    private DaoUtil daoUtil;
    @Mock
    APIUtils apiUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    private final String authorizationId = "auth123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";


    @Test
    void testGetMspAuthorizationNotes_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationNotes model = new AuthorizationNotes();
        response.setAuthorizationNotes(Collections.singletonList(model));
        response.setHttpStatusCode(123);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotes(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesMspService.getMspAuthorizationNotes(authorizationId, userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationNotes_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotes(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationNotesMspService.getMspAuthorizationNotes(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationNotes_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationNotes(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            authorizationNotesMspService.getMspAuthorizationNotes(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationCallLogsNotes_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationCallLogNotes model = new AuthorizationCallLogNotes();
        response.setAuthorizationCallLogNotes(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesMspService.getMspAuthorizationCallLogsNotes(authorizationId, userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationCallLogsNotes_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
        	authorizationNotesMspService.getMspAuthorizationCallLogsNotes(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationCallLogsNotes_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationCallLogsNotes(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
        	authorizationNotesMspService.getMspAuthorizationCallLogsNotes(authorizationId, userIdentities, accessToken);
        });
    }
    
    @Test
    void testGetMspAuthorizationNotesClinicalReview_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        AuthorizationClinicalNotes model = new AuthorizationClinicalNotes();
        response.setAuthorizationClinicalNotes(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        ResponseEntity<AuthorizationNotesResponse> result = authorizationNotesMspService.getMspAuthorizationNotesClinicalReview(authorizationId, userIdentities, accessToken);

        assertNotNull(result);
    }

    @Test
    void testGetMspAuthorizationNotesClinicalReview_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        AuthorizationNotesResponse response = new AuthorizationNotesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<AuthorizationNotesResponse> future = CompletableFuture.completedFuture(response);
        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
        	authorizationNotesMspService.getMspAuthorizationNotesClinicalReview(authorizationId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspAuthorizationNotesClinicalReview_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(authorizationData.getAuthorizationNotesClinical(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
        	authorizationNotesMspService.getMspAuthorizationNotesClinicalReview(authorizationId, userIdentities, accessToken);
        });
    }
    
}
