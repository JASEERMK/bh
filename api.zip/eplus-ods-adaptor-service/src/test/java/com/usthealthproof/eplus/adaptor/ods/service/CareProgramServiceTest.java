package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.CareProgramData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.carePrograms.CareProgram;
import com.usthealthproof.eplus.adaptor.ods.model.carePrograms.CareProgramsDetails;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CareProgramServiceTest {

    @InjectMocks
    private CareProgramService careProgramService;
    @Mock
    private CareProgramData careProgramData;
    @Mock
    private DaoUtil daoUtil;
    private final String userIdentities = "SC:Medicare:Medicare HMO Individual";
    private final String accessToken = "token123";
    private final String memberId = "123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspCareProgramDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareProgramsDetails response = new CareProgramsDetails();
        CareProgram model = new CareProgram();
        response.setCarePrograms(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CareProgramsDetails> future = CompletableFuture.completedFuture(response);
        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CareProgramsDetails> result = careProgramService.getMspCareProgramsDetails(memberId, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspCareProgramDetails_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareProgramsDetails response = new CareProgramsDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<CareProgramsDetails> future = CompletableFuture.completedFuture(response);
        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            careProgramService.getMspCareProgramsDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspCareProgramDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            careProgramService.getMspCareProgramsDetails(memberId, userIdentities, accessToken);
        });
    }

    @Test
    void testGetCareProgramsDetails_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareProgramsDetails response = new CareProgramsDetails();
        CareProgram model = new CareProgram();
        response.setCarePrograms(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<CareProgramsDetails> future = CompletableFuture.completedFuture(response);
        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<CareProgramsDetails> result = careProgramService.getCareProgramsDetails(memberId, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetCareProgramsDetails_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            careProgramService.getCareProgramsDetails(memberId, accessToken);
        });
    }

    @Test
    void testGetClaimAdjustment_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        CareProgramsDetails response = new CareProgramsDetails();
        response.setHttpStatusCode(504);
        response.setCarePrograms(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<CareProgramsDetails> future = CompletableFuture.completedFuture(response);
        when(careProgramData.getMemberCareProgramsDetails(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            careProgramService.getCareProgramsDetails(memberId, accessToken);
        });
    }

}
