package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.PharmacyClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.PharmacyClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.when;

class PharmacyClaimServiceTest {

    @InjectMocks
    PharmacyClaimService pharmacyClaimService;

    @Mock
    private PharmacyClaimData pharmacyClaimData;

    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    PharmacyClaimsResponseMapper pharmacyClaimsResponseMapper;
    @Mock
    private DaoUtil daoUtil;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetRxClaimDetails_Success() throws Exception {

        RxClaimDetails response = new RxClaimDetails();
        response.setClaimId("123");
        response.setCheckNumber("234");
        response.setAdjustmentType("open");
        CompletableFuture<RxClaimDetails> future = CompletableFuture.completedFuture(response);
        when(pharmacyClaimData.findRxClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        RxClaimDetails result = pharmacyClaimService.getRxClaimDetails("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetRxClaimDetails_WebClientResponseException() throws Exception {

        RxClaimDetails response = new RxClaimDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<RxClaimDetails> future = CompletableFuture.completedFuture(response);
        when(pharmacyClaimData.findRxClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            pharmacyClaimService.getRxClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetRxClaimDetails_Exception() throws Exception {

        when(pharmacyClaimData.findRxClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            pharmacyClaimService.getRxClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetRxClaimDetails_ODSAdaptorException() throws Exception {

        RxClaimDetails response = new RxClaimDetails();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<RxClaimDetails> future = CompletableFuture.completedFuture(response);
        when(pharmacyClaimData.findRxClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            pharmacyClaimService.getRxClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetMspRxClaimDetails_Success() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        RxClaimDetails response = new RxClaimDetails();
        response.setClaimId("123");
        response.setMemberId("456");
        response.setCheckNumber("234");
        response.setAdjustmentType("open");
        CompletableFuture<RxClaimDetails> future = CompletableFuture.completedFuture(response);
        when(pharmacyClaimData.findRxClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);
        doCallRealMethod().when(pharmacyClaimsResponseMapper).pharmacyClaimDetailsResponseMapper(any(),any());

        RxClaimDetails result = pharmacyClaimService.getMspRxClaimDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetMspRxClaimDetails_WebClientResponseException() throws Exception {

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        RxClaimDetails response = new RxClaimDetails();
        List<String> errors = Arrays.asList("Error caught");
        response.setErrors(errors);
        response.setHttpStatusCode(504);
        CompletableFuture<RxClaimDetails> future = CompletableFuture.completedFuture(response);
        when(pharmacyClaimData.findRxClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            pharmacyClaimService.getMspRxClaimDetails("123", "SC:Medicare:Medicare HMO Individual","accessToken");
        });
    }

    @Test
    void testGetMspRxClaimDetails_Exception() throws Exception {

        when(pharmacyClaimData.findRxClaimId(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            pharmacyClaimService.getMspRxClaimDetails("123", "SC:Medicare:Medicare HMO Individual", "accessToken");
        });
    }

}
