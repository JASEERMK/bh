package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class AuthDataAvailabilityServiceTest {

    @InjectMocks
    AuthorizationService authorizationService;

    @Mock
    private AuthorizationData authorizationData;

    @Mock
    private DaoUtil daoUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    private final String authorizationId = "auth123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";


    @Test
    void testProviderAuthDataAvailabilityCheck_Success() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
//         ResponseEntity<AuthorizationSearchResponseList> future =
        when(authorizationData.providerAuthDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        ResponseEntity<AuthorizationSearchResponseList> result = authorizationService.providerAuthDataAvailabilityCheck(authorizationSearchRequest, accessToken);
        assertNotNull(result);
    }

    @Test
    void testProviderAuthDataAvailabilityCheck() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setUserIdentities("SC:Medicare:Medicare HMO Individual");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);

        when(authorizationData.providerAuthDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(ResponseValidationException.class, () -> {
            authorizationService.providerAuthDataAvailabilityCheck(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testProviderAuthDataAvailabilityCheck_ResponseValidation() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setUserIdentities("SC:Medicare:Medicare HMO Individual");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        AuthorizationSearchResponse model = new AuthorizationSearchResponse();
        response.setResults(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        response.setDataAvailabilityFlag("true");

        when(authorizationData.providerAuthDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(ResponseValidationException.class, () -> {
            authorizationService.providerAuthDataAvailabilityCheck(authorizationSearchRequest, accessToken);
        });
    }

    @Test
    void testProviderAuthDataAvailabilityCheck_WebClientException() throws Exception {

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setUserIdentities("SC:Medicare:Medicare HMO Individual");

        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap("SC:Medicare:Medicare HMO Individual")).thenReturn(mspConfigMap);

        AuthorizationSearchResponseList response = new AuthorizationSearchResponseList();
        response.setHttpStatusCode(504);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        when(authorizationData.providerAuthDataAvailabilityCheck(any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(response);

        assertThrows(WebClientResponseException.class, () -> {
            authorizationService.providerAuthDataAvailabilityCheck(authorizationSearchRequest, accessToken);
        });
    }
}
