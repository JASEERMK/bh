package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.VisionClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.VisionClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.*;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class VisionClaimServiceTest {

    @InjectMocks
    VisionClaimService visionClaimService;
    @Mock
    private VisionClaimData visionClaimData;

    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    VisionClaimsResponseMapper visionClaimsResponseMapper;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetVisionClaimDetails_Success() throws Exception {

        VisionClaimDetails response = new VisionClaimDetails();
        response.setAllowedAmount("123");
        response.setCheckNumber("234");
        CompletableFuture<VisionClaimDetails> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.findVisionClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        VisionClaimDetails result = visionClaimService.getVisionClaimDetails("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetVisionClaimDetails_WebClientResponseException() throws Exception {

        VisionClaimDetails response = new VisionClaimDetails();
        response.setHttpStatusCode(504);
        CompletableFuture<VisionClaimDetails> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.findVisionClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getVisionClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimDetails_Exception() throws Exception {

        when(visionClaimData.findVisionClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimDetails_ODSAdaptorException() throws Exception {

        VisionClaimDetails response = new VisionClaimDetails();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<VisionClaimDetails> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.findVisionClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLines_Success() throws Exception {

        VisionClaimLinesResponse response = new VisionClaimLinesResponse();
        VisionClaimLines model = new VisionClaimLines();
        response.setVisionClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<VisionClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        VisionClaimLinesResponse result = visionClaimService.getVisionClaimLines("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetVisionClaimLines_WebClientResponseException() throws Exception {

        VisionClaimLinesResponse response = new VisionClaimLinesResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<VisionClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLines(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getVisionClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLines_Exception() throws Exception {

        when(visionClaimData.getVisionClaimLines(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLines_ODSAdaptorException() throws Exception {

        VisionClaimLinesResponse response = new VisionClaimLinesResponse();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<VisionClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLines(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLineDetails_Success() throws Exception {

        VisionClaimLineDetailsResponse response = new VisionClaimLineDetailsResponse();
        VisionClaimLineDetails model = new VisionClaimLineDetails();
        response.setVisionClaimLineDetails(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<VisionClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        VisionClaimLineDetailsResponse result = visionClaimService.getVisionClaimLineDetails("123", "233", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetVisionClaimLineDetails_WebClientResponseException() throws Exception {

        VisionClaimLineDetailsResponse response = new VisionClaimLineDetailsResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<VisionClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            visionClaimService.getVisionClaimLineDetails("123", "233", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLineDetails_Exception() throws Exception {

        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimLineDetails("123", "233", "accessToken");
        });
    }

    @Test
    void testGetVisionClaimLineDetails_ODSAdaptorException() throws Exception {

        VisionClaimLineDetailsResponse response = new VisionClaimLineDetailsResponse();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<VisionClaimLineDetailsResponse> future = CompletableFuture.completedFuture(response);
        when(visionClaimData.getVisionClaimLineDetails(any(), any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            visionClaimService.getVisionClaimLineDetails("123", "233", "accessToken");
        });
    }
}
