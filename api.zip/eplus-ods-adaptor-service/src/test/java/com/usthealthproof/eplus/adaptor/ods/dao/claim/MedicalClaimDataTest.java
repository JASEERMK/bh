package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLinesResponse;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {MedicalClaimData.class, OdsAdaptorServiceConfig.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class MedicalClaimDataTest {

    @InjectMocks
    private MedicalClaimData medicalClaimData;

    @Mock
    private WebClient webClientGatewayRoute;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

    @Mock
    private WebClient.Builder webClientBuilder;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testfindClaimIdWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(medicalClaimData, "isOAuthTokenRequired", "true");
        MedicalClaimDetails mockResponse = new MedicalClaimDetails();
        Mono<MedicalClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimDetails> future = medicalClaimData.findClaimId(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "kl", "jkl");

        MedicalClaimDetails response = future.join();
        assertNotNull(response);
    }

    @Test
    void testfindClaimIdWithoutOAuthToken() throws InterruptedException, ExecutionException {

        MedicalClaimDetails mockResponse = new MedicalClaimDetails();
        Mono<MedicalClaimDetails> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimDetails.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimDetails> futureResponse = medicalClaimData.findClaimId("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42");

        assertNotNull(futureResponse);
        MedicalClaimDetails response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testFindClaimId() {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> (new MedicalClaimData()).findClaimId("", "Context Path", "42",
                "Claim Fact Key", "MD", "Lob", "Product", "ABC123"));
    }

    @Test
    void testfindClaimIdWebClientException() throws InterruptedException {

        MedicalClaimDetails mockResponse = new MedicalClaimDetails();
        Mono<MedicalClaimDetails> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimDetails.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<MedicalClaimDetails> futureResponse = medicalClaimData.findClaimId("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42");

    }

    @Test
    void testfindClaimLinesWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(medicalClaimData, "isOAuthTokenRequired", "true");
        MedicalClaimLinesResponse mockResponse = new MedicalClaimLinesResponse();
        Mono<MedicalClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimLinesResponse> future = medicalClaimData.getClaimLines(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "kl", "jkl");

        MedicalClaimLinesResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testfindClaimLinesWithoutOAuthToken() throws InterruptedException, ExecutionException {

        MedicalClaimLinesResponse mockResponse = new MedicalClaimLinesResponse();
        Mono<MedicalClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLinesResponse.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimLinesResponse> futureResponse = medicalClaimData.getClaimLines("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42");

        assertNotNull(futureResponse);
        MedicalClaimLinesResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetClaimLines() {
        //   Diffblue Cover was unable to create a Spring-specific test for this Spring method.

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> (new MedicalClaimData()).getClaimLines("", "Context Path",
                "42", "Claim Fact Key", "MD", "Lob", "Product", "ABC123"));
    }

    @Test
    void testfindClaimLinesWebClientException() throws InterruptedException {

        MedicalClaimLinesResponse mockResponse = new MedicalClaimLinesResponse();
        Mono<MedicalClaimLinesResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLinesResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<MedicalClaimLinesResponse> futureResponse = medicalClaimData.getClaimLines("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42");

    }

    @Test
    void testfindClaimLineDetailsWithOAuthToken() throws ExecutionException, InterruptedException {

        ReflectionTestUtils.setField(medicalClaimData, "isOAuthTokenRequired", "true");
        MedicalClaimLineDetailsResponse mockResponse = new MedicalClaimLineDetailsResponse();
        Mono<MedicalClaimLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.header(any(String.class), any(String.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimLineDetailsResponse> future = medicalClaimData.getClaimLineDetails(
                "https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "kl", "jkl", "jko");

        MedicalClaimLineDetailsResponse response = future.join();
        assertNotNull(response);
    }

    @Test
    void testfindClaimLineDetailsWithoutOAuthToken() throws InterruptedException, ExecutionException {

        MedicalClaimLineDetailsResponse mockResponse = new MedicalClaimLineDetailsResponse();
        Mono<MedicalClaimLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLineDetailsResponse.class)).thenReturn(monoResponse);

        CompletableFuture<MedicalClaimLineDetailsResponse> futureResponse = medicalClaimData.getClaimLineDetails("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "kol");

        assertNotNull(futureResponse);
        MedicalClaimLineDetailsResponse response = futureResponse.get();
        assertNotNull(response);
    }

    @Test
    void testGetClaimLineDetails() {
        //   Diffblue Cover was unable to create a Spring-specific test for this Spring method.

        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> (new MedicalClaimData()).getClaimLineDetails("",
                "Context Path", "42", "42", "Claim Fact Key", "MD", "Lob", "Product", "ABC123"));
    }

    @Test
    void testfindClaimLineDetailsWebClientException() throws InterruptedException {

        MedicalClaimLineDetailsResponse mockResponse = new MedicalClaimLineDetailsResponse();
        Mono<MedicalClaimLineDetailsResponse> monoResponse = Mono.just(mockResponse);

        JSONObject responseBody = new JSONObject();
        responseBody.put("error", "Resource not found");

        when(webClientBuilder.build()).thenReturn(webClientGatewayRoute);
        when(webClientGatewayRoute.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(MedicalClaimLineDetailsResponse.class)).thenThrow(new WebClientResponseException(404, "Error message", null, responseBody.toString().getBytes(StandardCharsets.UTF_8), null));

        CompletableFuture<MedicalClaimLineDetailsResponse> futureResponse = medicalClaimData.getClaimLineDetails("https://example.org/example", "Context Path", "Claim Types", "42",
                "2020-03-01", "2020-03-01", "Claim Status", "42", "kl");

    }
}
