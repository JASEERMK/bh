package com.usthealthproof.eplus.adaptor.ods.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.reactive.function.client.ClientResponse;

@ContextConfiguration(classes = {Validator.class})
@ExtendWith(SpringExtension.class)
class ValidatorDiffblueTest {
    @Autowired
    private Validator validator;

    /**
     * Method under test: {@link Validator#validateBearerToken(HttpServletRequest)}
     */
    @Test
    void testValidateBearerToken() throws RequestValidationException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> validator.validateBearerToken(new MockHttpServletRequest()));
        assertThrows(RequestValidationException.class, () -> validator.validateBearerToken(null));
    }

    /**
     * Method under test: {@link Validator#validateBearerToken(HttpServletRequest)}
     */
    @Test
    void testValidateBearerToken2() throws RequestValidationException {
        // Arrange
        HttpServletRequestWrapper httpServletRequest = mock(HttpServletRequestWrapper.class);
        when(httpServletRequest.getHeader(Mockito.<String>any())).thenReturn("https://example.org/example");

        // Act
        String actualValidateBearerTokenResult = validator.validateBearerToken(httpServletRequest);

        // Assert
        verify(httpServletRequest).getHeader(eq("Authorization"));
        assertEquals("https://example.org/example", actualValidateBearerTokenResult);
    }

    /**
     * Method under test: {@link Validator#validateClientResponse(ClientResponse)}
     */
    @Test
    void testValidateClientResponse() throws Exception {
        // Arrange, Act and Assert
        assertThrows(Exception.class, () -> validator.validateClientResponse(null));
    }

    /**
     * Method under test: {@link Validator#validateMspConfigResponse(Map)}
     */
    @Test
    void testValidateMspConfigResponse() throws ResponseValidationException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> validator.validateMspConfigResponse(new HashMap<>()));
    }

    /**
     * Method under test: {@link Validator#validateMspConfigData(Map)}
     */
    @Test
    void testValidateMspConfigData() throws RequestValidationException {
        // Arrange, Act and Assert
        assertThrows(RequestValidationException.class, () -> validator.validateMspConfigData(new HashMap<>()));
    }
}
