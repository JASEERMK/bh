package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.service.CorrespondenceHistoryService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {CorrespondenceHistoryAdaptorService.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class CorrespondenceHistoryAdaptorServiceTest {
    @Autowired
    private CorrespondenceHistoryAdaptorService correspondenceHistoryAdaptorService;

    @MockitoBean
    private CorrespondenceHistoryService correspondenceHistoryService;

    /**
     * Method under test:
     * {@link CorrespondenceHistoryAdaptorService#getCorrespondenceSearch(String, String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetCorrespondenceSearch() throws Exception {
        // Arrange
        when(correspondenceHistoryService.getCorrespondenceSearch(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v2/correspondence/search")
                .param("correspondenceName", "foo")
                .param("memberId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(correspondenceHistoryAdaptorService)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Method under test:
     * {@link CorrespondenceHistoryAdaptorService#getCorrespondenceDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetCorrespondenceDetails() throws Exception {
        // Arrange
        when(correspondenceHistoryService.getCorrespondenceDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v2/correspondence/details")
                .param("correspondenceId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(correspondenceHistoryAdaptorService)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
