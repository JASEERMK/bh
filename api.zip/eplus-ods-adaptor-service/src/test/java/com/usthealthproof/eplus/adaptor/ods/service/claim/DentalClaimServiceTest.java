package com.usthealthproof.eplus.adaptor.ods.service.claim;

import com.usthealthproof.eplus.adaptor.ods.dao.claim.DentalClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.*;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class DentalClaimServiceTest {

    @InjectMocks
    DentalClaimService dentalClaimService;
    @Mock
    private DentalClaimData dentalClaimData;
    @Mock
    HttpServletRequest httpServletRequest;
    @Mock
    DentalClaimsResponseMapper dentalClaimsResponseMapper;

    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetDentalClaimDetails_Success() throws Exception {

        DentalClaimDetails response = new DentalClaimDetails();
        response.setAllowed("123");
        response.setCobAmount("2000");
        CompletableFuture<DentalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.findDentalClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenReturn(future);

        DentalClaimDetails result = dentalClaimService.getDentalClaimDetails("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetDentalClaimDetails_WebClientResponseException() throws Exception {

        DentalClaimDetails response = new DentalClaimDetails();
        response.setCobAmount("123");
        CompletableFuture<DentalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.findDentalClaimId(any(), any(), any(), any(), any(), any(),any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getDentalClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimDetails_Exception() throws Exception {

        when(dentalClaimData.findDentalClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimDetails_ODSAdaptorException() throws Exception {

        DentalClaimDetails response = new DentalClaimDetails();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<DentalClaimDetails> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.findDentalClaimId(any(), any(), any(),any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimDetails("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLines_Success() throws Exception {

        DentalClaimLinesResponse response = new DentalClaimLinesResponse();
        DentalClaimLines model = new DentalClaimLines();
        response.setDentalClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        DentalClaimLinesResponse result = dentalClaimService.getDentalClaimLines("123", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetDentalClaimLines_WebClientResponseException() throws Exception {

        DentalClaimLinesResponse response = new DentalClaimLinesResponse();
        DentalClaimLines model = new DentalClaimLines();
        response.setDentalClaimLines(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getDentalClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLines_Exception() throws Exception {

        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLines_ODSAdaptorException() throws Exception {

        DentalClaimLinesResponse response = new DentalClaimLinesResponse();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<DentalClaimLinesResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLines(any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimLines("123", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLineDetails_Success() throws Exception {

        DentalClaimLineDetailResponse response = new DentalClaimLineDetailResponse();
        DentalClaimLineDetails model = new DentalClaimLineDetails();
        response.setDentalClaimLineDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLineDetailResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        DentalClaimLineDetailResponse result = dentalClaimService.getDentalClaimLineDetails("123", "qwe", "accessToken");
        assertNotNull(result);
    }

    @Test
    void testGetDentalClaimLineDetails_WebClientResponseException() throws Exception {

        DentalClaimLineDetailResponse response = new DentalClaimLineDetailResponse();
        DentalClaimLineDetails model = new DentalClaimLineDetails();
        response.setDentalClaimLineDetailsList(Collections.singletonList(model));
        response.setHttpStatusCode(200);
        CompletableFuture<DentalClaimLineDetailResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        assertThrows(WebClientResponseException.class, () -> {
            dentalClaimService.getDentalClaimLineDetails("123", "qwe", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLineDetails_Exception() throws Exception {

        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimLineDetails("123", "qwe", "accessToken");
        });
    }

    @Test
    void testGetDentalClaimLineDetails_ODSAdaptorException() throws Exception {

        DentalClaimLineDetailResponse response = new DentalClaimLineDetailResponse();
        List<String> errors = Arrays.asList("Error occurred");
        response.setErrors(errors);
        response.setHttpStatusCode(404);
        CompletableFuture<DentalClaimLineDetailResponse> future = CompletableFuture.completedFuture(response);
        when(dentalClaimData.getDentalClaimLineDetails(any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(Exception.class, () -> {
            dentalClaimService.getDentalClaimLineDetails("123", "qwe", "accessToken");
        });
    }
}
