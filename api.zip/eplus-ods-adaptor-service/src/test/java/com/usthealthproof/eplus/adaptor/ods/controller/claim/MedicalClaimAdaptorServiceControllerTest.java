package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.service.claim.MedicalClaimService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {MedicalClaimAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class MedicalClaimAdaptorServiceControllerTest {
    @Autowired
    private MedicalClaimAdaptorServiceController medicalClaimAdaptorServiceController;

    @MockitoBean
    private MedicalClaimService medicalClaimService;

    /**
     * Method under test:
     * {@link MedicalClaimAdaptorServiceController#getClaimDetails(String, String, HttpServletRequest)}
     */
    @Test
    void testGetClaimDetails() throws Exception {
        // Arrange
        when(medicalClaimService.getClaimDetails(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/medical")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Method under test:
     * {@link MedicalClaimAdaptorServiceController#getClaimLines(String, String, HttpServletRequest)}
     */
    @Test
    void testGetClaimLines() throws Exception {
        // Arrange
        when(medicalClaimService.getClaimLines(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/medical/claimlines")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    /**
     * Method under test:
     * {@link MedicalClaimAdaptorServiceController#getClaimLineDetails(String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetClaimLineDetails() throws Exception {
        // Arrange
        when(medicalClaimService.getClaimLineDetails(Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/medical/claimline")
                .param("claimHccId", "foo")
                .param("claimLineHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }
}
