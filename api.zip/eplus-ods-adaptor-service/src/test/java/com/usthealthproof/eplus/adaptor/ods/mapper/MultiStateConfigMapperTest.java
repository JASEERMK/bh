package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.MSPConfigResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {MultiStateConfigMapper.class})
@ExtendWith(SpringExtension.class)
class MultiStateConfigMapperTest {
    @Autowired
    private MultiStateConfigMapper multiStateConfigMapper;

    /**
     * Method under test: {@link MultiStateConfigMapper#mapRow(ResultSet, int)}
     */
    @Test
    void testMapRow() throws SQLException {
        // Arrange
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString(Mockito.<String>any())).thenReturn("String");
        // Act
        MSPConfigResponse actualMapRowResult = multiStateConfigMapper.mapRow(rs, 1);
        // Assert
        verify(rs, atLeast(1)).getString(Mockito.<String>any());
        assertEquals("String", actualMapRowResult.getCombinedSLP());
        assertEquals("String", actualMapRowResult.getServiceContextPath());
    }

    /**
     * Method under test: {@link MultiStateConfigMapper#mapRow(ResultSet, int)}
     */
    @Test
    void testMapRow2() throws SQLException {
        // Arrange
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString(Mockito.<String>any())).thenThrow(new SQLException());
        // Act and Assert
        assertThrows(SQLException.class, () -> multiStateConfigMapper.mapRow(rs, 1));
        verify(rs).getString(eq("SLP"));
    }

}
