package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ContextConfiguration(classes = {AuthorizationSearchRequestMapper.class})
@ExtendWith(SpringExtension.class)
class AuthorizationSearchRequestMapperTest {
    @Autowired
    private AuthorizationSearchRequestMapper authorizationSearchRequestMapper;

    /**
     * Method under test:
     * {@link AuthorizationSearchRequestMapper#authorizationSearchRequestMapper(String, String, String, String, String, String, String)}
     */
    @Test
    void testAuthorizationSearchRequestMapper() {
        // Arrange and Act
        AuthorizationSearchRequest actualAuthorizationSearchRequestMapperResult = authorizationSearchRequestMapper
                .authorizationSearchRequestMapper("42", "42", "42", "Status", "Type", "2020-03-01", "2020-03-01");

        // Assert
        assertEquals("2020-03-01", actualAuthorizationSearchRequestMapperResult.getSearchEndDate());
        assertEquals("2020-03-01", actualAuthorizationSearchRequestMapperResult.getSearchStartDate());
        assertEquals("42", actualAuthorizationSearchRequestMapperResult.getAuthorizationId());
        assertEquals("42", actualAuthorizationSearchRequestMapperResult.getMemberNumber());
        assertEquals("42", actualAuthorizationSearchRequestMapperResult.getProviderId());
        assertEquals("Status", actualAuthorizationSearchRequestMapperResult.getStatus());
        assertEquals("Type", actualAuthorizationSearchRequestMapperResult.getType());
        assertNull(actualAuthorizationSearchRequestMapperResult.getIsMatchingUserRole());
        assertNull(actualAuthorizationSearchRequestMapperResult.getLob());
        assertNull(actualAuthorizationSearchRequestMapperResult.getProduct());
        assertNull(actualAuthorizationSearchRequestMapperResult.getState());
        assertNull(actualAuthorizationSearchRequestMapperResult.getUserIdentities());
    }
}
