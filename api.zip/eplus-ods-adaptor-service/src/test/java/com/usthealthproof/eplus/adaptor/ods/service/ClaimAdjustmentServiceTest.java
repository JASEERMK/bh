package com.usthealthproof.eplus.adaptor.ods.service;

import com.usthealthproof.eplus.adaptor.ods.dao.ClaimAdjustmentData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentModel;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentResponse;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ClaimAdjustmentServiceTest {

    @Mock
    private DaoUtil daoUtil;

    @Mock
    private ClaimAdjustmentData claimAdjustmentData;

    @InjectMocks
    private ClaimAdjustmentService claimAdjustmentService;

    private final String claimNumber = "claim123";
    private final String claimFactKey = "factKey123";
    private final String previousClaimFactKey = "prevFactKey123";
    private final String userIdentities = "user123";
    private final String accessToken = "token123";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        MSPConfigUtils.serviceUrlMap = new HashMap<>();
    }

    @Test
    void testGetMspClaimAdjustment_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimAdjustmentResponse response = new ClaimAdjustmentResponse();
        ClaimAdjustmentModel model = new ClaimAdjustmentModel();
        response.setAdjustedFieldList(Collections.singletonList(model));
        response.setRequestId("123");
        CompletableFuture<ClaimAdjustmentResponse> future = CompletableFuture.completedFuture(response);
        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimAdjustmentResponse> result = claimAdjustmentService.getMspClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, userIdentities, accessToken);
        assertNotNull(result);
    }

    @Test
    void testGetMspClaimAdjustment_WebClientResponseException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimAdjustmentResponse response = new ClaimAdjustmentResponse();
        response.setHttpStatusCode(504);
        CompletableFuture<ClaimAdjustmentResponse> future = CompletableFuture.completedFuture(response);
        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(WebClientResponseException.class, () -> {
            claimAdjustmentService.getMspClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, userIdentities, accessToken);
        });
    }

    @Test
    void testGetMspClaimAdjustment_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            claimAdjustmentService.getMspClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, userIdentities, accessToken);
        });
    }

    @Test
    void testGetClaimAdjustment_Success() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("SC:Medicare:Medicare HMO Individual", "/PA");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimAdjustmentResponse response = new ClaimAdjustmentResponse();
        ClaimAdjustmentModel model = new ClaimAdjustmentModel();
        response.setAdjustedFieldList(Collections.singletonList(model));
        response.setRequestId("123");
        CompletableFuture<ClaimAdjustmentResponse> future = CompletableFuture.completedFuture(response);
        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        ResponseEntity<ClaimAdjustmentResponse> result = claimAdjustmentService.getClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, accessToken);
        assertNotNull(result);
    }


    @Test
    void testGetClaimAdjustment_ODSAdaptorExceptionException() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        ClaimAdjustmentResponse response = new ClaimAdjustmentResponse();
        response.setHttpStatusCode(504);
        response.setAdjustedFieldList(null);
        response.setErrors(Collections.singletonList("Invalid previous claim fact key"));
        CompletableFuture<ClaimAdjustmentResponse> future = CompletableFuture.completedFuture(response);
        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenReturn(future);

        assertThrows(ODSAdaptorException.class, () -> {
            claimAdjustmentService.getClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, accessToken);
        });
    }

    @Test
    void testGetClaimAdjustment_Exception() throws Exception {
        Map<String, String> mspConfigMap = new HashMap<>();
        mspConfigMap.put("state:lob:product", "contextPath");
        when(daoUtil.getMspConfigMap(userIdentities)).thenReturn(mspConfigMap);

        when(claimAdjustmentData.getClaimAdjustmentFields(any(), any(), any(), any(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("General error"));

        assertThrows(Exception.class, () -> {
            claimAdjustmentService.getClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, accessToken);
        });
    }
}
