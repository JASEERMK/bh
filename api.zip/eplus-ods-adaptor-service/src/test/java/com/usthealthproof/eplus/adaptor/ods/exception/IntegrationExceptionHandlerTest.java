package com.usthealthproof.eplus.adaptor.ods.exception;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.ProblemDetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {IntegrationExceptionHandler.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class IntegrationExceptionHandlerTest {
    @MockitoBean
    private APIUtils aPIUtils;

    @Autowired
    private IntegrationExceptionHandler integrationExceptionHandler;

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#invalidRequestHandler(RequestValidationException, WebRequest)}
     */
    @Test
    void testInvalidRequestHandler() {
        // Arrange
        ProblemDetails problemDetails = new ProblemDetails();
        problemDetails.setErrors(new ArrayList<>());
        problemDetails.setStatus("Status");
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(problemDetails);
        RequestValidationException ex = new RequestValidationException("An error occurred");
        ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());

        // Act
        ResponseEntity<ErrorResponse> actualInvalidRequestHandlerResult = integrationExceptionHandler
                .invalidRequestHandler(ex, request);

        // Assert
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
        HttpStatusCode statusCode = actualInvalidRequestHandlerResult.getStatusCode();
        assertTrue(statusCode instanceof HttpStatus);
        assertEquals(400, actualInvalidRequestHandlerResult.getStatusCodeValue());
        assertEquals(HttpStatus.BAD_REQUEST, statusCode);
        assertTrue(actualInvalidRequestHandlerResult.hasBody());
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#invalidRequestHandler(RequestValidationException, WebRequest)}
     */
    @Test
    void testInvalidRequestHandlerException() {
        // Arrange
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new RequestValidationException("An error occurred"));
        RequestValidationException ex = new RequestValidationException("An error occurred");

        // Act and Assert
        assertThrows(RequestValidationException.class, () -> integrationExceptionHandler.invalidRequestHandler(ex,
                new ServletWebRequest(new MockHttpServletRequest())));
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#invalidResponseHandler(ResponseValidationException, WebRequest)}
     */
    @Test
    void testInvalidResponseHandler() {
        // Arrange
        ProblemDetails problemDetails = new ProblemDetails();
        problemDetails.setErrors(new ArrayList<>());
        problemDetails.setStatus("Status");
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(problemDetails);
        ResponseValidationException ex = new ResponseValidationException("An error occurred");
        ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());
        // Act
        ResponseEntity<ErrorResponse> actualInvalidResponseHandlerResult = integrationExceptionHandler
                .invalidResponseHandler(ex, request);
        // Assert
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
        HttpStatusCode statusCode = actualInvalidResponseHandlerResult.getStatusCode();
        assertTrue(statusCode instanceof HttpStatus);
        assertEquals(404, actualInvalidResponseHandlerResult.getStatusCodeValue());
        assertEquals(HttpStatus.NOT_FOUND, statusCode);
        assertTrue(actualInvalidResponseHandlerResult.hasBody());
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#invalidResponseHandler(ResponseValidationException, WebRequest)}
     */
    @Test
    void testInvalidResponseHandlerException() {
        // Arrange
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new RequestValidationException("An error occurred"));
        ResponseValidationException ex = new ResponseValidationException("An error occurred");

        // Act and Assert
        assertThrows(RequestValidationException.class, () -> integrationExceptionHandler.invalidResponseHandler(ex,
                new ServletWebRequest(new MockHttpServletRequest())));
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#webclientExceptionHandler(HttpStatusCodeException, WebRequest)}
     */
    @Test
    void testWebclientExceptionHandler() {
        // Arrange
        ProblemDetails problemDetails = new ProblemDetails();
        problemDetails.setErrors(new ArrayList<>());
        problemDetails.setStatus("Status");
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(problemDetails);
        HttpClientErrorException ex = mock(HttpClientErrorException.class);
        when(ex.getMessage()).thenReturn("Not all who wander are lost");
        ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());

        // Act
        ResponseEntity<ErrorResponse> actualWebclientExceptionHandlerResult = integrationExceptionHandler
                .webclientExceptionHandler(ex, request);

        // Assert
        verify(aPIUtils).createProblemDetails(eq("Something went wrong, please check the log for more details"),
                eq("FAILURE"));
        verify(ex).getMessage();
        HttpStatusCode statusCode = actualWebclientExceptionHandlerResult.getStatusCode();
        assertTrue(statusCode instanceof HttpStatus);
        assertEquals(500, actualWebclientExceptionHandlerResult.getStatusCodeValue());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, statusCode);
        assertTrue(actualWebclientExceptionHandlerResult.hasBody());
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#webclientRequestExceptionHandler(WebClientRequestException, WebRequest)}
     */
    @Test
    void testWebclientRequestExceptionHandler() {
        // Arrange
        ProblemDetails problemDetails = new ProblemDetails();
        problemDetails.setErrors(new ArrayList<>());
        problemDetails.setStatus("Status");
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(problemDetails);
        Throwable ex = new Throwable();
        HttpMethod method = HttpMethod.valueOf("https://example.org/example");
        URI uri = Paths.get(System.getProperty("java.io.tmpdir"), "test.txt").toUri();
        WebClientRequestException ex2 = new WebClientRequestException(ex, method, uri, new HttpHeaders());

        // Act
        ResponseEntity<ErrorResponse> actualWebclientRequestExceptionHandlerResult = integrationExceptionHandler
                .webclientRequestExceptionHandler(ex2, new ServletWebRequest(new MockHttpServletRequest()));

        // Assert
        verify(aPIUtils).createProblemDetails(eq("Something went wrong, please check the log for more details"),
                eq("FAILURE"));
        HttpStatusCode statusCode = actualWebclientRequestExceptionHandlerResult.getStatusCode();
        assertTrue(statusCode instanceof HttpStatus);
        assertEquals(400, actualWebclientRequestExceptionHandlerResult.getStatusCodeValue());
        assertEquals(HttpStatus.BAD_REQUEST, statusCode);
        assertTrue(actualWebclientRequestExceptionHandlerResult.hasBody());
        assertTrue(actualWebclientRequestExceptionHandlerResult.getHeaders().isEmpty());
        assertSame(problemDetails, actualWebclientRequestExceptionHandlerResult.getBody().getProblemDetails());
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#webclientRequestExceptionHandler(WebClientRequestException, WebRequest)}
     */
    @Test
    void testWebclientRequestExceptionHandler2() {
        // Arrange
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new RequestValidationException("An error occurred"));
        Throwable ex = new Throwable();
        HttpMethod method = HttpMethod.valueOf("https://example.org/example");
        URI uri = Paths.get(System.getProperty("java.io.tmpdir"), "test.txt").toUri();
        WebClientRequestException ex2 = new WebClientRequestException(ex, method, uri, new HttpHeaders());

        // Act and Assert
        assertThrows(RequestValidationException.class, () -> integrationExceptionHandler
                .webclientRequestExceptionHandler(ex2, new ServletWebRequest(new MockHttpServletRequest())));
        verify(aPIUtils).createProblemDetails(eq("Something went wrong, please check the log for more details"),
                eq("FAILURE"));
    }


    @Test
    void testGlobalException() {

        Exception ex = new Exception("error occurred");

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.globalExceptionHandler(ex,
                new ServletWebRequest(new MockHttpServletRequest()));
        assertThat(result).isNotNull();
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#globalExceptionHandler(Exception, WebRequest)}
     */
    @Test
    void testGlobalExceptionHandler() {
        // Arrange
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new RequestValidationException("An error occurred"));
        Exception ex = new Exception("foo");

        // Act and Assert
        assertThrows(RequestValidationException.class, () -> integrationExceptionHandler.globalExceptionHandler(ex,
                new ServletWebRequest(new MockHttpServletRequest())));
        verify(aPIUtils).createProblemDetails(eq("Something went wrong, please check the log for more details"),
                eq("FAILURE"));
    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#serviceNotAvailableExceptionHandler(ODSAdaptorException, WebRequest)}
     */
    @Test
    void testServiceNotAvailableExceptionHandler() {
        // Arrange
        ProblemDetails problemDetails = new ProblemDetails();
        problemDetails.setErrors(new ArrayList<>());
        problemDetails.setStatus("Status");
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(problemDetails);
        ODSAdaptorException ex = new ODSAdaptorException("An error occurred");
        ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());

        // Act
        ResponseEntity<ErrorResponse> actualServiceNotAvailableExceptionHandlerResult = integrationExceptionHandler
                .serviceNotAvailableExceptionHandler(ex, request);

        // Assert
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
        HttpStatusCode statusCode = actualServiceNotAvailableExceptionHandlerResult.getStatusCode();
        assertTrue(statusCode instanceof HttpStatus);
        assertEquals(500, actualServiceNotAvailableExceptionHandlerResult.getStatusCodeValue());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, statusCode);
        assertTrue(actualServiceNotAvailableExceptionHandlerResult.hasBody());
    }

    @Test
    void testServiceNotAvailableException2() {
        ODSAdaptorException ex = new ODSAdaptorException("An error occurred|404");
        ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());
        ResponseEntity<ErrorResponse> actualServiceNotAvailableExceptionHandlerResult = integrationExceptionHandler
                .serviceNotAvailableExceptionHandler(ex, request);
        assertNotNull(actualServiceNotAvailableExceptionHandlerResult);

    }

    /**
     * Method under test:
     * {@link IntegrationExceptionHandler#serviceNotAvailableExceptionHandler(ODSAdaptorException, WebRequest)}
     */
    @Test
    void testServiceNotAvailableException() {
        // Arrange
        when(aPIUtils.createProblemDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenThrow(new RequestValidationException("An error occurred"));
        ODSAdaptorException ex = new ODSAdaptorException("An error occurred");

        // Act and Assert
        assertThrows(RequestValidationException.class, () -> integrationExceptionHandler
                .serviceNotAvailableExceptionHandler(ex, new ServletWebRequest(new MockHttpServletRequest())));
        verify(aPIUtils).createProblemDetails(eq("An error occurred"), eq("FAILURE"));
    }

    @Test
    void testWebclientResponseException() {
        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(200, "message", null, null, null), null);
        assertThat(result).isNotNull();
        JSONObject responseBody = new JSONObject();
        responseBody.put("ErrorCode", "404");
        responseBody.put("ErrorDescription", "Resource not found");

        result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(404, "No Data Found", null,
                        responseBody.toString().getBytes(StandardCharsets.UTF_8), null), null);
        assertThat(result).isNotNull();

    }

    @Test
    void testWebclientResponseException503() {
        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(200, "message", null, null, null), null);
        assertThat(result).isNotNull();
        JSONObject responseBody = new JSONObject();
        responseBody.put("ErrorCode", "503");
        responseBody.put("ErrorDescription", "Resource not found");

        result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(503, "Service Unavailable", null,
                        responseBody.toString().getBytes(StandardCharsets.UTF_8), null), null);
        assertThat(result).isNotNull();
    }

    @Test
    void testWebclientResponseException503else() {

        JSONObject responseBody = new JSONObject();
        responseBody.put("ErrorCode", "503");
        responseBody.put("problemDetails", "Resource not found");

        ResponseEntity<ErrorResponse> result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(403, "Service Unavailable", null,
                        responseBody.toString().getBytes(StandardCharsets.UTF_8), null), null);
        assertThat(result).isNotNull();
        responseBody.clear();

        responseBody.put("error", "Resource not found");
        result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(403, "Service Unavailable", null,
                        responseBody.toString().getBytes(StandardCharsets.UTF_8), null), null);
        assertThat(result).isNotNull();
        responseBody.clear();

        responseBody.put("errors", new JSONArray());
        result = integrationExceptionHandler.webclientResponseExceptionHandler(
                new WebClientResponseException(403, "Service Unavailable", null,
                        responseBody.toString().getBytes(StandardCharsets.UTF_8), null), null);
        assertThat(result).isNotNull();
    }

}
