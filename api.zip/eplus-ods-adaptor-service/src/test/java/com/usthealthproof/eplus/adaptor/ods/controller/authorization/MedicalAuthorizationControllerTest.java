package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ContextConfiguration(classes = {MedicalAuthorizationController.class})
@ExtendWith(SpringExtension.class)
@WebMvcTest(MedicalAuthorizationController.class)
@DisabledInAotMode
class MedicalAuthorizationControllerTest {
    @MockitoBean
    private AuthorizationService authorizationService;

    @Autowired
    private MedicalAuthorizationController medicalAuthorizationController;
    @Autowired
    private MockMvc mockMvc;

    /**
     * Method under test:
     * {@link MedicalAuthorizationController#getAuthorizationDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationDetails() throws Exception {
        // Arrange
        when(authorizationService.getAuthorizationDetails(Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/medical")
                .param("authorizationId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationDetails_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationDetailsResponse response = new AuthorizationDetailsResponse();
        ResponseEntity<AuthorizationDetailsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationService.getMspAuthorizationDetails(authorizationId, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/medical")
                        .param("authorizationId", authorizationId)
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test:
     * {@link MedicalAuthorizationController#getAuthorizationLines(String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationLines() throws Exception {
        // Arrange
        when(authorizationService.getAuthorizationLines(Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/medical/authlines")
                .param("authorizationId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationLines_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationLinesResponseList response = new AuthorizationLinesResponseList();
        ResponseEntity<AuthorizationLinesResponseList> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationService.getMspAuthorizationLines(authorizationId, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/medical/authlines")
                        .param("authorizationId", authorizationId)
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    /**
     * Method under test:
     * {@link MedicalAuthorizationController#getAuthorizationLineDetails(String, String, String, String, HttpServletRequest)}
     */
    @Test
    void testGetAuthorizationLineDetails() throws Exception {
        // Arrange
        when(authorizationService.getAuthorizationLineDetails(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any(), Mockito.<String>any(), Mockito.<String>any())).thenReturn(null);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/auths/medical/authline")
                .param("authorizationId", "foo")
                .param("serviceLineId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(medicalAuthorizationController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationLineDetails_WithUserIdentities() throws Exception {
        String authorizationId = "123";
        String userIdentities = "user1";
        String accessToken = "token";

        AuthorizationLineDetailsResponse response = new AuthorizationLineDetailsResponse();
        ResponseEntity<AuthorizationLineDetailsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(authorizationService.getMspAuthorizationLineDetails(authorizationId, "1", null, null, userIdentities, accessToken))
                .thenReturn(responseEntity);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/auths/medical/authline")
                        .param("authorizationId", authorizationId)
                        .param("serviceLineId", "foo")
                        .header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
                        .header(OdsAdaptorServiceConstants.USERIDENTITIES_KEY, userIdentities)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}
