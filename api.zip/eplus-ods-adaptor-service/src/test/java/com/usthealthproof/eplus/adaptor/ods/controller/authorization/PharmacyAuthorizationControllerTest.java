package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.service.auth.PharmacyAuthService;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PharmacyAuthorizationController.class)
class PharmacyAuthorizationControllerTest {

    @MockitoBean
    private APIUtils apiUtils;
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private PharmacyAuthService pharmacyAuthService;
    @MockitoBean
    private Validator validator;

    @Test
    @WithMockUser(value = "user")
    void testGetAuthorizationLines() throws Exception {
        ResultActions response = mockMvc.perform(get("/v1/auths/pharmacy").param("authorizationId",
                "123456"));
        // then - verify the output
        response.andDo(print()).andExpect(status().isOk());
    }

}

