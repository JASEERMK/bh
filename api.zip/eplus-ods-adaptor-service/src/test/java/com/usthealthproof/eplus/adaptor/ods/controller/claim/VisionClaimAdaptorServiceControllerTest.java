package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.VisionClaimService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.aot.DisabledInAotMode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.mockito.Mockito.when;

@ContextConfiguration(classes = {VisionClaimAdaptorServiceController.class})
@ExtendWith(SpringExtension.class)
@DisabledInAotMode
class VisionClaimAdaptorServiceControllerTest {
    @Autowired
    private VisionClaimAdaptorServiceController visionClaimAdaptorServiceController;

    @MockitoBean
    private VisionClaimService visionClaimService;

    /**
     * Method under test:
     * {@link VisionClaimAdaptorServiceController#getVisionClaimDetails(String, HttpServletRequest)}
     */
    @Test
    void testGetVisionClaimDetails() throws Exception {
        // Arrange
        VisionClaimDetails visionClaimDetails = new VisionClaimDetails();
        visionClaimDetails.setAllowedAmount("10");
        visionClaimDetails.setBilledAmount("10");
        visionClaimDetails.setCheckCleared("Check Cleared");
        visionClaimDetails.setCheckNumber("42");
        visionClaimDetails.setCobAmount("10");
        visionClaimDetails.setCoinsuranceAmount("10");
        visionClaimDetails.setCopayAmount("10");
        visionClaimDetails.setCreatedBy("Jan 1, 2020 8:00am GMT+0100");
        visionClaimDetails.setDeductibleAmount("10");
        visionClaimDetails.setEftAccount("3");
        visionClaimDetails.setEftFlag("Eft Flag");
        visionClaimDetails.setEndDate("2020-03-01");
        visionClaimDetails.setEnteredDate("2020-03-01");
        visionClaimDetails.setErrors(new ArrayList<>());
        visionClaimDetails.setFromDate("2020-03-01");
        visionClaimDetails.setHttpStatusCode(1);
        visionClaimDetails.setInsureId("42");
        visionClaimDetails.setInsurerName("Doe");
        visionClaimDetails.setLastModifiedBy("Jan 1, 2020 9:00am GMT+0100");
        visionClaimDetails.setLocationId("42");
        visionClaimDetails.setLocationName("Location Name");
        visionClaimDetails.setMemberId("42");
        visionClaimDetails.setMemberName("Member Name");
        visionClaimDetails.setNetPaidAmount("10");
        visionClaimDetails.setNetworkId("42");
        visionClaimDetails.setNetworkName("Network Name");
        visionClaimDetails.setOriginalPaidAmount("10");
        visionClaimDetails.setOverMax("Over Max");
        visionClaimDetails.setPaidAmount("10");
        visionClaimDetails.setPayMember("Pay Member");
        visionClaimDetails.setPayeeId("42");
        visionClaimDetails.setPayeeName("Payee Name");
        visionClaimDetails.setPaymentAmount("10");
        visionClaimDetails.setPaymentDate("2020-03-01");
        visionClaimDetails.setPaymentNotes("Payment Notes");
        visionClaimDetails.setPaymentStatus("Payment Status");
        visionClaimDetails.setProviderId("42");
        visionClaimDetails.setProviderName("Provider Name");
        visionClaimDetails.setReceivedDate("2020-03-01");
        when(visionClaimService.getVisionClaimDetails(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(visionClaimDetails);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/vision")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(visionClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"memberId\":\"42\",\"insureId\":\"42\",\"insurerName\":\"Doe\",\"providerId\":\"42\",\"providerName\":\"Provider"
                                        + " Name\",\"fromDate\":\"2020-03-01\",\"endDate\":\"2020-03-01\",\"locationId\":\"42\",\"locationName\":\"Location"
                                        + " Name\",\"payeeId\":\"42\",\"payeeName\":\"Payee Name\",\"networkId\":\"42\",\"networkName\":\"Network Name\",\"receivedDate"
                                        + "\":\"2020-03-01\",\"enteredDate\":\"2020-03-01\",\"paymentDate\":\"2020-03-01\",\"checkNumber\":\"42\",\"paidAmount\""
                                        + ":\"10\",\"netPaidAmount\":\"10\",\"billedAmount\":\"10\",\"allowedAmount\":\"10\",\"deductibleAmount\":\"10\",\"copayAmount"
                                        + "\":\"10\",\"coinsuranceAmount\":\"10\",\"overMax\":\"Over Max\",\"cobAmount\":\"10\",\"originalPaidAmount\":\"10\","
                                        + "\"paymentStatus\":\"Payment Status\",\"payMember\":\"Pay Member\",\"paymentNotes\":\"Payment Notes\",\"paymentAmount"
                                        + "\":\"10\",\"eftFlag\":\"Eft Flag\",\"eftAccount\":\"3\",\"checkCleared\":\"Check Cleared\",\"createdBy\":\"Jan 1, 2020"
                                        + " 8:00am GMT+0100\",\"lastModifiedBy\":\"Jan 1, 2020 9:00am GMT+0100\",\"memberName\":\"Member Name\",\"httpStatusCode"
                                        + "\":1}"));
    }

    /**
     * Method under test:
     * {@link VisionClaimAdaptorServiceController#getVisionClaimLines(String, HttpServletRequest)}
     */
    @Test
    void testGetVisionClaimLines() throws Exception {
        // Arrange
        VisionClaimLinesResponse visionClaimLinesResponse = new VisionClaimLinesResponse();
        visionClaimLinesResponse.setErrors(new ArrayList<>());
        visionClaimLinesResponse.setHttpStatusCode(1);
        visionClaimLinesResponse.setVisionClaimLines(new ArrayList<>());
        when(visionClaimService.getVisionClaimLines(Mockito.<String>any(), Mockito.<String>any()))
                .thenReturn(visionClaimLinesResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/vision/claimlines")
                .param("claimHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(visionClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"httpStatusCode\":1}"));
    }

    /**
     * Method under test:
     * {@link VisionClaimAdaptorServiceController#getVisionClaimLineDetails(String, String, HttpServletRequest)}
     */
    @Test
    void testGetVisionClaimLineDetails() throws Exception {
        // Arrange
        VisionClaimLineDetailsResponse visionClaimLineDetailsResponse = new VisionClaimLineDetailsResponse();
        visionClaimLineDetailsResponse.setErrors(new ArrayList<>());
        visionClaimLineDetailsResponse.setHttpStatusCode(1);
        visionClaimLineDetailsResponse.setVisionClaimLineDetails(new ArrayList<>());
        when(visionClaimService.getVisionClaimLineDetails(Mockito.<String>any(), Mockito.<String>any(),
                Mockito.<String>any())).thenReturn(visionClaimLineDetailsResponse);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/v1/claims/vision/claimline")
                .param("claimHccId", "foo")
                .param("claimLineHccId", "foo");

        // Act and Assert
        MockMvcBuilders.standaloneSetup(visionClaimAdaptorServiceController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"httpStatusCode\":1}"));
    }
}
