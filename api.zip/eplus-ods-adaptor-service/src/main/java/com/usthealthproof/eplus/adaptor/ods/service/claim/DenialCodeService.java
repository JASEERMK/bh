package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.DenialCodeData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCodes;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DenialCodeService {

    @Autowired
    private DenialCodeData denialCodeData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.claimServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<DenialCodes> getMspDenialCodes(String claimNumber, String userIdentities,
                                                                      String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspDenialCodes() in the Service class for ClaimID: {}", claimNumber);

        DenialCodes denialCodes = new DenialCodes();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<DenialCodes>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<DenialCodes> completableFuture = denialCodeData.getDenialCodes(
                        MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath),
                        defaultContextPath + multiStateContextPath, claimNumber, state, lob, product, accessToken);

                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<DenialCodes> future : completableFutureList) {
                DenialCodes response = future.get(); // Blocking call to get result
                if (response != null && response.getDenialCodes() != null && !response.getDenialCodes().isEmpty()) {
                    denialCodes.setClaimId(response.getClaimId());
                    denialCodes.setDenialCodes(response.getDenialCodes());
                }
            }

            if (denialCodes.getDenialCodes() == null || denialCodes.getDenialCodes().isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                DenialCodes errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }

        } catch (Exception ex) {
            log.error("Exception occurred in getMspDenialCodes method: ", ex);
            throw ex;
        }
        log.info("Successfully generated denial Code Response");
        return new ResponseEntity<>(denialCodes, HttpStatus.OK);
    }

    public ResponseEntity<DenialCodes> getDenialCodes(String claimNumber, String accessToken)
            throws InterruptedException, ExecutionException {
        log.info("Inside getDenialCodes() in the Service class for ClaimID: {}", claimNumber);

        DenialCodes denialCodes = new DenialCodes();
        try {
            CompletableFuture<DenialCodes> completableFuture = denialCodeData.getDenialCodes(
                    MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState),
                    defaultContextPath + defaultState, claimNumber, null, null, null, accessToken);

            DenialCodes response = completableFuture.get(); // Blocking call to get result

            if (response.getDenialCodes() != null && !response.getDenialCodes().isEmpty()) {
                denialCodes.setClaimId(response.getClaimId());
                denialCodes.setDenialCodes(response.getDenialCodes());
            } else {
                handleDenialCodeErrors(response);
            }
        } catch (Exception ex) {
            log.error("Exception occurred in getDenialCodes method: ", ex);
            throw ex;
        }

        log.info("Successfully generated Denial code response");
        return new ResponseEntity<>(denialCodes, HttpStatus.OK);
    }

    public void handleDenialCodeErrors(DenialCodes response) throws ODSAdaptorException {
        List<String> denialCodeErrors = response.getErrors();
        if (denialCodeErrors != null && !denialCodeErrors.isEmpty()) {
            log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
            String exceptionMessage = denialCodeErrors.get(0) == null || StringUtils.isBlank(denialCodeErrors.get(0))
                    ? OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500"
                    : denialCodeErrors.get(0) + "|" + response.getHttpStatusCode();
            throw new ODSAdaptorException(exceptionMessage);
        } else {
            throw new ODSAdaptorException(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500");
        }
    }
}
