package com.usthealthproof.eplus.adaptor.ods.model.careGaps;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class containing Care Gaps details of Member")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "careGapsList", "problemDetails", "requestId" })
public class CareGapsDetails implements Serializable {

	private static final long serialVersionUID = 1281928897938784983L;

	@Schema(description = "Collection of Member's Care Gaps")
	@JsonProperty("careGapsList")
	private List<CareGapsDetailsList> careGapsDetailsList;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}