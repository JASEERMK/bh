package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding the Authorization search results fields")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AuthorizationSearchResponse {

	@Schema(description = "Authorization ID")
	private String authorizationId;
	@Schema(description = "Date auth was requested MM/DD/YYYY")
	private String authRequestedDate;
	@Schema(description = "Date of Service, available only for Medical Authorization")
	private String dateOfService;
	@Schema(description = "Claim Type, available only for Medical Authorization")
	private String claimType;
	@Schema(description = "Requesting Provider Name, available only for Member Search of Medical Authorization")
	private String requestingProviderName;
	@Schema(description = "Performing Provider Name, available only for Medical Authorization")
	private String performingProviderName;
	@Schema(description = "Status of the authorization")
	private String status;
	@Schema(description = "Member Identification Number, available only for Medical Authorization")
	private String memberNumber;
//	Specific for Pharmacy Authorization Search
	@Schema(description = "Reason for the Authorization, available only for Pharmacy Authorization")
	private String authReason;
	@Schema(description = "Name of drug requested, available only for Pharmacy Authorization")
	private String drugName;
	@Schema(description = "Request Type, available only for Pharmacy Authorization")
	private String requestType;
	@Schema(description = "Pharmacy Id, available only for Pharmacy Authorization")
	private String rxId;

}
