package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class DentalAuthorizationResponseMapper {

    public void dentalAuthDetailsResponseMapper(DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse, CompletableFuture<DentalAuthorizationDetailsResponse> completableFuture) throws InterruptedException, ExecutionException {
        log.info("Inside dentalAuthDetailsResponseMapper()");

        dentalAuthorizationDetailsResponse.setAuthorizationId(completableFuture.get().getAuthorizationId());
        dentalAuthorizationDetailsResponse.setMemberId(completableFuture.get().getMemberId());
        dentalAuthorizationDetailsResponse.setRequestingProviderId(completableFuture.get().getRequestingProviderId());
        dentalAuthorizationDetailsResponse.setRequestingProviderName(completableFuture.get().getRequestingProviderName());
        dentalAuthorizationDetailsResponse.setStatus(completableFuture.get().getStatus());
        dentalAuthorizationDetailsResponse.setRequestDate(completableFuture.get().getRequestDate());
        dentalAuthorizationDetailsResponse.setAuthorizationReason(completableFuture.get().getAuthorizationReason());
        dentalAuthorizationDetailsResponse.setDeterminationDate(completableFuture.get().getDeterminationDate());
        dentalAuthorizationDetailsResponse
                .setDeterminationTurnAroundTime(completableFuture.get().getDeterminationTurnAroundTime());
        dentalAuthorizationDetailsResponse.setStatusReason(completableFuture.get().getStatusReason());
        dentalAuthorizationDetailsResponse.setRequestor(completableFuture.get().getRequestor());
        dentalAuthorizationDetailsResponse.setPerformingProviderId(completableFuture.get().getPerformingProviderId());
        dentalAuthorizationDetailsResponse.setPerformingProviderName(completableFuture.get().getPerformingProviderName());
        dentalAuthorizationDetailsResponse.setUrgency(completableFuture.get().getUrgency());
        dentalAuthorizationDetailsResponse.setAuthorizationType(completableFuture.get().getAuthorizationType());
        dentalAuthorizationDetailsResponse.setServiceType(completableFuture.get().getServiceType());
        dentalAuthorizationDetailsResponse.setSource(completableFuture.get().getSource());
        dentalAuthorizationDetailsResponse.setDeterminationDueDate(completableFuture.get().getDeterminationDueDate());
        dentalAuthorizationDetailsResponse.setAuthorizationOwner(completableFuture.get().getAuthorizationOwner());
        dentalAuthorizationDetailsResponse.setAuthorizationAge(completableFuture.get().getAuthorizationAge());
        dentalAuthorizationDetailsResponse.setAuthorizationComments(completableFuture.get().getAuthorizationComments());
        dentalAuthorizationDetailsResponse.setServiceComments(completableFuture.get().getServiceComments());
        dentalAuthorizationDetailsResponse.setServiceExceptionComments(completableFuture.get().getServiceExceptionComments());
    }

    public void dentalAuthLineDetailsResponseMapper(DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse, CompletableFuture<DentalAuthorizationLineDetailsResponse> completableFuture) throws InterruptedException, ExecutionException {
        log.info("Inside dentalAuthLineDetailsResponseMapper()");

        dentalAuthorizationLineDetailsResponse.setServiceLineId(completableFuture.get().getServiceLineId());
        dentalAuthorizationLineDetailsResponse.setServiceCode(completableFuture.get().getServiceCode());
        dentalAuthorizationLineDetailsResponse.setToothNo(completableFuture.get().getToothNo());
        dentalAuthorizationLineDetailsResponse.setPlaceOfService(completableFuture.get().getPlaceOfService());
        dentalAuthorizationLineDetailsResponse.setUnits(completableFuture.get().getUnits());
        dentalAuthorizationLineDetailsResponse.setUnitType(completableFuture.get().getUnitType());
        dentalAuthorizationLineDetailsResponse.setServiceStartDate(completableFuture.get().getServiceStartDate());
        dentalAuthorizationLineDetailsResponse.setServiceEndDate(completableFuture.get().getServiceEndDate());
        dentalAuthorizationLineDetailsResponse.setDeterminationStatus(completableFuture.get().getDeterminationStatus());
        dentalAuthorizationLineDetailsResponse.setStatusReason(completableFuture.get().getStatusReason());
        dentalAuthorizationLineDetailsResponse.setAuthorizationComments(completableFuture.get().getAuthorizationComments());
        dentalAuthorizationLineDetailsResponse.setServiceComments(completableFuture.get().getServiceComments());
        dentalAuthorizationLineDetailsResponse.setServiceExceptionComments(completableFuture.get().getServiceExceptionComments());
    }
}
