package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Medical Authorization Services")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/auths")
@SecurityRequirement(name = "OdsAdaptorService")
public class MedicalAuthorizationController {


    @Autowired
    private AuthorizationService authorizationService;

    /**
     * Adaptor service to retrieve authorization details for the given
     * AuthorizationId
     *
     * @param authorizationId
     * @return AuthorizationDetailsResponse
     * @throws Exception
     */

    @Operation(summary = "Medical Authorization Details", description = "Details regarding medical authorizations, can be accessed through the specified service. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Medical Authorization Details", content = {
                    @Content(schema = @Schema(implementation = AuthorizationDetailsResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/medical", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationDetailsResponse> getAuthorizationDetails(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationDetails() of MedicalAuthorizationController");
        log.debug("Inside getAuthorizationDetails() of MedicalAuthorizationController and the requests: Authorization ID: {}", authorizationId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationService.getMspAuthorizationDetails(authorizationId, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationService.getAuthorizationDetails(authorizationId, accessToken);
        }
    }


    /**
     * Adaptor service to retrieve authorization lines for the given
     * AuthorizationId
     *
     * @param authorizationId
     * @return AuthorizationLinesResponseList
     */

    @Operation(summary = "Medical Authorization Lines", description = "Service Lines information’s regarding medical authorizations, can be accessed through the specified service. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Medical Authorization Lines", content = {
                    @Content(schema = @Schema(implementation = AuthorizationLinesResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/medical/authlines", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationLinesResponseList> getAuthorizationLines(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationLines() of MedicalAuthorizationController");
        log.debug("Inside getAuthorizationLines() of MedicalAuthorizationController and the requests: Authorization ID: {}", authorizationId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationService.getMspAuthorizationLines(authorizationId, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationService.getAuthorizationLines(authorizationId, accessToken);
        }
    }

    /**
     * Adaptor service to retrieve authorization line details for the given
     * AuthorizationId and ServiceLineId
     *
     * @param authorizationId
     * @param serviceLineId
     * @return AuthorizationLineDetailsResponse
     */
    @Operation(summary = "Medical Authorization Line Details", description = "Service Line details regarding medical authorizations, can be accessed through the specified service. Authorization ID and Authorization Line ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Medical Authorization Line Details", content = {
                    @Content(schema = @Schema(implementation = AuthorizationLineDetailsResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/medical/authline", produces = { MediaType.APPLICATION_JSON_VALUE })

    @ResponseBody
    public ResponseEntity<AuthorizationLineDetailsResponse> getAuthorizationLineDetails(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            @Parameter(description = "Service Line Id", required = true) @RequestParam(value = "serviceLineId") String serviceLineId,
            @Parameter(description = "Service Start Date", required = true, hidden = true) @RequestParam(value = "serviceStartDate", required = false) String serviceStartDate,
            @Parameter(description = "Procedure Code", required = true, hidden = true) @RequestParam(value = "procedureCode", required = false) String procedureCode,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationLineDetails() of MedicalAuthorizationController");
        log.debug("Inside getAuthorizationLineDetails() of MedicalAuthorizationController and the requests: Authorization ID:- {} and ServiceLineId:- {}",
                authorizationId, serviceLineId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationService.getMspAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationService.getAuthorizationLineDetails(authorizationId, serviceLineId, serviceStartDate, procedureCode, accessToken);
        }
    }
}
