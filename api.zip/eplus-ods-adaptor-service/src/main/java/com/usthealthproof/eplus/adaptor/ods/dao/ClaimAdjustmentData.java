package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ClaimAdjustmentData {

	public static final String CLAIM_ADJUSTMENT = "/v1/adjustment/claim";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async("asyncExecutor")
	public CompletableFuture<ClaimAdjustmentResponse> getClaimAdjustmentFields(String serviceUrl, String contextPath, String claimNumber,
			String claimFactKey, String previousClaimFactKey, String state, String lob, String product, String accessToken)
			throws Exception {
		log.info("Inside getClaimAdjustmentFields() of ClaimAdjustmentData");
		log.debug("Inside getClaimAdjustmentFields() of ClaimAdjustmentData class and the requests are contextPath: {} & "
						+ "accessToken: {}", contextPath, accessToken);

		ClaimAdjustmentResponse claimAdjustmentResponse = new ClaimAdjustmentResponse();
		String url = serviceUrl + contextPath + CLAIM_ADJUSTMENT;
		log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, url);
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + CLAIM_ADJUSTMENT);
				claimAdjustmentResponse = webClientGatewayRoute.get().uri(uriBuilder -> uriBuilder.path(contextPath + CLAIM_ADJUSTMENT)
								.queryParam("claimNumber", claimNumber).queryParamIfPresent("claimFactKey", Optional.ofNullable(claimFactKey))
								.queryParamIfPresent("previousClaimFactKey", Optional.ofNullable(previousClaimFactKey))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state)).queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()).header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
						.retrieve().bodyToMono(ClaimAdjustmentResponse.class).block();
			}
			else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + CLAIM_ADJUSTMENT)
						.queryParam("claimNumber", claimNumber).queryParamIfPresent("claimFactKey", Optional.ofNullable(claimFactKey))
						.queryParamIfPresent("previousClaimFactKey", Optional.ofNullable(previousClaimFactKey))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state)).queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				claimAdjustmentResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(ClaimAdjustmentResponse.class).block();
			}

		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			claimAdjustmentResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			claimAdjustmentResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getClaimAdjustmentFields() completed");
		return CompletableFuture.completedFuture(claimAdjustmentResponse);
	}
}
