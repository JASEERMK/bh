
package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "authorizationId", "memberId", "determinationStatus", "requestedDate", "authorizationReason", "requestor",
		"requestingProviderName", "requestingProviderId", "authOwner", "supplierName", "supplierId" })
@Data
@Schema(description = "Object for holding the Authorization details results fields")
public class AuthorizationDetailsResponse implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "HCC ID of the authorization")
	@JsonProperty("authorizationId")
	private String authorizationId;

	@Schema(description = "HCC ID of the Member")
	@JsonProperty("memberId")
	private String memberId;

	@Schema(description = "Overall determination for the auth. i.e., Pending, Approved, Denied, Partially Approved")
	@JsonProperty("determinationStatus")
	private String determinationStatus;

	@Schema(description = "Date auth was requested MM/DD/YYYY")
	@JsonProperty("requestedDate")
	private String requestedDate;

	@Schema(description = "Reason for the authorization")
	@JsonProperty("authorizationReason")
	private String authorizationReason;

	@Schema(description = "Who is requesting the authorization, i.e., Provider, Member, Member Beneficiary")
	@JsonProperty("requestor")
	private String requestor;

	@Schema(description = "Name of provider requesting the authorization")
	@JsonProperty("requestingProviderName")
	private String requestingProviderName;

	@Schema(description = "ID of provider requesting the authorization")
	@JsonProperty("requestingProviderId")
	private String requestingProviderId;

	@Schema(description = "Staff member responsible for the authorization")
	@JsonProperty("authOwner")
	private String authOwner;

	@Schema(description = "Name of supplier")
	@JsonProperty("supplierName")
	private String supplierName;

	@Schema(description = "ID of supplier")
	@JsonProperty("supplierId")
	private String supplierId;

	@Schema(description = "Facility Provider Name")
	private String facilityProviderName;

	@Schema(description = "Admitting Provider Name")
	private String admittingProviderName;

	@Schema(description = "Performing Provider Name")
	private String performingProviderName;

	@Schema(description = "Source")
	private String source;

	@Schema(description = "To hold the error", hidden = true)
	private String error;

	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
