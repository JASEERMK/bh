package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.ExternalMessageClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessagesResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@Slf4j
public class ExternalMessageClaimService {

	@Autowired
	private ExternalMessageClaimData externalMessageClaimData;

	@Autowired
	private DaoUtil daoUtil;

	@Value("${service.name.claimServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	@Value("${service.uri.defaultState}")
	private String defaultState;

	public MedicalExternalMessagesResponse getExternalmessageDetails(String claimHccId, String claimLineHccId, String claimFactKey, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getExternalmessageDetails() of ExternalMessageClaimService class");

		MedicalExternalMessagesResponse medicalExternalMessagesResponse = new MedicalExternalMessagesResponse();
		try {
			CompletableFuture<MedicalExternalMessagesResponse> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = externalMessageClaimData.getExternalMessageDetails(serviceUrl, defaultContextPath + defaultState,
					claimHccId, claimLineHccId, claimFactKey, null, null, null, accessToken);
			List<MedicalExternalMessage> medicalExternalMessageList = new ArrayList<>();
			if (completableFuture.get().getExternalMessages() != null
					&& !completableFuture.get().getExternalMessages().isEmpty()) {
				medicalExternalMessageList.addAll(completableFuture.get().getExternalMessages());
			} else {
				List<String> externalClaimErrors = completableFuture.get().getErrors();
				if (externalClaimErrors != null && !externalClaimErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(externalClaimErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = externalClaimErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
			medicalExternalMessagesResponse.setExternalMessages(medicalExternalMessageList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return medicalExternalMessagesResponse;
	}

	public MedicalExternalMessagesResponse getMspExternalmessageDetails(String claimHccId, String claimLineHccId, String claimFactKey, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspExternalmessageDetails() of ExternalMessageClaimService class");

		MedicalExternalMessagesResponse medicalExternalMessagesResponse = new MedicalExternalMessagesResponse();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<MedicalExternalMessagesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<MedicalExternalMessagesResponse> completableFuture = null;
				completableFuture = externalMessageClaimData.getExternalMessageDetails(serviceUrl, defaultContextPath + multiStateContextPath,
						claimHccId, claimLineHccId, claimFactKey, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			List<MedicalExternalMessage> medicalExternalMessageList = new ArrayList<>();
			for (CompletableFuture<MedicalExternalMessagesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getExternalMessages() != null
						&& !completableFuture.get().getExternalMessages().isEmpty()) {
					medicalExternalMessageList.addAll(completableFuture.get().getExternalMessages());
				}
			}
			if (null == medicalExternalMessageList || medicalExternalMessageList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				MedicalExternalMessagesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
				medicalExternalMessagesResponse.setExternalMessages(medicalExternalMessageList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return medicalExternalMessagesResponse;
	}
}
