package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetails;
import com.usthealthproof.eplus.adaptor.ods.service.CareGapsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Member Care Gaps")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/member")
@SecurityRequirement(name = "OdsAdaptorService")
public class CareGapsAdaptorServiceController {

	@Autowired
	private CareGapsService careGapsService;

	/**
	 * 1. Adaptor service for Care Gap service
	 *
	 * @param memberId
	 * @param httpServletRequest
	 * @return CareGapsDetails
	 * @throws Exception
	 */

	@Operation(summary = "Retrieves member's care gap details", description = "The Member Care Gap Service obtains comprehensive data regarding the gaps in care for a particular member, identified by their Member ID. The only necessary field is Member ID.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of member's care gaps details", content = {
					@Content(schema = @Schema(implementation = CareGapsDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = { "/caregap/care/{memberId}", "/care/caregap/{memberId}" }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<CareGapsDetails> getCareGapsDetails(
			@Parameter(description = "Member ID", required = true) @PathVariable("memberId") String memberId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getCareGapsDetails() of CareGapsAdaptorServiceController");
		log.debug("Member Care Gaps service request received with memberId: {}", memberId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return careGapsService.getMspCareGapsDetails(memberId, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return careGapsService.getCareGapsDetails(memberId, accessToken);
		}
	}
}