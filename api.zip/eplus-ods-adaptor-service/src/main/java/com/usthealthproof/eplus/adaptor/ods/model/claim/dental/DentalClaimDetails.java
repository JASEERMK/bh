package com.usthealthproof.eplus.adaptor.ods.model.claim.dental;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class containing dental claim details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DentalClaimDetails implements Serializable {

	private static final long serialVersionUID = -427889981973809232L;

	@Schema(description = "Member Key")
	private String memberId;

	@Schema(description = "Pay Member")
	private String payMember;

	@Schema(description = "Insure ID")
	private String insurerId;

	@Schema(description = "Insurer name")
	private String insurerName;

	@Schema(description = "Provider Id")
	private String providerId;

	@Schema(description = "Provider")
	private String providerName;

	@Schema(description = "Service Start Date of the dental claim")
	private String serviceStartDate;

	@Schema(description = "Service End Date of the dental claim")
	private String serviceEndDate;

	@Schema(description = "Location ID")
	private String locationId;

	@Schema(description = "Location Name")
	private String locationName;

	@Schema(description = "Payee other ID")
	private String payeeOtherId;

	@Schema(description = "Payee other Name")
	private String payeeOtherName;

	@Schema(description = "Network ID")
	private String networkId;

	@Schema(description = "Network Name")
	private String networkName;

	@Schema(description = "Claim Received Date")
	private String claimReceivedDate;

	@Schema(description = "Claim Entered Date")
	private String claimEnteredDate;

	@Schema(description = "Missing Teeth")
	private String missingTeeth;

	@Schema(description = "Date on which claim was Paid")
	private String paymentDate;

	@Schema(description = "payment number for claim")
	private String paymentNumber;

	@Schema(description = "Net Paid Amount")
	private String netPaidAmount;

	@Schema(description = "Billed Amount")
	private String billedAmount;

	@Schema(description = "Allowed Amount")
	private String allowed;

	@Schema(description = "Amount on check")
	private String paidAmount;

	@Schema(description = "Deductible")
	private String deductible;

	@Schema(description = "Copay")
	private String coPay;

	@Schema(description = "Coinsurance")
	private String coinsuranceAmount;

	@Schema(description = "Over Max")
	private String overMax;

	@Schema(description = "Coordination of benefit Collected")
	private String cobAmount;

	@Schema(description = "Check Status")
	private String paymentStatus;

	@Schema(description = "Payment Notes")
	private String paymentNotes;

	@Schema(description = "Indicator if EFT was used")
	private String eftFlag;

	@Schema(description = "Account number if EFT was used")
	private String eftAccount;

	@Schema(description = "If check is cleared or not")
	private String checkCleared;

	@Schema(description = "Created by")
	private String createdBy;

	@Schema(description = "Last Modified By")
	private String lastModifiedBy;

//	Added as part of cpb3134
	@Schema(description = "Member Name")
	private String memberName;

	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;

	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
