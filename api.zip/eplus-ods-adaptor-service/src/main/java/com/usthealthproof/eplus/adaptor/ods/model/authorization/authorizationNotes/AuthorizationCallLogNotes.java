package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(value = Include.NON_EMPTY)
@Schema(description = "Object for holding the Authorization Call Log Notes")
public class AuthorizationCallLogNotes implements Serializable {

	private static final long serialVersionUID = 5257199160691849897L;

	@Schema(description = "Authorization Id")
	private String authorizationId;

	@Schema(description = "Contact Date")
	private String contactDate;

	@Schema(description = "Call Type")
	private String callType;

	@Schema(description = "CallComment")
	private String callComment;
}
