package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PharmacyAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.service.auth.PharmacyAuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Pharmacy Authorization Services")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/auths")
@SecurityRequirement(name = "OdsAdaptorService")
public class PharmacyAuthorizationController {

    @Autowired
    private PharmacyAuthService pharmacyAuthService;

    /**
     * Service retrieves pharmacy authorization details for the given
     * AuthorizationId
     *
     * @param authorizationId
     * @return AuthorizationDetailsResponse
     */
    @Operation(summary = "Pharmacy Authorization Details", description = "An external vendor system, such as MedHok, provides the data for the pharmacy authorization.\n" +
            "Using this service, with an authorization ID or RX ID (MedHok Specific), it can request information about a pharmacy authorization. To process the request, you must provide either an authorization ID or an RX ID. If MedHok is the external system, we must provide the RX ID as a request in order to obtain the pharmacy details.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Pharmacy Authorization Details", content = {
                    @Content(schema = @Schema(implementation = PharmacyAuthorizationDetailsResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/pharmacy", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<PharmacyAuthorizationDetailsResponse> getPharmacyAuthorizationDetails(
            @Parameter(description = "Authorization ID", required = false) @RequestParam(value = "authorizationId", required = false) String authorizationId,
            @Parameter(description = "RxId", required = false) @RequestParam(value = "rxId", required = false) String rxId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getPharmacyAuthorizationDetails() of PharmacyAuthorizationController");
        log.debug("Inside getPharmacyAuthorizationDetails() of PharmacyAuthorizationController and the requests: AuthorizationID: {}, RxId {}", authorizationId, rxId);

        PharmacyAuthorizationDetailsResponse pharmacyAuthorizationDetails = pharmacyAuthService.getPharmacyAuthorizationDetails(authorizationId, httpServletRequest, rxId);
        log.info("Successfully generated dental-authorization-details response !!!");
        return new ResponseEntity<>(pharmacyAuthorizationDetails, HttpStatus.OK);
    }
}
