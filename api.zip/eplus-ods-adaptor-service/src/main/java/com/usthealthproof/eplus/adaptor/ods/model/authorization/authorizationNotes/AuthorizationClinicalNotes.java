package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(value = Include.NON_EMPTY)
@Schema(description = "Object for holding the Authorization Clinical Notes")
public class AuthorizationClinicalNotes implements Serializable {

	private static final long serialVersionUID = -784844729297636386L;

	@Schema(description = "Authorization Id")
	private String authorizationId;

	@Schema(description = "Initiated Date")
	private String initiatedDate;

	@Schema(description = "Initial Review Note")
	private String initialReviewNote;

	@Schema(description = "Decision Rationale Note")
	private String decisionRationaleNote;
}
