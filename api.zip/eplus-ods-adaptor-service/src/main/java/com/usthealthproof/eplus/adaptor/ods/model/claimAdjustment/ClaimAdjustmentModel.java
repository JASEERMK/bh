package com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Wrapper class containing claim adjustment related fields")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimAdjustmentModel implements Serializable {

	private static final long serialVersionUID = -2739567740734398496L;

	@Schema(description = "Adjusted date")
	private String adjustedDate;

	@Schema(description = "Name of adjusted field")
	private String adjustedFieldName;

	@Schema(description = "Value before adjustment")
	private String before;

	@Schema(description = "Value after adjustment")
	private String after;

	@Schema(description = "Code related to the adjustment performed")
	private String adjustmentCode;

	@Schema(description = "Reason for adjustment")
	private String reasonForAdjustment;

	@Schema(description = "Last updated date")
	private String lastUpdated;

}
