package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalAuthorizationResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class DentalAuthService {

    @Autowired
    private AuthorizationData authorizationData;

    @Autowired
    private DaoUtil daoUtil;

    @Autowired
    DentalAuthorizationResponseMapper dentalAuthorizationResponseMapper;

    @Value("${service.name.authorizationServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public DentalAuthorizationDetailsResponse getDentalAuthorizationDetails(String authorizationId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getDentalAuthorizationDetails() of DentalAuthService class");

        DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse = new DentalAuthorizationDetailsResponse();
        try {
            CompletableFuture<DentalAuthorizationDetailsResponse> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getDentalAuthorizationDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationId, null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getAuthorizationId())) {
                dentalAuthorizationResponseMapper.dentalAuthDetailsResponseMapper(dentalAuthorizationDetailsResponse, completableFuture);
            }
            else {
                List<String> dentalAuthErrors = completableFuture.get().getErrors();
                if (dentalAuthErrors != null && !dentalAuthErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(dentalAuthErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = dentalAuthErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationDetailsResponse;
    }


    public DentalAuthorizationLinesResponseList getDentalAuthorizationLines(String authorizationId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getDentalAuthorizationLines() of DentalAuthService class");

        DentalAuthorizationLinesResponseList dentalAuthorizationLinesResponseList = new DentalAuthorizationLinesResponseList();
        try {
            CompletableFuture<DentalAuthorizationLinesResponseList> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getDentalAuthorizationLines(serviceUrl, defaultContextPath + defaultState, authorizationId,
                    null, null, null, accessToken);

            List<DentalAuthorizationLinesResponse> dentalAuthorizationLinesResponses = new ArrayList<>();
            if (completableFuture.get().getDentalAuthorizationLines() != null
                    && !completableFuture.get().getDentalAuthorizationLines().isEmpty()) {
                dentalAuthorizationLinesResponses.addAll(completableFuture.get().getDentalAuthorizationLines());
            } else {
                List<String> dentalAuthErrors = completableFuture.get().getErrors();
                if (dentalAuthErrors != null && !dentalAuthErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage;
                    if (StringUtils.isBlank(dentalAuthErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = dentalAuthErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
            dentalAuthorizationLinesResponseList.setDentalAuthorizationLines(dentalAuthorizationLinesResponses);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationLinesResponseList;
    }

    public DentalAuthorizationLineDetailsResponse getDentalAuthorizationLineDetails(String authorizationId, String serviceLineId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getDentalAuthorizationLineDetails() of DentalAuthService class");

        DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse = new DentalAuthorizationLineDetailsResponse();
        try {
            CompletableFuture<DentalAuthorizationLineDetailsResponse> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getDentalAuthorizationLineDetails(serviceUrl, defaultContextPath + defaultState, authorizationId, serviceLineId,
                   null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getServiceLineId())) {
                dentalAuthorizationResponseMapper.dentalAuthLineDetailsResponseMapper(dentalAuthorizationLineDetailsResponse, completableFuture);
            } else {
                List<String> dentalAuthErrors = completableFuture.get().getErrors();
                if (dentalAuthErrors != null && !dentalAuthErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage;
                    if (StringUtils.isBlank(dentalAuthErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = dentalAuthErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationLineDetailsResponse;
    }

    public DentalAuthorizationDetailsResponse getMspDentalAuthorizationDetails(String authorizationId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
        log.info("Inside getMspDentalAuthorizationDetails() of DentalAuthService class");

        DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse = new DentalAuthorizationDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<DentalAuthorizationDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<DentalAuthorizationDetailsResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = authorizationData.getDentalAuthorizationDetails(serviceUrl, defaultContextPath + multiStateContextPath,
                        authorizationId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<DentalAuthorizationDetailsResponse> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getAuthorizationId())) {
                    dentalAuthorizationResponseMapper.dentalAuthDetailsResponseMapper(dentalAuthorizationDetailsResponse, completableFuture);
                }
            }
            if (null != dentalAuthorizationDetailsResponse && StringUtils.isAllBlank(
                    dentalAuthorizationDetailsResponse.getAuthorizationId(), dentalAuthorizationDetailsResponse.getMemberId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                DentalAuthorizationDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(), errorResponse.getErrors().get(0), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationDetailsResponse;
    }

    public DentalAuthorizationLinesResponseList getMspDentalAuthorizationLines(String authorizationId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
        log.info("Inside getMspDentalAuthorizationLines() of DentalAuthService class");

        DentalAuthorizationLinesResponseList dentalAuthorizationLinesResponseList = new DentalAuthorizationLinesResponseList();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<DentalAuthorizationLinesResponseList>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                CompletableFuture<DentalAuthorizationLinesResponseList> completableFuture = null;
                completableFuture = authorizationData.getDentalAuthorizationLines(serviceUrl, defaultContextPath + multiStateContextPath, authorizationId,
                        state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<DentalAuthorizationLinesResponse> dentalAuthorizationLinesResponses = new ArrayList<>();
            for (CompletableFuture<DentalAuthorizationLinesResponseList> completableFuture : completableFutureList) {
                if (completableFuture.get().getDentalAuthorizationLines() != null
                        && !completableFuture.get().getDentalAuthorizationLines().isEmpty()) {
                    dentalAuthorizationLinesResponses.addAll(completableFuture.get().getDentalAuthorizationLines());
                }
            }
            if (null == dentalAuthorizationLinesResponses || dentalAuthorizationLinesResponses.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                DentalAuthorizationLinesResponseList errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
                dentalAuthorizationLinesResponseList.setDentalAuthorizationLines(dentalAuthorizationLinesResponses);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationLinesResponseList;
    }

    public DentalAuthorizationLineDetailsResponse getMspDentalAuthorizationLineDetails(String authorizationId, String serviceLineId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
        log.info("Inside getMspDentalAuthorizationLineDetails() of DentalAuthService class");

        DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse = new DentalAuthorizationLineDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<DentalAuthorizationLineDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                CompletableFuture<DentalAuthorizationLineDetailsResponse> completableFuture = null;
                completableFuture = authorizationData.getDentalAuthorizationLineDetails(serviceUrl, defaultContextPath + multiStateContextPath, authorizationId, serviceLineId,
                        state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<DentalAuthorizationLineDetailsResponse> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getServiceLineId())) {
                    dentalAuthorizationResponseMapper.dentalAuthLineDetailsResponseMapper(dentalAuthorizationLineDetailsResponse, completableFuture);
                }
            }
            if (null != dentalAuthorizationLineDetailsResponse
                    && StringUtils.isAllBlank(dentalAuthorizationLineDetailsResponse.getServiceLineId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                DentalAuthorizationLineDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return dentalAuthorizationLineDetailsResponse;
    }

}
