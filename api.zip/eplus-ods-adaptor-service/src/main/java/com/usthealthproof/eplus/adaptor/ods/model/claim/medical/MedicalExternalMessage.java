package com.usthealthproof.eplus.adaptor.ods.model.claim.medical;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class for medical External Message level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MedicalExternalMessage implements Serializable {

	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "Action of the external message")
	private String action;
	@Schema(description = "Message code of the external message")
	private String messageCode;
	@Schema(description = "Description of the external message")
	private String description;
	@Schema(description = "Source of the external message")
	private String source;
//	Added as part of CPB-3167
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;
}
