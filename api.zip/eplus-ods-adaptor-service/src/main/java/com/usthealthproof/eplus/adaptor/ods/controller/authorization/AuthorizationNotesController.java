package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationNotesNonMspService;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationNotesMspService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Authorization Notes Services")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/auths")
@SecurityRequirement(name = "OdsAdaptorService")
public class AuthorizationNotesController {

    @Autowired
    private AuthorizationNotesMspService authorizationNotesMspService;

    @Autowired
    private AuthorizationNotesNonMspService authorizationNotesNonMspService;
    /**
     * Adaptor service for Authorization Clinical Review Notes service
     *
     * @param authorizationId
     * @return AuthorizationNotesClinicalResponse
     */
    @Operation(summary = "Clinical Authorization Notes", description = "Notes that have a review of the care, received by a specific patient or family, performed because of interest in the welfare of this patient or family. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "List of Authorization Clinical Notes", content = {
                    @Content(schema = @Schema(implementation = AuthorizationNotesResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/notes/clinical", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationNotesResponse> getAuthorizationNotesClinicalReview(
            @Parameter(description = "Authorization ID") @RequestParam(value = "authorizationId", required = false) String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationNotesClinicalReview() of AuthorizationNotesController");
        log.debug("Inside getAuthorizationNotesClinicalReview() of AuthorizationNotesController and the requests: AuthorizationID: {}",
                authorizationId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationNotesMspService.getMspAuthorizationNotesClinicalReview(authorizationId, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationNotesNonMspService.getAuthorizationNotesClinicalReview(authorizationId, accessToken);
        }
    }

    /**
     * Adaptor service for Authorization Call Logs Notes service
     *
     * @param authorizationId
     * @return AuthorizationNotesClinicalResponse
     */
    @Operation(summary = "Call Logs Authorization Notes", description = "Call Log Authorization Notes has Call History details like the Provider details, when and at what time the call was made. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = " List of Authorization Call Log Notes", content = {
                    @Content(schema = @Schema(implementation = AuthorizationNotesResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/notes/calllogs", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationNotesResponse> getAuthorizationCallLogsNotes(
            @Parameter(description = "Authorization ID") @RequestParam(value = "authorizationId", required = false) String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationCallLogsNotes() of AuthorizationNotesController");
        log.debug("Inside getAuthorizationCallLogsNotes() of AuthorizationNotesController and the requests: AuthorizationID: {}", authorizationId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationNotesMspService.getMspAuthorizationCallLogsNotes(authorizationId, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationNotesNonMspService.getAuthorizationCallLogsNotes(authorizationId, accessToken);
        }
    }

    /**
     * Adaptor service for Authorization Notes service
     *
     * @param authorizationId
     * @return AuthorizationNotesClinicalResponse
     */
    @Operation(summary = "Authorization Notes", description = "Authorization Notes has the information of the Authorization details (Prior Auth/ Post Auth), number of visits details. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "List of Authorization Notes", content = {
                    @Content(schema = @Schema(implementation = AuthorizationNotesResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/notes/authnotes", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationNotesResponse> getAuthorizationNotes(
            @Parameter(description = "Authorization ID") @RequestParam(value = "authorizationId", required = false) String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getAuthorizationNotes() of AuthorizationNotesController");
        log.debug("Inside getAuthorizationNotes() of AuthorizationNotesController and the requests: AuthorizationID: {}", authorizationId);
        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return authorizationNotesMspService.getMspAuthorizationNotes(authorizationId, userIdentities, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationNotesNonMspService.getAuthorizationNotes(authorizationId, accessToken);
        }
    }
}
