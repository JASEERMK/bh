package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.carePrograms.CareProgramsDetails;
import com.usthealthproof.eplus.adaptor.ods.service.CareProgramService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Member Care Gaps")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/member/care")
@SecurityRequirement(name = "OdsAdaptorService")
public class CareProgramAdaptorServiceController {

	@Autowired
	private CareProgramService careProgramService;

	/**
	 * 1. Adaptor service for Care Program service
	 *
	 * @param memberId
	 * @param httpServletRequest
	 * @return CareProgramsDetails
	 * @throws Exception
	 */

	@Operation(summary = "Retrieves member's care program details", description = "The Member Care Program Service obtains details about their respective care programs, identified by their Member ID. The only necessary field is Member ID.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of member's care Program details", content = {
					@Content(schema = @Schema(implementation = CareProgramsDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/careprogram", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<CareProgramsDetails> getCareProgramDetails(
			@Parameter(description = "Member ID", required = true) @RequestParam(name = "memberId", required = true) String memberId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getCareProgramDetails() of CareProgramAdaptorServiceController");
		log.debug("Member Care Program service request received with memberId: {}", memberId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return careProgramService.getMspCareProgramsDetails(memberId, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return careProgramService.getCareProgramsDetails(memberId, accessToken);
		}
	}
}