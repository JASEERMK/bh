package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.DentalClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.mapper.DentalClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@Slf4j
public class DentalClaimService {

	@Autowired
	private DentalClaimData dentalClaimData;

	@Autowired
	private DaoUtil daoUtil;

	@Autowired
	DentalClaimsResponseMapper dentalClaimsResponseMapper;

	@Value("${service.name.claimServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	@Value("${service.uri.defaultState}")
	private String defaultState;

	public DentalClaimDetails getDentalClaimDetails(String claimHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getDentalClaimDetails() of DentalClaimService class");

		DentalClaimDetails dentalClaimDetails = new DentalClaimDetails();
		try {
			CompletableFuture<DentalClaimDetails> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = dentalClaimData.findDentalClaimId(serviceUrl, defaultContextPath + defaultState, claimHccId,null, null, null, accessToken);
			if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
				dentalClaimsResponseMapper.dentalClaimDetailsResponseMapper(dentalClaimDetails, completableFuture);
			} else {
				List<String> dentalClaimErrors = completableFuture.get().getErrors();
				if (dentalClaimErrors != null && !dentalClaimErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(dentalClaimErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = dentalClaimErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimDetails;
	}

	public DentalClaimLinesResponse getDentalClaimLines(String claimHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getDentalClaimLines() of DentalClaimService class");

		DentalClaimLinesResponse dentalClaimLinesResponse = new DentalClaimLinesResponse();
		try {
			CompletableFuture<DentalClaimLinesResponse> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = dentalClaimData.getDentalClaimLines(serviceUrl, defaultContextPath + defaultState, claimHccId,
					null, null, null, accessToken);

			List<DentalClaimLines> dentalClaimLinesList = new ArrayList<>();
			if (completableFuture.get().getDentalClaimLines() != null
					&& !completableFuture.get().getDentalClaimLines().isEmpty()) {
				dentalClaimLinesList.addAll(completableFuture.get().getDentalClaimLines());
				dentalClaimLinesResponse.setDentalClaimLines(dentalClaimLinesList);
			} else {
				List<String> dentalClaimLinesErrors = completableFuture.get().getErrors();
				if (dentalClaimLinesErrors != null && !dentalClaimLinesErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(dentalClaimLinesErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = dentalClaimLinesErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimLinesResponse;
	}

	public DentalClaimLineDetailResponse getDentalClaimLineDetails(String claimHccId, String claimLineHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getDentalClaimLineDetails() of DentalClaimService class");
		DentalClaimLineDetailResponse dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
		try {
			CompletableFuture<DentalClaimLineDetailResponse> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = dentalClaimData.getDentalClaimLineDetails(serviceUrl, defaultContextPath + defaultState, claimHccId,
					claimLineHccId, null, null, null, accessToken);

			List<DentalClaimLineDetails> dentalClaimLineDetails = new ArrayList<>();
			if (completableFuture.get().getDentalClaimLineDetailsList() != null
					&& !completableFuture.get().getDentalClaimLineDetailsList().isEmpty()) {
				dentalClaimLineDetails.addAll(completableFuture.get().getDentalClaimLineDetailsList());
			} else {
				List<String> dentalClaimlineDetailsErrors = completableFuture.get().getErrors();
				if (dentalClaimlineDetailsErrors != null && !dentalClaimlineDetailsErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(dentalClaimlineDetailsErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = dentalClaimlineDetailsErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
			dentalClaimLineDetailResponse.setDentalClaimLineDetailsList(dentalClaimLineDetails);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimLineDetailResponse;
	}

	public DentalClaimDetails getMspDentalClaimDetails(String claimHccId,String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspDentalClaimDetails() of DentalClaimService class");

		DentalClaimDetails dentalClaimDetails = new DentalClaimDetails();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<DentalClaimDetails>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<DentalClaimDetails> completableFuture = null;
				completableFuture = dentalClaimData.findDentalClaimId(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}

			for (CompletableFuture<DentalClaimDetails> completableFuture : completableFutureList) {
				if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
					dentalClaimsResponseMapper.dentalClaimDetailsResponseMapper(dentalClaimDetails, completableFuture);
				}
			}
			if (null == dentalClaimDetails || StringUtils.isBlank(dentalClaimDetails.getMemberId())) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				DentalClaimDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
		}catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimDetails;
	}

	public DentalClaimLinesResponse getMspDentalClaimLines(String claimHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspDentalClaimLines() DentalClaimService class");

		DentalClaimLinesResponse dentalClaimLinesResponse = new DentalClaimLinesResponse();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<DentalClaimLinesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<DentalClaimLinesResponse> completableFuture = null;
				completableFuture = dentalClaimData.getDentalClaimLines(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
						state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}

			List<DentalClaimLines> dentalClaimLinesList = new ArrayList<>();
			for (CompletableFuture<DentalClaimLinesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getDentalClaimLines() != null
						&& !completableFuture.get().getDentalClaimLines().isEmpty()) {
					dentalClaimLinesList.addAll(completableFuture.get().getDentalClaimLines());
				}
			}
			if (null == dentalClaimLinesList || dentalClaimLinesList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				DentalClaimLinesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			dentalClaimLinesResponse.setDentalClaimLines(dentalClaimLinesList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimLinesResponse;
	}

	public DentalClaimLineDetailResponse getMspDentalClaimLineDetails(String claimHccId, String claimLineHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspDentalClaimLineDetails() of DentalClaimService class");

		DentalClaimLineDetailResponse dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<DentalClaimLineDetailResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<DentalClaimLineDetailResponse> completableFuture = null;
				completableFuture = dentalClaimData.getDentalClaimLineDetails(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
						claimLineHccId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			List<DentalClaimLineDetails> dentalClaimLinesList = new ArrayList<>();
			for (CompletableFuture<DentalClaimLineDetailResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getDentalClaimLineDetailsList() != null
						&& !completableFuture.get().getDentalClaimLineDetailsList().isEmpty()) {
					dentalClaimLinesList.addAll(completableFuture.get().getDentalClaimLineDetailsList());
				}
			}
			if (null == dentalClaimLinesList || dentalClaimLinesList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				DentalClaimLineDetailResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
						.get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			dentalClaimLineDetailResponse.setDentalClaimLineDetailsList(dentalClaimLinesList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return dentalClaimLineDetailResponse;
	}
}