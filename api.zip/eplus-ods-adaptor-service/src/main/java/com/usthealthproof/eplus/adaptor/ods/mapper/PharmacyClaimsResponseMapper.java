package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class PharmacyClaimsResponseMapper {

    public void pharmacyClaimDetailsResponseMapper(RxClaimDetails rxClaimDetails, CompletableFuture<RxClaimDetails> completableFuture) throws InterruptedException, ExecutionException {
        log.info("Inside pharmacyClaimDetailsResponseMapper()");

        rxClaimDetails.setMemberId(completableFuture.get().getMemberId());
        rxClaimDetails.setClaimId(completableFuture.get().getClaimId());
        rxClaimDetails.setDrugName(completableFuture.get().getDrugName());
        rxClaimDetails.setFilledDate(completableFuture.get().getFilledDate());
        rxClaimDetails.setStatus(completableFuture.get().getStatus());
        rxClaimDetails.setPharmacyName(completableFuture.get().getPharmacyName());
        rxClaimDetails.setPrescriptionId(completableFuture.get().getPrescriptionId());
        rxClaimDetails.setSourceSystem(completableFuture.get().getSourceSystem());
        rxClaimDetails.setSourceSystemId(completableFuture.get().getSourceSystemId());
        rxClaimDetails.setAdjudicatedDate(completableFuture.get().getAdjudicatedDate());
        rxClaimDetails.setPrescriptionWrittenDate(completableFuture.get().getPrescriptionWrittenDate());
        rxClaimDetails.setDosage(completableFuture.get().getDosage());
        rxClaimDetails.setQuantity(completableFuture.get().getQuantity());
        rxClaimDetails.setDaysSupply(completableFuture.get().getDaysSupply());
        rxClaimDetails.setFillsCount(completableFuture.get().getFillsCount());
        rxClaimDetails.setPriorAuthorizationId(completableFuture.get().getPriorAuthorizationId());
        rxClaimDetails.setPartbPartdInd(completableFuture.get().getPartbPartdInd());
        rxClaimDetails.setSpecialtyRxInd(completableFuture.get().getSpecialtyRxInd());
        rxClaimDetails.setFormularyInd(completableFuture.get().getFormularyInd());
        rxClaimDetails.setFormularyTier(completableFuture.get().getFormularyTier());
        rxClaimDetails.setMaintenanceDrug(completableFuture.get().getMaintenanceDrug());
        rxClaimDetails.setDispensedAsWrittenType(completableFuture.get().getDispensedAsWrittenType());
        rxClaimDetails.setDrugType(completableFuture.get().getDrugType());
        rxClaimDetails.setDrugCategoryType(completableFuture.get().getDrugCategoryType());
        rxClaimDetails.setPharmacyAddress(completableFuture.get().getPharmacyAddress());
        rxClaimDetails.setPharmacyTelephoneNumber(completableFuture.get().getPharmacyTelephoneNumber());
        rxClaimDetails.setPharmacyDispenseType(completableFuture.get().getPharmacyDispenseType());
        rxClaimDetails.setPrescribingPhysicianName(completableFuture.get().getPrescribingPhysicianName());
        rxClaimDetails.setPrescribingPhysicianAddress(completableFuture.get().getPrescribingPhysicianAddress());
        rxClaimDetails.setPrescribingPhysicianSpecialtyCode(completableFuture.get().getPrescribingPhysicianSpecialtyCode());
        rxClaimDetails.setDiagnosis(completableFuture.get().getDiagnosis());
        rxClaimDetails.setIngredientCostAmount(completableFuture.get().getIngredientCostAmount());
        rxClaimDetails.setDispenseFeeAmount(completableFuture.get().getDispenseFeeAmount());
        rxClaimDetails.setSalesTaxAmount(completableFuture.get().getSalesTaxAmount());
        rxClaimDetails.setDeductibleAmount(completableFuture.get().getDeductibleAmount());
        rxClaimDetails.setCopayAmount(completableFuture.get().getCopayAmount());
        rxClaimDetails.setCoinsuranceAmount(completableFuture.get().getCoinsuranceAmount());
        rxClaimDetails.setOutOfPocketAmount(completableFuture.get().getOutOfPocketAmount());
        rxClaimDetails.setMemberPaidAmount(completableFuture.get().getMemberPaidAmount());
        rxClaimDetails.setPlanPaidAmount(completableFuture.get().getPlanPaidAmount());
        rxClaimDetails.setCobIndicator(completableFuture.get().getCobIndicator());
        rxClaimDetails.setCobPaidAmount(completableFuture.get().getCobPaidAmount());
        rxClaimDetails.setCheckNumber(completableFuture.get().getCheckNumber());
        rxClaimDetails.setAdjustmentReason(completableFuture.get().getAdjustmentReason());
        rxClaimDetails.setAdjustmentType(completableFuture.get().getAdjustmentType());
        rxClaimDetails.setRejectCount(completableFuture.get().getRejectCount());
        rxClaimDetails.setRejectMessage1(completableFuture.get().getRejectMessage1());
        rxClaimDetails.setRejectMessage2(completableFuture.get().getRejectMessage2());
        rxClaimDetails.setRejectMessage3(completableFuture.get().getRejectMessage3());
        rxClaimDetails.setFirstFilledDate(completableFuture.get().getFirstFilledDate());
        rxClaimDetails.setMemberName(completableFuture.get().getMemberName());
        rxClaimDetails.setProviderId(completableFuture.get().getProviderId());
        rxClaimDetails.setProviderName(completableFuture.get().getProviderName());
    }
}
