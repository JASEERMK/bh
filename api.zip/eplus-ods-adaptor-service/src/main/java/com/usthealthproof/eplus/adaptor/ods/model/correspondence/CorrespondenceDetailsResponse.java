package com.usthealthproof.eplus.adaptor.ods.model.correspondence;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class for holding the correspondence details of a correspondence Id")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "claimId", "supplierId", "resentDate", "cancelledDate" })
public class CorrespondenceDetailsResponse extends CorrespondenceSearchResponse {

	private static final long serialVersionUID = 3133405993372548374L;

	@Schema(description = "claim ID")
	private String claimId;
	@Schema(description = "Supplier ID")
	private String supplierId;
	@Schema(description = "Resent Date")
	private String resentDate;
	@Schema(description = "Cancelled Date")
	private String cancelledDate;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
