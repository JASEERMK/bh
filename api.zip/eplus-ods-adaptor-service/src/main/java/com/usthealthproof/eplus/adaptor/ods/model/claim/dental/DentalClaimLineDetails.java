package com.usthealthproof.eplus.adaptor.ods.model.claim.dental;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing dental claim line level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DentalClaimLineDetails implements Serializable {

	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "Unique identifier of the dental claim")
	private String claimHccId;

	@Schema(description = "Service code")
	private String codeDescription;

	@Schema(description = "Start date of the dental claim")
	private String serviceStartDate;

	@Schema(description = "Tooth")
	private String tooth;

	@Schema(description = "Surface")
	private String surface;

	@Schema(description = "Area Of Oral Cavity")
	private String areaOfOralCavity;

	@Schema(description = "Authorization number for vision claim")
	private String authorizationNumber;

	@Schema(description = "Service exception message")
	private String serviceException;

	@Schema(description = "Allowed amount")
	private String allowedAmount;

	@Schema(description = "Net Paid amount")
	private String paidAmount;

	@Schema(description = "Deductible amount")
	private String deductible;

	@Schema(description = "Copay computed")
	private String coPay;

	@Schema(description = "Over Max")
	private String overMax;

	@Schema(description = "Coordination of benefit collected")
	private String cobAmount;

	@Schema(description = "Coinsurance computed")
	private String coInsurance;

	@Schema(description = "Payment notes")
	private String paymentNotes;

	@Schema(description = "Billed Amount")
	private String billedAmount;

}
