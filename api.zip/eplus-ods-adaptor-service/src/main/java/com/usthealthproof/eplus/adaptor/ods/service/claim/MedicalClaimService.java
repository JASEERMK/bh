package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.MedicalClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MedicalClaimService {

    @Autowired
    private MedicalClaimData medicalClaimData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.claimServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<MedicalClaimDetails> getMspClaimDetails(String claimHccId, String claimFactKey, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspClaimDetails() of MedicalClaimService class");

        MedicalClaimDetails medicalClaimDetails = new MedicalClaimDetails();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<MedicalClaimDetails>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<MedicalClaimDetails> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = medicalClaimData.findClaimId(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
                        claimFactKey, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<MedicalClaimDetails> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
                    medicalClaimDetails = setMedicalClaimDetails(completableFuture);
                }
            }
            if (null == medicalClaimDetails || StringUtils.isBlank(medicalClaimDetails.getMemberId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                MedicalClaimDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Details Response");
        return new ResponseEntity<>(medicalClaimDetails, HttpStatus.OK);
    }

    public ResponseEntity<MedicalClaimDetails> getClaimDetails(String claimHccId, String claimFactKey, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getClaimDetails() of MedicalClaimService class");

        MedicalClaimDetails medicalClaimDetails = new MedicalClaimDetails();
        try {
            CompletableFuture<MedicalClaimDetails> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = medicalClaimData.findClaimId(serviceUrl, defaultContextPath + defaultState, claimHccId, claimFactKey,
                    null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
                medicalClaimDetails = setMedicalClaimDetails(completableFuture);
            } else {
                List<String> medicalClaimErrors = completableFuture.get().getErrors();
                if (medicalClaimErrors != null && !medicalClaimErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(medicalClaimErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = medicalClaimErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }

        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Details Response");
        return new ResponseEntity<>(medicalClaimDetails, HttpStatus.OK);
    }

    public ResponseEntity<MedicalClaimLinesResponse> getMspClaimLines(String claimHccId, String claimFactKey, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspClaimLines() of MedicalClaimService class");

        MedicalClaimLinesResponse medicalClaimLinesResponse = new MedicalClaimLinesResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<MedicalClaimLinesResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<MedicalClaimLinesResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = medicalClaimData.getClaimLines(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
                        claimFactKey, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }
            List<MedicalClaimLines> medicalClaimLinesList = new ArrayList<>();
            for (CompletableFuture<MedicalClaimLinesResponse> completableFuture : completableFutureList) {
                if (completableFuture.get().getMedicalClaimLines() != null
                        && !completableFuture.get().getMedicalClaimLines().isEmpty()) {
                    medicalClaimLinesList.addAll(completableFuture.get().getMedicalClaimLines());
                }
            }
            if (null == medicalClaimLinesList || medicalClaimLinesList.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                MedicalClaimLinesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            medicalClaimLinesResponse.setMedicalClaimLines(medicalClaimLinesList);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Lines Response");
        return new ResponseEntity<>(medicalClaimLinesResponse, HttpStatus.OK);
    }

    public ResponseEntity<MedicalClaimLinesResponse> getClaimLines(String claimHccId, String claimFactKey, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getClaimLines() of MedicalClaimService class");

        MedicalClaimLinesResponse medicalClaimLinesResponse = new MedicalClaimLinesResponse();
        CompletableFuture<MedicalClaimLinesResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = medicalClaimData.getClaimLines(serviceUrl, defaultContextPath + defaultState, claimHccId, claimFactKey,
                    null, null, null, accessToken);
            if (completableFuture.get().getMedicalClaimLines() != null
                    && !completableFuture.get().getMedicalClaimLines().isEmpty()) {
                medicalClaimLinesResponse.setMedicalClaimLines(completableFuture.get().getMedicalClaimLines());
            } else {
                List<String> medicalClaimErrors = completableFuture.get().getErrors();
                if (medicalClaimErrors != null && !medicalClaimErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(medicalClaimErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = medicalClaimErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Lines Response");
        return new ResponseEntity<>(medicalClaimLinesResponse, HttpStatus.OK);
    }

    public ResponseEntity<MedicalClaimLineDetailsResponse> getMspClaimLineDetails(String claimHccId, String claimLineHccId, String claimFactKey, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspClaimLineDetails() of MedicalClaimService class");

        MedicalClaimLineDetailsResponse medicalClaimLineDetailsResponse = new MedicalClaimLineDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<MedicalClaimLineDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<MedicalClaimLineDetailsResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = medicalClaimData.getClaimLineDetails(serviceUrl, defaultContextPath + multiStateContextPath,
                        claimHccId, claimLineHccId, claimFactKey, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }
            List<MedicalClaimLineDetails> medicalClaimLinesList = new ArrayList<>();
            for (CompletableFuture<MedicalClaimLineDetailsResponse> completableFuture : completableFutureList) {
                if (completableFuture.get().getMedicalClaimLineDetailsList() != null
                        && !completableFuture.get().getMedicalClaimLineDetailsList().isEmpty()) {
                    medicalClaimLinesList.addAll(completableFuture.get().getMedicalClaimLineDetailsList());
                }
            }
            if (null == medicalClaimLinesList || medicalClaimLinesList.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                MedicalClaimLineDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            medicalClaimLineDetailsResponse.setClaimHccId(claimHccId);
            medicalClaimLineDetailsResponse.setMedicalClaimLineDetailsList(medicalClaimLinesList);

        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Line Details Response");
        return new ResponseEntity<>(medicalClaimLineDetailsResponse, HttpStatus.OK);
    }

    public ResponseEntity<MedicalClaimLineDetailsResponse> getClaimLineDetails(String claimHccId, String claimLineHccId, String claimFactKey, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getClaimLineDetails() of MedicalClaimService class");

        MedicalClaimLineDetailsResponse medicalClaimLineDetailsResponse = new MedicalClaimLineDetailsResponse();
        CompletableFuture<MedicalClaimLineDetailsResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = medicalClaimData.getClaimLineDetails(serviceUrl, defaultContextPath + defaultState, claimHccId,
                    claimLineHccId, claimFactKey, null, null, null, accessToken);
            if (completableFuture.get().getMedicalClaimLineDetailsList() != null
                    && !completableFuture.get().getMedicalClaimLineDetailsList().isEmpty()) {
            	medicalClaimLineDetailsResponse.setClaimHccId(claimHccId);
                medicalClaimLineDetailsResponse
                        .setMedicalClaimLineDetailsList(completableFuture.get().getMedicalClaimLineDetailsList());
            } else {
                List<String> medicalClaimErrors = completableFuture.get().getErrors();
                if (medicalClaimErrors != null && !medicalClaimErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(medicalClaimErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = medicalClaimErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Medical Claim Line Details Response");
        return new ResponseEntity<>(medicalClaimLineDetailsResponse, HttpStatus.OK);
    }

    private MedicalClaimDetails setMedicalClaimDetails(CompletableFuture<MedicalClaimDetails> completableFuture) throws ExecutionException, InterruptedException {
        MedicalClaimDetails medicalClaimDetails = new MedicalClaimDetails();
        medicalClaimDetails.setMemberId(completableFuture.get().getMemberId());
        medicalClaimDetails.setClaimHccId(completableFuture.get().getClaimHccId());
        medicalClaimDetails.setServiceStartDate(completableFuture.get().getServiceStartDate());
        medicalClaimDetails.setServiceEndDate(completableFuture.get().getServiceEndDate());
        medicalClaimDetails.setStatus(completableFuture.get().getStatus());
        medicalClaimDetails.setBilledAmount(completableFuture.get().getBilledAmount());
        medicalClaimDetails.setClaimReceiptDate(completableFuture.get().getClaimReceiptDate());
        medicalClaimDetails.setAdmissionDate(completableFuture.get().getAdmissionDate());
        medicalClaimDetails.setDischargeDate(completableFuture.get().getDischargeDate());
        medicalClaimDetails.setClaimType(completableFuture.get().getClaimType());
        medicalClaimDetails.setPaymentStatus(completableFuture.get().getPaymentStatus());
        medicalClaimDetails.setProcessTime(completableFuture.get().getProcessTime());
        medicalClaimDetails.setAllowedAmount(completableFuture.get().getAllowedAmount());
        medicalClaimDetails.setPaidAmount(completableFuture.get().getPaidAmount());
        medicalClaimDetails.setMemberResponsibility(completableFuture.get().getMemberResponsibility());
        medicalClaimDetails.setAmountDeductible(completableFuture.get().getAmountDeductible());
        medicalClaimDetails.setCopayAmount(completableFuture.get().getCopayAmount());
        medicalClaimDetails.setCoinsuranceAmount(completableFuture.get().getCoinsuranceAmount());
        medicalClaimDetails.setCreatedBy(completableFuture.get().getCreatedBy());
        medicalClaimDetails.setModifiedBy(completableFuture.get().getModifiedBy());
        medicalClaimDetails.setIsAdjusted(completableFuture.get().getIsAdjusted());
        medicalClaimDetails.setPayeeID(completableFuture.get().getPayeeID());
        medicalClaimDetails.setPayeeName(completableFuture.get().getPayeeName());
        medicalClaimDetails.setPayee(completableFuture.get().getPayee());
        medicalClaimDetails.setClaimPayer(completableFuture.get().getClaimPayer());
        medicalClaimDetails.setDateEntered(completableFuture.get().getDateEntered());
        medicalClaimDetails.setDeliveryType(completableFuture.get().getDeliveryType());
        medicalClaimDetails.setExternalClaimID(completableFuture.get().getExternalClaimID());
        medicalClaimDetails.setPaymentDate(completableFuture.get().getPaymentDate());
        medicalClaimDetails.setTotalAmount(completableFuture.get().getTotalAmount());
        medicalClaimDetails.setPaymentNumber(completableFuture.get().getPaymentNumber());
        medicalClaimDetails.setMemberPenalty(completableFuture.get().getMemberPenalty());
        medicalClaimDetails.setDiscountAmount(completableFuture.get().getDiscountAmount());
        medicalClaimDetails.setNonCoveredAmount(completableFuture.get().getNonCoveredAmount());
        medicalClaimDetails.setBonusAmount(completableFuture.get().getBonusAmount());
        medicalClaimDetails.setProviderPenalty(completableFuture.get().getProviderPenalty());
        medicalClaimDetails.setProviderId(completableFuture.get().getProviderId());
        medicalClaimDetails.setProviderName(completableFuture.get().getProviderName());
        medicalClaimDetails.setTypeOfBill(completableFuture.get().getTypeOfBill());
        medicalClaimDetails.setDiagnosisCodeDesc(completableFuture.get().getDiagnosisCodeDesc());
        medicalClaimDetails.setPrimaryDiagnosis(completableFuture.get().getPrimaryDiagnosis());
        medicalClaimDetails.setSecondaryDiagnosis(completableFuture.get().getSecondaryDiagnosis());
        medicalClaimDetails.setCobPaid(completableFuture.get().getCobPaid());
        medicalClaimDetails.setCobCoPay(completableFuture.get().getCobCoPay());
        medicalClaimDetails.setCobCoInsurance(completableFuture.get().getCobCoInsurance());
        medicalClaimDetails.setCobDeductible(completableFuture.get().getCobDeductible());
        medicalClaimDetails.setCobBilled(completableFuture.get().getCobBilled());
        medicalClaimDetails.setCobAllowed(completableFuture.get().getCobAllowed());
        medicalClaimDetails.setCobDiscount(completableFuture.get().getCobDiscount());
        medicalClaimDetails.setCobMemberPenalty(completableFuture.get().getCobMemberPenalty());
        medicalClaimDetails.setCobMemberResponsibility(completableFuture.get().getCobMemberResponsibility());
        medicalClaimDetails.setCobProviderPenalty(completableFuture.get().getCobProviderPenalty());
        medicalClaimDetails.setCobNonCovered(completableFuture.get().getCobNonCovered());
        medicalClaimDetails.setCobPerDayLimit(completableFuture.get().getCobPerDayLimit());
        medicalClaimDetails.setCobTax(completableFuture.get().getCobTax());
        medicalClaimDetails.setClaimNote(completableFuture.get().getClaimNote());
        medicalClaimDetails.setClaimSource(completableFuture.get().getClaimSource());
        medicalClaimDetails.setClearinghouseNo(completableFuture.get().getClearinghouseNo());
        medicalClaimDetails.setPatientAccountNo(completableFuture.get().getPatientAccountNo());
        medicalClaimDetails.setIsConverted(completableFuture.get().getIsConverted());
        medicalClaimDetails.setIsRenewed(completableFuture.get().getIsRenewed());
        medicalClaimDetails.setIsVoided(completableFuture.get().getIsVoided());
        medicalClaimDetails.setMedicalRecordNo(completableFuture.get().getMedicalRecordNo());
        medicalClaimDetails.setAdmissionType(completableFuture.get().getAdmissionType());
        medicalClaimDetails.setAdmissionSource(completableFuture.get().getAdmissionSource());
        medicalClaimDetails.setSupplierTaxId(completableFuture.get().getSupplierTaxId());
        medicalClaimDetails.setSupplierNpi(completableFuture.get().getSupplierNpi());
        medicalClaimDetails.setRenderingLocationId(completableFuture.get().getRenderingLocationId());
        medicalClaimDetails.setRenderingLocationName(completableFuture.get().getRenderingLocationName());
        medicalClaimDetails.setRenderingLocationNpi(completableFuture.get().getRenderingLocationNpi());
        medicalClaimDetails.setRenderingProviderAddress(completableFuture.get().getRenderingProviderAddress());
        medicalClaimDetails.setBalanceBilledAmount(completableFuture.get().getBalanceBilledAmount());
        medicalClaimDetails.setBulkCheckAmount(completableFuture.get().getBulkCheckAmount());
        medicalClaimDetails.setClearedCheckDate(completableFuture.get().getClearedCheckDate());
        medicalClaimDetails.setFrequencyCode(completableFuture.get().getFrequencyCode());
        medicalClaimDetails.setReferringPhysician(completableFuture.get().getReferringPhysician());
        medicalClaimDetails.setReferringPhysicianNpi(completableFuture.get().getReferringPhysicianNpi());
        medicalClaimDetails.setTransactionNumber(completableFuture.get().getTransactionNumber());
        medicalClaimDetails.setMemberName(completableFuture.get().getMemberName());
        medicalClaimDetails.setClaimFactKeys(completableFuture.get().getClaimFactKeys());
        medicalClaimDetails.setClaimFactKey(completableFuture.get().getClaimFactKey());
        medicalClaimDetails.setSubmittedDrgCodeAndDesc(completableFuture.get().getSubmittedDrgCodeAndDesc());
        medicalClaimDetails.setAprDrgCodeAndDesc(completableFuture.get().getAprDrgCodeAndDesc());
        medicalClaimDetails.setIllnessCodeAndDesc(completableFuture.get().getIllnessCodeAndDesc());
        medicalClaimDetails.setSccfNo(completableFuture.get().getSccfNo());
        medicalClaimDetails.setCheckNumber(completableFuture.get().getCheckNumber());
        medicalClaimDetails.setProviderSpeciality(completableFuture.get().getProviderSpeciality());
        medicalClaimDetails.setReferringPhysicianName(completableFuture.get().getReferringPhysicianName());
        return medicalClaimDetails;
    }

}