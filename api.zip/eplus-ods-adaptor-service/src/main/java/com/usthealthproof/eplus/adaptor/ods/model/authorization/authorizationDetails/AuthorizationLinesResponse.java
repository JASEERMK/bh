
package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "serviceLineId", "procedureCode", "placeOfService", "determinationStatus", "performingProviderName",
		"performingProviderId" })
@Data
@Schema(description = "Object for holding the Authorization lines results fields")
public class AuthorizationLinesResponse implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "Unique service Line ID for the particular services")
	@JsonProperty("serviceLineId")
	private String serviceLineId;

	@Schema(description = "ProcedureCode & Description of the procedure undergone")
	@JsonProperty("procedureCode")
	private String procedureCode;

	@Schema(description = "Place of Service where the service will be performed")
	@JsonProperty("placeOfService")
	private String placeOfService;

	@Schema(description = "Determination status of the auth service line")
	@JsonProperty("determinationStatus")
	private String determinationStatus;

	@Schema(description = "Name of the provider performing the service")
	@JsonProperty("performingProviderName")
	private String performingProviderName;

	@Schema(description = "ID of the provider performing the service")
	@JsonProperty("performingProviderId")
	private String performingProviderId;

	@Schema(description = "Start Date of Service")
	@JsonProperty("serviceStartDate")
	private String serviceStartDate;

	@Schema(description = "End Date of Service")
	@JsonProperty("serviceEndDate")
	private String serviceEndDate;

}
