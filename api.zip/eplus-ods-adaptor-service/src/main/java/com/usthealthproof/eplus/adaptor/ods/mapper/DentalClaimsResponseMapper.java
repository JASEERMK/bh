package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class DentalClaimsResponseMapper {

    public void dentalClaimDetailsResponseMapper(DentalClaimDetails dentalClaimDetails, CompletableFuture<DentalClaimDetails> completableFuture) throws InterruptedException, ExecutionException {
        log.info("Inside dentalClaimDetailsResponseMapper()");

        dentalClaimDetails.setMemberId(completableFuture.get().getMemberId());
        dentalClaimDetails.setPayMember(completableFuture.get().getPayMember());
        dentalClaimDetails.setInsurerId(completableFuture.get().getInsurerId());
        dentalClaimDetails.setInsurerName(completableFuture.get().getInsurerName());
        dentalClaimDetails.setProviderId(completableFuture.get().getProviderId());
        dentalClaimDetails.setProviderName(completableFuture.get().getProviderName());
        dentalClaimDetails.setServiceStartDate(completableFuture.get().getServiceStartDate());
        dentalClaimDetails.setServiceEndDate(completableFuture.get().getServiceEndDate());
        dentalClaimDetails.setLocationId(completableFuture.get().getLocationId());
        dentalClaimDetails.setLocationName(completableFuture.get().getLocationName());
        dentalClaimDetails.setPayeeOtherId(completableFuture.get().getPayeeOtherId());
        dentalClaimDetails.setPayeeOtherName(completableFuture.get().getPayeeOtherName());
        dentalClaimDetails.setNetworkId(completableFuture.get().getNetworkId());
        dentalClaimDetails.setNetworkName(completableFuture.get().getNetworkName());
        dentalClaimDetails.setClaimReceivedDate(completableFuture.get().getClaimReceivedDate());
        dentalClaimDetails.setClaimEnteredDate(completableFuture.get().getClaimEnteredDate());
        dentalClaimDetails.setMissingTeeth(completableFuture.get().getMissingTeeth());
        dentalClaimDetails.setPaymentDate(completableFuture.get().getPaymentDate());
        dentalClaimDetails.setPaymentNumber(completableFuture.get().getPaymentNumber());
        dentalClaimDetails.setNetPaidAmount(completableFuture.get().getNetPaidAmount());
        dentalClaimDetails.setBilledAmount(completableFuture.get().getBilledAmount());
        dentalClaimDetails.setAllowed(completableFuture.get().getAllowed());
        dentalClaimDetails.setPaidAmount(completableFuture.get().getPaidAmount());
        dentalClaimDetails.setDeductible(completableFuture.get().getDeductible());
        dentalClaimDetails.setCoPay(completableFuture.get().getCoPay());
        dentalClaimDetails.setCoinsuranceAmount(completableFuture.get().getCoinsuranceAmount());
        dentalClaimDetails.setOverMax(completableFuture.get().getOverMax());
        dentalClaimDetails.setCobAmount(completableFuture.get().getCobAmount());
        dentalClaimDetails.setPaymentStatus(completableFuture.get().getPaymentStatus());
        dentalClaimDetails.setPaymentNotes(completableFuture.get().getPaymentNotes());
        dentalClaimDetails.setEftFlag(completableFuture.get().getEftFlag());
        dentalClaimDetails.setEftAccount(completableFuture.get().getEftAccount());
        dentalClaimDetails.setCheckCleared(completableFuture.get().getCheckCleared());
        dentalClaimDetails.setCreatedBy(completableFuture.get().getCreatedBy());
        dentalClaimDetails.setLastModifiedBy(completableFuture.get().getLastModifiedBy());
        dentalClaimDetails.setMemberName(completableFuture.get().getMemberName());
    }
}
