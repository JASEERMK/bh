package com.usthealthproof.eplus.adaptor.ods.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.ClaimAdjustmentData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentModel;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentResponse;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ClaimAdjustmentService {

    @Autowired
    private ClaimAdjustmentData claimAdjustmentData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.claimAdjustmentServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<ClaimAdjustmentResponse> getMspClaimAdjustment(String claimNumber, String claimFactKey, String previousClaimFactKey, String userIdentities, String accessToken) throws Exception {
        log.info("Inside getMspClaimAdjustment() of ClaimAdjustmentService class");

        ClaimAdjustmentResponse claimAdjustmentResponse = new ClaimAdjustmentResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<ClaimAdjustmentResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<ClaimAdjustmentResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = claimAdjustmentData.getClaimAdjustmentFields(serviceUrl,
                        defaultContextPath + multiStateContextPath, claimNumber, claimFactKey, previousClaimFactKey, state,
                        lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<ClaimAdjustmentModel> claimAdjustmentModelList = new ArrayList<>();
            for (CompletableFuture<ClaimAdjustmentResponse> completableFuture : completableFutureList) {
                if (completableFuture.get().getAdjustedFieldList() != null
                        && !completableFuture.get().getAdjustedFieldList().isEmpty()) {
                    claimAdjustmentModelList.addAll(completableFuture.get().getAdjustedFieldList());
                    claimAdjustmentResponse.setRequestId(completableFuture.get().getRequestId());
                }
            }
            if (null == claimAdjustmentModelList || claimAdjustmentModelList.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                ClaimAdjustmentResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            claimAdjustmentResponse.setAdjustedFieldList(claimAdjustmentModelList);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Claim Adjustment Response");
        return new ResponseEntity<>(claimAdjustmentResponse, HttpStatus.OK);
    }

    public ResponseEntity<ClaimAdjustmentResponse> getClaimAdjustment(String claimNumber, String claimFactKey, String previousClaimFactKey, String accessToken) throws Exception {
        log.info("Inside getClaimAdjustment() of ClaimAdjustmentService class");

        ClaimAdjustmentResponse claimAdjustmentResponse = new ClaimAdjustmentResponse();
        CompletableFuture<ClaimAdjustmentResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = claimAdjustmentData.getClaimAdjustmentFields(serviceUrl, defaultContextPath + defaultState,
                    claimNumber, claimFactKey, previousClaimFactKey, null, null, null, accessToken);
            if (completableFuture.get().getAdjustedFieldList() != null
                    && !completableFuture.get().getAdjustedFieldList().isEmpty()) {
                claimAdjustmentResponse.setRequestId(completableFuture.get().getRequestId());
                claimAdjustmentResponse.setAdjustedFieldList(completableFuture.get().getAdjustedFieldList());
            } else {
                List<String> claimAdjustmentErrors = completableFuture.get().getErrors();
                if (claimAdjustmentErrors != null && !claimAdjustmentErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(claimAdjustmentErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = claimAdjustmentErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Claim Adjustment Response");
        return new ResponseEntity<>(claimAdjustmentResponse, HttpStatus.OK);
    }
}
