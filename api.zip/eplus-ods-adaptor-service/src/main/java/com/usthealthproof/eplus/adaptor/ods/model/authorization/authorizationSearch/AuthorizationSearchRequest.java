package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch;

import lombok.Data;

@Data
public class AuthorizationSearchRequest {

    private String memberNumber;
    private String authorizationId;
    private String type;
    private String status;
    private String searchStartDate;
    private String searchEndDate;
    private String state;
    private String lob;
    private String product;
    //	Specific to Provider Authorization Search
    private String providerId;
    private String userIdentities;
    private String isMatchingUserRole;

}
