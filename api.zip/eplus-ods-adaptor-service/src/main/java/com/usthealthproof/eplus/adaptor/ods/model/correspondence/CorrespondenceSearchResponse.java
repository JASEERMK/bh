package com.usthealthproof.eplus.adaptor.ods.model.correspondence;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class for holding the correspondence details")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "correspondenceId", "correspondenceName", "currentStatus", "createdDate", "generatedDate", "sentDate" })
public class CorrespondenceSearchResponse implements Serializable {

	private static final long serialVersionUID = 3133405993372548374L;

	@Schema(description = "Correspondence ID")
	private String correspondenceId;
	@Schema(description = "Correspondence Name")
	private String correspondenceName;
	@Schema(description = "Current Status of the correspondence")
	private String currentStatus;
	@Schema(description = "Created Date")
	private String createdDate;
	@Schema(description = "Generated Date")
	private String generatedDate;
	@Schema(description = "Sent Date")
	private String sentDate;

}
