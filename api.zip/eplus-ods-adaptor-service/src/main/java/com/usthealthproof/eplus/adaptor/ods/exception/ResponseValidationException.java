package com.usthealthproof.eplus.adaptor.ods.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = -225432130379799744L;

	public ResponseValidationException() {
	}

	public ResponseValidationException(String message) {
		super(message);
	}

	public ResponseValidationException(Throwable cause) {
		super(cause);
	}

	public ResponseValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
