package com.usthealthproof.eplus.adaptor.ods.model.careGaps;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing Member's Care Gaps details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CareGapsDetailsList implements Serializable {

	private static final long serialVersionUID = -1018884697183728500L;

	@Schema(description = "Member HCC ID")
	private String memberId;

	@Schema(description = "Name of Care Gap")
	private String careGapName;

	@Schema(description = "Code of Care Gap")
	private String careGapCode;

	@Schema(description = "Care Gap status")
	private String careGapStatus;

	@Schema(description = "Care Gap source")
	private String source;

	@Schema(description = "Care Gap due date")
	private String careGapDueDate;

	@Schema(description = "Care Gap last completed")
	private String careGapLastCompleted;

	@Schema(description = "Name of Care team")
	private String careTeamName;

	@Schema(description = "Last date on which service was provided by PCP")
	private String pcpLastDos;

	@Schema(description = "Reward amount")
	private String rewardAmount;

	@Schema(description = "Reward date")
	private String rewardDate;

	@Schema(description = "Origin")
	private String origin;

	@Schema(description = "Priority")
	private String priority;

	@Schema(description = "Care Gap Action")
	private String careGapAction;

	@Schema(description = "Last Call Date")
	private String lastCallDate;

}