package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response object for holding the Authorization search results as a List")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AuthorizationSearchResponseList {
	@Schema(description = "For storing the response as list")
	private List<AuthorizationSearchResponse> results;
	@Schema(description = "Flag to indicate whether there is any data available for the request")
	private String dataAvailabilityFlag;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}
