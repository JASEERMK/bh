
package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "memberId", "authId", "drugName", "authStatus", "requestor", "requestType", "determinationDueDate",
		"ndc", "duration", "authReason", "authRequestedDate", "determinationStatusReason", "rxId", "urgency",
		"determinationDate", "quantity", "diagnosisCodeDescription", "diagnosisCodeCategory", "technician",
		"pharmacist", "decisionerFirstName", "decisionerLastName", "authEffectiveDate", "internalNotes",
		"authTerminationDate", "prescriberInfo" })
@Data
@Schema(description = "Object for holding the Authorization details results fields")
public class PharmacyAuthorizationDetailsResponse implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "Member ID")
	@JsonProperty("memberId")
	private String memberId;

	@Schema(description = "Authorization ID")
	@JsonProperty("authId")
	private String authId;

	@Schema(description = "Name of drug requested")
	@JsonProperty("drugName")
	private String drugName;

	@Schema(description = "Status of the authorization")
	@JsonProperty("authStatus")
	private String authStatus;

	@Schema(description = "Who is requesting the authorization, i.e., Provider, Member, Member Beneficiary")
	@JsonProperty("requestor")
	private String requestor;

	@Schema(description = "Type of Request. i.e., Prior Authorization")
	@JsonProperty("requestType")
	private String requestType;

	@Schema(description = "Calculated date based on Urgency and Received Date")
	@JsonProperty("determinationDueDate")
	private String determinationDueDate;

	@Schema(description = "NDC for the drug authorization")
	@JsonProperty("ndc")
	private String ndc;

	@Schema(description = "Days supply requested")
	@JsonProperty("duration")
	private String duration;

	@Schema(description = "Reason for the Authorization, i.e., Pharmacy")
	@JsonProperty("authReason")
	private String authReason;

	@Schema(description = "Date auth was requested MM/DD/YYYY")
	@JsonProperty("authRequestedDate")
	private String authRequestedDate;

	@Schema(description = "Explanation regarding the determination status. i.e., Met Criteria")
	@JsonProperty("determinationStatusReason")
	private String determinationStatusReason;

	@Schema(description = "Rx ID associated with the authorization")
	@JsonProperty("rxId")
	private String rxId;

	@Schema(description = "Urgency. i.e., Standard, Expedited")
	@JsonProperty("urgency")
	private String urgency;

	@Schema(description = "Date Determination was made")
	@JsonProperty("determinationDate")
	private String determinationDate;

	@Schema(description = "Quantity requested")
	@JsonProperty("quantity")
	private String quantity;

	@Schema(description = "Diagnosis code & description")
	@JsonProperty("diagnosisCodeDescription")
	private String diagnosisCodeDescription;

	@Schema(description = "Diagnosis code type")
	@JsonProperty("diagnosisCodeCategory")
	private String diagnosisCodeCategory;

	// Added as a part of cpb-4982

	@Schema(description = "Diagnosis code")
	@JsonProperty("diagnosisCode")
	private String diagnosisCode;

	@Schema(description = "Source")
	@JsonProperty("source")
	private String source;

	@Schema(description = "Technician responsible for the authorization")
	@JsonProperty("technician")
	private String technician;

	@Schema(description = "Pharmacist’s name")
	@JsonProperty("pharmacist")
	private String pharmacist;

	@Schema(description = "First name of person responsible for the the final decision")
	@JsonProperty("decisionerFirstName")
	private String decisionerFirstName;

	@Schema(description = "Last name of person responsible for the the final decision")
	@JsonProperty("decisionerLastName")
	private String decisionerLastName;

	@Schema(description = "Auth Effective Date in MM/DD/YYYY")
	@JsonProperty("authEffectiveDate")
	private String authEffectiveDate;

	@Schema(description = "Internal Notes")
	@JsonProperty("internalNotes")
	private String internalNotes;

	@Schema(description = "Auth Termination Date in MM/DD/YYYY")
	@JsonProperty("authTerminationDate")
	private String authTerminationDate;

	@Schema(description = "Object to hold the Prescriber Information")
	@JsonProperty("prescriberInfo")
	private PrescriberInformation prescriberInfo;

	@Schema(description = "Request Id for the response")
	private String requestId;

	@Schema(description = "To hold the error", hidden = true)
	private String error;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;


}



