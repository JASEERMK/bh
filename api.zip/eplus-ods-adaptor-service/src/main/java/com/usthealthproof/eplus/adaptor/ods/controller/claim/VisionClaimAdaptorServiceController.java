package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLineDetailsResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.VisionClaimService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Vision Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class VisionClaimAdaptorServiceController {

	@Autowired
	private VisionClaimService visionClaimService;

	/**
	 * 1. Adaptor service to get vision claim details
	 *
	 * @param claimHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@GetMapping(value = "/vision", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Vision Claim Details", description = "Details regarding Vision claims can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Vision claim details of the particular claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<VisionClaimDetails> getVisionClaimDetails(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getVisionClaimDetails() of VisionClaimAdaptorServiceController");
		log.debug("Vision claim details service request received with claimHccId= {}", claimHccId);

		VisionClaimDetails visionClaimDetails;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			 visionClaimDetails = visionClaimService.getMspVisionClaimDetails(claimHccId, userIdentities, accessToken);
        } else {
			 visionClaimDetails = visionClaimService.getVisionClaimDetails(claimHccId, accessToken);
        }
        return new ResponseEntity<>(visionClaimDetails, HttpStatus.OK);
    }

	/**
	 *  2. Adaptor service to get all claim lines of the particular vision claim
	 *
	 * @param claimHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Vision Claim Lines", description = "Service Lines information’s regarding Vision claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of all the vision claim lines of the claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimLinesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/vision/claimlines", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<VisionClaimLinesResponse> getVisionClaimLines(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getVisionClaimLines() of VisionClaimAdaptorServiceController");
		log.debug("Vision Claim claim lines service request received with claimHccId= {}", claimHccId);

		VisionClaimLinesResponse visionClaimLinesResponse;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			visionClaimLinesResponse = visionClaimService.getMspVisionClaimLines(claimHccId, userIdentities, accessToken);
		} else {
			visionClaimLinesResponse = visionClaimService.getVisionClaimLines(claimHccId, accessToken);
		}
		log.info("Successfully generated vision claim lines response");
		return new ResponseEntity<>(visionClaimLinesResponse, HttpStatus.OK);
	}

	/***
	 * 3. Adaptor service to get specific vision claim line details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Vision Claim Line Details", description = "Service Line details regarding Vision claims, can be accessed through the specified service. Claim HCC ID and Claim Line HCC ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Vision claim line detail of the particular claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimLineDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/vision/claimline", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<VisionClaimLineDetailsResponse> getVisionClaimLineDetails(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			@Parameter(description = "Vision Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") String claimLineHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getVisionClaimLineDetails() of VisionClaimAdaptorServiceController");
		log.debug("Vision Claim line details service request received with claimHccID= {} claimLineHccId= {}", claimHccId,
				claimLineHccId);

		VisionClaimLineDetailsResponse visionClaimLineDetailsResponse;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			visionClaimLineDetailsResponse = visionClaimService.getMspVisionClaimLineDetails(claimHccId,claimLineHccId, userIdentities, accessToken);
		} else {
			visionClaimLineDetailsResponse = visionClaimService.getVisionClaimLineDetails(claimHccId, claimLineHccId, accessToken);
		}
		log.info("Successfully generated vision claim line details response");
		return new ResponseEntity<>(visionClaimLineDetailsResponse, HttpStatus.OK);
	}
}