package com.usthealthproof.eplus.adaptor.ods.exception;

public class ODSAdaptorException extends RuntimeException {

	private static final long serialVersionUID = -225432130379799744L;

	public ODSAdaptorException() {
	}

	public ODSAdaptorException(String message) {
		super(message);
	}

	public ODSAdaptorException(Throwable cause) {
		super(cause);
	}

	public ODSAdaptorException(String message, Throwable cause) {
		super(message, cause);
	}

}
