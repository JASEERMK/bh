package com.usthealthproof.eplus.adaptor.ods.dao;

import java.net.URI;
import java.util.concurrent.CompletableFuture;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class OtherInsuranceData {

	public static final String MEMBER_OTHERINSURANCE = "/v1/member/otherinsurance";
	
	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async
	public CompletableFuture<OtherInsuranceDetails> getOtherInsuranceDetails(String serviceUrl, String contextPath, String memberId, String state,
			String lob, String product, String accessToken) {
		log.info("Inside getOtherInsuranceDetails() of OtherInsuranceData class");
		log.debug("Inside getOtherInsuranceDetails() of OtherInsuranceData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		OtherInsuranceDetails otherInsuranceDetails = new OtherInsuranceDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEMBER_OTHERINSURANCE);
				otherInsuranceDetails = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEMBER_OTHERINSURANCE).queryParam("memberId", memberId)
								.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(OtherInsuranceDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEMBER_OTHERINSURANCE)
						.queryParam("memberId", memberId)
						.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				otherInsuranceDetails = webClientBuilder.build().get()
						.uri(uri)
						.retrieve().bodyToMono(OtherInsuranceDetails.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			otherInsuranceDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			otherInsuranceDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getOtherInsuranceDetails() completed");
		return CompletableFuture.completedFuture(otherInsuranceDetails);
	}
}