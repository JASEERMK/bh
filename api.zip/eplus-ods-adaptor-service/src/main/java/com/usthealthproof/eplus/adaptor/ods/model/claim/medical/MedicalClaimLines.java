package com.usthealthproof.eplus.adaptor.ods.model.claim.medical;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class for medical Claim Lines details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class MedicalClaimLines implements Serializable, Comparable<MedicalClaimLines> {

	private static final long serialVersionUID = -3950173175057043273L;
	@Schema(description = "HCC ID of the claim line")
	private String claimLineNumber;
	@Schema(description = "billed amount")
	private String billedAmount;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "paid Amount")
	private String paidAmount;
	@JsonIgnore
	private Integer orderField;
	@Schema(description = "User message")
	private String userMessage;
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;

	@Override
	public int compareTo(MedicalClaimLines medicalClaimLines) {
		if (null != this.getOrderField() && null != medicalClaimLines && null != medicalClaimLines.getOrderField()) {
			int orderField1 = this.getOrderField();
			int orderField2 = medicalClaimLines.getOrderField();
			return orderField1 - orderField2;
		}
		return 0;
	}
}
