package com.usthealthproof.eplus.adaptor.ods.util;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.ProblemDetails;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class APIUtils {

	@Autowired
	private Validator validator;

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		log.info("Inside createProblemDetails() of APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(Arrays.asList(errorMsg));
		return problemDetails;
	}

	public String getBearerToken(HttpServletRequest httpServletRequest) {
		log.info("Inside getBearerToken() of APIUtils");
		return validator.validateBearerToken(httpServletRequest);
	}

	public static ErrorResponse createErrorResponse(WebClientResponseException ex) {
		log.info("Inside createErrorResponse() and the exception is: {}", ex.getResponseBodyAsString());

		ErrorResponse errorResponse = new ErrorResponse();
		ProblemDetails problemDetails = new ProblemDetails();
		try {
			if (503 == ex.getStatusCode().value()) {
				log.info("The called service is un-available. It may be down or some internal error occurred.");
				problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
				problemDetails.setErrors(Arrays.asList(OdsAdaptorServiceConstants.SERVICE_UNAVAILABLE));
				errorResponse.setProblemDetails(problemDetails);
				return errorResponse;
			} else if (StringUtils.isNotBlank(ex.getResponseBodyAsString())) {
				JSONObject exceptionJsonMessage = new JSONObject(ex.getResponseBodyAsString());
				if (exceptionJsonMessage.has("error")) {
					problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
					problemDetails.setErrors(Arrays.asList(exceptionJsonMessage.getString("error")));
					errorResponse.setProblemDetails(problemDetails);
					return errorResponse;
				} else if (exceptionJsonMessage.has("problemDetails")) {
					return ex.getResponseBodyAs(ErrorResponse.class);
				}
			}
		} catch (Exception e) {
			log.info("The received error message can't convert into JSON object");
			if (503 == ex.getStatusCode().value()) {
				log.info("The called service is un-available. It may be down or some internal error occurred.");
				problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
				problemDetails.setErrors(Arrays.asList(OdsAdaptorServiceConstants.SERVICE_UNAVAILABLE));
				errorResponse.setProblemDetails(problemDetails);
				return errorResponse;
			} else {
				problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
				problemDetails.setErrors(Arrays.asList(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE));
				errorResponse.setProblemDetails(problemDetails);
				return errorResponse;
			}
		}
		problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
		problemDetails.setErrors(Arrays.asList(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE));
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

	public void errorHandling(CompletableFuture<AuthorizationNotesResponse> completableFuture) throws InterruptedException, ExecutionException {
		if (completableFuture.get().getErrors() != null && !completableFuture.get().getErrors().isEmpty()) {
			log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
			String exceptionMessage;
			if (StringUtils.isBlank(completableFuture.get().getErrors().get(0))) {
				exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
			} else {
				exceptionMessage = completableFuture.get().getErrors().get(0) + "|"
						+ completableFuture.get().getHttpStatusCode();
			}
			throw new ODSAdaptorException(exceptionMessage);
		}
	}
}
