package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class CareGapsData {

	public static final String MEMBER_CAREGAP = "/v1/member/care/caregap";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;


	@Async("asyncExecutor")
	public CompletableFuture<CareGapsDetails> getMemberCareGapsDetails(String serviceUrl, String contextPath, String memberId, String state,
			String lob, String product, String accessToken) {
		log.info("Inside getMemberCareGapsDetails() of CareGapsData class");
		log.debug("Inside getMemberCareGapsDetails() of CareGapsData class and the requests are- contextPath: {} & accessToken: {} state: {} & lob: {} & product: {}",
				contextPath, accessToken, state, lob, product);

		CareGapsDetails careGapsDetails = new CareGapsDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEMBER_CAREGAP);
				careGapsDetails = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEMBER_CAREGAP).queryParam("memberId", memberId)
								.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(CareGapsDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEMBER_CAREGAP)
						.queryParam("memberId", memberId)
						.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product)
						.build().toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				careGapsDetails = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(CareGapsDetails.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			careGapsDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			careGapsDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getMemberCareGapsDetails() completed");
		return CompletableFuture.completedFuture(careGapsDetails);
	}
}