package com.usthealthproof.eplus.adaptor.ods.model.otherInsurance;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing Member's Other Insurance Policy details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OtherInsuranceDetailsList implements Serializable {

	private static final long serialVersionUID = -1018884697183728500L;

	@Schema(description = "Member HCC ID")
	private String memberId;

	@Schema(description = "Name of the Member")
	private String memberName;

	@Schema(description = "Other Insurance Company Name")
	private String companyName;

	@Schema(description = "Status of the Policy")
	private String status;

	@Schema(description = "Policy effective start date")
	private String effectiveDateFrom;

	@Schema(description = "Policy effective end date")
	private String effectiveDateTo;

	@Schema(description = "Other Insurance Plan Id")
	private String planId;

	@Schema(description = "Other Insurance Plan Name")
	private String planName;

	@Schema(description = "Other Insurance Plan Type")
	private String planType;

	@Schema(description = "Other Insurence Policy Type")
	private String policyType;

	@Schema(description = "Priority")
	private String priority;

	@Schema(description = "Court Ordered Coverage")
	private String courtOrderedCoverage;
	//Added as part of CPB-4505
	@Schema(description = "Verification Status")
	private String verificationStatus;
	@Schema(description = "Last Verified Date")
	private String lastVerifiedDate;
}