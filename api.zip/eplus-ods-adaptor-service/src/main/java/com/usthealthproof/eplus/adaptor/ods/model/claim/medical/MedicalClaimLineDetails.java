package com.usthealthproof.eplus.adaptor.ods.model.claim.medical;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class for medical Claim Line level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MedicalClaimLineDetails implements Serializable {

	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "HCC ID of the claim line")
	private String claimLineNumber;
	@Schema(description = "Unique identifier of the claim")
	private String claimHccId;
	@Schema(description = "claim line key")
	private String claimLineKey;
	@Schema(description = "billed amount")
	private String billedAmount;
	@Schema(description = "denied")
	private String denied;
	@Schema(description = "description")
	@JsonProperty(value = "denialCodeDesc")
	private String denialCodeDesc;
	@Schema(description = "Service start date")
	private String serviceStartDate;
	@Schema(description = "Service end date")
	private String serviceEndDate;
	@Schema(description = "error level")
	private String errorLevel;
	@Schema(description = "external source")
	private String externalSource;
	@Schema(description = "Amount paid")
	private String paidAmount;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Deductible amount")
	private String deductibleAmount;
	@Schema(description = "Allowed amount")
	private String allowedAmount;
	@Schema(description = "Coinsurance amount")
	private String coinsuranceAmount;
	@Schema(description = "Copay amount")
	private String copayAmount;
	@Schema(description = "disposition")
	private String disposition;
	@Schema(description = "Referring/Auth number")
	@JsonProperty("Ref/Auth Number")
	private String refAuthNumber;
	@Schema(description = "Indicator used for service related to Early Periodic Screening, Diagnosis and Treatment(EPSDT)")
	private String epsdtIndicator;
	@Schema(description = "cpt code desc")
	private String cptCodeDesc;
	@Schema(description = "modifier code desc")
	private String modifierCodeDesc;
	@Schema(description = "revenue code")
	private String revenueCode;
	@Schema(description = "minute")
	private String minute;
	@Schema(description = "uos")
	private String uos;
	@Schema(description = "primary diagnosis")
	private String primaryDiagnosis;
	@Schema(description = "other diagnosis code")
	private String otherDiagnosisCodes;
	@Schema(description = "other diagnosis desc")
	private String userMessageCodeDesc;
	@Schema(description = "place of service")
	private String placeOfService;
	@Schema(description = "non covered amount")
	private String nonCoveredAmount;
	@Schema(description = "balance billed amount")
	private String balanceBilledAmount;
	@Schema(description = "member penalty")
	private String memberPenalty;
	@Schema(description = "member responsibility")
	private String memberResponsibility;
	@Schema(description = "provider penalty")
	private String providerPenalty;
	@Schema(description = "bonus amount")
	private String bonusAmount;
	@Schema(description = "other discount")
	private String otherDiscount;
	@Schema(description = "hcc amount")
	private String hccAmount;
	@Schema(description = "Coordination of benefit paid")
	private String cobPaid;
	@Schema(description = "Coordination of benefit copay")
	private String cobCopay;
	@Schema(description = "Coordination of benefit CoInsurance")
	private String cobConInsurance;
	@Schema(description = "Coordination of benefit deductible")
	private String cobDeductible;
	@Schema(description = "Coordination of benefit allowed")
	private String cobAllowed;
	@Schema(description = "Coordination of benefit Discount")
	private String cobDiscount;
	@Schema(description = "Coordination of benefit member penalty")
	private String cobMemberPenalty;
	@Schema(description = "Coordination of benefit member responsibility")
	private String cobMemberResponsibility;
	@Schema(description = "Coordination of benefit provider penalty")
	private String cobProviderPenalty;
	@Schema(description = "Coordination of benefit non covered amount")
	private String cobNonCoveredAmount;
	@Schema(description = "Coordination of benefit per day limit")
	private String cobPerDayLimit;
	@Schema(description = "Coordination of benefit tax amount")
	private String cobTaxAmount;
	@Schema(description = "List of Claim notes")
	private List<ClaimNotes> claimNote;
//	Added as part of Version2
	@Schema(description = "Rendering Practitioner ID")
	private String renderingPractitionerId;
	@Schema(description = "Rendering Practitioner Name")
	private String renderingPractitionerName;
	@Schema(description = "Rendering Practitioner NPI")
	private String renderingPractitionerNpi;
//	Added as part of v23.1 - CPB-2711
	@Schema(description = "Benefit Tier")
	private String benefitTier;
	@Schema(description = "Tier Name")
	private String tierName;
	@Schema(description = "Benefit Label")
	private String benefitLabel;
//	Added as part of CPB-3167
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;
	//Added as part of API-628
	@Schema(description = "Benefit Network")
	private String benefitNetwork;
	//Added as part of API-1467
	@Schema(description = "Rejection Code and Description")
	private String rejectionCodeDesc;
}
