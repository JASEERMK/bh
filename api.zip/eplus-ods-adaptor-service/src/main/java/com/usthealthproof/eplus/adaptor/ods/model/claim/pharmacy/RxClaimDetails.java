package com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Schema(description = "Response class containing Rx claim details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class RxClaimDetails implements Serializable {
	private static final long serialVersionUID = 3774024749927375867L;
	@Schema(description = "Unique identifier of the member")
	private String memberId;
	@Schema(description = "Claim Id")
	private String claimId;
	@Schema(description = "Drug name")
	private String drugName;
	@Schema(description = "Filled date")
	private String filledDate;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Name of Pharmacy")
	private String pharmacyName;
	@Schema(description = "Prescription Id")
	private String prescriptionId;
	@Schema(description = "Source system")
	private String sourceSystem;
	@Schema(description = "Identifier of Source system")
	private String sourceSystemId;
	@Schema(description = "Adjudicated date")
	private String adjudicatedDate;
	@Schema(description = "Date on which prescription was written")
	private String prescriptionWrittenDate;
	@Schema(description = "Dosage")
	private String dosage;
	@Schema(description = "quantity")
	private String quantity;
	@Schema(description = "Days supply")
	private String daysSupply;
	@Schema(description = "Fills count")
	private String fillsCount;
	@Schema(description = "Prior Authorization Id")
	private String priorAuthorizationId;
	@Schema(description = "PartB PartD Ind")
	private String partbPartdInd;
	@Schema(description = "Specialty Rx Ind")
	private String specialtyRxInd;
	@Schema(description = "Formulary Ind")
	private String formularyInd;
	@Schema(description = "Formulary Tier")
	private String formularyTier;
	@Schema(description = "Maintenance drug")
	private String maintenanceDrug;
	@Schema(description = "Dispensed as Written Type")
	private String dispensedAsWrittenType;
	@Schema(description = "Type of drug")
	private String drugType;
	@Schema(description = "Category type of drug")
	private String drugCategoryType;
	@Schema(description = "Pharmacy Address")
	private String pharmacyAddress;
	@Schema(description = "Telephone number of Pharmacy")
	private String pharmacyTelephoneNumber;
	@Schema(description = "Pharmacy's dispense type")
	private String pharmacyDispenseType;
	@Schema(description = "Name of prescribing physician")
	private String prescribingPhysicianName;
	@Schema(description = "Address of prescribing physician")
	private String prescribingPhysicianAddress;
	@Schema(description = "Specialty code of prescribing physician")
	private String prescribingPhysicianSpecialtyCode;
	@Schema(description = "Diagnosis")
	private String diagnosis;
	@Schema(description = "Ingredient cost amount")
	private String ingredientCostAmount;
	@Schema(description = "Dispense fee amount")
	private String dispenseFeeAmount;
	@Schema(description = "Amount of sales tax")
	private String salesTaxAmount;
	@Schema(description = "Deductible Amount")
	private String deductibleAmount;
	@Schema(description = "Copay Amount")
	private String copayAmount;
	@Schema(description = "Coinsurance Amount")
	private String coinsuranceAmount;
	@Schema(description = "OutOfPocket Amount")
	private String outOfPocketAmount;
	@Schema(description = "Amount paid by member")
	private String memberPaidAmount;
	@Schema(description = "Plan paid amount")
	private String planPaidAmount;
	@Schema(description = "COB Indicator")
	private String cobIndicator;
	@Schema(description = "Amount paid for COB")
	private String cobPaidAmount;
	@Schema(description = "Check Number")
	private String checkNumber;
	@Schema(description = "Reason for adjustment")
	private String adjustmentReason;
	@Schema(description = "Type of adjustment")
	private String adjustmentType;
	@Schema(description = "Reject Count")
	private String rejectCount;
	@Schema(description = "Reject message 1")
	private String rejectMessage1;
	@Schema(description = "Reject message 2")
	private String rejectMessage2;
	@Schema(description = "Reject message 3")
	private String rejectMessage3;
	@Schema(description = "First Filled date")
	private String firstFilledDate;
//	Added as part of 3134
	@Schema(description = "Member Name")
	private String memberName;
	@Schema(description = "Provider Id")
	private String providerId;
	@Schema(description = "Provider Name")
	private String providerName;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
