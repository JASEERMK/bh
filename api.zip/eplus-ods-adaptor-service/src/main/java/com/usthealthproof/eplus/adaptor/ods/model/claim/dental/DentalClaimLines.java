package com.usthealthproof.eplus.adaptor.ods.model.claim.dental;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing dental claim lines details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DentalClaimLines implements Serializable, Comparable<DentalClaimLines> {

	private static final long serialVersionUID = 1754237386514643581L;

	@Schema(description = "Claim Line Id")
	private String claimLineNumber;
	@Schema(description = "Unique identifier of the dental claim")
	private String claimHccId;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Start date of the dental claim")
	private String serviceStartDate;
	@Schema(description = "Service Code Description")
	private String serviceCodeDescription;
	@Override
	public int compareTo(DentalClaimLines dentalClaimLines) {
		return this.getClaimLineNumber().compareTo(dentalClaimLines.getClaimLineNumber());
	}
}
