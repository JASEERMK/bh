package com.usthealthproof.eplus.adaptor.ods.model.authorization;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "serviceLineId", "serviceCode", "toothNo", "placeOfService", "units", "unitType", "serviceStartDate",
		"serviceEndDate", "determinationStatus", "statusReason", "authorizationComments", "serviceComments", "serviceExceptionComments"
		 })
@Data
@Schema(description = "Object for holding the Authorization line details results fields")
public class DentalAuthorizationLineDetailsResponse implements Serializable {

	private static final long serialVersionUID = 1316835281044597365L;

	@Schema(description = "Unique service Line ID for the particular services")
	@JsonProperty("serviceLineId")
	private String serviceLineId;

	@Schema(description = "Service Code & Description of the service undergone")
	@JsonProperty("serviceCode")
	private String serviceCode;

	@Schema(description = "Specified tooth number(s)")
	@JsonProperty("toothNo")
	private String toothNo;

	@Schema(description = "Place of Service where the service will be performed")
	@JsonProperty("placeOfService")
	private String placeOfService;

	@Schema(description = "Units")
	@JsonProperty("units")
	private String units;

	@Schema(description = "Type of unit. i.e., units, hours, days")
	@JsonProperty("unitType")
	private String unitType;

	@Schema(description = "Expected service start date")
	@JsonProperty("serviceStartDate")
	private String serviceStartDate;

	@Schema(description = "Expected service end date")
	@JsonProperty("serviceEndDate")
	private String serviceEndDate;

	@Schema(description = "Determination status of the auth service line")
	@JsonProperty("determinationStatus")
	private String determinationStatus;

	@Schema(description = "Explanation regarding the status. i.e., Met Criteria")
	@JsonProperty("statusReason")
	private String statusReason;

	@Schema(description = "Comments of the Authorizer")
	@JsonProperty("authorizationComments")
	private String authorizationComments;

	@Schema(description = "Service Comments")
	@JsonProperty("serviceComments")
	private String serviceComments;

	@Schema(description = "Service Exception Comments")
	@JsonProperty("serviceExceptionComments")
	private String serviceExceptionComments;

	@Schema(description = "To hold the errors", hidden = true)
	private List<String> errors;

	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
