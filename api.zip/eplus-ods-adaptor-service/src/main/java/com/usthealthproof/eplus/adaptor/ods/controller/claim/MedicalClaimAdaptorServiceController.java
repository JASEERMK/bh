package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import java.util.concurrent.ExecutionException;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.MedicalClaimService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Medical Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class MedicalClaimAdaptorServiceController {

	@Autowired
	private MedicalClaimService medicalClaimService;

	/**
	 * 1. Adaptor Service to get the claim details
	 *
	 * @param claimHccId
	 * @param claimFactKey
	 * @param httpServletRequest
	 * @return
	 * @throws Throwable
	 */
	@Operation(summary = "Medical Claim Details", description = "Details regarding Medical claims can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Medical claim details of the particular claim", content = {
					@Content(schema = @Schema(implementation = MedicalClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/medical", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<MedicalClaimDetails> getClaimDetails(
			@Parameter(description = "Claim Id", required = true) @RequestParam(value = OdsAdaptorServiceConstants.CLAIM_HCC_ID) String claimHccId,
			@Parameter(description = "Claim Fact Key", required = false) @RequestParam(value = "claimFactKey", required = false) String claimFactKey,
			HttpServletRequest httpServletRequest) throws Throwable {
		log.info("Inside getClaimDetails() of MedicalClaimAdaptorServiceController");
		log.debug("Inside getClaimDetails() of MedicalClaimAdaptorServiceController, service request received with claimHccId: {} & claimFactKey: {}", claimHccId, claimFactKey);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return medicalClaimService.getMspClaimDetails(claimHccId, claimFactKey, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return medicalClaimService.getClaimDetails(claimHccId, claimFactKey, accessToken);
		}
	}


	/**
	 * 2. Adaptor Service to get all claim lines of the particular claim
	 *
	 * @param claimHccId
	 * @param claimFactKey
	 * @param httpServletRequest
	 * @return
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws JsonProcessingException
	 */
	@Operation(summary = "Medical Claim Lines", description = "Service Lines information’s regarding Medical claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of all the medical claim lines of the claim", content = {
					@Content(schema = @Schema(implementation = MedicalClaimLinesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/medical/claimlines", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<MedicalClaimLinesResponse> getClaimLines(
			@Parameter(description = "Medical Claim Id", required = true) @RequestParam(value = OdsAdaptorServiceConstants.CLAIM_HCC_ID) String claimHccId,
			@Parameter(description = "Claim Fact Key", required = false) @RequestParam(value = "claimFactKey", required = false) String claimFactKey,
			HttpServletRequest httpServletRequest) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getClaimLines() of MedicalClaimAdaptorServiceController");
		log.debug("Inside getClaimLines() of MedicalClaimAdaptorServiceController, service request received with claimHccId= {}", claimHccId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return medicalClaimService.getMspClaimLines(claimHccId, claimFactKey, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return medicalClaimService.getClaimLines(claimHccId, claimFactKey, accessToken);
		}
	}

	/***
	 * 3. Adaptor Service to get specific claim line details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param claimFactKey
	 * @param httpServletRequest
	 * @return
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws JsonProcessingException
	 */
	@Operation(summary = "Medical Claim Line Details", description = "Service Line details regarding Medical claims, can be accessed through the specified service. Claim HCC ID and Claim Line HCC ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Medical claim line details of the particular claim", content = {
					@Content(schema = @Schema(implementation = MedicalClaimLineDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/medical/claimline", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<MedicalClaimLineDetailsResponse> getClaimLineDetails(
			@Parameter(description = "Medical Claim Id", required = true) @RequestParam(value = OdsAdaptorServiceConstants.CLAIM_HCC_ID) String claimHccId,
			@Parameter(description = "Medical Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") String claimLineHccId,
			@Parameter(description = "Claim Fact Key", required = false) @RequestParam(value = "claimFactKey", required = false) String claimFactKey,
			HttpServletRequest httpServletRequest) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getClaimLineDetails() of MedicalClaimAdaptorServiceController");
		log.debug("Inside getClaimLineDetails() of MedicalClaimAdaptorServiceController, service request received with claimHccID= {} claimLineHccId= {}", claimHccId,
				claimLineHccId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return medicalClaimService.getMspClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return medicalClaimService.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, accessToken);
		}
	}

}