package com.usthealthproof.eplus.adaptor.ods.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class ServiceUrlResponse implements Serializable {

    private static final long serialVersionUID = 6918701136545354896L;
    private String serviceName;
    private String serviceUrl;
}
