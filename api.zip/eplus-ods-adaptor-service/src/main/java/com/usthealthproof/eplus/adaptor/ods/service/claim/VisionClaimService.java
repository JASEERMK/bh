package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.VisionClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.mapper.VisionClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.*;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@Slf4j
public class VisionClaimService {

	@Autowired
	private VisionClaimData visionClaimData;

	@Autowired
	private DaoUtil daoUtil;

	@Autowired
	VisionClaimsResponseMapper visionClaimsResponseMapper;

	@Value("${service.name.claimServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	@Value("${service.uri.defaultState}")
	private String defaultState;

	public VisionClaimDetails getVisionClaimDetails(String claimHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getVisionClaimDetails() of VisionClaimService class");
		VisionClaimDetails visionClaimDetails = new VisionClaimDetails();
		try {
			CompletableFuture<VisionClaimDetails> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = visionClaimData.findVisionClaimId(serviceUrl, defaultContextPath + defaultState, claimHccId, null, null, null, accessToken);
			if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
				visionClaimsResponseMapper.visionClaimDetailsResponseMapper(visionClaimDetails, completableFuture);
			} else {
				List<String> visionClaimErrors = completableFuture.get().getErrors();
				if (visionClaimErrors != null && !visionClaimErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(visionClaimErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = visionClaimErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimDetails;
	}


	public VisionClaimLinesResponse getVisionClaimLines(String claimHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getVisionClaimLines() of VisionClaimService class");

		VisionClaimLinesResponse visionClaimLinesResponse = new VisionClaimLinesResponse();
		try {
			CompletableFuture<VisionClaimLinesResponse> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = visionClaimData.getVisionClaimLines(serviceUrl, defaultContextPath + defaultState, claimHccId,
					null, null, null, accessToken);

			List<VisionClaimLines> visionClaimLinesList = new ArrayList<>();
			if (completableFuture.get().getVisionClaimLines() != null
					&& !completableFuture.get().getVisionClaimLines().isEmpty()) {
				visionClaimLinesList.addAll(completableFuture.get().getVisionClaimLines());
			} else {
				List<String> visionClaimLinesErrors = completableFuture.get().getErrors();
				if (visionClaimLinesErrors != null && !visionClaimLinesErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(visionClaimLinesErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = visionClaimLinesErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
			visionClaimLinesResponse.setVisionClaimLines(visionClaimLinesList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimLinesResponse;
	}

	public VisionClaimLineDetailsResponse getVisionClaimLineDetails(String claimHccId, String claimLineHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getVisionClaimLineDetails() of VisionClaimService class");

		VisionClaimLineDetailsResponse visionClaimLineDetailsResponse = new VisionClaimLineDetailsResponse();
		try {
			CompletableFuture<VisionClaimLineDetailsResponse> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = visionClaimData.getVisionClaimLineDetails(serviceUrl,defaultContextPath + defaultState, claimHccId,
					claimLineHccId, null,null, null, accessToken);
			List<VisionClaimLineDetails> visionClaimLineDetailsList = new ArrayList<>();
			if (completableFuture.get().getVisionClaimLineDetails() != null
					&& !completableFuture.get().getVisionClaimLineDetails().isEmpty()) {
				visionClaimLineDetailsList.addAll(completableFuture.get().getVisionClaimLineDetails());
			} else {
				List<String> visionClaimLineDetailsErrors = completableFuture.get().getErrors();
				if (visionClaimLineDetailsErrors != null && !visionClaimLineDetailsErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(visionClaimLineDetailsErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = visionClaimLineDetailsErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
			visionClaimLineDetailsResponse.setVisionClaimLineDetails(visionClaimLineDetailsList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimLineDetailsResponse;
	}

	public VisionClaimDetails getMspVisionClaimDetails(String claimHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspVisionClaimDetails() of VisionClaimService class");

		VisionClaimDetails visionClaimDetails = new VisionClaimDetails();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<VisionClaimDetails>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<VisionClaimDetails> completableFuture = null;
				completableFuture = visionClaimData.findVisionClaimId(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			for (CompletableFuture<VisionClaimDetails> completableFuture : completableFutureList) {
				if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
					visionClaimsResponseMapper.visionClaimDetailsResponseMapper(visionClaimDetails, completableFuture);
				}
			}
			if (null == visionClaimDetails || StringUtils.isBlank(visionClaimDetails.getMemberId())) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				VisionClaimDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
		}catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimDetails;
	}

	public VisionClaimLinesResponse getMspVisionClaimLines(String claimHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspVisionClaimLines() of VisionClaimService class");

		VisionClaimLinesResponse visionClaimLinesResponse = new VisionClaimLinesResponse();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<VisionClaimLinesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<VisionClaimLinesResponse> completableFuture = null;
				completableFuture = visionClaimData.getVisionClaimLines(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
						state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			List<VisionClaimLines> visionClaimLinesList = new ArrayList<>();
			for (CompletableFuture<VisionClaimLinesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getVisionClaimLines() != null
						&& !completableFuture.get().getVisionClaimLines().isEmpty()) {
					visionClaimLinesList.addAll(completableFuture.get().getVisionClaimLines());
				}
			}
			if (null == visionClaimLinesList || visionClaimLinesList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				VisionClaimLinesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			visionClaimLinesResponse.setVisionClaimLines(visionClaimLinesList);
		}catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimLinesResponse;
	}

	public VisionClaimLineDetailsResponse getMspVisionClaimLineDetails(String claimHccId, String claimLineHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspVisionClaimLineDetails() of VisionClaimService class");

		VisionClaimLineDetailsResponse visionClaimLineDetailsResponse = new VisionClaimLineDetailsResponse();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<VisionClaimLineDetailsResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<VisionClaimLineDetailsResponse> completableFuture = null;
				completableFuture = visionClaimData.getVisionClaimLineDetails(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId,
						claimLineHccId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			List<VisionClaimLineDetails> visionClaimLineDetailsList = new ArrayList<>();
			for (CompletableFuture<VisionClaimLineDetailsResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getVisionClaimLineDetails() != null
						&& !completableFuture.get().getVisionClaimLineDetails().isEmpty()) {
					visionClaimLineDetailsList.addAll(completableFuture.get().getVisionClaimLineDetails());
				}
			}
			if (null == visionClaimLineDetailsList || visionClaimLineDetailsList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				VisionClaimLineDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
						.get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
				visionClaimLineDetailsResponse.setVisionClaimLineDetails(visionClaimLineDetailsList);
		}catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return visionClaimLineDetailsResponse;
	}

}