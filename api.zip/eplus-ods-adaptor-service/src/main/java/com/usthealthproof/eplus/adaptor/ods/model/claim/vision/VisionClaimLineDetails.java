package com.usthealthproof.eplus.adaptor.ods.model.claim.vision;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing vision claim line level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VisionClaimLineDetails implements Serializable, Comparable<VisionClaimLineDetails> {

	private static final long serialVersionUID = 1361922835507200377L;

	@Schema(description = "Claim Line Id")
	private String claimLineNumber;
	@Schema(description = "Unique identifier of the vision claim")
	private String claimHccId;
	@Schema(description = "Service code")
	private String codeDescription;
	@Schema(description = "Start date of the vision claim")
	private String serviceStartDate;
	@Schema(description = "Authorization number for vision claim")
	private String authorizationNumber;
	@Schema(description = "Service exception message")
	private String serviceException;
	@Schema(description = "Allowed amount")
	private String allowedAmount;
	@Schema(description = "Deductible amount")
	private String deductible;
	@Schema(description = "Copay computed")
	private String copay;
	@Schema(description = "Coinsurance computed")
	private String coinsurance;
	@Schema(description = "Over Max")
	private String overMax;
	@Schema(description = "Coordination of benefit  collected")
	private String cobAmount;
	@Schema(description = "Payment notes")
	private String paymentNotes;
	@Schema(description = "Billed Amount")
	private String billedAmount;

	@Override
	public int compareTo(VisionClaimLineDetails obj) {
		return this.getClaimLineNumber().compareTo(obj.getClaimLineNumber());
	}
}
