package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PharmacyAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PrescriberInformation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class PharmacyAuthService {

    @Autowired
    private AuthorizationData authorizationData;

    @Value("${service.name.authorizationServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public PharmacyAuthorizationDetailsResponse getPharmacyAuthorizationDetails(String authorizationId, HttpServletRequest httpServletRequest, String rxId) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getPharmacyAuthorizationDetails() of PharmacyAuthService");

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        PharmacyAuthorizationDetailsResponse pharmacyAuthorizationDetails = new PharmacyAuthorizationDetailsResponse();
        try {
            CompletableFuture<PharmacyAuthorizationDetailsResponse> completableFuture = null;
            List<CompletableFuture<PharmacyAuthorizationDetailsResponse>> completableFutureList = new ArrayList<>();
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getPharmacyAuthorizationDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationId, accessToken, rxId);
            completableFutureList.add(completableFuture);

            pharmacyAuthorizationDetails.setAuthId(completableFuture.get().getAuthId());
            pharmacyAuthorizationDetails.setMemberId(completableFuture.get().getMemberId());
            pharmacyAuthorizationDetails.setAuthStatus(completableFuture.get().getAuthStatus());
            pharmacyAuthorizationDetails.setRxId(completableFuture.get().getRxId());
            pharmacyAuthorizationDetails.setDiagnosisCodeDescription(completableFuture.get().getDiagnosisCodeDescription());
            pharmacyAuthorizationDetails.setDiagnosisCodeCategory(completableFuture.get().getDiagnosisCodeCategory());
            // Added as a part of CPB-4982
            pharmacyAuthorizationDetails.setDiagnosisCode(completableFuture.get().getDiagnosisCode());
            pharmacyAuthorizationDetails.setSource(completableFuture.get().getSource());
            pharmacyAuthorizationDetails.setDecisionerFirstName(completableFuture.get().getDecisionerFirstName());
            pharmacyAuthorizationDetails.setDecisionerLastName(completableFuture.get().getDecisionerLastName());
            pharmacyAuthorizationDetails.setAuthEffectiveDate(completableFuture.get().getAuthEffectiveDate());

            PrescriberInformation prescriberInformation = new PrescriberInformation();
            if (completableFuture.get().getPrescriberInfo() != null
                    && (completableFuture.get().getPrescriberInfo().getFirstName() != null)) {
                prescriberInformation.setFirstName(completableFuture.get().getPrescriberInfo().getFirstName());
                prescriberInformation.setLastName(completableFuture.get().getPrescriberInfo().getLastName());
                prescriberInformation.setAddress(completableFuture.get().getPrescriberInfo().getAddress());
                prescriberInformation.setState(completableFuture.get().getPrescriberInfo().getState());
                prescriberInformation.setCity(completableFuture.get().getPrescriberInfo().getCity());
                prescriberInformation.setZip(completableFuture.get().getPrescriberInfo().getZip());
                prescriberInformation.setFax(completableFuture.get().getPrescriberInfo().getFax());
                pharmacyAuthorizationDetails.setPrescriberInfo(prescriberInformation);
            }
            pharmacyAuthorizationDetails.setAuthReason(completableFuture.get().getAuthReason());
            pharmacyAuthorizationDetails.setAuthTerminationDate(completableFuture.get().getAuthTerminationDate());
            pharmacyAuthorizationDetails.setRequestor(completableFuture.get().getRequestor());
//          Added as part of API-291
            pharmacyAuthorizationDetails.setDrugName(completableFuture.get().getDrugName());
            pharmacyAuthorizationDetails.setAuthRequestedDate(completableFuture.get().getAuthRequestedDate());
            pharmacyAuthorizationDetails.setRequestType(completableFuture.get().getRequestType());
            pharmacyAuthorizationDetails.setDeterminationDate(completableFuture.get().getDeterminationDate());
            pharmacyAuthorizationDetails.setDeterminationDueDate(completableFuture.get().getDeterminationDueDate());
            pharmacyAuthorizationDetails.setNdc(completableFuture.get().getNdc());
            pharmacyAuthorizationDetails.setPharmacist(completableFuture.get().getPharmacist());
            pharmacyAuthorizationDetails.setQuantity(completableFuture.get().getQuantity());
            pharmacyAuthorizationDetails.setTechnician(completableFuture.get().getTechnician());
            pharmacyAuthorizationDetails.setUrgency(completableFuture.get().getUrgency());

            if (null != pharmacyAuthorizationDetails && StringUtils.isAllBlank(pharmacyAuthorizationDetails.getAuthId(),
                    pharmacyAuthorizationDetails.getMemberId())) {
                log.info("No results returned,");
                List<String> externalClaimErrors = completableFuture.get().getErrors();
                if (externalClaimErrors != null && !externalClaimErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(externalClaimErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = externalClaimErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        return pharmacyAuthorizationDetails;
    }
}
