package com.usthealthproof.eplus.adaptor.ods.model.claim.vision;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Response class containing vision claim line details")
public class VisionClaimLineDetailsResponse implements Serializable {

	private static final long serialVersionUID = -2305657041973938961L;
	@Schema(description = "List containing claim line level details of the vision claim")
	@JsonProperty("visionClaimLineDetailsList")
	private List<VisionClaimLineDetails> visionClaimLineDetails;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}
