package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment.ClaimAdjustmentResponse;
import com.usthealthproof.eplus.adaptor.ods.service.ClaimAdjustmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Claim Adjustment")
@RestController
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class ClaimAdjustmentAdaptorController {

	@Autowired
	private ClaimAdjustmentService claimAdjustmentService;

	/**
	 * 1. Adaptor service for Claim Adjustment service
	 *
	 * @param claimNumber
	 * @param claimFactKey
	 * @param previousClaimFactKey
	 * @param httpServletRequest
	 * @return ClaimAdjustmentResponse
	 * @throws Exception
	 */

	@Operation(summary = "Claim Adjustment Details", description = "Adjusted claim details can be retrieved through this service. The following search parameters can be used to find the adjusted claims: claim number, claim fact key and previous claim fact key. The claim number is required field among these. Both the claim fact key and previous claim fact key are completely optional fields. But, if the claim fact key is supplied with the request, the previous claim fact key has to be supplied, and vice versa.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Claim adjustment details", content = {
					@Content(schema = @Schema(implementation = ClaimAdjustmentResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/v1/adjustment/claim", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<ClaimAdjustmentResponse> getClaimAdjustment(
			@Parameter(description = "Claim Number", required = true) @RequestParam(value = "claimNumber") String claimNumber,
			@Parameter(description = "Claim FactKey", required = false) @RequestParam(value = "claimFactKey", required = false) String claimFactKey,
			@Parameter(description = "Previous Claim FactKey", required = false) @RequestParam(value = "previousClaimFactKey", required = false) String previousClaimFactKey,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getClaimAdjustment() of ClaimAdjustmentAdaptorController");
		log.debug("Inside getClaimAdjustment() of ClaimAdjustmentAdaptorController and the requests are -> claimNumber: {}, claimFactKey: {}, previousClaimFactKey: {}",
				claimNumber, claimFactKey, previousClaimFactKey);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return claimAdjustmentService.getMspClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return claimAdjustmentService.getClaimAdjustment(claimNumber, claimFactKey, previousClaimFactKey, accessToken);
		}
	}


}
