package com.usthealthproof.eplus.adaptor.ods.exception;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.ProblemDetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class IntegrationExceptionHandler {

	@Autowired
	private APIUtils apiUtils;

	/**
	 * Handles the request validation exceptions
	 *
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> invalidRequestHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException Occurred: {} , {} ", ex, ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(ex.getMessage(), OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles the response validation exceptions
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ResponseValidationException.class)
	public final ResponseEntity<ErrorResponse> invalidResponseHandler(ResponseValidationException ex, WebRequest request) {
		log.error("ResponseValidationException Occurred: {} , {} ", ex, ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(ex.getMessage(), OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	/**
	 * Handles the exception thrown by webClient for calling the external service
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(WebClientException.class)
	public final ResponseEntity<ErrorResponse> webclientExceptionHandler(HttpStatusCodeException ex, WebRequest request) {
		log.error("WebClientException Caught : {} , {}", ex, ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE, OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles the WebClientRequestException
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(WebClientRequestException.class)
	public final ResponseEntity<ErrorResponse> webclientRequestExceptionHandler(WebClientRequestException ex,
			WebRequest request) {
		log.error("WebClientRequestException Caught : {} , {}", ex, ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE, OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handles general exceptions
	 * 
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> globalExceptionHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : {} , {}", ex, ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE, OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles the WebClientResponseException
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(WebClientResponseException.class)
	public final ResponseEntity<ErrorResponse> webclientResponseExceptionHandler(WebClientResponseException ex,
			WebRequest request) {
		log.error("WebClientResponseException Caught : {} , {}", ex, ex.getMessage());

		ErrorResponse errorResponse = new ErrorResponse();
		try {
			if (404 == ex.getStatusCode().value()) {
				errorResponse.setProblemDetails(
						apiUtils.createProblemDetails(OdsAdaptorServiceConstants.NOT_FOUND, OdsAdaptorServiceConstants.FAILURE));
				return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
			} else if (503 == ex.getStatusCode().value()) {
				log.info("The called service is un-available. It may be down or some internal error occured.");
				errorResponse.setProblemDetails(apiUtils.createProblemDetails(OdsAdaptorServiceConstants.SERVICE_UNAVAILABLE,
						OdsAdaptorServiceConstants.FAILURE));
				return new ResponseEntity<>(errorResponse, ex.getStatusCode());
			} else if (StringUtils.isNotBlank(ex.getResponseBodyAsString())) {
				JSONObject error = new JSONObject(ex.getResponseBodyAsString());
				if (error.has("problemDetails")) {
					return new ResponseEntity<>(ex.getResponseBodyAs(ErrorResponse.class), ex.getStatusCode());
				} else if (error.has("error")) {
					errorResponse.setProblemDetails(
							apiUtils.createProblemDetails(error.getString("error"), OdsAdaptorServiceConstants.FAILURE));
					return new ResponseEntity<>(errorResponse, ex.getStatusCode());
				} else if (error.has("errors")) {
					ProblemDetails problemDetails = new ProblemDetails();
					JSONArray errors = error.getJSONArray("errors");
					List<String> parsedErrors = new ArrayList<>();
					for (int i = 0; i < errors.length(); i++) {
						parsedErrors.add(errors.getString(i));
					}
					problemDetails.setErrors(parsedErrors);
					problemDetails.setStatus(OdsAdaptorServiceConstants.FAILURE);
					errorResponse.setProblemDetails(problemDetails);
					return new ResponseEntity<>(errorResponse, ex.getStatusCode());
				}
			}
		} catch (Exception e) {
			log.info("The received error message can't convert into JSON object");
			if (503 == ex.getStatusCode().value()) {
				log.info("The called service is un-available. It may be down or some internal error occurred.");
				errorResponse.setProblemDetails(apiUtils.createProblemDetails(OdsAdaptorServiceConstants.SERVICE_UNAVAILABLE,
						OdsAdaptorServiceConstants.FAILURE));
				return new ResponseEntity<>(errorResponse, ex.getStatusCode());
			} else {
				errorResponse.setProblemDetails(apiUtils.createProblemDetails(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE,
						OdsAdaptorServiceConstants.FAILURE));
				return new ResponseEntity<>(errorResponse, ex.getStatusCode());
			}
		}
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(OdsAdaptorServiceConstants.EXCEPTION_MESSAGE, OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, ex.getStatusCode());
	}
	
	
	/**
	 * Handles ServiceNotAvailableException
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ODSAdaptorException.class)
	public final ResponseEntity<ErrorResponse> serviceNotAvailableExceptionHandler(ODSAdaptorException ex,
			WebRequest request) {
		log.error("ODSAdaptorException Occurred: {} , {} ", ex, ex.getMessage());

		int httpStatusCode = 500;
		String exceptionMessage = StringUtils.split(ex.getMessage(), "|")[0];
		if (StringUtils.split(ex.getMessage(), "|").length == 2) {
			httpStatusCode = Integer.parseInt(StringUtils.split(ex.getMessage(), "|")[1]);
		}

		String status = OdsAdaptorServiceConstants.FAILURE;
		if (404 == httpStatusCode) {
			status = OdsAdaptorServiceConstants.SUCCESS;
		}
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(apiUtils.createProblemDetails(exceptionMessage, status));
		return new ResponseEntity<>(errorResponse, HttpStatus.valueOf(httpStatusCode));

	}
	
	/**
	 * Exception Handler for handling Missing mandatory fields in the request
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<ErrorResponse> missingServletRequestParameterException(MissingServletRequestParameterException ex,
			WebRequest request) {
		log.error("MissingServletRequestParameterException Caught. Error Message: {} and Exception: ", ex.getMessage(), ex);

		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(ex.getMessage(), OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling the invalid URL's
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoResourceFoundException.class)
	public final ResponseEntity<ErrorResponse> noResourceFoundException(NoResourceFoundException ex, WebRequest request) {
		log.error("NoResourceFoundException Caught.  Error Message: {} and Exception: ", ex.getMessage(), ex);

		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(
				apiUtils.createProblemDetails(OdsAdaptorServiceConstants.INVALID_REQUEST_URL, OdsAdaptorServiceConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
}
