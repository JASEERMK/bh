package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.service.MemberPoaService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetails;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class MemberPOAAdaptorServiceController {

    @Autowired
    private MemberPoaService memberPoaService;

    /**
     * 1. Adaptor service for Member Responsible Party (POA) service using path
     * param
     *
     * @param memberId
     * @param httpServletRequest
     * @return MemberPOADetails
     * @throws Exception
     */

    @Operation(summary = "Retrieves Member POA details", description = "Service will retrieve the Power of Attorney(POA) details of the member. The request field that can be used to retrieve the POA details is the member ID, and it must be provided correctly.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "List of Power of Attorney's(POA) of the member", content = {
                    @Content(schema = @Schema(implementation = MemberPOADetails.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = "/v1/member/poa/details/{memberId}", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<MemberPOADetails> getPOADetails(@PathVariable("memberId") String memberId,
                                                          HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getPOADetails() of MemberPOAAdaptorServiceController");
        log.debug("Inside getPOADetails() of MemberPOAAdaptorServiceController and the requests: MemberId: {}", memberId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return memberPoaService.getMspMemberPoaDetails(memberId, userIdentities, accessToken);
        } else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return memberPoaService.getMemberPoaDetails(memberId, accessToken);
        }
    }
}
