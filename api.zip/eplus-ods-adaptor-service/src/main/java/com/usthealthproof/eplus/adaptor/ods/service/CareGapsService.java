package com.usthealthproof.eplus.adaptor.ods.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.CareGapsData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetails;
import com.usthealthproof.eplus.adaptor.ods.model.careGaps.CareGapsDetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class CareGapsService {
    @Autowired
    private CareGapsData careGapsData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.careGapServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<CareGapsDetails> getMspCareGapsDetails(String memberId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspCareGapsDetails() of CareGapsService class");

        CareGapsDetails careGapsDetails = new CareGapsDetails();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<CareGapsDetails>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<CareGapsDetails> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = careGapsData.getMemberCareGapsDetails(serviceUrl, defaultContextPath + multiStateContextPath,
                        memberId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<CareGapsDetailsList> careGapsDetailsLists = new ArrayList<>();
            for (CompletableFuture<CareGapsDetails> completableFuture : completableFutureList) {
                if (completableFuture.get().getCareGapsDetailsList() != null
                        && !completableFuture.get().getCareGapsDetailsList().isEmpty()) {
                    careGapsDetailsLists.addAll(completableFuture.get().getCareGapsDetailsList());
                }
            }
            if (null == careGapsDetailsLists || careGapsDetailsLists.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                CareGapsDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            careGapsDetails.setCareGapsDetailsList(careGapsDetailsLists);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Care Gap Response");
        return new ResponseEntity<>(careGapsDetails, HttpStatus.OK);
    }

    public ResponseEntity<CareGapsDetails> getCareGapsDetails(String memberId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getCareGapsDetails() of CareGapsService class");

        CareGapsDetails careGapsDetails = new CareGapsDetails();
        try {
            CompletableFuture<CareGapsDetails> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = careGapsData.getMemberCareGapsDetails(serviceUrl, defaultContextPath + defaultState, memberId, null,
                    null, null, accessToken);
            if (completableFuture.get().getCareGapsDetailsList() != null
                    && !completableFuture.get().getCareGapsDetailsList().isEmpty()) {
                careGapsDetails.setCareGapsDetailsList(completableFuture.get().getCareGapsDetailsList());
            } else {
                List<String> careGapErrors = completableFuture.get().getErrors();
                if (careGapErrors != null && !careGapErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(careGapErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = careGapErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Care Gap Response");
        return new ResponseEntity<>(careGapsDetails, HttpStatus.OK);
    }
}