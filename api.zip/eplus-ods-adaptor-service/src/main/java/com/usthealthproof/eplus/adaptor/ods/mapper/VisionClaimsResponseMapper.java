package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class VisionClaimsResponseMapper {

    public void visionClaimDetailsResponseMapper(VisionClaimDetails visionClaimDetails, CompletableFuture<VisionClaimDetails> completableFuture) throws InterruptedException, ExecutionException {
        log.info("Inside visionClaimDetailsResponseMapper()");

        visionClaimDetails.setMemberId(completableFuture.get().getMemberId());
        visionClaimDetails.setInsureId(completableFuture.get().getInsureId());
        visionClaimDetails.setInsurerName(completableFuture.get().getInsurerName());
        visionClaimDetails.setProviderId(completableFuture.get().getProviderId());
        visionClaimDetails.setProviderName(completableFuture.get().getProviderName());
        visionClaimDetails.setFromDate(completableFuture.get().getFromDate());
        visionClaimDetails.setEndDate(completableFuture.get().getEndDate());
        visionClaimDetails.setLocationId(completableFuture.get().getLocationId());
        visionClaimDetails.setLocationName(completableFuture.get().getLocationName());
        visionClaimDetails.setPayeeId(completableFuture.get().getPayeeId());
        visionClaimDetails.setPayeeName(completableFuture.get().getPayeeName());
        visionClaimDetails.setNetworkId(completableFuture.get().getNetworkId());
        visionClaimDetails.setNetworkName(completableFuture.get().getNetworkName());
        visionClaimDetails.setReceivedDate(completableFuture.get().getReceivedDate());
        visionClaimDetails.setEnteredDate(completableFuture.get().getEnteredDate());
        visionClaimDetails.setPaymentDate(completableFuture.get().getPaymentDate());
        visionClaimDetails.setCheckNumber(completableFuture.get().getCheckNumber());
        visionClaimDetails.setPaidAmount(completableFuture.get().getPaidAmount());
        visionClaimDetails.setNetPaidAmount(completableFuture.get().getNetPaidAmount());
        visionClaimDetails.setBilledAmount(completableFuture.get().getBilledAmount());
        visionClaimDetails.setAllowedAmount(completableFuture.get().getAllowedAmount());
        visionClaimDetails.setDeductibleAmount(completableFuture.get().getDeductibleAmount());
        visionClaimDetails.setCopayAmount(completableFuture.get().getCopayAmount());
        visionClaimDetails.setCoinsuranceAmount(completableFuture.get().getCoinsuranceAmount());
        visionClaimDetails.setOverMax(completableFuture.get().getOverMax());
        visionClaimDetails.setCobAmount(completableFuture.get().getCobAmount());
        visionClaimDetails.setOriginalPaidAmount(completableFuture.get().getOriginalPaidAmount());
        visionClaimDetails.setPaymentStatus(completableFuture.get().getPaymentStatus());
        visionClaimDetails.setPayMember(completableFuture.get().getPayMember());
        visionClaimDetails.setPaymentNotes(completableFuture.get().getPaymentNotes());
        visionClaimDetails.setPaymentAmount(completableFuture.get().getPaymentAmount());
        visionClaimDetails.setEftFlag(completableFuture.get().getEftFlag());
        visionClaimDetails.setEftAccount(completableFuture.get().getEftAccount());
        visionClaimDetails.setCheckCleared(completableFuture.get().getCheckCleared());
        visionClaimDetails.setCreatedBy(completableFuture.get().getCreatedBy());
        visionClaimDetails.setLastModifiedBy(completableFuture.get().getLastModifiedBy());
        visionClaimDetails.setMemberName(completableFuture.get().getMemberName());
    }
}
