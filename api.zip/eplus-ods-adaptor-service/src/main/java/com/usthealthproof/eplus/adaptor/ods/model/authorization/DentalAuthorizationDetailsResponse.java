
package com.usthealthproof.eplus.adaptor.ods.model.authorization;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "authorizationId", "memberId", "requestingProviderId", "requestingProviderName", "status", "requestDate",
		"authorizationReason", "determinationDate", "determinationTurnAroundTime", "statusReason", "requestor", "performingProviderId",
		"performingProviderName", "urgency", "authorizationType", "serviceType", "source", "determinationDueDate", "authorizationOwner",
		"authorizationAge", "authorizationComments", "serviceComments", "serviceExceptionComments"})
@Data
@Schema(description = "Object for holding the Authorization details results fields")
public class DentalAuthorizationDetailsResponse implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "Authorization ID")
	@JsonProperty("authorizationId")
	private String authorizationId;
	@Schema(description = "Member ID")
	@JsonProperty("memberId")
	private String memberId;
	@Schema(description = "Name of provider requesting the authorization")
	@JsonProperty("requestingProviderName")
	private String requestingProviderName;
	@Schema(description = "ID of provider requesting the authorization")
	@JsonProperty("requestingProviderId")
	private String requestingProviderId;
	@Schema(description = "Status of the authorization")
	@JsonProperty("status")
	private String status;
	@Schema(description = "Requested date MM/DD/YYYY")
	@JsonProperty("requestDate")
	private String requestDate;
	@Schema(description = "Reason for the authorization")
	@JsonProperty("authorizationReason")
	private String authorizationReason;
	@Schema(description = "Date Determination was made")
	@JsonProperty("determinationDate")
	private String determinationDate;
	@Schema(description = "Determination turn around time")
	@JsonProperty("determinationTurnAroundTime")
	private String determinationTurnAroundTime;
	@Schema(description = "Explanation regarding the determination status. i.e., Met Criteria")
	@JsonProperty("statusReason")
	private String statusReason;
	@Schema(description = "Who is requesting the authorization, i.e., Provider, Member, Member Beneficiary")
	@JsonProperty("requestor")
	private String requestor;
	@Schema(description = "ID of the provider performing the service")
	@JsonProperty("performingProviderId")
	private String performingProviderId;
	@Schema(description = "Name of the provider performing the service")
	@JsonProperty("performingProviderName")
	private String performingProviderName;
	@Schema(description = "Urgency. i.e., Standard, Expedited")
	@JsonProperty("urgency")
	private String urgency;
	@Schema(description = "Type of authorization")
	@JsonProperty("authorizationType")
	private String authorizationType;
	@Schema(description = "Type of service")
	@JsonProperty("serviceType")
	private String serviceType;
	@Schema(description = "Source")
	@JsonProperty("source")
	private String source;
	@Schema(description = "Calculated date based on Urgency and Received Date")
	@JsonProperty("determinationDueDate")
	private String determinationDueDate;
	@Schema(description = "Owner of the Authorization")
	@JsonProperty("authorizationOwner")
	private String authorizationOwner;
	@Schema(description = "Age of the Authorizer")
	@JsonProperty("authorizationAge")
	private String authorizationAge;
	@Schema(description = "Comments of the Authorizer")
	@JsonProperty("authorizationComments")
	private String authorizationComments;
	@Schema(description = "Service Comments")
	@JsonProperty("serviceComments")
	private String serviceComments;
	@Schema(description = "Service Exception Comments")
	@JsonProperty("serviceExceptionComments")
	private String serviceExceptionComments;

	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}



