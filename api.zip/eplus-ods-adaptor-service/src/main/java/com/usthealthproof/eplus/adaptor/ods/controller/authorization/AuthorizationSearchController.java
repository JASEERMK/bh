package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.mapper.AuthorizationSearchRequestMapper;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.service.auth.AuthorizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Authorization Search Services")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/auths")
@SecurityRequirement(name = "OdsAdaptorService")
public class AuthorizationSearchController {

    @Autowired
    private AuthorizationService authorizationService;

    @Autowired
    private AuthorizationSearchRequestMapper authorizationSearchRequestMapper;

    /**
     *  Adaptor service for Member Authorization Search service
     *
     * @param memberNumber
     * @param authorizationId
     * @param type
     * @param status
     * @param searchStartDate
     * @param searchEndDate
     * @param httpServletRequest
     * @return
     * @throws Exception
     */
    @GetMapping(value = "/member/search")
    @Operation(summary = "Member Authorizations Search", description = "A member's authorizations can be retrieved through this service; depending on the filter conditions, all the member's authorizations will be returned as a response. This API allows us to search for authorizations in three separate categories: medical, dental, and pharmacy.The following search parameters can be used to find member's authorizations: member number, authorization id, authorization type, status, authorization request start and end dates. The member number and authorization type are required fields among these. Besides that, there are other conditional necessary cases that we need to pass, that is for Medical and Dental authorizations, the authorization request start and end dates if the authorization id is not provided. Furthermore, we can use the status parameter in the filters for the medical and dental search however we see appropriate; it is entirely optional. And the status filter is not applicable for Pharmacy authorization search. The member number, authorization type, and date fields are possible request fields for pharmacy authorization. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Member Authorization Search Details", content = {
                    @Content(schema = @Schema(implementation = AuthorizationSearchResponseList.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @ResponseBody
    public ResponseEntity<AuthorizationSearchResponseList> getMemberAuthSearchDetails(
            @Parameter(description = "Member Number", required = true) @RequestParam(value = "memberNumber") String memberNumber,
            @Parameter(description = "Authorization ID") @RequestParam(value = "authorizationId", required = false) String authorizationId,
            @Parameter(description = "Type") @RequestParam(value = "type", required = false) String type,
            @Parameter(description = "Status") @RequestParam(value = "status", required = false) String status,
            @Parameter(description = "Authorization Search Start Date") @RequestParam(value = "searchStartDate", required = false) String searchStartDate,
            @Parameter(description = "Authorization Search End Date") @RequestParam(value = "searchEndDate", required = false) String searchEndDate,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getMemberAuthSearchDetails() of AuthorizationSearchController");
        log.debug("Inside getMemberAuthSearchDetails() of AuthorizationSearchController and the requests: MemberNumber : {}, AuthorizationID: {}, Type: {}, Status:{}, SearchStartDate:{}, SearchEndDate: {}",
                memberNumber, authorizationId, type, status, searchStartDate, searchEndDate);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        AuthorizationSearchRequest authorizationSearchRequest = authorizationSearchRequestMapper.authorizationSearchRequestMapper(null, authorizationId, memberNumber, status, type, searchStartDate, searchEndDate);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            authorizationSearchRequest.setUserIdentities(userIdentities);
            return authorizationService.getMspMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationService.getMemberAuthSearchDetails(authorizationSearchRequest, accessToken);
        }
    }

    /**
     *  Adaptor service for Provider Authorization Search service
     *
     * @param providerId
     * @param authorizationId
     * @param memberNumber
     * @param status
     * @param type
     * @param searchStartDate
     * @param searchEndDate
     * @param selectedSlp
     * @param isMatchingUserRole
     * @param httpServletRequest
     * @return
     * @throws Exception
     */
    @Operation(summary = "Provider Authorizations Search", description = "A provider's authorizations can be retrieved through this service; depending on the filter conditions, all the provider's authorizations will be returned as a response. The following search parameters can be used to find the authorizations of a provider: provider id, authorization id, member number, status, authorization type, authorization request start and end dates. The provider id and authorization type are required fields among these. The remaining fields are optional; based on their availability, they will be used as filters. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Provider Authorization Search Details", content = {
                    @Content(schema = @Schema(implementation = AuthorizationSearchResponseList.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/provider/search", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<AuthorizationSearchResponseList> getProviderAuthSearchDetails(
            @Parameter(description = "Provider ID", required = true) @RequestParam(value = "providerId") String providerId,
            @Parameter(description = "Authorization ID") @RequestParam(value = "authorizationId", required = false) String authorizationId,
            @Parameter(description = "Member Number") @RequestParam(value = "memberNumber", required = false) String memberNumber,
            @Parameter(description = "Status") @RequestParam(value = "status", required = false) String status,
            @Parameter(description = "Type") @RequestParam(value = "type", required = false) String type,
            @Parameter(description = "Authorization Search Start Date") @RequestParam(value = "searchStartDate", required = false) String searchStartDate,
            @Parameter(description = "Authorization Search End Date") @RequestParam(value = "searchEndDate", required = false) String searchEndDate,
            @Parameter(description = "Selected user role", hidden = false) @RequestParam(value = "selectedSlp", required = false) String selectedSlp,
            @Parameter(description = "Is user role available in the request", hidden = false) @RequestParam(value = "isMatchingUserRole", required = false) String isMatchingUserRole,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getProviderAuthSearchDetails() of AuthorizationSearchController");
        log.debug("Inside getProviderAuthSearchDetails() of AuthorizationSearchController and the requests: ProviderID: {}, AuthorizationID: {}, MemberNumber : {}, Status : {}, Type: {},  SearchStartDate:{}, SearchEndDate: {}, SelectedSlp: {}, IsMatchingUserRole: {}",
                providerId, authorizationId, memberNumber, status, type, searchStartDate, searchEndDate, selectedSlp, isMatchingUserRole);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        AuthorizationSearchRequest authorizationSearchRequest = authorizationSearchRequestMapper.authorizationSearchRequestMapper(providerId, authorizationId, memberNumber, status, type, searchStartDate, searchEndDate);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            if (StringUtils.isNotBlank(selectedSlp) && StringUtils.isNotBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "true")) {
                authorizationSearchRequest.setUserIdentities(selectedSlp);
                authorizationSearchRequest.setIsMatchingUserRole(isMatchingUserRole);
                return authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
            } else if (StringUtils.isNotBlank(selectedSlp) && StringUtils.isNotEmpty(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "false")) {
                authorizationSearchRequest.setUserIdentities(selectedSlp);
                return authorizationService.providerAuthDataAvailabilityCheck(authorizationSearchRequest, accessToken);
            } else {
                authorizationSearchRequest.setUserIdentities(userIdentities);
                authorizationSearchRequest.setIsMatchingUserRole(isMatchingUserRole);
                return authorizationService.getMspProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
            }
        }
        else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return authorizationService.getProviderAuthSearchDetails(authorizationSearchRequest, accessToken);
        }
    }
}
