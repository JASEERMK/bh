package com.usthealthproof.eplus.adaptor.ods.service.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class AuthorizationService {

    @Autowired
    private AuthorizationData authorizationData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.authorizationServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<AuthorizationDetailsResponse> getMspAuthorizationDetails(String authorizationId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspAuthorizationDetails() of AuthorizationService class");

        AuthorizationDetailsResponse authorizationDetailsResponse = new AuthorizationDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<AuthorizationDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<AuthorizationDetailsResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = authorizationData.getAuthorizationDetails(serviceUrl, defaultContextPath + multiStateContextPath,
                        authorizationId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<AuthorizationDetailsResponse> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getAuthorizationId())) {
                    authorizationDetailsResponse = setAuthDetailsResponse(completableFuture);
                }
            }
            if (null != authorizationDetailsResponse && StringUtils.isAllBlank(
                    authorizationDetailsResponse.getAuthorizationId(), authorizationDetailsResponse.getMemberId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                AuthorizationDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(), errorResponse.getError(), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Details Response");
        return new ResponseEntity<>(authorizationDetailsResponse, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationDetailsResponse> getAuthorizationDetails(String authorizationId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getAuthorizationDetails() of AuthorizationService class");

        AuthorizationDetailsResponse authorizationDetailsResponse = new AuthorizationDetailsResponse();
        CompletableFuture<AuthorizationDetailsResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getAuthorizationDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationId, null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getAuthorizationId())) {
                authorizationDetailsResponse = setAuthDetailsResponse(completableFuture);
            }
            if (completableFuture.get().getError() != null && !completableFuture.get().getError().isEmpty()) {
                log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                String exceptionMessage = completableFuture.get().getError() + "|"
                        + completableFuture.get().getHttpStatusCode();
                throw new ODSAdaptorException(exceptionMessage);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Details Response");
        return new ResponseEntity<>(authorizationDetailsResponse, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationLinesResponseList> getMspAuthorizationLines(String authorizationId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspAuthorizationLines() of AuthorizationService class");

        AuthorizationLinesResponseList authorizationLinesResponseList = new AuthorizationLinesResponseList();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<AuthorizationLinesResponseList>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<AuthorizationLinesResponseList> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = authorizationData.getAuthorizationLines(serviceUrl, defaultContextPath + multiStateContextPath,
                        authorizationId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<AuthorizationLinesResponse> authorizationLinesResponses = new ArrayList<>();
            for (CompletableFuture<AuthorizationLinesResponseList> completableFuture : completableFutureList) {
                if (completableFuture.get().getAuthorizationLines() != null
                        && !completableFuture.get().getAuthorizationLines().isEmpty()) {
                    authorizationLinesResponses.addAll(completableFuture.get().getAuthorizationLines());
                }
            }
            if (null == authorizationLinesResponses || authorizationLinesResponses.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                AuthorizationLinesResponseList errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            authorizationLinesResponseList.setAuthorizationLines(authorizationLinesResponses);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Lines Response");
        return new ResponseEntity<>(authorizationLinesResponseList, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationLinesResponseList> getAuthorizationLines(String authorizationId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getAuthorizationLines() of AuthorizationService class");

        AuthorizationLinesResponseList authorizationLinesResponseList = new AuthorizationLinesResponseList();
        CompletableFuture<AuthorizationLinesResponseList> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getAuthorizationLines(serviceUrl, defaultContextPath + defaultState, authorizationId,
                    null, null, null, accessToken);
            if (completableFuture.get().getAuthorizationLines() != null
                    && !completableFuture.get().getAuthorizationLines().isEmpty()) {
                authorizationLinesResponseList.setAuthorizationLines(completableFuture.get().getAuthorizationLines());
            } else {
                List<String> authErrors = completableFuture.get().getErrors();
                if (authErrors != null && !authErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage;
                    if (StringUtils.isBlank(authErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = authErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Lines Response");
        return new ResponseEntity<>(authorizationLinesResponseList, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationLineDetailsResponse> getMspAuthorizationLineDetails(String authorizationId, String serviceLineId, String serviceStartDate, String procedureCode, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspAuthorizationLineDetails() of AuthorizationService class");

        AuthorizationLineDetailsResponse authorizationLineDetailsResponse = new AuthorizationLineDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<AuthorizationLineDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<AuthorizationLineDetailsResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = authorizationData.getAuthorizationLineDetails(serviceUrl,
                        defaultContextPath + multiStateContextPath, authorizationId, serviceLineId, serviceStartDate,
                        procedureCode, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<AuthorizationLineDetailsResponse> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getServiceLineId())) {
                    authorizationLineDetailsResponse = setAuthLineDetailsResponse(completableFuture);
                }
            }
            if (null != authorizationLineDetailsResponse
                    && StringUtils.isAllBlank(authorizationLineDetailsResponse.getServiceLineId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                AuthorizationLineDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Line Details Response");
        return new ResponseEntity<>(authorizationLineDetailsResponse, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationLineDetailsResponse> getAuthorizationLineDetails(String authorizationId, String serviceLineId, String serviceStartDate, String procedureCode, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getAuthorizationLineDetails() of AuthorizationService class");

        AuthorizationLineDetailsResponse authorizationLineDetailsResponse = new AuthorizationLineDetailsResponse();
        CompletableFuture<AuthorizationLineDetailsResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getAuthorizationLineDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationId, serviceLineId, serviceStartDate, procedureCode, null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getServiceLineId())) {
                authorizationLineDetailsResponse = setAuthLineDetailsResponse(completableFuture);
            }
            List<String> authErrors = completableFuture.get().getErrors();
            if (authErrors != null && !authErrors.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                String exceptionMessage;
                if (StringUtils.isBlank(authErrors.get(0))) {
                    exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                } else {
                    exceptionMessage = authErrors.get(0) + "|"
                            + completableFuture.get().getHttpStatusCode();
                }
                throw new ODSAdaptorException(exceptionMessage);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Line Details Response");
        return new ResponseEntity<>(authorizationLineDetailsResponse, HttpStatus.OK);
    }

    private AuthorizationLineDetailsResponse setAuthLineDetailsResponse(CompletableFuture<AuthorizationLineDetailsResponse> completableFuture) throws InterruptedException, ExecutionException {
        AuthorizationLineDetailsResponse authorizationLineDetailsResponse = new AuthorizationLineDetailsResponse();
        authorizationLineDetailsResponse.setServiceLineId(completableFuture.get().getServiceLineId());
        authorizationLineDetailsResponse.setProcedureCode(completableFuture.get().getProcedureCode());
        authorizationLineDetailsResponse.setPlaceOfService(completableFuture.get().getPlaceOfService());
        authorizationLineDetailsResponse.setDeterminationStatus(completableFuture.get().getDeterminationStatus());
        authorizationLineDetailsResponse.setDenialReason(completableFuture.get().getDenialReason());
        authorizationLineDetailsResponse.setServiceDateStart(completableFuture.get().getServiceDateStart());
        authorizationLineDetailsResponse.setRequestedUnits(completableFuture.get().getRequestedUnits());
        authorizationLineDetailsResponse.setDeniedUnits(completableFuture.get().getDeniedUnits());
        authorizationLineDetailsResponse.setDecisionDate(completableFuture.get().getDecisionDate());
        authorizationLineDetailsResponse.setDecisionStatus(completableFuture.get().getDecisionStatus());
        authorizationLineDetailsResponse.setModifiers(completableFuture.get().getModifiers());
        authorizationLineDetailsResponse.setServiceDateEnd(completableFuture.get().getServiceDateEnd());
        authorizationLineDetailsResponse.setApprovedUnits(completableFuture.get().getApprovedUnits());
        authorizationLineDetailsResponse.setUnitType(completableFuture.get().getUnitType());
        authorizationLineDetailsResponse.setDecisionStatusCode(completableFuture.get().getDecisionStatusCode());
        authorizationLineDetailsResponse
                .setPerformingProviderId(completableFuture.get().getPerformingProviderId());
        authorizationLineDetailsResponse
                .setPerformingProviderName(completableFuture.get().getPerformingProviderName());
        authorizationLineDetailsResponse.setUrgency(completableFuture.get().getUrgency());
        authorizationLineDetailsResponse.setReferralCategory(completableFuture.get().getReferralCategory());
        authorizationLineDetailsResponse.setReferralDesc(completableFuture.get().getReferralDesc());
        authorizationLineDetailsResponse.setAuthorizationType(completableFuture.get().getAuthorizationType());
        authorizationLineDetailsResponse.setStatusReason(completableFuture.get().getStatusReason());
        authorizationLineDetailsResponse.setReimbursementMethod(completableFuture.get().getReimbursementMethod());
        authorizationLineDetailsResponse.setAmount(completableFuture.get().getAmount());
        authorizationLineDetailsResponse.setFlatFeeType(completableFuture.get().getFlatFeeType());
        authorizationLineDetailsResponse.setPercentageBilled(completableFuture.get().getPercentageBilled());
        authorizationLineDetailsResponse.setServiceSetNote(completableFuture.get().getServiceSetNote());
//        Added as part of API-673
        authorizationLineDetailsResponse.setServiceType(completableFuture.get().getServiceType());
        authorizationLineDetailsResponse.setDiagnosisCodeAndDescription(completableFuture.get().getDiagnosisCodeAndDescription());
        authorizationLineDetailsResponse.setDiagnosisCategory(completableFuture.get().getDiagnosisCategory());
        authorizationLineDetailsResponse.setMedicationCode(completableFuture.get().getMedicationCode());
        authorizationLineDetailsResponse.setMedicationStrength(completableFuture.get().getMedicationStrength());
//        Added as part of API-704
        authorizationLineDetailsResponse.setDeterminationDate(completableFuture.get().getDeterminationDate());
        return authorizationLineDetailsResponse;
    }

    private AuthorizationDetailsResponse setAuthDetailsResponse(CompletableFuture<AuthorizationDetailsResponse> completableFuture) throws InterruptedException, ExecutionException {
        AuthorizationDetailsResponse authorizationDetailsResponse = new AuthorizationDetailsResponse();
        authorizationDetailsResponse.setAuthorizationId(completableFuture.get().getAuthorizationId());
        authorizationDetailsResponse.setMemberId(completableFuture.get().getMemberId());
        authorizationDetailsResponse.setDeterminationStatus(completableFuture.get().getDeterminationStatus());
        authorizationDetailsResponse.setRequestedDate(completableFuture.get().getRequestedDate());
        authorizationDetailsResponse.setAuthorizationReason(completableFuture.get().getAuthorizationReason());
        authorizationDetailsResponse.setRequestor(completableFuture.get().getRequestor());
        authorizationDetailsResponse
                .setRequestingProviderName(completableFuture.get().getRequestingProviderName());
        authorizationDetailsResponse.setRequestingProviderId(completableFuture.get().getRequestingProviderId());
        authorizationDetailsResponse.setAuthOwner(completableFuture.get().getAuthOwner());
        authorizationDetailsResponse.setSupplierName(completableFuture.get().getSupplierName());
        authorizationDetailsResponse.setSupplierId(completableFuture.get().getSupplierId());
        authorizationDetailsResponse.setFacilityProviderName(completableFuture.get().getFacilityProviderName());
        authorizationDetailsResponse.setAdmittingProviderName(completableFuture.get().getAdmittingProviderName());
        authorizationDetailsResponse
                .setPerformingProviderName(completableFuture.get().getPerformingProviderName());
        authorizationDetailsResponse.setSource(completableFuture.get().getSource());
        return authorizationDetailsResponse;
    }

    public ResponseEntity<AuthorizationSearchResponseList> getMspMemberAuthSearchDetails(
            AuthorizationSearchRequest authorizationSearchRequest, String accessToken)
            throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspProviderAuthSearchDetails() in the AuthorizationService class");
        log.debug("Inside getMspMemberAuthSearchDetails() in the Service class for authorizationSearchRequest {} & accessToken: {}",
                authorizationSearchRequest, accessToken);

        AuthorizationSearchResponseList authorizationSearchResponses = new AuthorizationSearchResponseList();
        try {
            CompletableFuture<AuthorizationSearchResponseList> completableFutures = null;
            List<CompletableFuture<AuthorizationSearchResponseList>> completableFutureList = new ArrayList<>();
            if (StringUtils.equalsIgnoreCase(OdsAdaptorServiceConstants.PHARMACY_AUTH_TYPE,  authorizationSearchRequest.getType())) {
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
                completableFutures = authorizationData.getMemberAuthSearchDetails(serviceUrl, defaultContextPath + defaultState,
                        authorizationSearchRequest.getMemberNumber(), authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getType(), authorizationSearchRequest.getStatus(), authorizationSearchRequest.getSearchStartDate(), authorizationSearchRequest.getSearchEndDate(), null, null, null,
                        accessToken);
                completableFutureList.add(completableFutures);
            } else {
                completableFutureList = getAuthSearchResponse(authorizationSearchRequest, accessToken, null);
            }

            authorizationSearchResponses.setResults(getAuthSearchResponseList(completableFutureList, null, "memberSearch"));
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Search Response");
        return new ResponseEntity<>(authorizationSearchResponses, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationSearchResponseList> getMemberAuthSearchDetails(
            AuthorizationSearchRequest authorizationSearchRequest, String accessToken)
            throws InterruptedException, ExecutionException {
        log.info("Inside getMemberAuthSearchDetails() in the Service class for authorizationSearchRequest {} & accessToken: {}",
                authorizationSearchRequest, accessToken);

        AuthorizationSearchResponseList authorizationSearchResponses = new AuthorizationSearchResponseList();
        CompletableFuture<AuthorizationSearchResponseList> completableFutures = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFutures = authorizationData.getMemberAuthSearchDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationSearchRequest.getMemberNumber(), authorizationSearchRequest.getAuthorizationId(),
                    authorizationSearchRequest.getType(), authorizationSearchRequest.getStatus(),
                    authorizationSearchRequest.getSearchStartDate(), authorizationSearchRequest.getSearchEndDate(), null, null,
                    null, accessToken);
            if (completableFutures.get().getResults() != null && !completableFutures.get().getResults().isEmpty()) {
                authorizationSearchResponses.setResults(completableFutures.get().getResults());
            }
            errorAuthHandling(completableFutures);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization search Response");
        return new ResponseEntity<>(authorizationSearchResponses, HttpStatus.OK);
    }

    public ResponseEntity<AuthorizationSearchResponseList> getMspProviderAuthSearchDetails(
            AuthorizationSearchRequest authorizationSearchRequest,
            String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspProviderAuthSearchDetails() in the AuthorizationService class");
        log.debug("Inside getMspProviderAuthSearchDetails() in the Service class for authorizationSearchRequest: {} & accessToken: {}",
                authorizationSearchRequest, accessToken);

        AuthorizationSearchResponseList authorizationSearchResponses = new AuthorizationSearchResponseList();
        CompletableFuture<AuthorizationSearchResponseList> completableFutures = null;
        String searchType = "provider" ;
        try {
            List<CompletableFuture<AuthorizationSearchResponseList>> completableFutureList = new ArrayList<>();
            if (StringUtils.equalsIgnoreCase(OdsAdaptorServiceConstants.DEFAULT_AUTH_TYPE, authorizationSearchRequest.getType())) {
                completableFutureList = getAuthSearchResponse(authorizationSearchRequest, accessToken, searchType);
            } else {
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
                completableFutures = authorizationData.getProviderAuthSearchDetails(serviceUrl, defaultContextPath + defaultState,
                        authorizationSearchRequest.getProviderId(), authorizationSearchRequest.getMemberNumber(),
                        authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getType(),
                        authorizationSearchRequest.getStatus(), authorizationSearchRequest.getSearchStartDate(),
                        authorizationSearchRequest.getSearchEndDate(), null, null, null, accessToken);
                completableFutureList.add(completableFutures);
            }
            authorizationSearchResponses.setResults(getAuthSearchResponseList(completableFutureList, authorizationSearchRequest.getIsMatchingUserRole() , "providerSearch"));
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Provider Search Response");
        return new ResponseEntity<>(authorizationSearchResponses, HttpStatus.OK);
    }

    private List<AuthorizationSearchResponse> getAuthSearchResponseList(List<CompletableFuture<AuthorizationSearchResponseList>> completableFutureList, String isMatchingUserRole, String authSearchType) throws InterruptedException, ExecutionException, JsonProcessingException {
        List<AuthorizationSearchResponse> authorizationSearchResponseList = new ArrayList<>();
        for (CompletableFuture<AuthorizationSearchResponseList> completableFuture : completableFutureList) {
            if (completableFuture.get().getResults() != null && !completableFuture.get().getResults().isEmpty()) {
                authorizationSearchResponseList.addAll(completableFuture.get().getResults());
            }
        }
        if (null == authorizationSearchResponseList || authorizationSearchResponseList.isEmpty()) {
            log.info(OdsAdaptorServiceConstants.NO_DATA);
            AuthorizationSearchResponseList errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                    .get();
            if (errorResponse.getHttpStatusCode() == 404 && StringUtils.isNotBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "true")) {
                throw new ODSAdaptorException(OdsAdaptorServiceConstants.NO_DATA + "|404");
            } else if (errorResponse.getHttpStatusCode() == 404 && StringUtils.isBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(authSearchType, "providerSearch")){
                throw new ODSAdaptorException(OdsAdaptorServiceConstants.DATA_NOT_FOUND + "|404");
            } else {
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        }
        return authorizationSearchResponseList;
    }

    public ResponseEntity<AuthorizationSearchResponseList> getProviderAuthSearchDetails(
            AuthorizationSearchRequest authorizationSearchRequest, String accessToken)
            throws InterruptedException, ExecutionException {
        log.info("Inside getProviderAuthSearchDetails() in the AuthorizationService class");
        log.debug("Inside getProviderAuthSearchDetails() in the Service class for authorizationSearchRequest: {} & accessToken: {}",
                authorizationSearchRequest, accessToken);

        AuthorizationSearchResponseList authorizationSearchResponses = new AuthorizationSearchResponseList();
        CompletableFuture<AuthorizationSearchResponseList> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = authorizationData.getProviderAuthSearchDetails(serviceUrl, defaultContextPath + defaultState,
                    authorizationSearchRequest.getProviderId(), authorizationSearchRequest.getMemberNumber(),
                    authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getType(),
                    authorizationSearchRequest.getStatus(), authorizationSearchRequest.getSearchStartDate(),
                    authorizationSearchRequest.getSearchEndDate(), null, null, null, accessToken);
            if (completableFuture.get().getResults() != null && !completableFuture.get().getResults().isEmpty()) {
                authorizationSearchResponses.setResults(completableFuture.get().getResults());
            }
            errorAuthHandling(completableFuture);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Authorization Provider Search Response");
        return new ResponseEntity<>(authorizationSearchResponses, HttpStatus.OK);
    }

    private void errorAuthHandling(CompletableFuture<AuthorizationSearchResponseList> completableFutures) throws InterruptedException, ExecutionException {
        if (completableFutures.get().getErrors() != null && !completableFutures.get().getErrors().isEmpty()) {
            log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
            String exceptionMessage = null;
            if (StringUtils.isBlank(completableFutures.get().getErrors().get(0))) {
                exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
            } else {
                exceptionMessage = completableFutures.get().getErrors().get(0) + "|"
                        + completableFutures.get().getHttpStatusCode();
            }
            throw new ODSAdaptorException(exceptionMessage);
        }
    }

    private List<CompletableFuture<AuthorizationSearchResponseList>> getAuthSearchResponse(AuthorizationSearchRequest authorizationSearchRequest, String accessToken, String searchType) throws InterruptedException {
        String state;
        String lob;
        String product;
        CompletableFuture<AuthorizationSearchResponseList> completableFutures;
        List<CompletableFuture<AuthorizationSearchResponseList>> completableFutureList = new ArrayList<>();
        Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(authorizationSearchRequest.getUserIdentities());
        for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
            String multiStateContextPath = slp.getValue();
            List<String> slpData = Arrays.asList(slp.getKey().split(":"));
            state = !slpData.isEmpty() ? slpData.get(0) : "";
            lob = slpData.size() > 1 ? slpData.get(1) : "";
            product = slpData.size() > 2 ? slpData.get(2) : "";
            log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
            if (!StringUtils.equalsIgnoreCase(OdsAdaptorServiceConstants.PROVIDER_SEARCH_TYPE,searchType)) {
                completableFutures = authorizationData.getMemberAuthSearchDetails(serviceUrl,
                        defaultContextPath + multiStateContextPath, authorizationSearchRequest.getMemberNumber(), authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getType(), authorizationSearchRequest.getStatus(),
                        authorizationSearchRequest.getSearchStartDate(), authorizationSearchRequest.getSearchEndDate(), state, lob, product, accessToken);
                completableFutureList.add(completableFutures);
            } else {
                completableFutures = authorizationData.getProviderAuthSearchDetails(serviceUrl,
                        defaultContextPath + multiStateContextPath, authorizationSearchRequest.getProviderId(), authorizationSearchRequest.getMemberNumber(), authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getType(), authorizationSearchRequest.getStatus(),
                        authorizationSearchRequest.getSearchStartDate(), authorizationSearchRequest.getSearchEndDate(), state, lob, product, accessToken);
                completableFutureList.add(completableFutures);
            }
        }
        return completableFutureList;
    }

    public ResponseEntity<AuthorizationSearchResponseList> providerAuthDataAvailabilityCheck(
            AuthorizationSearchRequest authorizationSearchRequest, String accessToken)
            throws JsonProcessingException {
        log.info("Inside providerAuthDataAvailabilityCheck() in the AuthorizationService class");
        log.debug("Inside providerAuthDataAvailabilityCheck() in the Service class for authorizationSearchRequest: {} &  accessToken: {}",
                authorizationSearchRequest, accessToken);

        AuthorizationSearchResponseList authorizationSearchResponseList = new AuthorizationSearchResponseList();
        Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(authorizationSearchRequest.getUserIdentities());
        for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
            String multiStateContextPath = slp.getValue();
            List<String> slpData = Arrays.asList(slp.getKey().split(":"));
            String state = !slpData.isEmpty() ? slpData.get(0) : "";
            String lob = slpData.size() > 1 ? slpData.get(1) : "";
            String product = slpData.size() > 2 ? slpData.get(2) : "";
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
            authorizationSearchResponseList = authorizationData.providerAuthDataAvailabilityCheck(serviceUrl,
                    defaultContextPath + multiStateContextPath, authorizationSearchRequest.getProviderId(),
                    authorizationSearchRequest.getAuthorizationId(), authorizationSearchRequest.getMemberNumber(),
                    authorizationSearchRequest.getStatus(), authorizationSearchRequest.getType(),
                    authorizationSearchRequest.getSearchStartDate(), authorizationSearchRequest.getSearchEndDate(), state, lob,
                    product, accessToken);
            if (authorizationSearchResponseList.getErrors() != null && !authorizationSearchResponseList.getErrors().isEmpty()) {
                throw new WebClientResponseException(authorizationSearchResponseList.getHttpStatusCode(),
                        StringUtils.join(authorizationSearchResponseList.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(authorizationSearchResponseList), null);
            } else if (StringUtils.equalsIgnoreCase(authorizationSearchResponseList.getDataAvailabilityFlag(), "true")) {
                log.info(OdsAdaptorServiceConstants.NOT_APPROPRIATE_QUEUE);
                throw new ResponseValidationException(OdsAdaptorServiceConstants.NOT_APPROPRIATE_QUEUE);
            } else {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                throw new ResponseValidationException(OdsAdaptorServiceConstants.NO_DATA);
            }
        }
        log.info("Successfully completed provider auth search available check");
        return new ResponseEntity<>(authorizationSearchResponseList, HttpStatus.OK);
    }
}


