package com.usthealthproof.eplus.adaptor.ods.model.claimAdjustment;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Response class containing Claim Adjustment details")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClaimAdjustmentResponse {

	@Schema(description = "Collection to hold Claim Adjusted response fields")
	private List<ClaimAdjustmentModel> adjustedFieldList;
	@Schema(description = "Request Id")
	private String requestId;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
