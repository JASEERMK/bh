package com.usthealthproof.eplus.adaptor.ods.model.claim.search;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Component
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Wrapper class containing response of claim search details")
public class ClaimHeaderSearchRequest implements Serializable {

	private static final long serialVersionUID = -1481835782815922754L;

	@Schema(description = "Claim types")
	private String claimTypes;

	@Schema(description = "Claim number")
	private String claimNumber;

	@Schema(description = "Service from date")
	private String serviceFromDate;

	@Schema(description = "Service to date")
	private String serviceToDate;

	@Schema(description = "Member number")
	private String memberNumber;

	@Schema(description = " Claim Status")
	private String claimStatus;

	@Schema(description = " Provider Id")
	private String providerId;

	@Schema(description = " Provider Id Type ")
	private String providerIdType;

	//Added as part of cpb-4243
	@Schema(description = "Service Code")
	private String serviceCode;

	@Schema(description = "Diagnosis Code")
	private String diagnosisCode;

}
