package com.usthealthproof.eplus.adaptor.ods.model.carePrograms;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response class containing Care Program details of Member")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CareProgramsDetails implements Serializable {

	private static final long serialVersionUID = 1281928897938784983L;

	@Schema(description = "Collection of Member's Care Program")
	private List<CareProgram> carePrograms;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
