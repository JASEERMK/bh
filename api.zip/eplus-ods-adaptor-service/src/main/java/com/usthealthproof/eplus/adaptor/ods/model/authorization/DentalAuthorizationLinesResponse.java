
package com.usthealthproof.eplus.adaptor.ods.model.authorization;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "serviceLineId", "serviceCode", "placeOfService", "determinationStatus"})
@Data
@Schema(description = "Object for holding the Authorization lines results fields")
public class DentalAuthorizationLinesResponse implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "Unique service Line ID for the particular services")
	@JsonProperty("serviceLineId")
	private String serviceLineId;

	@Schema(description = "ServiceCode & Description of the service undergone")
	@JsonProperty("serviceCode")
	private String serviceCode;

	@Schema(description = "Place of Service where the service will be performed")
	@JsonProperty("placeOfService")
	private String placeOfService;

	@Schema(description = "Determination status of the auth service line")
	@JsonProperty("determinationStatus")
	private String determinationStatus;

}
