package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.ServiceUrlResponse;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;


@Component
public class ServiceUrlMapper implements RowMapper<ServiceUrlResponse> {

    @Override
    public ServiceUrlResponse mapRow(ResultSet rs, int i) throws SQLException {

        ServiceUrlResponse serviceUrlResponse = new ServiceUrlResponse();
        serviceUrlResponse.setServiceName(rs.getString("service_name"));
        serviceUrlResponse.setServiceUrl(rs.getString("service_url"));

        return serviceUrlResponse;
    }
}
