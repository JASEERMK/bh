package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ClaimSearchData {

	public static final String PROVIDER_CLAIM_SEARCH = "/v1/claims/provider/claimSearch";

	public static final String MEMBER_CLAIM_SEARCH = "/v1/claims/member/claimSearch";

	public static final String PROVIDER_DATA_CHECK = "/v1/claims/provider/claimSearch/isAvailable";

	public static final String CLAIM_NUMBER = "claimNumber";

	public static final String SERVICE_FROM_DATE = "serviceFromDate";

	public static final String SERVICE_TO_DATE = "serviceToDate";

	public static final String CLAIM_STATUS = "claimStatus";

	public static final String MEMBER_NUMBER = "memberNumber";

	public static final String SERVICE_CODE = "serviceCode";

	public static final String DIAGNOSIS_CODE = "diagnosisCode";

	public static final String CLAIM_TYPES = "claimTypes";
	public static final String PROVIDER_ID = "providerId";
	public static final String PROVIDER_TYPE = "providerType";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async
	public CompletableFuture<ClaimHeaderSearchResponse> getMemberClaimSearch(String serviceUrl, String contextPath, String claimTypes,
			String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber,
			String state, String lob, String product, String accessToken, String serviceCode, String diagnosisCode ) {
		log.info("Inside getMemberClaimSearch() of ClaimSearchData class");
		log.debug("Inside getMemberClaimSearch() of ClaimSearchData class and the requests are- contextPath: {} & accesstoken: {}",
				contextPath, accessToken);

		ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEMBER_CLAIM_SEARCH);
				claimHeaderSearchResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEMBER_CLAIM_SEARCH)
								.queryParam(CLAIM_TYPES, claimTypes)
								.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
								.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
								.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
								.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
								.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
								.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEMBER_CLAIM_SEARCH)
						.queryParam(CLAIM_TYPES, claimTypes)
						.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
						.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
						.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
						.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
						.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
						.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				claimHeaderSearchResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
				}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);

			claimHeaderSearchResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			claimHeaderSearchResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getMemberClaimSearch() completed");
		return CompletableFuture.completedFuture(claimHeaderSearchResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<ClaimHeaderSearchResponse> getProviderClaimSearch(String serviceUrl, String contextPath, String providerId,
			String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate,
			String claimStatus, String memberNumber, String state, String lob, String product, String accessToken, String serviceCode, String diagnosisCode) {
		log.info("Inside getProviderClaimSearch() of ClaimSearchData class");
		log.debug("Inside getProviderClaimSearch() in the ClaimSearchData class and the requests are- contextPath: {} & accesstoken: {}",
				contextPath, accessToken);

		ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + PROVIDER_CLAIM_SEARCH);
				claimHeaderSearchResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + PROVIDER_CLAIM_SEARCH)
								.queryParamIfPresent(PROVIDER_ID, Optional.ofNullable(providerId))
								.queryParamIfPresent(PROVIDER_TYPE, Optional.ofNullable(providerType))
								.queryParam(CLAIM_TYPES, claimTypes)
								.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
								.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
								.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
								.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
								.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
								.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + PROVIDER_CLAIM_SEARCH)
						.queryParamIfPresent(PROVIDER_ID, Optional.ofNullable(providerId))
						.queryParamIfPresent(PROVIDER_TYPE, Optional.ofNullable(providerType))
						.queryParam(CLAIM_TYPES, claimTypes)
						.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
						.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
						.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
						.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
						.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
						.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				claimHeaderSearchResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);

			claimHeaderSearchResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			claimHeaderSearchResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getProviderClaimSearch() completed");
		return CompletableFuture.completedFuture(claimHeaderSearchResponse);
	}

	public ClaimHeaderSearchResponse providerClaimDataAvailabilityCheck(String serviceUrl, String contextPath, String providerId, String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String state, String lob, String product, String serviceCode, String diagnosisCode, String accessToken) {
		log.info("Inside providerClaimDataAvailabilityCheck() of ClaimSearchData class");
		log.debug("Inside providerClaimDataAvailabilityCheck() in the ClaimSearchData class and the requests are- contextPath: {} & accesstoken: {}",
				contextPath, accessToken);
		ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + PROVIDER_DATA_CHECK);
				claimHeaderSearchResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + PROVIDER_DATA_CHECK)
								.queryParamIfPresent(PROVIDER_ID, Optional.ofNullable(providerId))
								.queryParamIfPresent(PROVIDER_TYPE, Optional.ofNullable(providerType))
								.queryParam(CLAIM_TYPES, claimTypes)
								.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
								.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
								.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
								.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
								.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
								.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + PROVIDER_DATA_CHECK)
						.queryParamIfPresent(PROVIDER_ID, Optional.ofNullable(providerId))
						.queryParamIfPresent(PROVIDER_TYPE, Optional.ofNullable(providerType))
						.queryParam(CLAIM_TYPES, claimTypes)
						.queryParamIfPresent(CLAIM_NUMBER, Optional.ofNullable(claimNumber))
						.queryParamIfPresent(SERVICE_FROM_DATE, Optional.ofNullable(serviceFromDate))
						.queryParamIfPresent(SERVICE_TO_DATE, Optional.ofNullable(serviceToDate))
						.queryParamIfPresent(CLAIM_STATUS, Optional.ofNullable(claimStatus))
						.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.queryParamIfPresent(SERVICE_CODE, Optional.ofNullable(serviceCode))
						.queryParamIfPresent(DIAGNOSIS_CODE, Optional.ofNullable(diagnosisCode)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				claimHeaderSearchResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(ClaimHeaderSearchResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);

			claimHeaderSearchResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			claimHeaderSearchResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("providerClaimDataAvailabilityCheck() completed");
		return claimHeaderSearchResponse;
	}
}