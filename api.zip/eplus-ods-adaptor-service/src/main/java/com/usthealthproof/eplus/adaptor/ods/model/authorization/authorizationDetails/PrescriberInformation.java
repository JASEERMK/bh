
package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "firstName", "lastName", "address", "city", "state", "zip", "fax", "phone" })
@Data
@Schema(description = "Object for holding the Authorization details results fields")
public class PrescriberInformation implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "Prescribing provider’s first name")
	@JsonProperty("firstName")
	private String firstName;

	@Schema(description = "Prescribing provider’s Last name")
	@JsonProperty("lastName")
	private String lastName;

	@Schema(description = "Prescribing provider’s address")
	@JsonProperty("address")
	private String address;

	@Schema(description = "Prescribing provider’s city")
	@JsonProperty("city")
	private String city;

	@Schema(description = "Prescribing provider’s state")
	@JsonProperty("state")
	private String state;

	@Schema(description = "Prescribing provider’s zip code")
	@JsonProperty("zip")
	private String zip;

	@Schema(description = "Prescribing provider’s fax")
	@JsonProperty("fax")
	private String fax;

	@Schema(description = "Prescriber Phone")
	@JsonProperty("phone")
	private String phone;

}
