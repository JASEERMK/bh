package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.service.claim.PharmacyClaimService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Pharmacy Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class PharmacyClaimAdaptorServiceController {

	@Autowired
	private PharmacyClaimService rxClaimDetailsService;

	/**
	 * 1. Adaptor service to get Rx claim details
	 *
	 * @param claimHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */

	@GetMapping(value = "/rx", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Pharmacy Claim Details", description = "Details regarding Pharmacy claims can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Pharmacy claim details of the particular claim", content = {
					@Content(schema = @Schema(implementation = RxClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<RxClaimDetails> getRxClaimDetails(
			@Parameter(description = "Pharmacy Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getRxClaimDetails() of PharmacyClaimAdaptorServiceController");
		log.debug("Rx claim detail service request received with claimHccId= {}", claimHccId);

		RxClaimDetails rxClaimDetails;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			rxClaimDetails = rxClaimDetailsService.getMspRxClaimDetails(claimHccId, userIdentities, accessToken);
		} else {
			rxClaimDetails = rxClaimDetailsService.getRxClaimDetails(claimHccId, accessToken);
		}
		return new ResponseEntity<>(rxClaimDetails, HttpStatus.OK);
	}

}
