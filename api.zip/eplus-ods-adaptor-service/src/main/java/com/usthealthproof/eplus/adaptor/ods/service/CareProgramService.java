package com.usthealthproof.eplus.adaptor.ods.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.CareProgramData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.carePrograms.CareProgram;
import com.usthealthproof.eplus.adaptor.ods.model.carePrograms.CareProgramsDetails;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class CareProgramService {

    @Autowired
    private CareProgramData careProgramData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.careGapServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<CareProgramsDetails> getCareProgramsDetails(String memberId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getCareProgramsDetails() of CareProgramService class");

        CareProgramsDetails careProgramsDetails = new CareProgramsDetails();
        CompletableFuture<CareProgramsDetails> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = careProgramData.getMemberCareProgramsDetails(serviceUrl, defaultContextPath + defaultState, memberId,
                    null, null, null, accessToken);
            if (completableFuture.get().getCarePrograms() != null && !completableFuture.get().getCarePrograms().isEmpty()) {
                careProgramsDetails.setCarePrograms(completableFuture.get().getCarePrograms());
            } else {
                List<String> careProgramErrors = completableFuture.get().getErrors();
                if (careProgramErrors != null && !careProgramErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(careProgramErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = careProgramErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Care Program Response");
        return new ResponseEntity<>(careProgramsDetails, HttpStatus.OK);
    }

    public ResponseEntity<CareProgramsDetails> getMspCareProgramsDetails(String memberId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getCareProgramsDetails() of CareProgramService class");

        CareProgramsDetails careProgramsDetails = new CareProgramsDetails();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<CareProgramsDetails>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<CareProgramsDetails> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = careProgramData.getMemberCareProgramsDetails(serviceUrl,
                        defaultContextPath + multiStateContextPath, memberId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<CareProgram> careProgramDetailsLists = new ArrayList<>();
            for (CompletableFuture<CareProgramsDetails> completableFuture : completableFutureList) {
                if (completableFuture.get().getCarePrograms() != null
                        && !completableFuture.get().getCarePrograms().isEmpty()) {
                    careProgramDetailsLists.addAll(completableFuture.get().getCarePrograms());
                }
            }
            if (null == careProgramDetailsLists || careProgramDetailsLists.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                CareProgramsDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors()), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            careProgramsDetails.setCarePrograms(careProgramDetailsLists);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Care Program Response");
        return new ResponseEntity<>(careProgramsDetails, HttpStatus.OK);
    }
}