package com.usthealthproof.eplus.adaptor.ods.model.carePrograms;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing Member's Care Program details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CareProgram implements Serializable {

	private static final long serialVersionUID = -1018884697183728500L;

	@Schema(description = "Care Program Name")
	private String careProgramName;
	@Schema(description = "Member Name")
	private String memberName;
	@Schema(description = "Care Program ID")
	private String careProgramId;
	@Schema(description = "Care Team Name")
	private String careTeamName;
	@Schema(description = "Start Date")
	private String startDate;
	@Schema(description = "End Date")
	private String endDate;
	@Schema(description = "Status")
	private String status;
}
