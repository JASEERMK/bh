package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class PharmacyClaimData {

	public static final String CLAIMS_RX = "/v1/claims/rx";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async("asyncExecutor")
	public CompletableFuture<RxClaimDetails> findRxClaimId(String serviceUrl, String contextPath, String claimHccId, String state, String lob, String product, String accessToken) {
		log.info("Inside findRxClaimId() of PharmacyClaimData");
		log.debug("Inside findRxClaimId() of PharmacyClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		RxClaimDetails rxClaimDetails = new RxClaimDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + CLAIMS_RX);
				rxClaimDetails = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + CLAIMS_RX).queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(RxClaimDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + CLAIMS_RX)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				rxClaimDetails = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(RxClaimDetails.class).block();
			}
		}catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			rxClaimDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			rxClaimDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("findRxClaimId() completed");
		return CompletableFuture.completedFuture(rxClaimDetails);
	}
}