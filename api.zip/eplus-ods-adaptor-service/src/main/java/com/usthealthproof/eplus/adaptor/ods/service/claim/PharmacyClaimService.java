package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.PharmacyClaimData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.mapper.PharmacyClaimsResponseMapper;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.adaptor.ods.model.claim.pharmacy.RxClaimDetails;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@Slf4j
public class PharmacyClaimService {

	@Autowired
	private PharmacyClaimData pharmacyClaimData;

	@Autowired
	private DaoUtil daoUtil;

	@Autowired
	PharmacyClaimsResponseMapper pharmacyClaimsResponseMapper;

	@Value("${service.name.claimServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	@Value("${service.uri.defaultState}")
	private String defaultState;


	public RxClaimDetails getRxClaimDetails(String claimHccId, String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getRxClaimDetails() of PharmacyClaimService class");

		RxClaimDetails rxClaimDetails = new RxClaimDetails();
		try {
			CompletableFuture<RxClaimDetails> completableFuture = null;
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName+ ":" + defaultState);
			completableFuture = pharmacyClaimData.findRxClaimId(serviceUrl,defaultContextPath + defaultState, claimHccId, null, null, null, accessToken);
			if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
				pharmacyClaimsResponseMapper.pharmacyClaimDetailsResponseMapper(rxClaimDetails, completableFuture);
			} else {
				List<String> medicalClaimErrors = completableFuture.get().getErrors();
				if (medicalClaimErrors != null && !medicalClaimErrors.isEmpty()) {
					log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
					String exceptionMessage = null;
					if (StringUtils.isBlank(medicalClaimErrors.get(0))) {
						exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
					} else {
						exceptionMessage = medicalClaimErrors.get(0) + "|"
								+ completableFuture.get().getHttpStatusCode();
					}
					throw new ODSAdaptorException(exceptionMessage);
				}
			}
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return rxClaimDetails;
	}



	public RxClaimDetails getMspRxClaimDetails(String claimHccId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
		log.info("Inside getMspRxClaimDetails() of PharmacyClaimService class");

		RxClaimDetails rxClaimDetails = new RxClaimDetails();
		try {
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<RxClaimDetails>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				String state = !slpData.isEmpty() ? slpData.get(0) : "";
				String lob = slpData.size() > 1 ? slpData.get(1) : "";
				String product = slpData.size() > 2 ? slpData.get(2) : "";
				log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<RxClaimDetails> completableFuture = null;
				completableFuture = pharmacyClaimData.findRxClaimId(serviceUrl, defaultContextPath + multiStateContextPath, claimHccId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}
			for (CompletableFuture<RxClaimDetails> completableFuture : completableFutureList) {
				if (StringUtils.isNotBlank(completableFuture.get().getMemberId())) {
					pharmacyClaimsResponseMapper.pharmacyClaimDetailsResponseMapper(rxClaimDetails, completableFuture);
				}
			}
			if (null == rxClaimDetails || StringUtils.isBlank(rxClaimDetails.getMemberId())) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				RxClaimDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return rxClaimDetails;
	}

}