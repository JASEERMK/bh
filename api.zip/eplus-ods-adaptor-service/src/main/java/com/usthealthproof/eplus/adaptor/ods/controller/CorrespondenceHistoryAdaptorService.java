package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.service.CorrespondenceHistoryService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponseList;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Correspondence History Service")
@RestController
@RequestMapping("/v2/correspondence")
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class CorrespondenceHistoryAdaptorService {

	@Autowired
	private CorrespondenceHistoryService correspondenceHistoryService;

	/**
	 * 1. Adaptor service to get the correspondence details of a member
	 *
	 * @param memberId
	 * @param correspondenceName
	 * @param createdFrom
	 * @param createdTo
	 * @param claimId
	 * @return CorrespondenceDetailsList
	 * @throws Exception
	 */
	@Operation(summary = "Retrieves the member's correspondences", description = "The correspondence records of a member will be retrieved by the service. The following search parameters can be used to find the correspondence records of a member: member ID, correspondence name, claim ID, created from and created to date fields. The member ID, correspondence name and claim ID/date fields are the required fields among these. The remaining fields are optional; based on their availability, they will be used as filters. Additionally, it does not permit searching using just one date field; both the from and to date fields must be provided if data to be retrieved based on date filters.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of Correspondence details of a member", content = {
					@Content(schema = @Schema(implementation = CorrespondenceSearchResponseList.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/search", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<CorrespondenceSearchResponseList> getCorrespondenceSearch(
			@Parameter(description = "Member ID", required = true) @RequestParam(value = "memberId") String memberId,
			@Parameter(description = "Correspondence Name", required = true) @RequestParam(value = "correspondenceName") String correspondenceName,
			@Parameter(description = "Created From", required = false) @RequestParam(value = "createdFrom", required = false) String createdFrom,
			@Parameter(description = "Created To", required = false) @RequestParam(value = "createdTo", required = false) String createdTo,
			@Parameter(description = "Claim ID", required = false) @RequestParam(value = "claimId", required = false) String claimId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getCorrespondenceSearch() of CorrespondenceHistoryAdaptorService");
		log.debug("Inside getCorrespondenceSearch() in CorrespondenceHistoryAdaptorService  and the request is >> memberId: {}, correspondenceName: {}, createdFrom: {}, createdTo: {}, claimId: {}",
				memberId, correspondenceName, createdFrom, createdTo, claimId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return correspondenceHistoryService.getMspCorrespondenceSearch(memberId, correspondenceName, createdFrom, createdTo, claimId, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return correspondenceHistoryService.getCorrespondenceSearch(memberId, correspondenceName, createdFrom, createdTo, claimId, accessToken);
		}
	}

	/**
	 * 2. Adaptor service to get the correspondence details based on the
	 * correspondence Id
	 *
	 * @param correspondenceId
	 * @return CorrespondenceDetailsResponse
	 * @throws Exception
	 */
	@Operation(summary = "Retrieves the correspondence details", description = "The service will gather and provide comprehensive information about the correspondence. Correspondence ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Correspondence details of the correspondence Id", content = {
					@Content(schema = @Schema(implementation = CorrespondenceDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/details", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<CorrespondenceDetailsResponse> getCorrespondenceDetails(
			@Parameter(description = "Correspondence ID", required = true) @RequestParam(value = "correspondenceId") String correspondenceId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getCorrespondenceDetails() of CorrespondenceHistoryAdaptorService");
		log.debug("Inside getCorrespondenceDetails() in CorrespondenceHistoryAdaptorService  and the request is >> correspondenceId: {}", correspondenceId);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return correspondenceHistoryService.getMspCorrespondenceDetails(correspondenceId, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return correspondenceHistoryService.getCorrespondenceDetails(correspondenceId, accessToken);
		}
	}
}