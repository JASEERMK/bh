package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(value = Include.NON_EMPTY)
@Schema(description = "Object for holding the Authorization Notes")
public class AuthorizationNotes implements Serializable {

	private static final long serialVersionUID = 4171957900823091847L;

	@Schema(description = "authorizationId")
	private String authorizationId;

	@Schema(description = "Note Date")
	private String noteDate;

	@Schema(description = "Note Type")
	private String noteType;

	@Schema(description = "Note Text")
	private String noteText;

}
