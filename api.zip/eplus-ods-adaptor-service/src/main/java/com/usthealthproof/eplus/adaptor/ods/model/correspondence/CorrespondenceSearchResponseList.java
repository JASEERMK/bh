package com.usthealthproof.eplus.adaptor.ods.model.correspondence;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class containing list of correspondence details")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "correspondenceList", "problemDetails", "requestId" })
public class CorrespondenceSearchResponseList implements Serializable {

	private static final long serialVersionUID = 3133405993372548374L;

	@Schema(description = "List to hold the correspondence search results")
	private List<CorrespondenceSearchResponse> correspondenceList;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
