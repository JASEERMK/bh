package com.usthealthproof.eplus.adaptor.ods.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.MemberPOAData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetails;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class MemberPoaService {
    @Autowired
    private MemberPOAData memberPOAData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.memberPoaServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<MemberPOADetails> getMspMemberPoaDetails(String memberId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspMemberPoaDetails() of MemberPoaService class");

        MemberPOADetails memberPOADetailsResponse = new MemberPOADetails();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<MemberPOADetails>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<MemberPOADetails> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = memberPOAData.getMemberPoaDetails(serviceUrl, defaultContextPath + multiStateContextPath, memberId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }
            List<MemberPOADetailsList> memberPOADetailsList = new ArrayList<>();
            for (CompletableFuture<MemberPOADetails> completableFuture : completableFutureList) {
                if (completableFuture.get().getMemberPOADetailsList() != null && !completableFuture.get().getMemberPOADetailsList().isEmpty()) {
                    memberPOADetailsList.addAll(completableFuture.get().getMemberPOADetailsList());
                }
            }
            if (null == memberPOADetailsList || memberPOADetailsList.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                MemberPOADetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(), StringUtils.join(errorResponse.getErrors(), ","), null, new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            memberPOADetailsResponse.setMemberId(memberId);
            memberPOADetailsResponse.setMemberPOADetailsList(memberPOADetailsList);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Member POA Response Details through query param");
        return new ResponseEntity<>(memberPOADetailsResponse, HttpStatus.OK);
    }

    public ResponseEntity<MemberPOADetails> getMemberPoaDetails(String memberId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getMemberPoaDetails() of MemberPoaService class");

        MemberPOADetails memberPOADetails = new MemberPOADetails();
        try {
            CompletableFuture<MemberPOADetails> completableFuture = null;
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = memberPOAData.getMemberPoaDetails(serviceUrl, defaultContextPath + defaultState, memberId, null, null, null, accessToken);
            if (completableFuture.get().getMemberPOADetailsList() != null && !completableFuture.get().getMemberPOADetailsList().isEmpty()) {
                memberPOADetails.setMemberId(memberId);
                memberPOADetails.setMemberPOADetailsList(completableFuture.get().getMemberPOADetailsList());
            } else if (completableFuture.get().getErrors() != null && !completableFuture.get().getErrors().isEmpty()) {
                log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                String exceptionMessage = null;
                if (StringUtils.isBlank(completableFuture.get().getErrors().get(0))) {
                    exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                } else {
                    exceptionMessage = completableFuture.get().getErrors().get(0) + "|" + completableFuture.get().getHttpStatusCode();
                }
                throw new ODSAdaptorException(exceptionMessage);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Member POA Response Details through path param");
        return new ResponseEntity<>(memberPOADetails, HttpStatus.OK);
    }
}