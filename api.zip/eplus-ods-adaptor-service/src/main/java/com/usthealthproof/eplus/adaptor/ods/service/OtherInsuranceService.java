package com.usthealthproof.eplus.adaptor.ods.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.OtherInsuranceData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetails;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetailsList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class OtherInsuranceService {

    @Autowired
    private OtherInsuranceData otherInsuranceData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.otherInsuranceServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<OtherInsuranceDetails> getMspOtherInsuranceDetails(String memberId, String userIdentities, String accessToken) throws ExecutionException, InterruptedException, JsonProcessingException {
        log.info("Inside getMspOtherInsurance() of OtherInsuranceService class");

        OtherInsuranceDetails otherInsuranceDetails = new OtherInsuranceDetails();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<OtherInsuranceDetails>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<OtherInsuranceDetails> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = otherInsuranceData.getOtherInsuranceDetails(serviceUrl, defaultContextPath + multiStateContextPath, memberId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }
            List<OtherInsuranceDetailsList> otherInsuranceDetailsList = new ArrayList<>();
            for (CompletableFuture<OtherInsuranceDetails> completableFuture : completableFutureList) {
                if (completableFuture.get().getOtherInsuranceDetailsList() != null && !completableFuture.get().getOtherInsuranceDetailsList().isEmpty()) {
                    otherInsuranceDetailsList.addAll(completableFuture.get().getOtherInsuranceDetailsList());
                }
            }
            if (null == otherInsuranceDetailsList || otherInsuranceDetailsList.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                OtherInsuranceDetails errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(), StringUtils.join(errorResponse.getErrors(), ","), null, new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            otherInsuranceDetails.setOtherInsuranceDetailsList(otherInsuranceDetailsList);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Other Insurance Response Details through query param");
        return new ResponseEntity<>(otherInsuranceDetails, HttpStatus.OK);
    }

    public ResponseEntity<OtherInsuranceDetails> getOtherInsuranceDetails(String memberId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getOtherInsurance() of OtherInsuranceService class");

        CompletableFuture<OtherInsuranceDetails> completableFuture = null;
        OtherInsuranceDetails otherInsuranceDetails = new OtherInsuranceDetails();
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = otherInsuranceData.getOtherInsuranceDetails(serviceUrl, defaultContextPath + defaultState, memberId, null, null, null, accessToken);
            if (completableFuture.get().getOtherInsuranceDetailsList() != null && !completableFuture.get().getOtherInsuranceDetailsList().isEmpty()) {
                otherInsuranceDetails.setOtherInsuranceDetailsList(completableFuture.get().getOtherInsuranceDetailsList());
            } else if (completableFuture.get().getErrors() != null && !completableFuture.get().getErrors().isEmpty()) {
                log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                String exceptionMessage = null;
                if (StringUtils.isBlank(completableFuture.get().getErrors().get(0))) {
                    exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                } else {
                    exceptionMessage = completableFuture.get().getErrors().get(0) + "|" + completableFuture.get().getHttpStatusCode();
                }
                throw new ODSAdaptorException(exceptionMessage);
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Other Insurance Response Details through path param");
        return new ResponseEntity<>(otherInsuranceDetails, HttpStatus.OK);
    }
}
