package com.usthealthproof.eplus.adaptor.ods.service.claim;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.claim.ClaimSearchData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimSearchModel;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimHeaderSearchResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ClaimSearchService {

    @Autowired
    private ClaimSearchData claimSearchData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.claimServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;


    /**
     * To get msp member claim details
     *
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param memberNumber
     * @param serviceCode
     * @param diagnosisCode
     * @param userIdentities
     * @param accessToken
     * @return
     */
    public ResponseEntity<ClaimHeaderSearchResponse> getMspMemberClaimSearch(String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspMemberClaimSearch() of ClaimSearchService class");

        String claimSearchType = "memberClaimSearch";
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        try {
            List<CompletableFuture<ClaimHeaderSearchResponse>> completableFutureList = new ArrayList<>();
            CompletableFuture<ClaimHeaderSearchResponse> completableFutures = null;
                completableFutureList = getClaimSearchResponse(null, null, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, userIdentities, accessToken, claimSearchType);
            claimHeaderSearchResponse.setResults(getClaimSearchModelList(completableFutureList, claimSearchType, null));
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Member Claim Search Response");
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }

    /**
     * To get member claim details
     *
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param memberNumber
     * @param serviceCode
     * @param diagnosisCode
     * @param accessToken
     * @return
     */

    public ResponseEntity<ClaimHeaderSearchResponse> getMemberClaimSearch(String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getMemberClaimSearch() of ClaimSearchService class");

        ClaimHeaderSearchResponse claimHeaderSearchResponse;
        CompletableFuture<ClaimHeaderSearchResponse> completableFutures = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFutures = claimSearchData.getMemberClaimSearch(serviceUrl, defaultContextPath + defaultState, claimTypes,
                    claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, null, null, null, accessToken,
                    serviceCode, diagnosisCode);
            claimHeaderSearchResponse = getClaimHeaderSearchResponse(completableFutures);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Member Claim Search Response");
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }

    /**
     * To get msp provider claim details
     *
     * @param providerId
     * @param providerType
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param memberNumber
     * @param serviceCode
     * @param diagnosisCode
     * @param userIdentities
     * @param isMatchingUserRole
     * @param accessToken
     * @return
     */
    public ResponseEntity<ClaimHeaderSearchResponse> getMspProviderClaimSearch(String providerId, String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String userIdentities, String isMatchingUserRole, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspProviderClaimSearch() of ClaimSearchService class");

        String claimSearchType = "providerSearch";
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        try {
            List<CompletableFuture<ClaimHeaderSearchResponse>> completableFutureList = new ArrayList<>();
            CompletableFuture<ClaimHeaderSearchResponse> completableFutures = null;
            if (StringUtils.equalsIgnoreCase(OdsAdaptorServiceConstants.DEFAULT_CLAIM_TYPE, claimTypes)) {
                completableFutureList = getClaimSearchResponse(providerId, providerType,claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, userIdentities, accessToken, claimSearchType);
            } else {
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
                completableFutures = claimSearchData.getProviderClaimSearch(serviceUrl, defaultContextPath + defaultState, providerId,
                        providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber,
                        null, null, null, accessToken, serviceCode, diagnosisCode);
                completableFutureList.add(completableFutures);
            }
            claimHeaderSearchResponse.setResults(getClaimSearchModelList(completableFutureList, claimSearchType, isMatchingUserRole));
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Provider Claim Search Response");
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }

    /**
     * To get provider claim details
     *
     * @param providerId
     * @param providerType
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param memberNumber
     * @param serviceCode
     * @param diagnosisCode
     * @param accessToken
     * @return
     */
    public ResponseEntity<ClaimHeaderSearchResponse> getProviderClaimSearch(String providerId, String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getProviderClaimSearch() of ClaimSearchService class");

        ClaimHeaderSearchResponse claimHeaderSearchResponse;
        CompletableFuture<ClaimHeaderSearchResponse> completableFutures = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFutures = claimSearchData.getProviderClaimSearch(serviceUrl, defaultContextPath + defaultState, providerId,
                    providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, null,
                    null, null, accessToken, serviceCode, diagnosisCode);
            claimHeaderSearchResponse = getClaimHeaderSearchResponse(completableFutures);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Provider Claim Search Response");
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }

    public List<ClaimSearchModel> getClaimSearchModelList(List<CompletableFuture<ClaimHeaderSearchResponse>> completableFutureList, String claimSearchType, String isMatchingUserRole) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getClaimSearchModelList() of ClaimSearchService class");

        List<ClaimSearchModel> claimSearchModelList = new ArrayList<>();
        for (CompletableFuture<ClaimHeaderSearchResponse> completableFuture : completableFutureList) {
            if (completableFuture.get().getResults() != null && !completableFuture.get().getResults().isEmpty()) {
                claimSearchModelList.addAll(completableFuture.get().getResults());
            }
        }
        if (null == claimSearchModelList || claimSearchModelList.isEmpty()) {
            log.info("No results returned");
            ClaimHeaderSearchResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
            if (errorResponse.getHttpStatusCode() == 404 && StringUtils.isNotBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "true")) {
                throw new ODSAdaptorException(OdsAdaptorServiceConstants.NO_DATA + "|404");
            } else if (errorResponse.getHttpStatusCode() == 404 && StringUtils.isBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(claimSearchType, "providerSearch")){
                throw new ODSAdaptorException(OdsAdaptorServiceConstants.DATA_NOT_FOUND + "|404");
            } else {
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
        }
        return claimSearchModelList;
    }

    private ClaimHeaderSearchResponse getClaimHeaderSearchResponse(CompletableFuture<ClaimHeaderSearchResponse> completableFutures) throws InterruptedException, ExecutionException {
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        if (completableFutures.get().getResults() != null && !completableFutures.get().getResults().isEmpty()) {
            claimHeaderSearchResponse.setResults(completableFutures.get().getResults());
        } else if (completableFutures.get().getErrors() != null && !completableFutures.get().getErrors().isEmpty()) {
            log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
            String exceptionMessage = null;
            if (StringUtils.isBlank(completableFutures.get().getErrors().get(0))) {
                exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
            } else {
                exceptionMessage = completableFutures.get().getErrors().get(0) + "|"
                        + completableFutures.get().getHttpStatusCode();
            }
            throw new ODSAdaptorException(exceptionMessage);
        }
        return claimHeaderSearchResponse;
    }

    private List<CompletableFuture<ClaimHeaderSearchResponse>> getClaimSearchResponse(String providerId, String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String userIdentities, String accessToken, String claimSearchType) {
        CompletableFuture<ClaimHeaderSearchResponse> completableFutures;
        List<CompletableFuture<ClaimHeaderSearchResponse>> completableFutureList = new ArrayList<>();
        String state;
        String lob;
        String product;
        Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
        for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
            String multiStateContextPath = slp.getValue();
            List<String> slpData = Arrays.asList(slp.getKey().split(":"));
            state = !slpData.isEmpty() ? slpData.get(0) : "";
            lob = slpData.size() > 1 ? slpData.get(1) : "";
            product = slpData.size() > 2 ? slpData.get(2) : "";
            log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
            if(StringUtils.equalsIgnoreCase(claimSearchType, "memberClaimSearch")) {
                completableFutures = claimSearchData.getMemberClaimSearch(serviceUrl, defaultContextPath + multiStateContextPath,
                        claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, state, lob,
                        product, accessToken, serviceCode, diagnosisCode);
                completableFutureList.add(completableFutures);
            }
            else {
                completableFutures = claimSearchData.getProviderClaimSearch(serviceUrl, defaultContextPath + multiStateContextPath,
                        providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, state, lob,
                        product, accessToken, serviceCode, diagnosisCode);
                completableFutureList.add(completableFutures);
            }
        }
        return completableFutureList;
    }

    /**
     * To check availability of provider claim data
     *
     * @param providerId
     * @param providerType
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param memberNumber
     * @param serviceCode
     * @param diagnosisCode
     * @param selectedSlp
     * @param accessToken
     * @return
     */
    public ResponseEntity<ClaimHeaderSearchResponse> providerClaimDataAvailabilityCheck(String providerId, String providerType, String claimTypes, String claimNumber, String serviceFromDate, String serviceToDate, String claimStatus, String memberNumber, String serviceCode, String diagnosisCode, String selectedSlp, String accessToken) throws JsonProcessingException {
        log.info("Inside providerClaimDataAvailabilityCheck() of ClaimSearchService class");

        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(selectedSlp);
        for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
            String multiStateContextPath = slp.getValue();
            List<String> slpData = Arrays.asList(slp.getKey().split(":"));
            String state = !slpData.isEmpty() ? slpData.get(0) : "";
            String lob = slpData.size() > 1 ? slpData.get(1) : "";
            String product = slpData.size() > 2 ? slpData.get(2) : "";
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
            claimHeaderSearchResponse = claimSearchData.providerClaimDataAvailabilityCheck(serviceUrl, defaultContextPath + multiStateContextPath, providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, state, lob,
                    product, serviceCode, diagnosisCode, accessToken);
            if (claimHeaderSearchResponse.getErrors() != null && !claimHeaderSearchResponse.getErrors().isEmpty()) {
                throw new WebClientResponseException(claimHeaderSearchResponse.getHttpStatusCode(),
                        StringUtils.join(claimHeaderSearchResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(claimHeaderSearchResponse), null);
            } else if (StringUtils.equalsIgnoreCase(claimHeaderSearchResponse.getDataAvailabilityFlag(), "true")) {
                log.info(OdsAdaptorServiceConstants.NOT_APPROPRIATE_QUEUE);
                throw new ResponseValidationException(OdsAdaptorServiceConstants.NOT_APPROPRIATE_QUEUE);
            } else {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                throw new ResponseValidationException(OdsAdaptorServiceConstants.NO_DATA);
            }
        }
        log.info("Successfully completed provider claim search data available check");
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }
}