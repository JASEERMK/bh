
package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Data
@Schema(description = "Object for holding the Authorization search results fields as a list")
public class AuthorizationLinesResponseList implements Serializable {

	private static final long serialVersionUID = 6990278868758377320L;

	@Schema(description = "For storing the authorization lines as list")
	private List<AuthorizationLinesResponse> authorizationLines;


	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;

	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}
