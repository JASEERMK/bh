package com.usthealthproof.eplus.adaptor.ods.util;

import java.util.*;
import java.util.stream.Collectors;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.validator.Validator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DaoUtil {

	@Autowired
	Validator validator;

	public Map<String, String> getMspConfigDetails(String userIdentities) {
		log.info("Inside getMspConfigDetails()");

		List<String> userIdentitiesList = Arrays.asList(StringUtils.split(userIdentities, ';'));
		userIdentitiesList = userIdentitiesList.stream().distinct().collect(Collectors.toList());
		log.info("Distinct userIdentitiesList after split: {}" , userIdentitiesList);
		Map<String, String> mspConfigDetails = new HashMap<>();
		userIdentitiesList.forEach(element -> {
			element = element.trim();
			if (MSPConfigUtils.mspConfigMap.containsKey(element)) {
				mspConfigDetails.put(element, MSPConfigUtils.mspConfigMap.get(element));
			}
		});
		return mspConfigDetails;
	}

	public Map<String, String> getMspConfigMap(String userIdentities) {
		Map<String, String> mspConfigMap = getMspConfigDetails(userIdentities);
		log.debug(OdsAdaptorServiceConstants.MSP_MAP_LOGGING_MESSAGE, mspConfigMap.toString());
		log.info(OdsAdaptorServiceConstants.MSP_MAP_SIZE_LOGGING_MESSAGE, mspConfigMap.size());
		validator.validateMspConfigData(mspConfigMap);
		return mspConfigMap;
	}
}