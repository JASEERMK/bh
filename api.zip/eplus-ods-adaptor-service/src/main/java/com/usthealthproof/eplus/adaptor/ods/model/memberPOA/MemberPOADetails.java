package com.usthealthproof.eplus.adaptor.ods.model.memberPOA;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class containing list of Member Responsibleparty/POA details")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "memberId", "status", "poaList", "problemDetails", "requestId" })
public class MemberPOADetails implements Serializable {

	private static final long serialVersionUID = -628764090970438792L;
	@Schema(description = "Member HCC ID")
	private String memberId;
	@Schema(description = "Collection of Member Responsible Party/Power of Attorney(POA) details")
	@JsonProperty("poaList")
	private List<MemberPOADetailsList> memberPOADetailsList;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}
