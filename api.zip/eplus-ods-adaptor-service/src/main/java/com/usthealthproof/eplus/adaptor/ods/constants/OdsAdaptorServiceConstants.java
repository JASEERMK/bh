package com.usthealthproof.eplus.adaptor.ods.constants;

import org.springframework.stereotype.Component;

@Component
public class OdsAdaptorServiceConstants {
	private OdsAdaptorServiceConstants() {
	}

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String AUTHORIZATION_KEY = "Authorization";
	public static final String USERIDENTITIES_KEY = "userIdentities";
	public static final String NOT_FOUND = "No record found/Access Restricted";
	public static final String EXCEPTION_MESSAGE = "Something went wrong, please check the log for more details";
	public static final String SERVICE_UNAVAILABLE = "Something went wrong, Please contact your Supervisor!";
	public static final String DEFAULT_CLAIM_TYPE = "Medical";
	public static final String DEFAULT_AUTH_TYPE = "Medical";
	public static final String MSP_ENABLED_MESSAGE = "Service is enabled for Multi market capability or MSP";
	public static final String MSP_DISABLED_MESSAGE = "Service is disabled for Multi market capability or MSP";
	public static final String NO_DATA = "No Data Found.";
	public static final String NOT_APPROPRIATE_QUEUE = "Data found please transfer the call to appropriate Queue.";
	public static final String DATA_NOT_FOUND = "No data found. For further verification, select SLP combination from dropdown.";
	public static final String GENERAL_EXCEPTION_MESSAGE = "Some exception occured and hence the error field in the response model got some values";
	public static final String WEBCLIENT_RESPONSE_EXCEPTION = "Not handling the WebClientResponseException, it is just logging only for proceeding the other iterations of AsyncCall.\n Received WebClientResponseException, Message : {} ,StatusCode : {}, Exception : {}";
	public static final String WITH_OAUTH_TOKEN_MESSAGE = "Proceeding with OAuth Token";
	public static final String WITHOUT_OAUTH_TOKEN_MESSAGE = "Proceeding without OAuth Token";
	public static final String SERVICE_URL_MESSAGE = "Invalid Request: The URL for the service does not find any match";
	public static final String ENDPOINT_LOGGING_MESSAGE = "Endpoint URL: {}";
	public static final String MSP_MAP_LOGGING_MESSAGE = "mspConfigMap: {}";
	public static final String MSP_MAP_SIZE_LOGGING_MESSAGE = "mspConfigMap Size: {}";
	public static final String USER_IDENTITIES_LOGGING_MESSAGE = "User Identities: {} & State Configured: {}";
	public static final String STATE = "state";
	public static final String PRODUCT = "product";
	public static final String LOB = "lob";
	public static final String AUTHORIZATION_ID = "authorizationId";
	public static final String CLAIM_HCC_ID = "claimHccId";
	public static final String RX_ID = "rxId";
	public static final String PROVIDER_SEARCH_TYPE = "provider";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";
	public static final String PHARMACY_AUTH_TYPE = "pharmacy";
}

