package com.usthealthproof.eplus.adaptor.ods.model.memberPOA;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing Member Responsible Party/POA details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberPOADetailsList implements Serializable {

	private static final long serialVersionUID = -3148560865755192899L;
	@Schema(description = "Name of member's responsible party")
	private String name;
	@Schema(description = "Relationship with Member")
	private String relationship;
	@Schema(description = "Effective start date")
	private String effectiveStartDate;
	@Schema(description = "Effective end date")
	private String effectiveEndDate;
	@Schema(description = "Authorization type")
	private String authType;

}
