package com.usthealthproof.eplus.adaptor.ods.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.adaptor.ods.model.MSPConfigResponse;

@Component
public class MultiStateConfigMapper implements RowMapper<MSPConfigResponse> {

	@Override
	public MSPConfigResponse mapRow(ResultSet rs, int i) throws SQLException {

		MSPConfigResponse mspConfigResponse = new MSPConfigResponse();
		mspConfigResponse.setCombinedSLP(rs.getString("SLP"));
		mspConfigResponse.setServiceContextPath(rs.getString("SERVICE_CONTEXT_PATH"));

		return mspConfigResponse;
	}

}
