package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalExternalMessagesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.ExternalMessageClaimService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Medical Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class ExternalMessageAdaptorServiceController {

	@Autowired
	private ExternalMessageClaimService externalMessageClaimService;


	/**
	 *  1. Adaptor Service for External message claim service
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param claimFactKey
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "External messages details", description = "The external message service is responsible for retrieving the message from the external system and displaying the denial or payment reason.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Medical external message details of the particular claim", content = {
					@Content(schema = @Schema(implementation = MedicalClaimLineDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/external/messages", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<MedicalExternalMessagesResponse> getExternalmessageDetails(
			@Parameter(description = "Medical Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			@Parameter(description = "Medical Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") String claimLineHccId,
			@Parameter(description = "Medical Claim Fact Key", required = false) @RequestParam(value = "claimFactKey", required = false) String claimFactKey,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getExternalmessageDetails() of ExternalMessageAdaptorServiceController");
		log.debug("External Message detail service request received with claimHccID= {} claimLineHccId= {} claimFactKey= {}",
				claimHccId, claimLineHccId, claimFactKey);

		MedicalExternalMessagesResponse medicalExternalMessagesResponse;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			medicalExternalMessagesResponse = externalMessageClaimService.getMspExternalmessageDetails(claimHccId, claimLineHccId, claimFactKey, userIdentities, accessToken);
		} else {
			medicalExternalMessagesResponse = externalMessageClaimService.getExternalmessageDetails(claimHccId, claimLineHccId, claimFactKey, accessToken);
		}
		log.info(
				"Successfully generated medical External Message details response");
		return new ResponseEntity<>(medicalExternalMessagesResponse, HttpStatus.OK);
	}
}
