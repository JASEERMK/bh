package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.PharmacyAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class AuthorizationData {

	public static final String MEDICAL_AUTH = "/v1/auths/medical";

	public static final String MEDICAL_AUTHLINES = "/v1/auths/medical/authlines";

	public static final String MEDICAL_AUTHLINE = "/v1/auths/medical/authline";

	public static final String PROVIDER_SEARCH = "/v1/auths/provider/search";

	public static final String MEMBER_SEARCH = "/v1/auths/member/search";

	public static final String PROVIDER_DATA_CHECK = "/v1/auths/provider/search/isAvailable";

	public static final String AUTHS_NOTES_CLINICAL = "/v1/auths/notes/clinical";

	public static final String DENTAL_AUTHLINES = "/v1/auths/dental/authlines";

	public static final String DENTAL_AUTHLINE = "/v1/auths/dental/authline";

	public static final String PHARMACY_AUTH = "/v1/auths/pharmacy";

	public static final String DENTAL_AUTH = "/v1/auths/dental";

	public static final String AUTHS_NOTES_CALLLOGS = "/v1/auths/notes/calllogs";

	public static final String AUTHNOTES = "/v1/auths/notes/authnotes";

	public static final String MEMBER_NUMBER = "memberNumber";

	public static final String STATUS = "status";

	public static final String SEARCH_START_DATE = "searchStartDate";

	public static final String SEARCH_END_DATE = "searchEndDate";

	public static final String TYPE = "type";

	public static final String SERVICE_LINE_ID = "serviceLineId";

	public static final String PROVIDER_ID = "providerId";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;


	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationDetailsResponse> getAuthorizationDetails(String serviceUrl, String contextPath, String authorizationId,
			String state, String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getAuthorizationDetails() of AuthorizationData class");
		log.debug("Inside getAuthorizationDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationDetailsResponse authorizationDetailsResponse = new AuthorizationDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_AUTH);
				authorizationDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_AUTH)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
								.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_AUTH)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
						.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationDetailsResponse.setError(errorResponse.getProblemDetails().getErrors().get(0));
			authorizationDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationDetails() completed");
		return CompletableFuture.completedFuture(authorizationDetailsResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationLinesResponseList> getAuthorizationLines(String serviceUrl, String contextPath, String authorizationId,
			String state, String lob, String product, String accessToken) {
		log.info("Inside getAuthorizationLines() of AuthorizationData class");
		log.debug("Inside getAuthorizationLines() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationLinesResponseList authorizationLinesResponseList = new AuthorizationLinesResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_AUTHLINES);
				authorizationLinesResponseList = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_AUTHLINES)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationLinesResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_AUTHLINES)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationLinesResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationLinesResponseList.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationLinesResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationLinesResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationLines() completed");
		return CompletableFuture.completedFuture(authorizationLinesResponseList);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationLineDetailsResponse> getAuthorizationLineDetails(String serviceUrl, String contextPath,
			String authorizationId, String serviceLineId, String serviceStartDate, String procedureCode, String state, String lob,
			String product, String accessToken) throws InterruptedException {
		log.info("Inside getAuthorizationLineDetails() of AuthorizationData class");
		log.debug("Inside getAuthorizationLineDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationLineDetailsResponse authorizationLineDetailsResponse = new AuthorizationLineDetailsResponse();
		log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_AUTHLINE);
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				authorizationLineDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_AUTHLINE)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParamIfPresent(SERVICE_LINE_ID, Optional.ofNullable(serviceLineId))
								.queryParamIfPresent("serviceStartDate", Optional.ofNullable(serviceStartDate))
								.queryParamIfPresent("procedureCode", Optional.ofNullable(procedureCode))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationLineDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_AUTHLINE)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(SERVICE_LINE_ID, Optional.ofNullable(serviceLineId))
						.queryParamIfPresent("serviceStartDate", Optional.ofNullable(serviceStartDate))
						.queryParamIfPresent("procedureCode", Optional.ofNullable(procedureCode))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationLineDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationLineDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationLineDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationLineDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationLineDetails() completed");
		return CompletableFuture.completedFuture(authorizationLineDetailsResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationSearchResponseList> getMemberAuthSearchDetails(String serviceUrl, String contextPath, String memberNumber,
			String authorizationId, String type, String status, String searchStartDate, String searchEndDate, String state,
			String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getMemberAuthSearchDetails() of AuthorizationData class");
		log.debug("Inside getMemberAuthSearchDetails() of AuthorizationData class and the requests are- contextPath: {} accessToken: {}",
				contextPath, accessToken);

		AuthorizationSearchResponseList authorizationSearchResponseList = new AuthorizationSearchResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEMBER_SEARCH);
				authorizationSearchResponseList = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEMBER_SEARCH)
								.queryParam(MEMBER_NUMBER, memberNumber)
								.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
								.queryParamIfPresent(TYPE, Optional.ofNullable(type))
								.queryParamIfPresent(STATUS, Optional.ofNullable(status))
								.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
								.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEMBER_SEARCH)
						.queryParam(MEMBER_NUMBER, memberNumber)
						.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
						.queryParamIfPresent(TYPE, Optional.ofNullable(type))
						.queryParamIfPresent(STATUS, Optional.ofNullable(status))
						.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
						.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationSearchResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationSearchResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationSearchResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getMemberAuthSearchDetails() completed");
		return CompletableFuture.completedFuture(authorizationSearchResponseList);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationSearchResponseList> getProviderAuthSearchDetails(String serviceUrl, String contextPath, String providerId,
			String memberNumber, String authorizationId, String type, String status, String searchStartDate, String searchEndDate,
			String state, String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getProviderAuthSearchDetails() of AuthorizationData class");
		log.debug("Inside getProviderAuthSearchDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationSearchResponseList authorizationSearchResponseList = new AuthorizationSearchResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + PROVIDER_SEARCH);
				authorizationSearchResponseList = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + PROVIDER_SEARCH)
								.queryParam(PROVIDER_ID, providerId)
								.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
								.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
								.queryParamIfPresent(TYPE, Optional.ofNullable(type))
								.queryParamIfPresent(STATUS, Optional.ofNullable(status))
								.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
								.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + PROVIDER_SEARCH)
						.queryParam(PROVIDER_ID, providerId)
						.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
						.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
						.queryParamIfPresent(TYPE, Optional.ofNullable(type))
						.queryParamIfPresent(STATUS, Optional.ofNullable(status))
						.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
						.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationSearchResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationSearchResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationSearchResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getProviderAuthSearchDetails() completed");
		return CompletableFuture.completedFuture(authorizationSearchResponseList);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationNotesResponse> getAuthorizationNotesClinical(String serviceUrl, String contextPath, String authorizationId,
																					   String state, String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getAuthorizationNotesClinical() of AuthorizationData class");
		log.debug("Inside getAuthorizationNotesClinical() of AuthorizationData class and the requests are- contextPath: {}, accessToken: {}",
				contextPath, accessToken);

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + AUTHS_NOTES_CLINICAL);
				authorizationNotesResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + AUTHS_NOTES_CLINICAL)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build()).header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
						.retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + AUTHS_NOTES_CLINICAL)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationNotesResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationNotesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationNotesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationNotesClinical() completed");
		return CompletableFuture.completedFuture(authorizationNotesResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationNotesResponse> getAuthorizationCallLogsNotes(String serviceUrl, String contextPath, String authorizationId,
																					   String state, String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getAuthorizationCallLogsNotes() of AuthorizationData class");
		log.debug("Inside getAuthorizationCallLogsNotes() of AuthorizationData class and the requests are- contextPath: {}, accessToken: {}",
				contextPath, accessToken);

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + AUTHS_NOTES_CALLLOGS);
				authorizationNotesResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + AUTHS_NOTES_CALLLOGS)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build()).header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
						.retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + AUTHS_NOTES_CALLLOGS)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationNotesResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationNotesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationNotesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationCallLogsNotes() completed");
		return CompletableFuture.completedFuture(authorizationNotesResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<AuthorizationNotesResponse> getAuthorizationNotes(String serviceUrl, String contextPath, String authorizationId,
																			   String state, String lob, String product, String accessToken) throws InterruptedException {
		log.info("Inside getAuthorizationNotes() of AuthorizationData class");
		log.debug("Inside getAuthorizationNotes() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();

		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath +AUTHNOTES);
				authorizationNotesResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + AUTHNOTES)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build()).header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken)
						.retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + AUTHNOTES)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationNotesResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationNotesResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationNotesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationNotesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getAuthorizationNotes() completed");
		return CompletableFuture.completedFuture(authorizationNotesResponse);
	}

    public CompletableFuture<DentalAuthorizationDetailsResponse> getDentalAuthorizationDetails(String serviceUrl, String contextPath, String authorizationId, String state, String lob, String product, String accessToken) {
		log.info("Inside getDentalAuthorizationDetails() of AuthorizationData class");
		log.debug("Inside getDentalAuthorizationDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse = new DentalAuthorizationDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_AUTH);
				dentalAuthorizationDetailsResponse = webClientGatewayRoute.get().uri(
								uriBuilder -> uriBuilder.path(contextPath + DENTAL_AUTH).queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
										.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
										.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
										.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
										.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalAuthorizationDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_AUTH)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalAuthorizationDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalAuthorizationDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalAuthorizationDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalAuthorizationDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
			log.info("getDentalAuthorizationDetails() completed");
			return CompletableFuture.completedFuture(dentalAuthorizationDetailsResponse);
	}

	public CompletableFuture<DentalAuthorizationLinesResponseList> getDentalAuthorizationLines(String serviceUrl, String contextPath, String authorizationId, String state, String lob, String product,String accessToken) {
		log.info("Inside getDentalAuthorizationLines() of AuthorizationData class");
		log.debug("Inside getDentalAuthorizationLines() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalAuthorizationLinesResponseList dentalAuthorizationLinesResponseList = new DentalAuthorizationLinesResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_AUTHLINES);
				dentalAuthorizationLinesResponseList = webClientGatewayRoute.get().uri(
								uriBuilder -> uriBuilder.path(contextPath + DENTAL_AUTHLINES).queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
										.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
										.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
										.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
										.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalAuthorizationLinesResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_AUTHLINES)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalAuthorizationLinesResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalAuthorizationLinesResponseList.class).block();
			}
		}catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalAuthorizationLinesResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalAuthorizationLinesResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getDentalAuthorizationLines() completed");
		return CompletableFuture.completedFuture(dentalAuthorizationLinesResponseList);
	}

	public CompletableFuture<DentalAuthorizationLineDetailsResponse> getDentalAuthorizationLineDetails(String serviceUrl, String contextPath, String authorizationId, String serviceLineId, String state, String lob, String product,String accessToken) {
		log.info("Inside getDentalAuthorizationLineDetails() of AuthorizationData class");
		log.debug("Inside getDentalAuthorizationLineDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse = new DentalAuthorizationLineDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_AUTHLINE);
				dentalAuthorizationLineDetailsResponse = webClientGatewayRoute.get().uri(
								uriBuilder -> uriBuilder.path(contextPath + DENTAL_AUTHLINE).queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
										.queryParam(SERVICE_LINE_ID, serviceLineId)
										.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
										.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
										.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
										.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalAuthorizationLineDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_AUTHLINE)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParam(SERVICE_LINE_ID, serviceLineId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalAuthorizationLineDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalAuthorizationLineDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalAuthorizationLineDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalAuthorizationLineDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getDentalAuthorizationLineDetails() completed");
		return CompletableFuture.completedFuture(dentalAuthorizationLineDetailsResponse);
	}

	public CompletableFuture<PharmacyAuthorizationDetailsResponse> getPharmacyAuthorizationDetails(String serviceUrl, String contextPath,
			String authorizationId, String accessToken, String rxId) {
		log.info("Inside getPharmacyAuthorizationDetails() of AuthorizationData class");
		log.debug("Inside getPharmacyAuthorizationDetails() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		PharmacyAuthorizationDetailsResponse pharmacyAuthorizationDetailsResponse = new PharmacyAuthorizationDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + PHARMACY_AUTH);
				pharmacyAuthorizationDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + PHARMACY_AUTH)
								.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
								.queryParam(OdsAdaptorServiceConstants.RX_ID, rxId).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve()
						.bodyToMono(PharmacyAuthorizationDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + PHARMACY_AUTH)
						.queryParam(OdsAdaptorServiceConstants.AUTHORIZATION_ID, authorizationId)
						.queryParam(OdsAdaptorServiceConstants.RX_ID, rxId).build().toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				pharmacyAuthorizationDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(PharmacyAuthorizationDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			pharmacyAuthorizationDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			pharmacyAuthorizationDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getPharmacyAuthorizationDetails() completed");
		return CompletableFuture.completedFuture(pharmacyAuthorizationDetailsResponse);
	}

    public AuthorizationSearchResponseList providerAuthDataAvailabilityCheck(String serviceUrl, String contextPath, String providerId, String authorizationId, String memberNumber, String status, String type, String searchStartDate, String searchEndDate, String state, String lob, String product, String accessToken) {
		log.info("Inside providerAuthDataAvailabilityCheck() of AuthorizationData class");
		log.debug("Inside providerAuthDataAvailabilityCheck() of AuthorizationData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		AuthorizationSearchResponseList authorizationSearchResponseList = new AuthorizationSearchResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + PROVIDER_SEARCH);
				authorizationSearchResponseList = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + PROVIDER_DATA_CHECK)
								.queryParam(PROVIDER_ID, providerId)
								.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
								.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
								.queryParamIfPresent(TYPE, Optional.ofNullable(type))
								.queryParamIfPresent(STATUS, Optional.ofNullable(status))
								.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
								.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + PROVIDER_DATA_CHECK)
						.queryParam(PROVIDER_ID, providerId)
						.queryParamIfPresent(MEMBER_NUMBER, Optional.ofNullable(memberNumber))
						.queryParamIfPresent(OdsAdaptorServiceConstants.AUTHORIZATION_ID, Optional.ofNullable(authorizationId))
						.queryParamIfPresent(TYPE, Optional.ofNullable(type))
						.queryParamIfPresent(STATUS, Optional.ofNullable(status))
						.queryParamIfPresent(SEARCH_START_DATE, Optional.ofNullable(searchStartDate))
						.queryParamIfPresent(SEARCH_END_DATE, Optional.ofNullable(searchEndDate))
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				authorizationSearchResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(AuthorizationSearchResponseList.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			authorizationSearchResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			authorizationSearchResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("providerAuthDataAvailabilityCheck() completed");
		return authorizationSearchResponseList;
    }
}
