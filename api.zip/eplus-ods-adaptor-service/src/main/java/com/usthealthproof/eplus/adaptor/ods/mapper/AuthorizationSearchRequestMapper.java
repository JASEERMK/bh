package com.usthealthproof.eplus.adaptor.ods.mapper;

import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationSearch.AuthorizationSearchRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class AuthorizationSearchRequestMapper {

    public AuthorizationSearchRequest authorizationSearchRequestMapper(String providerId, String authorizationId, String memberNumber, String status, String type, String searchStartDate,String searchEndDate){
        log.info("Inside authorizationSearchRequestMapper()");

        AuthorizationSearchRequest authorizationSearchRequest = new AuthorizationSearchRequest();
        authorizationSearchRequest.setProviderId(providerId);
        authorizationSearchRequest.setAuthorizationId(authorizationId);
        authorizationSearchRequest.setMemberNumber(memberNumber);
        authorizationSearchRequest.setStatus(status);
        authorizationSearchRequest.setType(type);
        authorizationSearchRequest.setSearchStartDate(searchStartDate);
        authorizationSearchRequest.setSearchEndDate(searchEndDate);
        return authorizationSearchRequest;
    }

}
