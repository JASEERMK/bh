package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "serviceLineId", "procedureCode", "placeOfService", "determinationStatus", "denialReason",
		"serviceDateStart", "requestedUnits", "deniedUnits", "decisionDate", "decisionStatus", "modifiers", "serviceDateEnd",
		"approvedUnits", "unitType", "decisionStatusCode", "performingProviderName", "performingProviderId", "urgency",
		"referralCategory", "referralDesc", "authorizationType", "statusReason", "reimbursementMethod", "amount", "flatFeeType",
		"percentageBilled", "serviceSetNote" })
@Data
@Schema(description = "Object for holding the Authorization line details results fields")
public class AuthorizationLineDetailsResponse implements Serializable {

	private static final long serialVersionUID = 1316835281044597365L;

	@Schema(description = "Unique service Line ID for the particular services")
	@JsonProperty("serviceLineId")
	private String serviceLineId;

	@Schema(description = "ProcedureCode & Description of the procedure undergone")
	@JsonProperty("procedureCode")
	private String procedureCode;

	@Schema(description = "Place of Service where the service will be performed")
	@JsonProperty("placeOfService")
	private String placeOfService;

	@Schema(description = "Determination status of the auth service line")
	@JsonProperty("determinationStatus")
	private String determinationStatus;

	@Schema(description = "Explanation for denying the authorization")
	@JsonProperty("denialReason")
	private String denialReason;

	@Schema(description = "Expected service start date")
	@JsonProperty("serviceDateStart")
	private String serviceDateStart;

	@Schema(description = "Requested Units")
	@JsonProperty("requestedUnits")
	private String requestedUnits;

	@Schema(description = "Denied Units")
	@JsonProperty("deniedUnits")
	private String deniedUnits;

	@Schema(description = "Decision Date")
	@JsonProperty("decisionDate")
	private String decisionDate;

	@Schema(description = "Decision Status")
	@JsonProperty("decisionStatus")
	private String decisionStatus;

	@Schema(description = "Modifiers")
	@JsonProperty("modifiers")
	private String modifiers;

	@Schema(description = "Expected service end date")
	@JsonProperty("serviceDateEnd")
	private String serviceDateEnd;

	@Schema(description = "Approved Units")
	@JsonProperty("approvedUnits")
	private String approvedUnits;

	@Schema(description = "Type of unit. i.e., units, hours, days")
	@JsonProperty("unitType")
	private String unitType;

	@Schema(description = "Decision Status Code")
	@JsonProperty("decisionStatusCode")
	private String decisionStatusCode;

	@Schema(description = "Name of the provider performing the service")
	@JsonProperty("performingProviderName")
	private String performingProviderName;

	@Schema(description = "ID of the provider performing the service")
	@JsonProperty("performingProviderId")
	private String performingProviderId;


	@Schema(description = "Urgency")
	@JsonProperty("urgency")
	private String urgency;

	// New fields added as part of CPB-2743
	@Schema(description = "Referral Category")
	@JsonProperty("referralCategory")
	private String referralCategory;

	@Schema(description = "Referral Description")
	@JsonProperty("referralDesc")
	private String referralDesc;

	// added as part of cpb3295
	@Schema(description = "Type of authorization")
	@JsonProperty("authorizationType")
	private String authorizationType;

	// added as part of cpb4381, V23.2
	@Schema(description = "Explanation regarding the status")
	@JsonProperty("statusReason")
	private String statusReason;

	@Schema(description = "Method name of supplier reimbursement")
	@JsonProperty("reimbursementMethod")
	private String reimbursementMethod;

	@Schema(description = "Supplier payment amount")
	@JsonProperty("amount")
	private String amount;

	@Schema(description = "Type of flat fee name")
	@JsonProperty("flatFeeType")
	private String flatFeeType;

	@Schema(description = "Supplier payment percent billed")
	@JsonProperty("percentageBilled")
	private String percentageBilled;

	@Schema(description = "Text of service note")
	@JsonProperty("serviceSetNote")
	private String serviceSetNote;

	@Schema(description = "To hold the errors", hidden = true)
	private List<String> errors;

	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

//	Added as part of API-673
	@Schema(description = "Type of service")
	@JsonProperty("serviceType")
	private String serviceType;
	
	@Schema(description = "Diagnosis Code & Description")
	@JsonProperty("diagnosisCodeAndDescription")
	private String diagnosisCodeAndDescription;
	
	@Schema(description = "Medication code")
	@JsonProperty("medicationCode")
	private String medicationCode;
	
	@Schema(description = "Type of diagnosis")
	@JsonProperty("diagnosisCategory")
	private String diagnosisCategory;
	
	@Schema(description = "Medication Strength")
	@JsonProperty("medicationStrength")
	private String medicationStrength;
	
//	Added as part of API-704
	@Schema(description = "Date Determination was made")
	@JsonProperty("determinationDate")
	private String determinationDate;
	
}
