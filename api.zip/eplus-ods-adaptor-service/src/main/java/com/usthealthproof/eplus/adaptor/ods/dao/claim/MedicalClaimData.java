package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.medical.MedicalClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class MedicalClaimData {

	public static final String MEDICAL_CLAIMLINE = "/v1/claims/medical/claimline";

	public static final String MEDICAL_DETAILS = "/v1/claims/medical";

	public static final String MEDICAL_CLAIMLINES = "/v1/claims/medical/claimlines";

	public static final String CLAIM_FACT_KEY = "claimFactKey";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;


	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async
	public CompletableFuture<MedicalClaimDetails> findClaimId(String serviceUrl, String contextPath, String claimHccId, String claimFactKey,
			String state, String lob, String product, String accessToken) {
		log.info("Inside findClaimId() of MedicalClaimData");
		log.debug("Inside findClaimId() of MedicalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		MedicalClaimDetails medicalClaimDetails = new MedicalClaimDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_DETAILS);
				medicalClaimDetails = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_DETAILS).queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
								.queryParam(CLAIM_FACT_KEY, claimFactKey).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
								.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(MedicalClaimDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_DETAILS)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
						.queryParam(CLAIM_FACT_KEY, claimFactKey).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
						.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				medicalClaimDetails = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(MedicalClaimDetails.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			medicalClaimDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			medicalClaimDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("findClaimId() completed");
		return CompletableFuture.completedFuture(medicalClaimDetails);
	}

	@Async("asyncExecutor")
	public CompletableFuture<MedicalClaimLinesResponse> getClaimLines(String serviceUrl, String contextPath, String claimHccId, String claimFactKey,
			String state, String lob, String product, String accessToken) {
		log.info("Inside getClaimLines() of MedicalClaimData");
		log.debug("Inside getClaimLines() of MedicalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		MedicalClaimLinesResponse medicalClaimLinesResponse = new MedicalClaimLinesResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_CLAIMLINES);
				medicalClaimLinesResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_CLAIMLINES)
								.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam(CLAIM_FACT_KEY, claimFactKey)
								.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(MedicalClaimLinesResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_CLAIMLINES)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam(CLAIM_FACT_KEY, claimFactKey)
						.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				medicalClaimLinesResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(MedicalClaimLinesResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			medicalClaimLinesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			medicalClaimLinesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getClaimLines() completed");
		return CompletableFuture.completedFuture(medicalClaimLinesResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<MedicalClaimLineDetailsResponse> getClaimLineDetails(String serviceUrl, String contextPath, String claimHccId,
			String claimLineHccId, String claimFactKey, String state, String lob, String product, String accessToken) {
		log.info("Inside getClaimLines() of MedicalClaimData");
		log.debug("Inside getClaimLineDetails() of MedicalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		MedicalClaimLineDetailsResponse medicalClaimLineDetailsResponse = new MedicalClaimLineDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEDICAL_CLAIMLINE);
				medicalClaimLineDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEDICAL_CLAIMLINE)
								.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
								.queryParam(CLAIM_FACT_KEY, claimFactKey).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
								.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(MedicalClaimLineDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEDICAL_CLAIMLINE)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
						.queryParam(CLAIM_FACT_KEY, claimFactKey).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
						.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				medicalClaimLineDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(MedicalClaimLineDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			medicalClaimLineDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			medicalClaimLineDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getClaimLineDetails() completed");
		return CompletableFuture.completedFuture(medicalClaimLineDetailsResponse);
	}
}