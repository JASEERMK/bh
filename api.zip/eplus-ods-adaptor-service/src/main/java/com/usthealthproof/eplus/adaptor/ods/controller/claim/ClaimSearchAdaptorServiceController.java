package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.ClaimSearchService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Claims Search Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class ClaimSearchAdaptorServiceController {

	@Autowired
	private ClaimSearchService claimSearchService;

	/**
	 * 1. Adaptor service for claim header details service for CRM
	 *
	 * @param claimTypes
	 * @param claimNumber
	 * @param serviceFromDate
	 * @param serviceToDate
	 * @param claimStatus
	 * @param memberNumber
	 * @param serviceCode
	 * @param diagnosisCode
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Member claims search", description = "A member's claims can be retrieved through this service; depending on the filter conditions, all the member's claims will be returned as a response. This API allows us to search for claims in three separate categories: medical, dental, vision and pharmacy. The following search parameters can be used to find member claims: claim types, member number, claim number, service from date, service to date, claim status, service code, diagnosis code. The claim types is the required field among these. All the other arguments are optional if the claim number is provided. Besides that, there are other conditional necessary cases that we need to pass, such as the member number, service from date, service to date and claim status if the claim number is not provided. Furthermore, we can use the other parameters in the filters however we see appropriate; it is entirely optional. For medical claim searches only, the service code and diagnosis code are applicable. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Claim Member Search Details", content = {
					@Content(schema = @Schema(implementation = ClaimHeaderSearchResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/member/claimSearch")
	@ResponseBody
	public ResponseEntity<ClaimHeaderSearchResponse> getClaimDetails(

			@Parameter(description = "Claim Types", required = true) @RequestParam(value = "claimTypes") String claimTypes,
			@Parameter(description = "Claim Number", required = false) @RequestParam(value = "claimNumber", required = false) String claimNumber,
			@Parameter(description = "Service From Date", required = false) @RequestParam(value = "serviceFromDate", required = false) String serviceFromDate,
			@Parameter(description = "Service To Date", required = false) @RequestParam(value = "serviceToDate", required = false) String serviceToDate,
			@Parameter(description = "Claim Status", required = false) @RequestParam(value = "claimStatus", required = false) String claimStatus,
			@Parameter(description = "Member Number", required = false) @RequestParam(value = "memberNumber", required = false) String memberNumber,
			@Parameter(description = "serviceCode", required = false) @RequestParam(value = "serviceCode", required = false) String serviceCode,
			@Parameter(description = "diagnosisCode", required = false) @RequestParam(value = "diagnosisCode", required = false) String diagnosisCode,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside member-getClaimDetails() of ClaimSearchAdaptorServiceController");
		log.debug("Inside member-getClaimDetails() ClaimSearchAdaptorServiceController and the requests:- claimTypes: {}, claimNumber: {}, serviceFromDate: {}, serviceToDate: {}, claimStatus: {}, memberNumber: {},ServiceCode: {}, diagnosisCode: {}",
				claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return claimSearchService.getMspMemberClaimSearch(claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, userIdentities, accessToken);
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return claimSearchService.getMemberClaimSearch(claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, accessToken);
		}

	}

	/**
	 * 2. Adaptor service for claim header details service for CRM
	 *
	 * @param providerId
	 * @param providerType
	 * @param claimTypes
	 * @param claimNumber
	 * @param serviceFromDate
	 * @param serviceToDate
	 * @param claimStatus
	 * @param memberNumber
	 * @param serviceCode
	 * @param diagnosisCode
	 * @param selectedSlp
	 * @param isMatchingUserRole
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Provider claims search", description = "A provider's claims can be retrieved through this service; depending on the filter conditions, all the provider's claims will be returned as a response. This API allows us to search for medical claims only. The following search parameters can be used to find provider's claims: provider ID, provider type, claim types, claim number, service from date, service to date, claim status, member number, service code, diagnosis code. The claim types is the required field among these. All the other arguments are optional if the claim number is provided. Besides that, there are other conditional necessary cases that we need to pass, such as the provider ID, provider type, service from date and service to date if the claim number is not provided. Furthermore, we can use the other parameters in the filters however we see appropriate; it is entirely optional. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters. Similarly, if provider ID is supplied, the provider type must also be provided, and vice versa.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Claim Provider Search Details", content = {
					@Content(schema = @Schema(implementation = ClaimHeaderSearchResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/provider/claimSearch")
	@ResponseBody
	public ResponseEntity<ClaimHeaderSearchResponse> getProviderClaimDetails(

			@Parameter(description = "Provider Id", required = false) @RequestParam(value = "providerId", required = false) String providerId,
			@Parameter(description = "Provider Type", required = false) @RequestParam(value = "providerType", required = false) String providerType,
			@Parameter(description = "Claim Types", required = true) @RequestParam(value = "claimTypes") String claimTypes,
			@Parameter(description = "Claim Number", required = false) @RequestParam(value = "claimNumber", required = false) String claimNumber,
			@Parameter(description = "Service From Date", required = false) @RequestParam(value = "serviceFromDate", required = false) String serviceFromDate,
			@Parameter(description = "Service To Date", required = false) @RequestParam(value = "serviceToDate", required = false) String serviceToDate,
			@Parameter(description = "Claim Status", required = false) @RequestParam(value = "claimStatus", required = false) String claimStatus,
			@Parameter(description = "Member Number", required = false) @RequestParam(value = "memberNumber", required = false) String memberNumber,
			@Parameter(description = "Service Code", hidden = false) @RequestParam(value = "serviceCode", required = false) String serviceCode,
			@Parameter(description = "Diagnosis Code", hidden = false) @RequestParam(value = "diagnosisCode", required = false) String diagnosisCode,
			@Parameter(description = "Selected user role", hidden = false) @RequestParam(value = "selectedSlp", required = false) String selectedSlp,
			@Parameter(description = "Is user role available in the request", hidden = false) @RequestParam(value = "isMatchingUserRole", required = false) String isMatchingUserRole,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getProviderClaimDetails() of ClaimSearchAdaptorServiceController");
		log.info("Inside getProviderClaimDetails() ClaimSearchAdaptorServiceController and the requests:- providerId: {}, providerType: {}, claimTypes: {}, claimNumber: {}, serviceFromDate: {}, serviceToDate: {}, claimStatus: {}, memberNumber: {},serviceCode: {}, diagnosisCode: {}, selectedSlp: {}, isMatchingUserRole: {}",
				providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, selectedSlp, isMatchingUserRole);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			if (StringUtils.isNotBlank(selectedSlp) && StringUtils.isNotBlank(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "true")) {
				return claimSearchService.getMspProviderClaimSearch(providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, selectedSlp, isMatchingUserRole, accessToken);
			} else if (StringUtils.isNotBlank(selectedSlp) && StringUtils.isNotEmpty(isMatchingUserRole) && StringUtils.equalsIgnoreCase(isMatchingUserRole, "false")) {
				return claimSearchService.providerClaimDataAvailabilityCheck(providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, selectedSlp, accessToken);
			} else {
				return claimSearchService.getMspProviderClaimSearch(providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, userIdentities, isMatchingUserRole, accessToken);
			}
		}
		else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return claimSearchService.getProviderClaimSearch(providerId, providerType, claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, serviceCode, diagnosisCode, accessToken);
		}
	}
}
