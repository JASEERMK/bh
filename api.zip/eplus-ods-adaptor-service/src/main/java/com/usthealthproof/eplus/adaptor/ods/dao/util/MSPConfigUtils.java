package com.usthealthproof.eplus.adaptor.ods.dao.util;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.usthealthproof.eplus.adaptor.ods.mapper.ServiceUrlMapper;
import com.usthealthproof.eplus.adaptor.ods.model.ServiceUrlResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.adaptor.ods.mapper.MultiStateConfigMapper;
import com.usthealthproof.eplus.adaptor.ods.model.MSPConfigResponse;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MSPConfigUtils {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private MultiStateConfigMapper multiStateConfigMapper;

	@Autowired
	private ServiceUrlMapper serviceUrlMapper;

	@Value("${mspConfigDetailsQuery}")
	private String mspConfigDetailsQuery;

	@Value("${serviceUrlDetailsQuery}")
	private String serviceUrlDetailsQuery;

	public static Map<String, String> mspConfigMap;

	public static Map<String, String> serviceUrlMap;

	@PostConstruct
	private void getMspConfigData() {
		log.info("Inside getMspConfigData() Post costruct in MSPConfigUtils class");

		List<MSPConfigResponse> mspConfigResponses = jdbcTemplate.query(mspConfigDetailsQuery, multiStateConfigMapper);
		mspConfigMap = mspConfigResponses.stream()
				.filter(response -> response.getCombinedSLP() != null && response.getServiceContextPath() != null)
				.collect(Collectors.toMap(MSPConfigResponse::getCombinedSLP, MSPConfigResponse::getServiceContextPath));
		log.info("MSP Data Configured in DB: {}", mspConfigMap);
	}

	@PostConstruct
	private void getServiceURL() {
		log.info("Inside getServiceURL() Post costruct in MSPConfigUtils class");

		List<ServiceUrlResponse> serviceUrlResponse = jdbcTemplate.query(serviceUrlDetailsQuery, serviceUrlMapper);
		serviceUrlMap = serviceUrlResponse.stream()
				.collect(Collectors.toMap(ServiceUrlResponse::getServiceName, ServiceUrlResponse::getServiceUrl));
		log.info("URL Configured in DB: {}", serviceUrlMap);
	}
}
