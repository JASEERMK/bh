package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.vision.VisionClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class VisionClaimData {

	public static final String VISION_CLAIMLINES = "/v1/claims/vision/claimlines";

	public static final String VISION_CLAIMLINE = "/v1/claims/vision/claimline";

	public static final String VISION_DETAILS = "/v1/claims/vision";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async
	public CompletableFuture<VisionClaimDetails> findVisionClaimId(String serviceUrl, String contextPath, String claimHccId, String state, String lob, String product,String accessToken) {
		log.info("Inside findVisionClaimId() of VisionClaimData");
		log.debug("Inside findVisionClaimId() of VisionClaimData class and the requests are- contextPath: {} & claimHccId: {} & accesstoken: {}",
				contextPath, claimHccId, accessToken);

		VisionClaimDetails visionClaimDetails = new VisionClaimDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + VISION_DETAILS);
				visionClaimDetails = webClientGatewayRoute.get().uri(
								uriBuilder -> uriBuilder.path(contextPath + VISION_DETAILS).queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
										.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
										.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
										.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
										.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(VisionClaimDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + VISION_DETAILS)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product)).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				visionClaimDetails = webClientBuilder.build().get()
						.uri(uri)
						.retrieve().bodyToMono(VisionClaimDetails.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			visionClaimDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			visionClaimDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("findVisionClaimId() completed");
		return CompletableFuture.completedFuture(visionClaimDetails);
	}

	@Async("asyncExecutor")
	public CompletableFuture<VisionClaimLinesResponse> getVisionClaimLines(String serviceUrl, String contextPath, String claimHccId,
			String state, String lob, String product, String accessToken) {
		log.info("Inside getVisionClaimLines() of VisionClaimData");
		log.debug("Inside getVisionClaimLines() of VisionClaimData class and the requests are- contextPath: {} & claimHccId: {} & accesstoken: {}",
				contextPath, claimHccId, accessToken);

		VisionClaimLinesResponse visionClaimLinesResponse = new VisionClaimLinesResponse();
		try {
		log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + VISION_CLAIMLINES);
		if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
			log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
			visionClaimLinesResponse = webClientGatewayRoute.get()
					.uri(uriBuilder -> uriBuilder.path(contextPath + VISION_CLAIMLINES)
							.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
							.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
							.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
							.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
							.build())
					.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(VisionClaimLinesResponse.class).block();
		} else {
			log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
			if (StringUtils.isBlank(serviceUrl)) {
				throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
			}
			URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + VISION_CLAIMLINES)
					.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
					.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
					.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
					.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
					.build()
					.toUri();
			log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
			visionClaimLinesResponse = webClientBuilder.build().get()
					.uri(uri).retrieve().bodyToMono(VisionClaimLinesResponse.class).block();
		}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			visionClaimLinesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			visionClaimLinesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getVisionClaimLines() completed");
		return CompletableFuture.completedFuture(visionClaimLinesResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<VisionClaimLineDetailsResponse> getVisionClaimLineDetails(String serviceUrl, String contextPath, String claimHccId,
			String claimLineHccId, String state, String lob, String product, String accessToken) {
		log.info("Inside getVisionClaimLineDetails() of VisionClaimData");
		log.debug("Inside getVisionClaimLineDetails() of VisionClaimData class and the requests are- contextPath: {} & claimHccId: {} & claimLineHccId: {} & accesstoken: {}",
				contextPath, claimHccId, claimLineHccId, accessToken);

		VisionClaimLineDetailsResponse visionClaimLineDetailsResponse = new VisionClaimLineDetailsResponse();
		try {
			log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + VISION_CLAIMLINE);
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				visionClaimLineDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + VISION_CLAIMLINE)
								.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(VisionClaimLineDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + VISION_CLAIMLINE)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				visionClaimLineDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(VisionClaimLineDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			visionClaimLineDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			visionClaimLineDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getVisionClaimLineDetails() completed");
		return CompletableFuture.completedFuture(visionClaimLineDetailsResponse);
	}
}