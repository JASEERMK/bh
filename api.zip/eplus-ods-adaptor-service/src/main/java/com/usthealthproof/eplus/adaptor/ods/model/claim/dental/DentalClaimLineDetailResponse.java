package com.usthealthproof.eplus.adaptor.ods.model.claim.dental;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Response class containing list of dental claim details")
public class DentalClaimLineDetailResponse implements Serializable {

	private static final long serialVersionUID = 7054645960398649233L;
	@Schema(description = "List containing claim line details of the dental claim")
	private List<DentalClaimLineDetails> dentalClaimLineDetailsList;
	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;
}
