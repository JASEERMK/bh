package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.denialcode.DenialCodes;
import com.usthealthproof.eplus.adaptor.ods.service.claim.DenialCodeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Claims Search Services")
@Slf4j
public class DenialCodeSearchController {

	@Autowired
	private DenialCodeService denialCodeService;

	/**
	 *
	 * @param claimNumber
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Retrieve all denial codes for a particular claim", description = "The API provides the denial code and description if a claim is denied, helping to identify the reason for the denial. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Denial Code Search Details", content = {
					@Content(schema = @Schema(implementation = DenialCodes.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/denialcodes")
	@ResponseBody
	public ResponseEntity<DenialCodes> getdenialcodesbyclaim(
			@Parameter(description = "Claim HCC ID", required = true) @RequestParam(value = "claimHccId", required = true) String claimNumber,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getdenialcodesbyclaim() of DenialCodeSearchController class");
		log.debug("Inside getdenialcodesbyclaim() of DenialCodeSearchController , service request received with:- claimNumber: {}", claimNumber);

		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			return denialCodeService.getMspDenialCodes(claimNumber, userIdentities, accessToken);
		} else {
			log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
			return denialCodeService.getDenialCodes(claimNumber, accessToken);
		}

	}

}
