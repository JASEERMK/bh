package com.usthealthproof.eplus.adaptor.ods.controller;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.service.OtherInsuranceService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.otherInsurance.OtherInsuranceDetails;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "Other Insurance Details")
@RequestMapping("/v1")
@RestController
@Slf4j
@Validated
@SecurityRequirement(name = "OdsAdaptorService")
public class OtherInsuranceAdaptorServiceController {

    @Autowired
    private OtherInsuranceService otherInsuranceService;

    /**
     * 1. Adaptor service for Other Insurance service using path param
     *
     * @param memberId
     * @param httpServletRequest
     * @return OtherInsuranceDetails
     * @throws Exception
     */
    @Operation(summary = "Retrieves member's other insurance policy details", description = "The service retrieves more information about the member's other insurance policies.  Member ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "List of member's other insurance policy details", content = {
                    @Content(schema = @Schema(implementation = OtherInsuranceDetails.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = "/member/otherinsurance/{memberId}", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<OtherInsuranceDetails> getOtherInsurance(
            @Parameter(description = "Member ID", required = true) @PathVariable("memberId") String memberId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getOtherInsurance() of OtherInsuranceAdaptorServiceController");
        log.debug("Member Other Insurance service request received with memberId: {}", memberId);

        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            return otherInsuranceService.getMspOtherInsuranceDetails(memberId, userIdentities, accessToken);
        } else {
            log.info(OdsAdaptorServiceConstants.MSP_DISABLED_MESSAGE);
            return otherInsuranceService.getOtherInsuranceDetails(memberId, accessToken);
        }
    }
}