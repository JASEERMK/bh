package com.usthealthproof.eplus.adaptor.ods.controller.authorization;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.DentalAuthorizationLinesResponseList;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLineDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationDetails.AuthorizationLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.auth.DentalAuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Dental Authorization Services")
@RestController
@Validated
@Slf4j
@RequestMapping("/v1/auths")
@SecurityRequirement(name = "OdsAdaptorService")
public class DentalAuthorizationController {


    @Autowired
    private DentalAuthService dentalAuthService;

    /**
     * Service retrieves dental authorization details for the given AuthorizationId
     *
     * @param authorizationId
     * @param httpServletRequest
     * @return
     * @throws Exception
     */
    @Operation(summary = "Dental Authorization Details", description = "Details regarding dental authorizations, can be accessed through the specified service. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Dental Authorization Details", content = {
                    @Content(schema = @Schema(implementation = DentalAuthorizationDetailsResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/dental", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<DentalAuthorizationDetailsResponse> getDentalAuthorizationDetails(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getDentalAuthorizationDetails() of DentalAuthorizationController");
        log.debug("To get the Dental Authorization Details based on Authorization ID:- {}", authorizationId);

        DentalAuthorizationDetailsResponse dentalAuthorizationDetailsResponse;
        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            dentalAuthorizationDetailsResponse= dentalAuthService.getMspDentalAuthorizationDetails(authorizationId, userIdentities,accessToken);
        } else {
            dentalAuthorizationDetailsResponse = dentalAuthService.getDentalAuthorizationDetails(authorizationId, accessToken);
        }
        log.info("Successfully generated dental-authorization-details response !!!");
        return new ResponseEntity<>(dentalAuthorizationDetailsResponse, HttpStatus.OK);
    }

    /**
     * Service retrieves dental authorization lines for the given AuthorizationId
     *
     * @param authorizationId
     * @param httpServletRequest
     * @return
     * @throws Exception
     */

    @Operation(summary = "Dental Authorization Lines", description = "Service Lines information’s regarding dental authorizations, can be accessed through the specified service. Authorization ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Dental Authorization Lines", content = {
                    @Content(schema = @Schema(implementation = AuthorizationLinesResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/dental/authlines", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<DentalAuthorizationLinesResponseList> getDentalAuthorizationLines(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getDentalAuthorizationLines() of DentalAuthorizationController");
        log.debug("To get the Dental Authorization Lines based on Authorization ID:- {}", authorizationId);

        DentalAuthorizationLinesResponseList dentalAuthorizationLinesResponseList;
        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            dentalAuthorizationLinesResponseList = dentalAuthService.getMspDentalAuthorizationLines(authorizationId, userIdentities,accessToken);
        } else {
            dentalAuthorizationLinesResponseList = dentalAuthService.getDentalAuthorizationLines(authorizationId, accessToken);
        }
        log.info("Successfully generated dental-authorization-lines response !!!");
        return new ResponseEntity<>(dentalAuthorizationLinesResponseList, HttpStatus.OK);
    }


    /**
     *  Service retrieves dental authorization line details for the given AuthorizationId and ServiceLineId
     *
     * @param authorizationId
     * @param serviceLineId
     * @param httpServletRequest
     * @return
     * @throws Exception
     */
    @Operation(summary = "Dental Authorization Line Details", description = "Service Line details regarding dental authorizations, can be accessed through the specified service. Authorization ID and Authorization Line ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Authorization Line Details", content = {
                    @Content(schema = @Schema(implementation = AuthorizationLineDetailsResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/dental/authline", produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseBody
    public ResponseEntity<DentalAuthorizationLineDetailsResponse> getDentalAuthorizationLineDetails(
            @Parameter(description = "Authorization ID", required = true) @RequestParam(value = "authorizationId") String authorizationId,
            @Parameter(description = "Service Line Id", required = true) @RequestParam(value = "serviceLineId") String serviceLineId,
            HttpServletRequest httpServletRequest) throws Exception {
        log.info("Inside getDentalAuthorizationLineDetails() of DentalAuthorizationController");
        log.info("To get the Dental Authorization Line Details based on Authorization ID:- {} and ServiceLineId:- {}", authorizationId,
                serviceLineId);

        DentalAuthorizationLineDetailsResponse dentalAuthorizationLineDetailsResponse;
        String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
        String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
        if (StringUtils.isNotBlank(userIdentities)) {
            log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
            dentalAuthorizationLineDetailsResponse = dentalAuthService.getMspDentalAuthorizationLineDetails(authorizationId, serviceLineId, userIdentities,accessToken);
        } else {
            dentalAuthorizationLineDetailsResponse = dentalAuthService.getDentalAuthorizationLineDetails(authorizationId, serviceLineId, accessToken);
        }
        log.info("Successfully generated dental-authorization-line details response !!!");
        return new ResponseEntity<>(dentalAuthorizationLineDetailsResponse, HttpStatus.OK);
    }
}
