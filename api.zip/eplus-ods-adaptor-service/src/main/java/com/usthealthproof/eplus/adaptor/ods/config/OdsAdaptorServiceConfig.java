package com.usthealthproof.eplus.adaptor.ods.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import lombok.Data;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

@Configuration
@EnableConfigurationProperties
@Data
@EnableAsync
public class OdsAdaptorServiceConfig {

	@Value("${service.uri.baseUrl}")
	private String baseUrl;

	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-ods-adaptor-service/api-docs
	 * Swagger UI: http://localhost:8080/eplus/eplus-ods-adaptor-service/index.html
	 */

	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("ODS Adaptor Services").description(
				"This is an Adaptor Service for handling the requests and will re-direct to the actual service based on the requests.\n\n"
						+ "The consumers are provided with a url and credentials to get the access token. The service calls are made with valid access token in the header as Bearer Token.\n\n"
						+ "For every failure a problemDetails object with error message and status will be available in the response.")
				.version("5.10.1" ));
	}

	@Bean
	public WebClient.Builder webClientBuilder() {
		final ExchangeStrategies strategies = ExchangeStrategies.builder()
				.codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient()))
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies);
	}

	@Bean
	public WebClient webClientGatewayRoute() {
		final ExchangeStrategies strategies = ExchangeStrategies.builder()
				.codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient())).baseUrl(baseUrl)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies).build();
	}

	private HttpClient getHttpClient() {
		ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(500).maxIdleTime(Duration.ofSeconds(20))
				.maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
				.evictInBackground(Duration.ofSeconds(120)).build();
		return HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 20000).doOnConnected(
				conn -> conn.addHandlerLast(new ReadTimeoutHandler(20)).addHandlerLast(new WriteTimeoutHandler(20)));

	}

	@Bean(name = "asyncExecutor")
	public Executor asyncExecutor() {

		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(100);
		executor.setMaxPoolSize(100);
		executor.setQueueCapacity(100);
		executor.setThreadNamePrefix("AsynchThread-");
		executor.initialize();
		return executor;
	}

}
