package com.usthealthproof.eplus.adaptor.ods.dao;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class CorrespondenceHistoryData {

	public static final String CORRESPONDENCE_SEARCH = "/v2/correspondence/search";

	public static final String CORRESPONDENCE_DETAILS = "/v2/correspondence/details";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async("asyncExecutor")
	public CompletableFuture<CorrespondenceSearchResponseList> getCorrespondenceSearch(String serviceUrl, String contextPath, String memberId,
			String correspondenceName, String createdFrom, String createdTo, String claimId, String state, String lob,
			String product, String accessToken) throws InterruptedException {
		log.info("Inside getCorrespondenceSearch() of CorrespondenceHistoryData");
		log.debug("Inside getCorrespondenceSearch() of CorrespondenceHistoryData class and the requests are contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		CorrespondenceSearchResponseList correspondenceSearchResponseList = new CorrespondenceSearchResponseList();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + CORRESPONDENCE_SEARCH);
				correspondenceSearchResponseList = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + CORRESPONDENCE_SEARCH).queryParam("memberId", memberId)
								.queryParam("correspondenceName", correspondenceName).queryParam("createdFrom", createdFrom)
								.queryParam("createdTo", createdTo).queryParam("claimId", claimId).queryParam(OdsAdaptorServiceConstants.STATE, state)
								.queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(CorrespondenceSearchResponseList.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + CORRESPONDENCE_SEARCH).queryParam("memberId", memberId).queryParam("correspondenceName", correspondenceName).queryParam("createdFrom", createdFrom)
						.queryParam("createdTo", createdTo).queryParam("claimId", claimId).queryParam(OdsAdaptorServiceConstants.STATE, state)
						.queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				correspondenceSearchResponseList = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(CorrespondenceSearchResponseList.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			correspondenceSearchResponseList.setErrors(errorResponse.getProblemDetails().getErrors());
			correspondenceSearchResponseList.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getCorrespondenceSearch() completed");
		return CompletableFuture.completedFuture(correspondenceSearchResponseList);
	}

	@Async("asyncExecutor")
	public CompletableFuture<CorrespondenceDetailsResponse> getCorrespondenceDetails(String serviceUrl, String contextPath, String correspondenceId,
			String state, String lob, String product, String accessToken) {
		log.info("Inside getCorrespondenceDetails() of CorrespondenceHistoryData");
		log.debug("Inside getCorrespondenceDetails() in the CorrespondenceHistoryData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		CorrespondenceDetailsResponse correspondenceDetailsResponse = new CorrespondenceDetailsResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + CORRESPONDENCE_DETAILS);
				correspondenceDetailsResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + CORRESPONDENCE_DETAILS)
								.queryParam("correspondenceId", correspondenceId).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
								.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(CorrespondenceDetailsResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + CORRESPONDENCE_DETAILS)
						.queryParam("correspondenceId", correspondenceId).queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob)
						.queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				correspondenceDetailsResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(CorrespondenceDetailsResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			correspondenceDetailsResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			correspondenceDetailsResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getCorrespondenceDetails() completed");
		return CompletableFuture.completedFuture(correspondenceDetailsResponse);
	}
}
