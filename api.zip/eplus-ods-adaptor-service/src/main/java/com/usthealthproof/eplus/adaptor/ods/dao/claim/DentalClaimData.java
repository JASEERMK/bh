package com.usthealthproof.eplus.adaptor.ods.dao.claim;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class DentalClaimData {

	public static final String DENTAL_CLAIMLINE = "/v1/claims/dental/claimline";

	public static final String DENTAL_CLAIMLINES = "/v1/claims/dental/claimlines";

	public static final String DENTAL_DETAILS = "/v1/claims/dental";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async
	public CompletableFuture<DentalClaimDetails> findDentalClaimId(String serviceUrl, String contextPath, String claimHccId, String state, String lob, String product, String accessToken) {
		log.info("Inside findDentalClaimId() of DentalClaimData class");
		log.debug("Inside findDentalClaimId() of DentalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalClaimDetails dentalClaimDetails = new DentalClaimDetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_DETAILS);
				dentalClaimDetails = webClientGatewayRoute.get().uri(
								uriBuilder -> uriBuilder.path(contextPath + DENTAL_DETAILS).queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
										.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
										.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
										.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
										.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalClaimDetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_DETAILS)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalClaimDetails = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalClaimDetails.class).block();
			}
		}catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalClaimDetails.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalClaimDetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("multiStateDentalDetails() completed");
		return CompletableFuture.completedFuture(dentalClaimDetails);
	}

	@Async("asyncExecutor")
	public CompletableFuture<DentalClaimLinesResponse> getDentalClaimLines(String serviceUrl, String contextPath, String claimHccId,
			String state, String lob, String product, String accessToken) {
		log.info("Inside getDentalClaimLines() of DentalClaimData class");
		log.debug("Inside getDentalClaimLines() of DentalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalClaimLinesResponse dentalClaimLinesResponse = new DentalClaimLinesResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_CLAIMLINES);
				dentalClaimLinesResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + DENTAL_CLAIMLINES)
								.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalClaimLinesResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_CLAIMLINES)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalClaimLinesResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalClaimLinesResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalClaimLinesResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalClaimLinesResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("multiStateDentalClaimLines() completed");
		return CompletableFuture.completedFuture(dentalClaimLinesResponse);
	}

	@Async("asyncExecutor")
	public CompletableFuture<DentalClaimLineDetailResponse> getDentalClaimLineDetails(String serviceUrl, String contextPath, String claimHccId,
			String claimLineHccId, String state, String lob, String product, String accessToken) {
		log.info("Inside getDentalClaimLineDetails() of DentalClaimData class");
		log.debug("Inside getDentalClaimLineDetails() of DentalClaimData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		DentalClaimLineDetailResponse dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + DENTAL_CLAIMLINE);
				dentalClaimLineDetailResponse = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + DENTAL_CLAIMLINE)
								.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
								.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
								.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
								.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
								.build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(DentalClaimLineDetailResponse.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + DENTAL_CLAIMLINE)
						.queryParam(OdsAdaptorServiceConstants.CLAIM_HCC_ID, claimHccId).queryParam("claimLineHccId", claimLineHccId)
						.queryParamIfPresent(OdsAdaptorServiceConstants.STATE, Optional.ofNullable(state))
						.queryParamIfPresent(OdsAdaptorServiceConstants.LOB, Optional.ofNullable(lob))
						.queryParamIfPresent(OdsAdaptorServiceConstants.PRODUCT, Optional.ofNullable(product))
						.build()
						.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				dentalClaimLineDetailResponse = webClientBuilder.build().get()
						.uri(uri).retrieve().bodyToMono(DentalClaimLineDetailResponse.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			dentalClaimLineDetailResponse.setErrors(errorResponse.getProblemDetails().getErrors());
			dentalClaimLineDetailResponse.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("multiStateDentalClaimLineDetails() completed");
		return CompletableFuture.completedFuture(dentalClaimLineDetailResponse);
	}
}