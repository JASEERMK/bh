package com.usthealthproof.eplus.adaptor.ods.service.auth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationCallLogNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationClinicalNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotes;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthorizationNotesMspService {

	@Autowired
	private AuthorizationData authorizationData;

	@Autowired
	private DaoUtil daoUtil;

	@Autowired
	APIUtils apiUtils;

	@Value("${service.name.authorizationServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	public ResponseEntity<AuthorizationNotesResponse> getMspAuthorizationNotes(String authorizationId, String userIdentities,
			String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
		log.info("Inside getMspAuthorizationNotes() of AuthorizationNotesMspService");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		try {
			String state;
			String lob;
			String product;
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<AuthorizationNotesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				state = !slpData.isEmpty() ? slpData.get(0) : "";
				lob = slpData.size() > 1 ? slpData.get(1) : "";
				product = slpData.size() > 2 ? slpData.get(2) : "";

				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<AuthorizationNotesResponse> completableFuture = authorizationData.getAuthorizationNotes(
						serviceUrl, defaultContextPath + multiStateContextPath, authorizationId, state, lob, product,
						accessToken);
				completableFutureList.add(completableFuture);
			}
			List<AuthorizationNotes> authorizationNotesList = new ArrayList<>();
			for (CompletableFuture<AuthorizationNotesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getAuthorizationNotes() != null
						&& !completableFuture.get().getAuthorizationNotes().isEmpty()) {
					authorizationNotesList.addAll(completableFuture.get().getAuthorizationNotes());
				}
			}

			if (null == authorizationNotesList || authorizationNotesList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				AuthorizationNotesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			authorizationNotesResponse.setAuthorizationNotes(authorizationNotesList);

		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

	public ResponseEntity<AuthorizationNotesResponse> getMspAuthorizationCallLogsNotes(String authorizationId,
			String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
		log.info("Inside getMspAuthorizationCallLogsNotes() of AuthorizationNotesMspService");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		try {
			String state;
			String lob;
			String product;
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<AuthorizationNotesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				state = !slpData.isEmpty() ? slpData.get(0) : "";
				lob = slpData.size() > 1 ? slpData.get(1) : "";
				product = slpData.size() > 2 ? slpData.get(2) : "";
				CompletableFuture<AuthorizationNotesResponse> completableFuture = null;
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				completableFuture = authorizationData.getAuthorizationCallLogsNotes(serviceUrl,
						defaultContextPath + multiStateContextPath, authorizationId, state, lob, product, accessToken);
				completableFutureList.add(completableFuture);
			}

			List<AuthorizationCallLogNotes> authorizationCallLogNotesList = new ArrayList<>();
			for (CompletableFuture<AuthorizationNotesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getAuthorizationCallLogNotes() != null
						&& !completableFuture.get().getAuthorizationCallLogNotes().isEmpty()) {
					authorizationCallLogNotesList.addAll(completableFuture.get().getAuthorizationCallLogNotes());
				}
			}

			if (null == authorizationCallLogNotesList || authorizationCallLogNotesList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				AuthorizationNotesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			authorizationNotesResponse.setAuthorizationCallLogNotes(authorizationCallLogNotesList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

	public ResponseEntity<AuthorizationNotesResponse> getMspAuthorizationNotesClinicalReview(String authorizationId,
			String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
		log.info("Inside getMspAuthorizationNotesClinicalReview() of AuthorizationNotesMspService");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		try {
			String state;
			String lob;
			String product;
			Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
			List<CompletableFuture<AuthorizationNotesResponse>> completableFutureList = new ArrayList<>();
			for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
				String multiStateContextPath = slp.getValue();
				List<String> slpData = Arrays.asList(slp.getKey().split(":"));
				state = !slpData.isEmpty() ? slpData.get(0) : "";
				lob = slpData.size() > 1 ? slpData.get(1) : "";
				product = slpData.size() > 2 ? slpData.get(2) : "";
				String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
				CompletableFuture<AuthorizationNotesResponse> completableFuture = authorizationData.getAuthorizationNotesClinical(
						serviceUrl, defaultContextPath + multiStateContextPath, authorizationId, state, lob, product,
						accessToken);
				completableFutureList.add(completableFuture);
			}

			List<AuthorizationClinicalNotes> authorizationNotesClinicalResponseList = new ArrayList<>();
			for (CompletableFuture<AuthorizationNotesResponse> completableFuture : completableFutureList) {
				if (completableFuture.get().getAuthorizationClinicalNotes() != null
						&& !completableFuture.get().getAuthorizationClinicalNotes().isEmpty()) {
					authorizationNotesClinicalResponseList.addAll(completableFuture.get().getAuthorizationClinicalNotes());
				}
			}

			if (null == authorizationNotesClinicalResponseList || authorizationNotesClinicalResponseList.isEmpty()) {
				log.info(OdsAdaptorServiceConstants.NO_DATA);
				AuthorizationNotesResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1).get();
				throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
						StringUtils.join(errorResponse.getErrors(), ","), null,
						new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
			}
			authorizationNotesResponse.setAuthorizationClinicalNotes(authorizationNotesClinicalResponseList);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

}
