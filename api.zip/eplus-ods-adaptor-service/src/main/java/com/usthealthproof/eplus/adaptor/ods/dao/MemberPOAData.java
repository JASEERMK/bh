package com.usthealthproof.eplus.adaptor.ods.dao;

import java.net.URI;
import java.util.concurrent.CompletableFuture;

import com.usthealthproof.eplus.adaptor.ods.config.OdsAdaptorServiceConfig;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.memberPOA.MemberPOADetails;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j

public class MemberPOAData {

	public static final String MEMBER_POA_DETAILS = "/v1/member/poa/details";

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private WebClient webClientGatewayRoute;

	@Autowired
	private OdsAdaptorServiceConfig odsAdaptorServiceConfig;

	@Value("${service.uri.isOAuthTokenRequired}")
	private String isOAuthTokenRequired;

	@Async("asyncExecutor")
	public CompletableFuture<MemberPOADetails> getMemberPoaDetails(String serviceUrl, String contextPath, String memberId, String state, String lob,
			String product, String accessToken) {
		log.info("Inside getMemberPoaDetails() of MemberPOAData");
		log.debug("Inside getMemberPoaDetails() of MemberPOAData class and the requests are- contextPath: {} & accessToken: {}",
				contextPath, accessToken);

		MemberPOADetails memberPOADetails = new MemberPOADetails();
		try {
			if (null != isOAuthTokenRequired && StringUtils.equalsIgnoreCase(isOAuthTokenRequired, "true")) {
				log.info(OdsAdaptorServiceConstants.WITH_OAUTH_TOKEN_MESSAGE);
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, odsAdaptorServiceConfig.getBaseUrl() + contextPath + MEMBER_POA_DETAILS);
				memberPOADetails = webClientGatewayRoute.get()
						.uri(uriBuilder -> uriBuilder.path(contextPath + MEMBER_POA_DETAILS).queryParam("memberId", memberId)
								.queryParam(OdsAdaptorServiceConstants.STATE, state).queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build())
						.header(OdsAdaptorServiceConstants.AUTHORIZATION_KEY, accessToken).retrieve().bodyToMono(MemberPOADetails.class).block();
			} else {
				log.info(OdsAdaptorServiceConstants.WITHOUT_OAUTH_TOKEN_MESSAGE);
				if (StringUtils.isBlank(serviceUrl)) {
					throw new RequestValidationException(OdsAdaptorServiceConstants.SERVICE_URL_MESSAGE);
				}
				URI uri = UriComponentsBuilder.fromHttpUrl(serviceUrl).path(contextPath + MEMBER_POA_DETAILS)
							.queryParam("memberId", memberId).queryParam(OdsAdaptorServiceConstants.STATE, state)
							.queryParam(OdsAdaptorServiceConstants.LOB, lob).queryParam(OdsAdaptorServiceConstants.PRODUCT, product).build()
							.toUri();
				log.info(OdsAdaptorServiceConstants.ENDPOINT_LOGGING_MESSAGE, uri);
				memberPOADetails = webClientBuilder.build().get().uri(uri).retrieve().bodyToMono(MemberPOADetails.class).block();
			}
		} catch (WebClientResponseException webClientResponseException) {
			log.info(OdsAdaptorServiceConstants.WEBCLIENT_RESPONSE_EXCEPTION, webClientResponseException.getMessage(),
					webClientResponseException.getStatusCode(), webClientResponseException);
			ErrorResponse errorResponse = APIUtils.createErrorResponse(webClientResponseException);
			memberPOADetails.setErrors(errorResponse.getProblemDetails().getErrors());
			memberPOADetails.setHttpStatusCode(webClientResponseException.getStatusCode().value());
		}
		log.info("getMemberPoaDetails() completed");
		return CompletableFuture.completedFuture(memberPOADetails);
	}
}
