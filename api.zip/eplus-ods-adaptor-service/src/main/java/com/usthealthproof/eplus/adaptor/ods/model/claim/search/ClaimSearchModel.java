package com.usthealthproof.eplus.adaptor.ods.model.claim.search;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Object for holding the claim search response")
public class ClaimSearchModel implements Serializable {

	private static final long serialVersionUID = -6435420302650121082L;
	@Schema(description = "Claim number")
	private String claimNumber;

	@Schema(description = "Service date")
	private String dos;

	@Schema(description = "Claim status")
	private String claimStatus;

	@Schema(description = "Provider name")
	private String providerName;

	@Schema(description = "Billed Amount")
	private String billedAmount;

	@Schema(description = "Date Paid")
	private String datePaid;

	@Schema(description = "Pharmacy Name")
	private String pharmacyName;

	@Schema(description = "Drug Name")
	private String drugName;

	@Schema(description = "Date Filled")
	private String dateFilled;

	@Schema(description = "Member name")
	private String memberName;

	@Schema(description = "Patient Account Number")
	private String patientAccountNumber;

	@Schema(description = "Member id")
	private String memberId;

	@Schema(description = "Prescription ID - Only relevant for Member search for Pharmacy claims")
	private String prescriptionId;
}
