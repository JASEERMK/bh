package com.usthealthproof.eplus.adaptor.ods.validator;

import java.util.Map;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;

import com.usthealthproof.eplus.adaptor.ods.exception.RequestValidationException;
import com.usthealthproof.eplus.adaptor.ods.exception.ResponseValidationException;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Validator {

	/**
	 * Method for validating the httpServletRequest and the Authorization token
	 * 
	 * @param httpServletRequest
	 * @return String
	 * @throws RequestValidationException
	 */
	public String validateBearerToken(HttpServletRequest httpServletRequest) throws RequestValidationException {
		log.info("Inside validateBearerToken()");

		if (null == httpServletRequest) {
			log.info("The httpServletRequest is NULL or Empty");
			throw new RequestValidationException("Please try with a valid request");
		}

		String bearerToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		if (StringUtils.isBlank(bearerToken)) {
			throw new RequestValidationException("Bearer Token cannot be NULL or Empty");
		}
		return bearerToken;
	}

	/**
	 * Method for validating the clientResponse that received from the WebClient
	 * call
	 * 
	 * @param clientResponse
	 * @throws Exception
	 */
	public void validateClientResponse(ClientResponse clientResponse) throws Exception {
		log.info("Inside validateClientResponse()");

		if (null == clientResponse) {
			log.info("The clientResponse from the external service call is NULL or Empty");
			throw new Exception();
		}
	}

	/**
	 * Method for validating the data received from the MSP configuration table
	 * 
	 * @param mspConfigMap
	 * @throws Exception
	 */
	public void validateMspConfigResponse(Map<String, String> mspConfigMap) throws ResponseValidationException {
		log.info("Inside validateMspConfigResponse()");

		if (null == mspConfigMap) {
			log.info("The mspConfigMap from the MSP Config table is NULL or Empty");
			throw new RequestValidationException("Invalid Request: The requested CSR access does not find any match");
		}

		if (mspConfigMap.size() < 1) {
			log.info("The mspConfigMap size from the MSP Config table is Zero");
			throw new RequestValidationException("Invalid Request: The requested CSR access does not find any match");
		}

	}

	/**
	 * Method for validating the MspConfigData except for claims and Auth
	 *
	 * @param mspConfigDetails
	 * @throws RequestValidationException
	 */
	public void validateMspConfigData(Map<String, String> mspConfigDetails) throws RequestValidationException {
		log.info("Inside validateMspConfigData() mspConfigDetails: {}", mspConfigDetails);

		if (null == mspConfigDetails || mspConfigDetails.isEmpty()) {
			throw new RequestValidationException("Invalid Request: Valid User Access is required");
		}
	}
}
