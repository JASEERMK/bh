package com.usthealthproof.eplus.adaptor.ods.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import com.usthealthproof.eplus.adaptor.ods.dao.CorrespondenceHistoryData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.exception.ODSAdaptorException;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceDetailsResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponse;
import com.usthealthproof.eplus.adaptor.ods.model.correspondence.CorrespondenceSearchResponseList;
import com.usthealthproof.eplus.adaptor.ods.util.DaoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class CorrespondenceHistoryService {

    @Autowired
    private CorrespondenceHistoryData correspondenceHistoryData;

    @Autowired
    private DaoUtil daoUtil;

    @Value("${service.name.correspondenceServiceName}")
    private String serviceName;

    @Value("${service.uri.defaultContextPath}")
    private String defaultContextPath;

    @Value("${service.uri.defaultState}")
    private String defaultState;

    public ResponseEntity<CorrespondenceSearchResponseList> getMspCorrespondenceSearch(String memberId, String correspondenceName, String createdFrom, String createdTo, String claimId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspCorrespondenceSearch() of CorrespondenceHistoryService class");

        CorrespondenceSearchResponseList correspondenceSearchResponseList = new CorrespondenceSearchResponseList();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<CorrespondenceSearchResponseList>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<CorrespondenceSearchResponseList> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = correspondenceHistoryData.getCorrespondenceSearch(serviceUrl,
                        defaultContextPath + multiStateContextPath, memberId, correspondenceName, createdFrom, createdTo,
                        claimId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            List<CorrespondenceSearchResponse> correspondenceSearchResponse = new ArrayList<>();
            for (CompletableFuture<CorrespondenceSearchResponseList> completableFuture : completableFutureList) {
                if (completableFuture.get().getCorrespondenceList() != null
                        && !completableFuture.get().getCorrespondenceList().isEmpty()) {
                    correspondenceSearchResponse.addAll(completableFuture.get().getCorrespondenceList());
                }
            }
            if (null == correspondenceSearchResponse || correspondenceSearchResponse.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                CorrespondenceSearchResponseList errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }
            correspondenceSearchResponseList.setCorrespondenceList(correspondenceSearchResponse);
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Correspondence Search Response");
        return new ResponseEntity<>(correspondenceSearchResponseList, HttpStatus.OK);
    }

    public ResponseEntity<CorrespondenceSearchResponseList> getCorrespondenceSearch(String memberId, String correspondenceName, String createdFrom, String createdTo, String claimId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getCorrespondenceSearch() of CorrespondenceHistoryService class");

        CorrespondenceSearchResponseList correspondenceSearchResponseList = new CorrespondenceSearchResponseList();

        CompletableFuture<CorrespondenceSearchResponseList> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = correspondenceHistoryData.getCorrespondenceSearch(serviceUrl, defaultContextPath + defaultState,
                    memberId, correspondenceName, createdFrom, createdTo, claimId, null, null, null, accessToken);
            if (completableFuture.get().getCorrespondenceList() != null
                    && !completableFuture.get().getCorrespondenceList().isEmpty()) {
                correspondenceSearchResponseList.setCorrespondenceList(completableFuture.get().getCorrespondenceList());
            } else {
                List<String> correspondenceHistoryErrors = completableFuture.get().getErrors();
                if (correspondenceHistoryErrors != null && !correspondenceHistoryErrors.isEmpty()) {
                    log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                    String exceptionMessage = null;
                    if (StringUtils.isBlank(correspondenceHistoryErrors.get(0))) {
                        exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                    } else {
                        exceptionMessage = correspondenceHistoryErrors.get(0) + "|"
                                + completableFuture.get().getHttpStatusCode();
                    }
                    throw new ODSAdaptorException(exceptionMessage);
                }
            }
        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Correspondence Search Response");
        return new ResponseEntity<>(correspondenceSearchResponseList, HttpStatus.OK);
    }

    public ResponseEntity<CorrespondenceDetailsResponse> getMspCorrespondenceDetails(String correspondenceId, String userIdentities, String accessToken) throws InterruptedException, ExecutionException, JsonProcessingException {
        log.info("Inside getMspCorrespondenceDetails() of CorrespondenceHistoryService class");

        CorrespondenceDetailsResponse correspondenceDetailsResponse = new CorrespondenceDetailsResponse();
        try {
            Map<String, String> mspConfigMap = daoUtil.getMspConfigMap(userIdentities);
            List<CompletableFuture<CorrespondenceDetailsResponse>> completableFutureList = new ArrayList<>();
            for (Map.Entry<String, String> slp : mspConfigMap.entrySet()) {
                String multiStateContextPath = slp.getValue();
                List<String> slpData = Arrays.asList(slp.getKey().split(":"));
                String state = !slpData.isEmpty() ? slpData.get(0) : "";
                String lob = slpData.size() > 1 ? slpData.get(1) : "";
                String product = slpData.size() > 2 ? slpData.get(2) : "";
                log.info(OdsAdaptorServiceConstants.USER_IDENTITIES_LOGGING_MESSAGE, slp.getKey(), slp.getValue());
                CompletableFuture<CorrespondenceDetailsResponse> completableFuture = null;
                String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + multiStateContextPath);
                completableFuture = correspondenceHistoryData.getCorrespondenceDetails(serviceUrl,
                        defaultContextPath + multiStateContextPath, correspondenceId, state, lob, product, accessToken);
                completableFutureList.add(completableFuture);
            }

            for (CompletableFuture<CorrespondenceDetailsResponse> completableFuture : completableFutureList) {
                if (StringUtils.isNotBlank(completableFuture.get().getCorrespondenceId())) {
                    correspondenceDetailsResponse = setCorrespondenceDetailsResponse(completableFuture);
                }
            }

            if (null != correspondenceDetailsResponse
                    && StringUtils.isBlank(correspondenceDetailsResponse.getCorrespondenceId())) {
                log.info(OdsAdaptorServiceConstants.NO_DATA);
                CorrespondenceDetailsResponse errorResponse = completableFutureList.get(completableFutureList.size() - 1)
                        .get();
                throw new WebClientResponseException(errorResponse.getHttpStatusCode(),
                        StringUtils.join(errorResponse.getErrors(), ","), null,
                        new ObjectMapper().writer().writeValueAsBytes(errorResponse), null);
            }

        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Correspondence Details Response");
        return new ResponseEntity<>(correspondenceDetailsResponse, HttpStatus.OK);
    }

    private CorrespondenceDetailsResponse setCorrespondenceDetailsResponse(CompletableFuture<CorrespondenceDetailsResponse> completableFuture) throws InterruptedException, ExecutionException {
        CorrespondenceDetailsResponse correspondenceDetailsResponse = new CorrespondenceDetailsResponse();
        correspondenceDetailsResponse.setCorrespondenceId(completableFuture.get().getCorrespondenceId());
        correspondenceDetailsResponse.setCorrespondenceName(completableFuture.get().getCorrespondenceName());
        correspondenceDetailsResponse.setCurrentStatus(completableFuture.get().getCurrentStatus());
        correspondenceDetailsResponse.setClaimId(completableFuture.get().getClaimId());
        correspondenceDetailsResponse.setCancelledDate(completableFuture.get().getCancelledDate());
        correspondenceDetailsResponse.setResentDate(completableFuture.get().getResentDate());
        correspondenceDetailsResponse.setSupplierId(completableFuture.get().getSupplierId());
        correspondenceDetailsResponse.setCreatedDate(completableFuture.get().getCreatedDate());
        correspondenceDetailsResponse.setSentDate(completableFuture.get().getSentDate());
        correspondenceDetailsResponse.setGeneratedDate(completableFuture.get().getGeneratedDate());
        return correspondenceDetailsResponse;
    }

    public ResponseEntity<CorrespondenceDetailsResponse> getCorrespondenceDetails(String correspondenceId, String accessToken) throws InterruptedException, ExecutionException {
        log.info("Inside getCorrespondenceDetails() of CorrespondenceHistoryService class");

        CorrespondenceDetailsResponse correspondenceDetailsResponse = new CorrespondenceDetailsResponse();
        CompletableFuture<CorrespondenceDetailsResponse> completableFuture = null;
        try {
            String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
            completableFuture = correspondenceHistoryData.getCorrespondenceDetails(serviceUrl, defaultContextPath + defaultState,
                    correspondenceId, null, null, null, accessToken);
            if (StringUtils.isNotBlank(completableFuture.get().getCorrespondenceId())) {
                correspondenceDetailsResponse = setCorrespondenceDetailsResponse(completableFuture);
            }
            List<String> correspondenceHistoryErrors = completableFuture.get().getErrors();
            if (correspondenceHistoryErrors != null && !correspondenceHistoryErrors.isEmpty()) {
                log.info(OdsAdaptorServiceConstants.GENERAL_EXCEPTION_MESSAGE);
                String exceptionMessage = null;
                if (StringUtils.isBlank(correspondenceHistoryErrors.get(0))) {
                    exceptionMessage = OdsAdaptorServiceConstants.EXCEPTION_MESSAGE + "|500";
                } else {
                    exceptionMessage = correspondenceHistoryErrors.get(0) + "|"
                            + completableFuture.get().getHttpStatusCode();
                }
                throw new ODSAdaptorException(exceptionMessage);
            }

        } catch (WebClientException clientException) {
            throw clientException;
        } catch (Exception ex) {
            throw ex;
        }
        log.info("Successfully generated Correspondence Details Response");
        return new ResponseEntity<>(correspondenceDetailsResponse, HttpStatus.OK);
    }
}
