package com.usthealthproof.eplus.adaptor.ods.service.auth;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientException;

import com.usthealthproof.eplus.adaptor.ods.dao.AuthorizationData;
import com.usthealthproof.eplus.adaptor.ods.dao.util.MSPConfigUtils;
import com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes.AuthorizationNotesResponse;
import com.usthealthproof.eplus.adaptor.ods.util.APIUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthorizationNotesNonMspService {

	@Autowired
	private AuthorizationData authorizationData;

	@Autowired
	APIUtils apiUtils;

	@Value("${service.name.authorizationServiceName}")
	private String serviceName;

	@Value("${service.uri.defaultContextPath}")
	private String defaultContextPath;

	@Value("${service.uri.defaultState}")
	private String defaultState;

	public ResponseEntity<AuthorizationNotesResponse> getAuthorizationNotes(String authorizationId, String accessToken)
			throws InterruptedException, ExecutionException {
		log.info("Inside getAuthorizationNotes() of AuthorizationNotesNonMspService class");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		CompletableFuture<AuthorizationNotesResponse> completableFuture = null;
		try {
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
			completableFuture = authorizationData.getAuthorizationNotes(serviceUrl, defaultContextPath + defaultState,
					authorizationId, null, null, null, accessToken);
			if (completableFuture.get().getAuthorizationNotes() != null
					&& !completableFuture.get().getAuthorizationNotes().isEmpty()) {
				authorizationNotesResponse.setAuthorizationNotes(completableFuture.get().getAuthorizationNotes());
			}
			apiUtils.errorHandling(completableFuture);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

	public ResponseEntity<AuthorizationNotesResponse> getAuthorizationCallLogsNotes(String authorizationId, String accessToken)
			throws InterruptedException, ExecutionException {
		log.info("Inside getAuthorizationCallLogsNotes() of AuthorizationNotesNonMspService class");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		CompletableFuture<AuthorizationNotesResponse> completableFuture = null;
		try {
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
			completableFuture = authorizationData.getAuthorizationCallLogsNotes(serviceUrl, defaultContextPath + defaultState,
					authorizationId, null, null, null, accessToken);
			if (completableFuture.get().getAuthorizationCallLogNotes() != null
					&& !completableFuture.get().getAuthorizationCallLogNotes().isEmpty()) {
				authorizationNotesResponse.setAuthorizationCallLogNotes(completableFuture.get().getAuthorizationCallLogNotes());
			}
			apiUtils.errorHandling(completableFuture);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

	public ResponseEntity<AuthorizationNotesResponse> getAuthorizationNotesClinicalReview(String authorizationId,
			String accessToken) throws InterruptedException, ExecutionException {
		log.info("Inside getAuthorizationNotesClinicalReview() of AuthorizationNotesNonMspService class");

		AuthorizationNotesResponse authorizationNotesResponse = new AuthorizationNotesResponse();
		CompletableFuture<AuthorizationNotesResponse> completableFuture = null;
		try {
			String serviceUrl = MSPConfigUtils.serviceUrlMap.get(serviceName + ":" + defaultState);
			completableFuture = authorizationData.getAuthorizationNotesClinical(serviceUrl, defaultContextPath + defaultState,
					authorizationId, null, null, null, accessToken);
			if (completableFuture.get().getAuthorizationClinicalNotes() != null
					&& !completableFuture.get().getAuthorizationClinicalNotes().isEmpty()) {
				authorizationNotesResponse.setAuthorizationClinicalNotes(completableFuture.get().getAuthorizationClinicalNotes());
			}
			apiUtils.errorHandling(completableFuture);
		} catch (WebClientException clientException) {
			throw clientException;
		} catch (Exception ex) {
			throw ex;
		}
		return new ResponseEntity<>(authorizationNotesResponse, HttpStatus.OK);
	}

}
