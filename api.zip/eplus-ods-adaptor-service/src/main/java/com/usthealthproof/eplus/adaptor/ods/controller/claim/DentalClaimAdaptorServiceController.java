package com.usthealthproof.eplus.adaptor.ods.controller.claim;

import com.usthealthproof.eplus.adaptor.ods.constants.OdsAdaptorServiceConstants;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.adaptor.ods.model.ErrorResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimDetails;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.adaptor.ods.model.claim.dental.DentalClaimLinesResponse;
import com.usthealthproof.eplus.adaptor.ods.service.claim.DentalClaimService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Dental Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "OdsAdaptorService")
public class DentalClaimAdaptorServiceController {

	@Autowired
	private DentalClaimService dentalClaimService;

	/***
	 * 1. Adaptor service to get the dental claim details
	 *
	 * @param claimHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Dental Claim Details", description = "Details regarding dental claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Dental Claim Details", content = {
					@Content(schema = @Schema(implementation = DentalClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimDetails> getDentalClaimDetails(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam("claimHccId") String claimHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getDentalClaimDetails() of DentalClaimAdaptorServiceController");
		log.debug("Inside getDentalClaimDetails() of DentalClaimAdaptorServiceController, service request received with:- claimHccId: {}", claimHccId);

		DentalClaimDetails dentalClaimDetails;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			dentalClaimDetails = dentalClaimService.getMspDentalClaimDetails(claimHccId, userIdentities, accessToken);
		} else {
			dentalClaimDetails = dentalClaimService.getDentalClaimDetails(claimHccId, accessToken);
		}
		log.info("Successfully generated dental claim Details response");
		return new ResponseEntity<>(dentalClaimDetails, HttpStatus.OK);
	}

	/***
	 * 2. Adaptor service to get all Dental claim lines of the particular claim
	 *
	 * @param claimHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Dental Claim Lines", description = "Service Lines information’s regarding dental claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of all claim lines of the claim", content = {
					@Content(schema = @Schema(implementation = DentalClaimLinesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental/claimlines", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimLinesResponse> getDentalClaimLines(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam(value = "claimHccId") String claimHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getDentalClaimLines() of DentalClaimAdaptorServiceController");
		log.debug("Inside getDentalClaimLines() of DentalClaimAdaptorServiceController, service request received with claimHccId= {}", claimHccId);

		DentalClaimLinesResponse dentalClaimLinesResponse;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			dentalClaimLinesResponse = dentalClaimService.getMspDentalClaimLines(claimHccId, userIdentities, accessToken);
		} else {
			dentalClaimLinesResponse = dentalClaimService.getDentalClaimLines(claimHccId, accessToken);
		}
		log.info("Successfully generated dental claim Lines response");
		return new ResponseEntity<>(dentalClaimLinesResponse, HttpStatus.OK);
	}

	/**
	 * 3. Adaptor service to get specific Dental claim line details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param httpServletRequest
	 * @return
	 * @throws Exception
	 */
	@Operation(summary = "Dental Claim Line Details", description = "Service Line details regarding dental claims, can be accessed through the specified service. Claim HCC ID and Claim Line HCC ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Dental claim line detail of the particular claim", content = {
					@Content(schema = @Schema(implementation = DentalClaimLineDetailResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental/claimline", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimLineDetailResponse> getDentalClaimLineDetails(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam(value = "claimHccId") String claimHccId,
			@Parameter(description = "Dental Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") String claimLineHccId,
			HttpServletRequest httpServletRequest) throws Exception {
		log.info("Inside getDentalClaimLineDetails() of DentalClaimAdaptorServiceController");
		log.debug("Inside getDentalClaimLineDetails() of DentalClaimAdaptorServiceController, service request received with claimHccID= {} claimLineHccId= {}", claimHccId,
				claimLineHccId);

		DentalClaimLineDetailResponse dentalClaimLineDetailResponse;
		String accessToken = httpServletRequest.getHeader(OdsAdaptorServiceConstants.AUTHORIZATION_KEY);
		String userIdentities = httpServletRequest.getHeader(OdsAdaptorServiceConstants.USERIDENTITIES_KEY);
		if (StringUtils.isNotBlank(userIdentities)) {
			log.info(OdsAdaptorServiceConstants.MSP_ENABLED_MESSAGE);
			dentalClaimLineDetailResponse = dentalClaimService.getMspDentalClaimLineDetails(claimHccId, claimLineHccId, userIdentities, accessToken);
		} else {
			dentalClaimLineDetailResponse = dentalClaimService.getDentalClaimLineDetails(claimHccId, claimLineHccId, accessToken);
		}
		log.info("Successfully generated Dental claim line details response");
		return new ResponseEntity<>(dentalClaimLineDetailResponse, HttpStatus.OK);
    }
}
