package com.usthealthproof.eplus.adaptor.ods.model.authorization.authorizationNotes;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(value = Include.NON_EMPTY)
@Schema(description = "Object for holding the Authorization Notes results")
public class AuthorizationNotesResponse implements Serializable {

	private static final long serialVersionUID = -2725458666588680090L;

	@Schema(description = "For storing the authorization Call Log Notes as list")
	private List<AuthorizationCallLogNotes> authorizationCallLogNotes;

	@Schema(description = "For storing the authorization Clinical Notes as list")
	private List<AuthorizationClinicalNotes> authorizationClinicalNotes;

	@Schema(description = "For storing the authorization Notes as list")
	private List<AuthorizationNotes> authorizationNotes;

	@Schema(description = "To hold the error", hidden = true)
	private List<String> errors;
	@Schema(description = "To hold the error HTTP Status Code", hidden = true)
	private Integer httpStatusCode;

}
