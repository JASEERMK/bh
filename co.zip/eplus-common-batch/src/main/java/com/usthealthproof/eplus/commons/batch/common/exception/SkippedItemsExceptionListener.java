package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.ExceptionUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * @author 210409
 *
 */
@Slf4j
@Component
@StepScope
public class SkippedItemsExceptionListener implements SkipListener<Object, Object>, StepExecutionListener {

    @Autowired
    AuditService auditService;

    @Autowired
    AdhocService adhocService;

    @Autowired
    AuditErrorMessageUtil auditErrorMessageUtil;

    @Value("${batch.audit.request}")
    private boolean enableAuditRequest;
    @Value("${batch.interface-id}")
    private String interfaceId;


    @Autowired
    ExceptionUtil exceptionUtil;

    private StepExecution stepExecution;

    @Override
    public void onSkipInRead(Throwable throwable) {
        log.error("EXCEPTION HANDLING onSkipInRead exception ", throwable);
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditException(jobId,CommonUtils.getThrowable(stepExecution),
                stepExecution.getStepName());
        if (!CollectionUtils.isEmpty(auditBatchList)) {
            auditService.auditException(auditBatchList);
        }
        }

    @Override
    public void onSkipInProcess(Object item, Throwable throwable) {
        log.error("EXCEPTION# HANDLING onSkipInProcess, stepName {},  exception {}",
                stepExecution.getStepName(), throwable);
        List<Map<String, String>> errorList = exceptionUtil.getProcessErrorDetails(item, enableAuditRequest);
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditBatchException(jobId,stepExecution.getStepName(),errorList,throwable);
        if (!CollectionUtils.isEmpty(auditBatchList)) {
            auditService.auditException(auditBatchList);
        }
        adhocService.setAdhocTableEntries(errorList, interfaceId);
    }

    @Override
    public void onSkipInWrite(Object itemList, Throwable throwable) {
        log.error("EXCEPTION# HANDLING onSkipInWrite, stepName {},  exception {}",
                stepExecution.getStepName(), throwable);
        List<Map<String, String>> errorList = exceptionUtil.getWriteErrorDetails(itemList, enableAuditRequest);
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditBatchException(jobId,stepExecution.getStepName(),errorList,throwable);
        if (!CollectionUtils.isEmpty(auditBatchList)) {
            auditService.auditException(auditBatchList);
        }
        adhocService.setAdhocTableEntries(errorList, interfaceId);
    }

    public static String formatStepName(String stepName) {
        if(StringUtils.isNotBlank(stepName)) {
            return stepName.substring(0, stepName.lastIndexOf(":"));
        }
        return stepName;
    }

    @Override
    public void beforeStep(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }
}
