package com.usthealthproof.eplus.commons.batch.common.constant;

import lombok.Getter;

@Getter
public enum ErrorCodeConstant {

    // REST SERVICE EXCEPTION
    NOT_AUTHORIZED_ERROR(1001, "UNAUTHORIZED"),
    REST_SERVICE_ERROR(1002, "REST_SERVICE_ERROR"),
    SF_ERROR_RESPONSE(1003, "SF_ERROR_RESPONSE"),
    UNKNOWN_REST_ERROR(1004, "REST_UNKNOWN_ERROR"),

    // DATA EXCEPTION
    NO_DATA_ERROR(2001, "NO_DATA_EXCEPTION"),
    UNKNOWN_DATA_ERROR(2002, "NO_DATA_EXCEPTION"),

    // JOB EXCEPTION
    JOB_INTERRUPTED_ERROR(3001, "JOB_INTERRUPTED_ERROR"),

    // Un handled Exception
    UNKNOWN_EXCEPTION(5000, "UNKNOWN_EXCEPTION");

    private final Integer code;
    private final String message;

    ErrorCodeConstant(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getAuditMessage() {
        return String.valueOf(code).concat("-").concat(message);
    }

}
