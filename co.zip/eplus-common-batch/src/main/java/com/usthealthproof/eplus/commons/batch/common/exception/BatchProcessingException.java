package com.usthealthproof.eplus.commons.batch.common.exception;

/**
 * @author 210409
 */
public class BatchProcessingException extends RuntimeException {

    public BatchProcessingException(String message, Throwable throwable) {
        super(message, throwable);
    }

    public BatchProcessingException(String message) {
        super(message);
    }

}
