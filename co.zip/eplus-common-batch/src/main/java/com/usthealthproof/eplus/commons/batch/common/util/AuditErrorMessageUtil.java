package com.usthealthproof.eplus.commons.batch.common.util;

import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import static java.text.MessageFormat.format;

@Slf4j
@Component
public class AuditErrorMessageUtil {

    @Value("${batch.audit.request}")
    private boolean isRequestAuditRequired;

    @Value("${batch.interface-id}")
    private String interfaceId;

    /* AUDIT RESPONSE ERROR FROM SF */
    public List<AuditBatch> auditSFDataLoadWriteError(String jobId,List<Map<String, String>> errorList,String processStep, String request) {
        log.info("Inside AuditException Service, auditSFDataLoadWriteError");
        if (CollectionUtils.isEmpty(errorList)) {
            return null;
        }
        List<AuditBatch> auditBatchList = new ArrayList<>();
        for (Map<String, String> errorMap : errorList) {
            String referenceId = errorMap.get(AuditConstants.REFERENCE_ID);
            String errorDetails = format("Error for Id: {0}, message: {1}, response: {2}",
                    errorMap.get(AuditConstants.REFERENCE_ID), errorMap.get(Constant.MESSAGE),
                    errorMap.get(Constant.RESPONSE_TEXT));
            AuditBatch auditBatch=AuditBatch.builder().correlationId(jobId)
                            .interfaceId(interfaceId)
                            .processStep(processStep)
                            .recordId(referenceId)
                            .processStatus(AuditConstants.PROCESS_STATUS_ERROR_VALUE)
                            .errorDetails(errorDetails)
                            .errorMessage(ErrorCodeConstant.REST_SERVICE_ERROR.getAuditMessage())
                            .errorRequest(request)
                            .createdDate(new Date())
                            .build();
            auditBatchList.add(auditBatch);
        }
        return  auditBatchList;
    }
    /* AUDIT BATCH EXCEPTION FOR MULTIPLE REQUEST/RESPONSE */
    public List<AuditBatch> auditBatchException(String jobId,String processStep, List<Map<String, String>> errorList, Throwable throwable) {
        log.info("EXCEPTION# Inside AuditException Service, auditing exception and account requests");

        if (CollectionUtils.isEmpty(errorList)) {
            log.info("Audit request is empty");
            return null;
        }
        String errorType = CommonUtils.getErrorMessageType(throwable);
        String errorDetails = CommonUtils.getErrorDetails(throwable);
        log.error("Error in Process Step : {} , Error Type : {} and Error Details : {}", processStep, errorType, errorDetails);
        List<AuditBatch> auditBatchList = errorList.stream()
                .map(errorMap -> {
                    String request = isRequestAuditRequired ? errorMap.get(AuditConstants.REQUEST_MESSAGE) : null;
                    return AuditBatch.builder()
                            .interfaceId(interfaceId)
                            .correlationId(jobId)
                            .processStep(processStep)
                            .recordId(errorMap.get(AuditConstants.REFERENCE_ID))
                            .processStatus(AuditConstants.PROCESS_STATUS_EXCEPTION_VALUE)
                            .errorMessage(errorType)
                            .errorRequest(request)
                            .createdDate(new Date())
                            .build();
                })
                .toList();
        return auditBatchList;
    }
    /* AUDIT EXCEPTION IN BATCH */
    public List<AuditBatch> auditException(String jobId,Throwable throwable, String processStep) {
        log.info("Inside AuditException Service, setAuditTableEntries");
        List<AuditBatch> auditBatchList = new ArrayList<>();
        String errorMessageType = CommonUtils.getErrorMessageType(throwable);
        String errorDetails = CommonUtils.getErrorDetails(throwable);
        log.error("Error Message Type : {} ", errorMessageType);
        log.error("Error Details {} ", processStep);
        AuditBatch auditBatch= AuditBatch.builder().correlationId(jobId)
                            .interfaceId(interfaceId)
                            .processStep(processStep)
                            .processStatus(AuditConstants.PROCESS_STATUS_EXCEPTION_VALUE)
                            .errorDetails(errorDetails)
                            .errorMessage(errorMessageType)
                            .createdDate(new Date())
                            .build();
        auditBatchList.add(auditBatch);
        return auditBatchList;
    }
}
