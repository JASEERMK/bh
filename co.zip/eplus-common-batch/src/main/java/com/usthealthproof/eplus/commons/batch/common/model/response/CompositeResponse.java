package com.usthealthproof.eplus.commons.batch.common.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

/**
 * @author U90305
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompositeResponse {
	private JsonNode body;
	private Integer httpStatusCode;
	private String referenceId;
}
