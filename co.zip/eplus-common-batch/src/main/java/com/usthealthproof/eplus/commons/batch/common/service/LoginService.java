package com.usthealthproof.eplus.commons.batch.common.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.text.MessageFormat;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_ERROR_VALUE;
import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;

/**
 * @author 210409
 */
@Slf4j
@Service
public class LoginService {

    @Value("${salesforce.url.login.path}")
    private String loginPath;

    @Autowired
    private WebClient webClient;

    @Autowired
    private AuditService auditService;

    public void callLoginService(StepExecution stepExecution) {
        log.debug("Inside callLoginService() in LoginService class");
        log.info("Exception while calling login service");
        String accessToken = null;
        String errorResponse = null;
        JsonNode response = null;
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        try {
            response = webClient.post().uri(loginPath)
                    .bodyValue(Constant.BLANK_STRING)
                    .retrieve().bodyToMono(JsonNode.class).block();
            if(response.get(Constant.ACCESS_TOKEN_FROM_SERVICE) != null) {
                accessToken = response.get(Constant.ACCESS_TOKEN_FROM_SERVICE).asText();
            }
        } catch (WebClientResponseException e) {
            errorResponse = e.getStatusCode().toString() + "-" + e.getStatusText();
        } catch (Exception e) {
            log.error("Exception while calling login service", e);
            errorResponse = e.getMessage();
        }
        if (StringUtils.isBlank(accessToken)) {
            log.error("Access token blank");
            if(StringUtils.isBlank(errorResponse)) {
                errorResponse = CommonUtils.getObjectAsString(response);
            }
            if(isLoginAttemptExceeded(stepExecution)) {
                log.error("login attempt exceeded");
                auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SF_LOGIN,PROCESS_STATUS_ERROR_VALUE,AuditConstants.ERROR_DETAIL_KEY_SF_LOGIN_MAX_ATTEMPT, errorResponse);
//                CommonUtils.cleanRecordTypeId()
                stepExecution.setTerminateOnly();
                return;
            }
            String errorMessage = MessageFormat.format(AuditConstants.ERROR_DETAIL_KEY_SF_LOGIN_FAILED,
                    stepExecution.getJobExecution().getExecutionContext().get(Constant.LOGIN_ATTEMPT));
            auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SF_LOGIN,PROCESS_STATUS_ERROR_VALUE,errorMessage, errorResponse);

            log.error("after exceed check");
            callLoginService(stepExecution);
            return;
        }
        log.info("Received access token");
        stepExecution.getJobExecution().getExecutionContext().put(Constant.ACCESS_TOKEN, accessToken);
        auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SF_LOGIN,PROCESS_STATUS_SUCCESS_VALUE,null,null);
    }

    public boolean isLoginAttemptExceeded(StepExecution stepExecution) {
        log.debug("Inside isLoginAttemptExceeded() in LoginService class");
        Integer loginCount = 1;
        if(stepExecution.getJobExecution().getExecutionContext().get(Constant.LOGIN_ATTEMPT) != null) {
            loginCount = (Integer) stepExecution.getJobExecution().getExecutionContext().get(Constant.LOGIN_ATTEMPT);
            loginCount++;
        }
        if(loginCount > 2) {
            return true; //if count is 3 then it already executed 3 times
        }
        stepExecution.getJobExecution().getExecutionContext().put(Constant.LOGIN_ATTEMPT, loginCount);
        return false;
    }
}
