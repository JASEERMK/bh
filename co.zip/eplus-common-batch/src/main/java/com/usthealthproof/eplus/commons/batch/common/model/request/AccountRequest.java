package com.usthealthproof.eplus.commons.batch.common.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 210409
 */
@Data
public class AccountRequest {

	private String graphId;

	@JsonProperty("compositeRequest")
	private List<CompositeRequest> compositeRequest;

}
