package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.db.entity.Adhoc;
import com.usthealthproof.eplus.commons.batch.common.db.repository.AdhocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author 210409
 */
@Component
public class AdhocService {

    private final AdhocRepository adhocRepository;

    @Autowired
    public AdhocService(AdhocRepository adhocRepository) {
        this.adhocRepository = adhocRepository;
    }

    /**
     * Method which inserts each id having error in an adhoc table
     *
     * @param errorList Error list to be saved to adhoc table
     */
    public void setAdhocTableEntries(List<Map<String, String>> errorList, String adhocType) {
        if (CollectionUtils.isEmpty(errorList)) {
            return;
        }
        List<Adhoc> adhocList = new ArrayList<>();
        for (Map<String, String> errorMap : errorList) {
            Adhoc adhoc = Adhoc.builder()
                    .errorId(errorMap.get(AuditConstants.GRAPH_ID))
                    .type(adhocType)
                    .createdDate(new Date())
                    .isExecuted(AuditConstants.ADHOC_IS_EXECUTED_FALSE)
                    .build();
            adhocList.add(adhoc);
        }
        adhocRepository.saveAll(adhocList);
    }

}
