package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.Runtime;
import com.usthealthproof.eplus.commons.batch.common.db.repository.RuntimeRepository;
import com.usthealthproof.eplus.commons.batch.common.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.TimeZone;

/**
 * @author 210409
 */
@Slf4j
@Service
public class RuntimeService {

    @Autowired
    private RuntimeRepository runtimeRepository;

    @Autowired
    private AuditService auditService;

    @Value("${batch.interface-id}")
    private String interfaceId;

    public void readRuntime(ExecutionContext executionContext) {
        log.debug("Inside isLoginAttemptExceeded() in LoginService class");
        log.info("Started Runtime Service Execution Context");
        String jobId= String.valueOf(executionContext.getLong("jobId"));
        Runtime runtimeEntity = runtimeRepository.findByInterfaceId(interfaceId);
        Date runtime = null;
        if(runtimeEntity != null) {
            runtime = runtimeEntity.getLastRuntime();
        }
        log.info("Received last runtime {}", runtime);
        log.info("Received time zone id {}, display name {} ", TimeZone.getDefault().toZoneId(), TimeZone.getDefault().getDisplayName());
        executionContext.put(Constant.RUNTIME, DateUtil.dateForStoredProcedure(runtime));
        Date newRuntime = new Date();
        log.info("Current time {}", newRuntime);
        executionContext.put(Constant.NEW_RUNTIME, newRuntime);
        auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_READ_RUNTIME, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE,DateUtil.dateForStoredProcedure(runtime),null);
    }

    public void updateRuntime(ExecutionContext executionContext) {
        log.debug("Inside isLoginAttemptExceeded() in LoginService class");
        String jobId= String.valueOf(executionContext.getLong("jobId"));
        Runtime runtimeEntity = runtimeRepository.findByInterfaceId(interfaceId);
        Date date = (Date) executionContext.get(Constant.NEW_RUNTIME);
        runtimeEntity.setLastRuntime(date);
        runtimeRepository.save(runtimeEntity);
        auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_UPDATE_RUNTIME, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE,DateUtil.dateForStoredProcedure(date),null);
        log.info("Updated run time");
    }

}
