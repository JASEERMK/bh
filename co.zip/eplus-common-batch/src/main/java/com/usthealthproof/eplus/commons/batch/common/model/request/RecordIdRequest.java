package com.usthealthproof.eplus.commons.batch.common.model.request;

import lombok.Data;

import java.util.List;

/**
 * @author 210409
 */
@Data
public class RecordIdRequest {
	
	private Boolean allOrNone =  true;
	
	private List<CompositeRequestRecordId> compositeRequest;

}
