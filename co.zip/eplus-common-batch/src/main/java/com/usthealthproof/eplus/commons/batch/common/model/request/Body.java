package com.usthealthproof.eplus.commons.batch.common.model.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 210409
 */
@Data
public abstract class Body {

	// Map for adding client specific fields which is not in product
	@JsonIgnore
	private Map<String, Object> customFields;

	@JsonAnySetter
	public void setCustomFields(String key, Object value) {
		if(customFields == null) {
			customFields = new HashMap<>();
		}
		customFields.put(key, value);
	}

	@JsonAnyGetter
	public Map<String, Object> getCustomFields(){
		return customFields;
	}

}
