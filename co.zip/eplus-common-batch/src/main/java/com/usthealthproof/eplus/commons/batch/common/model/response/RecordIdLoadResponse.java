package com.usthealthproof.eplus.commons.batch.common.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

/**
 * @author 210409
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecordIdLoadResponse {
	
	private JsonNode body;
	private Long httpStatusCode;
	private String referenceId;

}