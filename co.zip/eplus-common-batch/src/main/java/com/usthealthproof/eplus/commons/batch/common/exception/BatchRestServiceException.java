package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import lombok.Data;

@Data
public class BatchRestServiceException extends RuntimeException {

    private final ErrorCodeConstant errorCode;

    public BatchRestServiceException(ErrorCodeConstant errorCode, Throwable throwable) {
        super(throwable);
        this.errorCode = errorCode;
    }

    public BatchRestServiceException(ErrorCodeConstant errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

}
