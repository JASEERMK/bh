package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Component
@Slf4j
public class JobAuditListener implements JobExecutionListener {

    private final AuditErrorMessageUtil auditErrorMessageUtil;
    private final AuditService auditService;


    @Autowired
    public JobAuditListener(AuditErrorMessageUtil auditErrorMessageUtil, AuditService auditService) {
        this.auditErrorMessageUtil = auditErrorMessageUtil;
        this.auditService=auditService;
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.debug("Inside job execution");
        auditStepException(jobExecution);
    }

    private void auditStepException(JobExecution jobExecution) {
        log.info("Inside Auditing of Step Exception");
        Optional<StepExecution> stepExecutionOption =
                jobExecution.getStepExecutions().stream().filter(step -> !CollectionUtils.isEmpty(step.getFailureExceptions())).findFirst();

        if(stepExecutionOption.isPresent()) {
            log.debug("Step Execution with error exist");
            StepExecution stepExecution = stepExecutionOption.get();
            String jobId= String.valueOf(jobExecution.getJobId());
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditException(jobId,CommonUtils.getThrowable(stepExecution),
                    stepExecution.getStepName());
            if (!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }

        }

    }
}
