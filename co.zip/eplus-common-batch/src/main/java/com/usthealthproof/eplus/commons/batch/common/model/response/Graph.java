package com.usthealthproof.eplus.commons.batch.common.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @author 210409
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Graph {

	private String graphId;
	private GraphResponse graphResponse;
    private Boolean isSuccessful;
}
