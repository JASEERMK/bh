package com.usthealthproof.eplus.commons.batch.common.exception;

public class BatchRestCallException extends RuntimeException {

    public BatchRestCallException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
