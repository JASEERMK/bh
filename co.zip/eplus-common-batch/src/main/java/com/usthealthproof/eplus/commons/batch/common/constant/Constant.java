package com.usthealthproof.eplus.commons.batch.common.constant;

/**
 * @author 210409
 */
public class Constant {

    private Constant() { }

    public static final String BLANK_STRING = "";

    /* Thread Constants */
    public static final String THREAD_PREFIX = "AsyncThread-";

    /*Login Service*/
    public static final String ACCESS_TOKEN_FROM_SERVICE = "access_token";

    public static final String BEARER_TOKEN = "Bearer ";

    /*Context Variables*/
    public static final String RUNTIME = "runtime";
    public static final String NEW_RUNTIME = "newRuntime";
    public static final String ACCESS_TOKEN = "accessToken";

    public static final String RECORD_TYPE_MAP = "recordTypeMap";

    public static final String LOGIN_ATTEMPT = "loginAttempt";

    /*Error Constants*/
    public static final String MESSAGE = "message";
    public static final String RESPONSE_TEXT = "responseText";
    public static final String CORRELATION_ID = "correlationId";

    /*STEP NAME*/
    public static final String PROCESS_STEP_READ_RUNTIME = "ReadRunTimeStep";
    public static final String PROCESS_STEP_SP = "StoredProcedureStep";
    public static final String PROCESS_STEP_SF_LOGIN = "CallLoginServiceStep";
    public static final String PROCESS_STEP_RECORD_TYPE = "GetRecordTypeCreationStep";
    public static final String PROCESS_STEP_SF_DATA_LOAD = "DataLoadStep";
    public static final String PROCESS_STEP_UPDATE_RUNTIME = "UpdateLastRuntimeStep";
    public static final String PROCESS_JOB = "JobExecution";
    public static final String PROCESS_STEP_UPDATE_COUNT = "CountUpdateStep";

}
