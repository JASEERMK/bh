package com.usthealthproof.eplus.commons.batch.common.db.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Date;

/**
 * @author 210409
 *
 */
@Data
@Entity
@Table(name = "EPLUS_ADHOC_DTL")
@Builder
@AllArgsConstructor @NoArgsConstructor
public class Adhoc {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "SEQ_NO", columnDefinition = "NUMERIC(19,0)")
    private Long id;

    @Column(name = "ERROR_ID")
    private String errorId;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "IS_EXECUTED")
    private String isExecuted;

}
