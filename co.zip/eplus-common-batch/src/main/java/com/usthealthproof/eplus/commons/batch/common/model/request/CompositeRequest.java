package com.usthealthproof.eplus.commons.batch.common.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * @author 210409
 */
@Data
public class CompositeRequest {

	private String method = "PATCH";
	private String url;
	private String referenceId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Body body;

}