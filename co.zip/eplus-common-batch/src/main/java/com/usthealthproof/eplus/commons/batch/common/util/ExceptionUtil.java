package com.usthealthproof.eplus.commons.batch.common.util;

import java.util.List;
import java.util.Map;

public interface ExceptionUtil {

    public List<Map<String, String>> getProcessErrorDetails(Object object, boolean enableAuditRequest);
    public List<Map<String, String>> getWriteErrorDetails(Object object, boolean enableAuditRequest);

}
