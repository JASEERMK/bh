package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.util.RestResponseUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Objects;

@Service
@Slf4j
public class RestCallService<T> {

    @Autowired
    private WebClient webClient;

    public T callPostRequest(String url, Class<T> responseClass, Object request, StepExecution stepExecution) {
        return callService(url, responseClass, request, stepExecution, MediaType.APPLICATION_JSON, HttpMethod.POST);
    }

    public <S> S callPutCSVRequest(String url, Class<S> responseClass, Object request, StepExecution stepExecution) {
        return callService(url, responseClass, request, stepExecution,
                new MediaType("text", "csv"), HttpMethod.PUT);
    }

    public <S> S callPatchRequest(String url, Class<S> responseClass, Object request, StepExecution stepExecution) {
        return callService(url, responseClass, request, stepExecution, MediaType.APPLICATION_JSON, HttpMethod.PATCH);
    }

    public <S> S callGetRequest(String url, Class<S> responseClass, Object request, StepExecution stepExecution) {
        return callService(url, responseClass, request, stepExecution, MediaType.APPLICATION_JSON, HttpMethod.GET);
    }

    public <S> S callService(String url, Class<S> responseClass, Object request, StepExecution stepExecution,
                                 MediaType contentType, HttpMethod httpMethod) {
        log.debug("Inside callService() in RestCallService class");
        Object acessTokenObject = stepExecution.getJobExecution().getExecutionContext().get(Constant.ACCESS_TOKEN);
        String accessToken = Objects.isNull(acessTokenObject) ? "" : acessTokenObject.toString();

        return webClient.method(httpMethod)
                .uri(url)
                .contentType(contentType)
                .header(HttpHeaders.AUTHORIZATION, Constant.BEARER_TOKEN + accessToken)
                .bodyValue(request)
                .retrieve()
                .onStatus(httpStatus -> httpStatus.value() == HttpStatus.UNAUTHORIZED.value(),
                        RestResponseUtil::getUnAuthorizedException)
                .onStatus(httpStatus -> httpStatus.isError() && httpStatus.value() != HttpStatus.UNAUTHORIZED.value(),
                        res-> RestResponseUtil.getSFRestErrorException(request, res))
                .bodyToMono(responseClass)
                .block();
    }

}
