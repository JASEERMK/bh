package com.usthealthproof.eplus.commons.batch.common.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author 210409
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompositeRequestRecordId implements Serializable {

	@JsonProperty("method")
	private String method = "GET";

	@JsonProperty("url")
	private String url;

	@JsonProperty("referenceId")
	private String referenceId;

}
