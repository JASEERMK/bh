package com.usthealthproof.eplus.commons.batch.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * @author 210409
 */
public class DateUtil {

    private DateUtil() {}

    public static String dateForStoredProcedure(Date date) {
        if(Objects.isNull(date)) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.sss");
        return sdf.format(date);
    }

    public static String dateForFileCreation(Date date) {
        if(Objects.isNull(date)) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);

    }
}
