package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import lombok.Data;

@Data
public class BatchDataException extends RuntimeException {

    private final ErrorCodeConstant errorCode;

    public BatchDataException(ErrorCodeConstant errorCode, Throwable throwable) {
        super(throwable);
        this.errorCode = errorCode;
    }

    public BatchDataException(ErrorCodeConstant errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

}
