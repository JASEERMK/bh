package com.usthealthproof.eplus.commons.batch.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class ExceptionListener implements ChunkListener {

    @Override
    public void beforeChunk(ChunkContext chunkContext) {
        // implementation ignored
    }

    @Override
    public void afterChunk(ChunkContext chunkContext) {
        // No Implementation Required
    }

    @Override
    public void afterChunkError(ChunkContext context) {
        log.error("EXCEPTION# In afterChunkError. StepName : {} " + context.getStepContext().getStepName());
        Throwable throwable = (Throwable) context.getAttribute(ChunkListener.ROLLBACK_EXCEPTION_KEY);
        context.getStepContext().getStepExecution().setStatus(BatchStatus.FAILED);
        if(throwable != null) {
            context.getStepContext().getStepExecution().addFailureException(throwable);
        }
        log.error("Exception occurred while chunk. [context:{} , exception:{} ]", context,
                context.getAttribute(ChunkListener.ROLLBACK_EXCEPTION_KEY));
    }
}
