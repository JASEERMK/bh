package com.usthealthproof.eplus.commons.batch.common.db.repository;

import com.usthealthproof.eplus.commons.batch.common.db.entity.Adhoc;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author 210409
 */
public interface AdhocRepository extends JpaRepository<Adhoc, String> {

}
