package com.usthealthproof.eplus.commons.batch.common.constant;

/**
 * Constants used in audit log
 */
public class AuditConstants {

	private AuditConstants() {
		throw new IllegalStateException("Constant class");
	}

	public static final String ERROR_DETAIL_KEY_SF_LOGIN_MAX_ATTEMPT = "Sales force login failed with maximum attempt 3";
	public static final String ERROR_DETAIL_KEY_SF_LOGIN_FAILED = "Sales force login failed, Attempt : {0} ";
	
	/*Queue names in Provider router*/
	public static final String PROVIDER_REQUEST_WRITE = "PROVIDER_REQUEST_WRITE";
	
	public static final String PROVIDER_RESPONSE_WRITE = "PROVIDER_RESPONSE_WRITE";
	
	public static final String PROVIDER_AUDIT_DATA_LOAD_STATUS = "PROVIDER_AUDIT_DATA_LOAD_STATUS_QUEUE";

	/*Message Keys*/
	public static final String GRAPH_ID = "graphId";

	public static final String REFERENCE_ID = "referenceId";

	public static final String REQUEST_MESSAGE = "requestMessage";

	/*AUDIT LOGGING*/
	public static final String PROCESS_STATUS_SUCCESS_VALUE = "SUCCESS";
	public static final String PROCESS_STATUS_ERROR_VALUE = "ERROR";
	public static final String PROCESS_STATUS_EXCEPTION_VALUE = "EXCEPTION";

	/*ADHOC Entry*/
	public static final String ADHOC_PROVIDER_TYPE = "PROVIDER";
	public static final String ADHOC_ENROLLMENT_TYPE = "Enrollment";
	public static final String ADHOC_MEMBER_PCP_TYPE = "MEMBERPCP";
	public static final String ADHOC_IS_EXECUTED_FALSE = "false";
}
