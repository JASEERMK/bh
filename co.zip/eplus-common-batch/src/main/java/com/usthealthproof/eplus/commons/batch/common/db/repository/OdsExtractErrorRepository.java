package com.usthealthproof.eplus.commons.batch.common.db.repository;

import com.usthealthproof.eplus.commons.batch.common.db.entity.OdsExtractError;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * @author 210409
 */
@Repository
public interface OdsExtractErrorRepository extends JpaRepository<OdsExtractError, Long> {

    List<OdsExtractError> findByRunDateGreaterThanEqualAndErrorProcedureContains(Date date, String errorProcedure);

}
