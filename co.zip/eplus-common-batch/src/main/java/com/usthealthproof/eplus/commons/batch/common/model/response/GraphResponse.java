package com.usthealthproof.eplus.commons.batch.common.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

/**
 * @author 210409
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GraphResponse {

	private List<CompositeResponse> compositeResponse;
}
