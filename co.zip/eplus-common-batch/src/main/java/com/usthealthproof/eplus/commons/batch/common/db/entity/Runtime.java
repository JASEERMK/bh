package com.usthealthproof.eplus.commons.batch.common.db.entity;

import lombok.Data;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Date;

/**
 * @author 210409
 */
@Entity
@Table(name = "EPLUS_BATCH_RUNTIME")
@Data
public class Runtime {

    @Id
    @Column(name = "SEQ_NO", columnDefinition = "NUMERIC(11,0)")
    private Long id;

    @Column(name = "INTERFACE_ID")
    private String interfaceId;

    @Column(name = "LAST_RUNTIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastRuntime;

}
