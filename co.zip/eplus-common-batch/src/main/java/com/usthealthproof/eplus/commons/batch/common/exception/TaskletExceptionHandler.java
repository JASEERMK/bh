package com.usthealthproof.eplus.commons.batch.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.repeat.RepeatContext;
import org.springframework.batch.repeat.exception.ExceptionHandler;
import org.springframework.stereotype.Component;

/**
 * @author 210409
 */
@Slf4j
@Component
public class TaskletExceptionHandler implements ExceptionHandler {

    @Override
    public void handleException(RepeatContext repeatContext, Throwable throwable) {
        repeatContext.setCompleteOnly();
    }

}
