package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.db.entity.OdsExtractError;
import com.usthealthproof.eplus.commons.batch.common.db.repository.AuditBatchRepository;
import com.usthealthproof.eplus.commons.batch.common.db.repository.OdsExtractErrorRepository;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static java.text.MessageFormat.format;

/**
 * @author 210409
 */
@Slf4j
@Service
public class AuditService {

    @Autowired
    private AuditBatchRepository auditBatchRepository;

    @Value("${batch.interface-id}")
    private String interfaceId;

    @Value("${batch.audit.request}")
    private boolean auditRequest;

    @Autowired
    private OdsExtractErrorRepository odsExtractErrorRepository;


    private static String DEFAULT_CORRELATION_ID = StringUtils.EMPTY;
    private static Long DEFAULT_RECORD_COUNT = 0L;
    private static String DEFAULT_RECORD_ID = StringUtils.EMPTY;
    private static String DEFAULT_MESSAGE = StringUtils.EMPTY;
    private static String DEFAULT_ERROR_DETAILS = StringUtils.EMPTY;
    private static String DEFAULT_REQUEST = StringUtils.EMPTY;

    /* READ RUNTIME SUCCESS AUDIT */
    @Deprecated
    public void auditReadRunTimeSuccessStatus(Date runtime) {
        log.info("Inside audit log, auditReadRunTimeSuccessStatus");
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_READ_RUNTIME, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DateUtil.dateForStoredProcedure(runtime),StringUtils.EMPTY,StringUtils.EMPTY);
        updateAuditTable(auditBatch);
    }

    /* UPDATE RUNTIME SUCCESS AUDIT */
    @Deprecated
    public void auditUpdateRunTimeSuccessStatus(Date date) {
        log.info("Inside audit log, auditUpdateRunTimeSuccessStatus");
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_UPDATE_RUNTIME, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DateUtil.dateForStoredProcedure(date),DEFAULT_ERROR_DETAILS,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* SP CALLING SUCCESS AUDIT */
    @Deprecated
    public void addSPSuccessLog() {
        log.info("Inside audit log, addSPSuccessLog");
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_SP, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,DEFAULT_ERROR_DETAILS,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* SP CALLING ERROR AUDIT */
    @Deprecated
    public void addSPErrorLog(Date newRuntime, String procedureType, String procedureStep) {
        log.info("Inside audit log, addSPErrorLog");
        List<OdsExtractError> spErrors = odsExtractErrorRepository
                .findByRunDateGreaterThanEqualAndErrorProcedureContains(newRuntime, procedureType);
        String errorMessage = "";
        String errorProcedure = "";
        if (!CollectionUtils.isEmpty(spErrors)) {
            OdsExtractError spError = spErrors.get(0);
            errorMessage = spError.getErrorMessage();
            errorProcedure = spError.getErrorProcedure();
        }
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                procedureStep, AuditConstants.PROCESS_STATUS_ERROR_VALUE);
        auditBatch=setErrorInfo(auditBatch,errorProcedure,errorMessage,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* SF LOGIN SUCCESS AUDIT*/
    @Deprecated
    public void auditSalesForceLoginSuccessStatus() {
        log.info("Inside audit log, auditSalesForceLoginSuccessStatus");
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_SF_LOGIN, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,DEFAULT_ERROR_DETAILS,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* SF LOGIN ERROR AUDIT*/
    @Deprecated
    public void auditSalesForceLoginFailureStatus(String errorMessage, String errorDetails) {
        log.info("Inside audit log, auditSalesForceLoginFailureStatus");
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_SF_LOGIN, AuditConstants.PROCESS_STATUS_ERROR_VALUE);
        auditBatch=setErrorInfo(auditBatch,errorMessage,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* AUDIT RESPONSE ERROR FROM SF */
    @Deprecated
    public void auditSFDataLoadWriteError(List<Map<String, String>> errorList, String processStep
            , String request) {
        log.info("Inside audit log, auditSFDataLoadWriteError");
        if (CollectionUtils.isEmpty(errorList)) {
            return;
        }
        List<AuditBatch> auditBatchList = new ArrayList<>();
        for (Map<String, String> errorMap : errorList) {
            String referenceId = errorMap.get(AuditConstants.REFERENCE_ID);
            String errorDetails = format("Error for Id: {0}, message: {1}, response: {2}",
                    errorMap.get(AuditConstants.REFERENCE_ID), errorMap.get(Constant.MESSAGE),
                    errorMap.get(Constant.RESPONSE_TEXT));
            AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, referenceId,
                    DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                    processStep, AuditConstants.PROCESS_STATUS_ERROR_VALUE);
            auditBatch=setErrorInfo(auditBatch,ErrorCodeConstant.REST_SERVICE_ERROR.getAuditMessage(),errorDetails,request);
            auditBatchList.add(auditBatch);
        }
        auditBatchRepository.saveAll(auditBatchList);
        log.info("Inside audit log, auditSFDataLoadWriteError. Completed");
    }

    /* SUCCESS COUNT AUDIT */
    @Deprecated
    public void auditExecuteQuerySuccessCountStatus(Integer successCounter) {
        log.info("Inside auditExecuteQuerySuccessCountStatus");
        String errorDetails = "Success Count";
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, Long.valueOf(successCounter),
                Constant.PROCESS_STEP_UPDATE_COUNT, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* ERROR COUNT AUDIT */
    @Deprecated
    public void auditExecuteQueryErrorCountStatus(Integer errorCounter) {
        log.info("Inside auditExecuteQueryErrorCountStatus");
        String errorDetails = "Failure Count";
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, Long.valueOf(errorCounter),
                Constant.PROCESS_STEP_UPDATE_COUNT, AuditConstants.PROCESS_STATUS_ERROR_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* TOTAL COUNT AUDIT */
    @Deprecated
    public void auditExecuteQueryTotalCountStatus(long totalCounter) {
        log.info("Inside auditExecuteQueryTotalCountStatus");
        String errorDetails = "Total Count";
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                Long.valueOf(totalCounter), DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_UPDATE_COUNT, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* TOTAL DISTINCT COUNT AUDIT */
    @Deprecated
    public void auditExecuteQueryDistinctCountStatus(long distinctCounter) {
        log.info("Inside auditExecuteQueryDistinctCountStatus");
        String errorDetails = "Distinct Count";
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                Long.valueOf(distinctCounter), DEFAULT_RECORD_COUNT,
                Constant.PROCESS_STEP_UPDATE_COUNT, AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
    }

    /* AUDIT BATCH EXCEPTION FOR MULTIPLE REQUEST/RESPONSE */
    @Deprecated
    public void auditBatchException(String processStep, List<Map<String, String>> errorList, Throwable throwable) {
        log.info("EXCEPTION# Inside auditException, auditing exception and account requests");

        if (CollectionUtils.isEmpty(errorList)) {
            log.info("Audit request is empty");
            return;
        }

        String errorType = CommonUtils.getErrorMessageType(throwable);
        String errorDetails = CommonUtils.getErrorDetails(throwable);
        log.error("Error in Process Step : {} , Error Type : {} and Error Details : {}",
                processStep, errorType, errorDetails);

        List<AuditBatch> auditList = errorList.stream().map(errorMap -> {
            String request = DEFAULT_REQUEST;
            if (auditRequest) {
                request = errorMap.get(AuditConstants.REQUEST_MESSAGE);
            }
            AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, errorMap.get(AuditConstants.REFERENCE_ID),
                    DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                    processStep, AuditConstants.PROCESS_STATUS_EXCEPTION_VALUE);
            auditBatch=setErrorInfo(auditBatch,errorType,errorDetails,request);
            return auditBatch;
        }).toList();
        updateAuditEntity(auditList);
        log.debug("Inside audit log, auditException. Completed");
    }

    /* AUDIT EXCEPTION IN BATCH */
    @Deprecated
    public void auditException(Throwable throwable, String processStep) {
        log.info("Inside audit log, setAuditTableEntries");
        String errorMessageType = CommonUtils.getErrorMessageType(throwable);
        String errorDetails = CommonUtils.getErrorDetails(throwable);
        log.error("Error Message Type : {} ", errorMessageType);
        log.error("Error Details {} ", processStep);
        AuditBatch auditBatch = createEntity(DEFAULT_CORRELATION_ID, DEFAULT_RECORD_ID,
                DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT,
                processStep, AuditConstants.PROCESS_STATUS_EXCEPTION_VALUE);
        auditBatch=setErrorInfo(auditBatch,errorMessageType,errorDetails,DEFAULT_REQUEST);
        updateAuditTable(auditBatch);
        log.debug("Inside audit log, auditException. Completed");
    }

    /* AUDIT STATUS ERROR IN CORRESPONDENCE BATCH */
    @Deprecated
    public void addErrorAudit(String recordId, String processStep) {
        log.info("Inside auditError in AuditService class");
        String errorDetails = "Unexpected Status";
        AuditBatch auditBatch = this.createEntity(DEFAULT_CORRELATION_ID, recordId, DEFAULT_RECORD_COUNT, DEFAULT_RECORD_COUNT, processStep, "ERROR");
        auditBatch=setErrorInfo(auditBatch,DEFAULT_MESSAGE,errorDetails,DEFAULT_REQUEST);
        this.updateAuditTable(auditBatch);
        log.debug("Audit table updated with ERROR. Completed");
    }

    /* COUNT AUDIT */
    public void auditExecuteQueryCountStatus(String correlationId,long inputRecordCount,long responseRecordCount,String processStatus,String errorMessage) {
        log.info("Inside auditExecuteQueryCountStatus");
        AuditBatch auditBatch = createEntity(correlationId, null,
                Long.valueOf(inputRecordCount), Long.valueOf(responseRecordCount),
                Constant.PROCESS_STEP_UPDATE_COUNT, processStatus);
        auditBatch=setErrorInfo(auditBatch,errorMessage,null,null);
        updateAuditTable(auditBatch);
    }

    /* STEP AUDIT */
    public void auditStepStatus(String correlationId,String processStep,String processStatus,String errorMessage,String errorDetails) {
        log.info("Inside audit log, auditStepStatus");
        AuditBatch auditBatch = createEntity(correlationId, null,
                0L, 0L,
                processStep, processStatus);
        auditBatch=setErrorInfo(auditBatch,errorMessage,errorDetails,null);
        updateAuditTable(auditBatch);
    }
    /* STEP AUDIT */
    public void auditException(List<AuditBatch> auditBatchList) {
        log.info("Inside audit log, auditException");
        auditBatchRepository.saveAll(auditBatchList);
    }
    /* AUDIT BATCH ENTITY CREATION */
    private AuditBatch createEntity(String correlationId, String recordId, Long inputRecordCount,
                                    Long responseRecordsCount,
                                    String processStep,
                                    String processStatus) {
        return AuditBatch.builder()
                .interfaceId(interfaceId)
                .correlationId(correlationId)
                .recordId(recordId != null ? recordId : StringUtils.EMPTY)
                .numberOfInputRecords(inputRecordCount)
                .numberOfResponseRecords(responseRecordsCount)
                .processStep(processStep)
                .processStatus(processStatus)
                .createdDate(new Date())
                .build();
    }
    //SETTING AUDIT BATCH ERROR INFO
    private AuditBatch setErrorInfo(AuditBatch auditBatch,String errorMessage,String errorDetails,String errorRequest) {
        auditBatch.setErrorMessage(errorMessage);
        auditBatch.setErrorDetails(errorDetails);
        auditBatch.setErrorRequest(errorRequest);
        return auditBatch;
    }

    /* AUDIT BATCH ENTITY INSERT OR UPDATE */
    private void updateAuditTable(AuditBatch auditBatch) {
        auditBatchRepository.save(auditBatch);
    }

    /* AUDIT BATCH ENTITY LIST INSERT OR UPDATE */
    private void updateAuditEntity(List<AuditBatch> auditBatchList) {
        auditBatchRepository.saveAll(auditBatchList);
    }

}
