package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.db.entity.OdsExtractError;
import com.usthealthproof.eplus.commons.batch.common.db.repository.OdsExtractErrorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class SpErrorLogService {


    @Autowired
    private OdsExtractErrorRepository odsExtractErrorRepository;

    public AuditBatch addSPErrorLog(Date newRuntime, String procedureType) {
        log.info("Inside SpService , addSPErrorLog");
        List<OdsExtractError> spErrors = odsExtractErrorRepository
                .findByRunDateGreaterThanEqualAndErrorProcedureContains(newRuntime, procedureType);
        String errorMessage = "";
        String errorProcedure = "";
        if (!CollectionUtils.isEmpty(spErrors)) {
            OdsExtractError spError = spErrors.get(0);
            errorMessage = spError.getErrorMessage();
            errorProcedure = spError.getErrorProcedure();
        }
        AuditBatch auditBatch=new AuditBatch();
        auditBatch.setErrorMessage(errorProcedure);
        auditBatch.setErrorDetails(errorMessage);
        return auditBatch;
    }

}
