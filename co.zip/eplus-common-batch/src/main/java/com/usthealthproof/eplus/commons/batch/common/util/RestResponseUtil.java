package com.usthealthproof.eplus.commons.batch.common.util;

import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchRestServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Slf4j
public class RestResponseUtil {

    private RestResponseUtil() {}

    public static Mono<BatchRestServiceException> getUnAuthorizedException(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(String.class).map(body -> new BatchRestServiceException(ErrorCodeConstant.NOT_AUTHORIZED_ERROR, body));
    }

    public static Mono<BatchRestServiceException> getSFRestErrorException(Object request, ClientResponse clientResponse) {
        log.error("EXCEPTION#SF_RESPONSE SF Rest Error Request {}, Response {} ", request, clientResponse);
        return clientResponse.bodyToMono(String.class).map(body -> new BatchRestServiceException(ErrorCodeConstant.SF_ERROR_RESPONSE, body));
    }

}
