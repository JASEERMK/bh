package com.usthealthproof.eplus.commons.batch.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdLoadResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchDataException;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchRestServiceException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RegExUtils;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.StepExecution;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClientException;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.CompletionException;

/**
 * @author 210409
 */
@Slf4j
public class CommonUtils {

    public static final String FALSE = "false";
    public static final String TRUE = "true";

    private CommonUtils() { }

    public static String getErrorMessageType(Throwable throwable) {
        if (throwable instanceof BatchRestServiceException) {
            log.error("BATCH REST SERVICE EXCEPTION");
            return ((BatchRestServiceException) throwable).getErrorCode().getAuditMessage();
        } else if (throwable instanceof BatchDataException) {
            log.error("BATCH DATA EXCEPTION");
            return ((BatchDataException) throwable).getErrorCode().getAuditMessage();
        } else if (throwable instanceof JobInterruptedException) {
            log.error("JOB INTERRUPTED EXCEPTION");
            return ErrorCodeConstant.JOB_INTERRUPTED_ERROR.getAuditMessage();
        } else if(throwable instanceof SQLException) {
            log.error("SQL EXCEPTION");
            return ErrorCodeConstant.UNKNOWN_DATA_ERROR.getAuditMessage();
        }else if(throwable instanceof WebClientException) {
            log.error("WEB CLIENT EXCEPTION");
            return ErrorCodeConstant.UNKNOWN_REST_ERROR.getAuditMessage();
        } else {
            log.info("UNHANDLED EXCEPTION {}" , throwable);
            return ErrorCodeConstant.UNKNOWN_EXCEPTION.getAuditMessage();
        }
    }

    public static String getErrorDetails(Throwable throwable) {
        StringBuilder stringBuilder = new StringBuilder();
        getErrorMessage(throwable, stringBuilder);
        return stringBuilder.toString();
    }

    public static void getErrorMessage(Throwable throwable, StringBuilder stringBuilder) {
        if(throwable == null) {
            return;
        }
        String errorDetails;
        if(StringUtils.hasText(throwable.getLocalizedMessage())) {
            errorDetails = throwable.getLocalizedMessage();
        } else if (StringUtils.hasText(throwable.getMessage())) {
            errorDetails = throwable.getMessage();
        } else {
            errorDetails = throwable.toString();
        }
        stringBuilder.append("\n").append(errorDetails);
        getErrorMessage(throwable.getCause(), stringBuilder);
    }

    public static String getObjectAsString(Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("Parsing error for audit");
        }
        return "";
    }

    public static void writeDebugMessage(String message, Object values) {
        if(log.isDebugEnabled()) {
            log.debug(message, CommonUtils.getObjectAsString(values));
        }
    }

    /**
     * Method which formats a given date.
     *
     * @param date
     * @return String
     */
    public static String extractDate(Date date) {
        if (null == date) {
            return null;
        }
        SimpleDateFormat simpleformat = new SimpleDateFormat("yyyy-MM-dd");
        return simpleformat.format(date);
    }

    /**
     * Method which formats a given in string format.
     * converting with format yyyy-MM-dd
     * @param date
     * @return String
     */
    public static Date extractDate(String date) {
        Date convertedDate = null;
        if (null == date) {
            return null;
        }
        SimpleDateFormat simpleformat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            convertedDate = simpleformat.parse(date);
        } catch (ParseException e) {
            log.error("extractDate : ParseException while parsing exception");
        }
        return convertedDate;
    }

    public static String extractDateFromDB(String date) {
        Date convertedDate = null;
        if (null == date) {
            return null;
        }
        SimpleDateFormat dbFormat = new SimpleDateFormat("MM/dd/yyyy");
        try {
            convertedDate = dbFormat.parse(date);
        } catch (ParseException e) {
            log.error("extractDate : ParseException while parsing exception");
        }
        return extractDate(convertedDate);
    }


    public static String replaceNullToEmpty(String value) {
        return StringUtils.hasText(value) ? value : "";
    }

    public static String cleanRecordTypeId(String recordTypeId) {
        return StringUtils.replace(recordTypeId,"\"","");
    }

    public static Throwable getThrowable(StepExecution stepExecution) {
        Throwable throwable = null;
        if(!CollectionUtils.isEmpty(stepExecution.getFailureExceptions())) {
            log.info("Exceptions in Step, getFailureExecution");
            throwable = stepExecution.getFailureExceptions().get(0);
        }
        if(throwable instanceof CompletionException) {
            log.info("Completion Exception");
            throwable = throwable.getCause();
        }
        return throwable;
    }

    public static void validateRecordTypeResponse(RecordIdMainResponse recordIdMainResponse) {
        Optional<RecordIdLoadResponse> failResponse = recordIdMainResponse.getCompositeResponse().stream().filter(response ->
            response.getHttpStatusCode() != 200
        ).findAny();
        if(failResponse.isPresent())
            throw new BatchRestServiceException(ErrorCodeConstant.SF_ERROR_RESPONSE, CommonUtils.getObjectAsString(recordIdMainResponse));
    }

    public static String removeSpecialCharacter(String referenceId) {
        if(StringUtils.hasLength(referenceId)) {
            return RegExUtils.removeAll(referenceId, "[^a-zA-Z0-9_]");
        }
        return "";
    }

    /**
     *
     * @param value
     * @return validate and if empty string false will be return
     */
    public static String validateBooleanValue(String value) {
        if(StringUtils.hasText(value)) {
            return value.toLowerCase();
        } else {
            return FALSE;
        }
    }

    /**
     *
     * @param value
     * @return validate and if empty string false will be return
     */
    public static String validateBooleanValueYorN(String value) {
        if(StringUtils.hasText(value)&&value.equalsIgnoreCase("Y")) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     *
     * @param value
     * @return validate and if empty string false will be return
     */
    public static String validateBooleanValueYesOrNo(String value) {
        if(StringUtils.hasText(value) && value.equalsIgnoreCase("Yes")) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}
