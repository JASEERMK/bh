package com.usthealthproof.eplus.commons.batch.common.db.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Date;

/**
 * @author 210409
 */
@Table(name = "EPLUS_BATCH_ERROR_LOG")
@Entity
@Data
@Builder
@AllArgsConstructor @NoArgsConstructor
public class OdsExtractError {

    @Id
    @Column(name = "ERROR_KEY", columnDefinition = "NUMERIC(19,0)")
    private Long errorKey;

    @Column(name = "ERROR_NUMBER", columnDefinition = "NUMERIC(10,0)")
    private Long errorNumber;

    @Column(name = "ERROR_STATE")
    private String errorState;

    @Column(name = "ERROR_SEVERITY")
    private String errorSeverity;

    @Column(name = "ERROR_PROCEDURE")
    private String errorProcedure;

    @Column(name = "ERROR_LINE")
    private String errorLine;

    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "RUN_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date runDate;
}
