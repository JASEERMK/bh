package com.usthealthproof.eplus.commons.batch.common.db.repository;

import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author 210409
 */
@Repository
public interface AuditBatchRepository extends JpaRepository<AuditBatch, Long> {
}
