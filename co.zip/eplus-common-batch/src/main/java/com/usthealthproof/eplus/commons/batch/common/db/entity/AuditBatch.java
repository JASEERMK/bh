package com.usthealthproof.eplus.commons.batch.common.db.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Date;

/**
 * @author 210409
 */
@Table(name = "EPLUS_BATCH_AUDIT_LOG")
@Entity
@Data
@Builder
@AllArgsConstructor @NoArgsConstructor
public class AuditBatch {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "SEQ_NO", columnDefinition = "NUMERIC(18,0)")
    private Long id;

    @Column(name = "INTERFACE_ID")
    private String interfaceId;

    @Column(name = "CORRELATION_ID")
    private String correlationId;

    @Column(name = "RECORD_ID")
    private String recordId;

    @Column(name = "NUMBER_OF_INPUT_RECORDS", columnDefinition = "NUMERIC(11,0)")
    private Long numberOfInputRecords;

    @Column(name = "NUMBER_OF_RESPONSE_RECORDS", columnDefinition = "NUMERIC(11,0)")
    private Long numberOfResponseRecords;

    @Column(name = "PROCESS_STEP")
    private String processStep;

    @Column(name = "PROCESS_STATUS")
    private String processStatus;

    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;

    @Column(name = "ERROR_DETAIL")
    private String errorDetails;

    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "ERROR_REQUEST")
    private String errorRequest;

}
