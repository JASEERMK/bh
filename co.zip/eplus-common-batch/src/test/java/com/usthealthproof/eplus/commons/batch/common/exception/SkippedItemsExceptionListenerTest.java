package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.util.ExceptionUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class SkippedItemsExceptionListenerTest {
    @InjectMocks
    private SkippedItemsExceptionListener skippedItemsExceptionListener;
    @Mock
    private Throwable throwable;
    @Mock
    private StepExecution stepExecution;
    @Mock
    private JobExecution jobExecution;
    @Mock
    private AuditService auditService;
    @Mock
    private ExceptionUtil exceptionUtil;
    @Mock
    private AdhocService adhocService;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;
    @Test
    void testOnSkipInRead() {
        log.info("inside testOnSkipInRead");
        //mock
        when(stepExecution.getStepName()).thenReturn("step");
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "auditService", auditService);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "auditErrorMessageUtil", auditErrorMessageUtil);
        skippedItemsExceptionListener.onSkipInRead(throwable);
    }

    @Test
    void testOnSkipInProcess() {
        log.info("inside testOnSkipInProcess");
        //mock
        when(stepExecution.getStepName()).thenReturn("stepName:Step");
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "exceptionUtil", exceptionUtil);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "adhocService", adhocService);
        Object object=new Object();
        skippedItemsExceptionListener.onSkipInProcess(object,throwable);
    }

    @Test
    void testOnSkipInWrite() {
        log.info("inside testOnSkipInWrite");
        //mock
        when(stepExecution.getStepName()).thenReturn("stepName:Step");
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "exceptionUtil", exceptionUtil);
        ReflectionTestUtils.setField(skippedItemsExceptionListener, "adhocService", adhocService);
        Object object=new Object();
        skippedItemsExceptionListener.onSkipInWrite(object,throwable);
    }

    @Test
    void testFormatStepName() {
        log.info("inside testFormatStepName");
        skippedItemsExceptionListener.formatStepName("");

    }

    @Test
    void testBeforeStep() {
        log.info("inside testBeforeStep");
        skippedItemsExceptionListener.beforeStep(stepExecution);
    }

    @Test
    void testAfterStep() {
        log.info("inside testAfterStep");
        skippedItemsExceptionListener.afterStep(stepExecution);
    }
}