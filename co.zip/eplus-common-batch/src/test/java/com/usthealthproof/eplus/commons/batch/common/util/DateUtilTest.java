package com.usthealthproof.eplus.commons.batch.common.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DateUtilTest {

    @InjectMocks
    private  DateUtil dateUtil;

    @Test
    void testDateForStoredProcedure() {
        log.info("inside testDateForStoredProcedure");
        Date date=new Date();
        String result=dateUtil.dateForStoredProcedure(date);
        //null
        dateUtil.dateForStoredProcedure(null);

    }

    @Test
    void testDateForFileCreation() {
        log.info("inside testDateForFileCreation");
        Date date=new Date();
        dateUtil.dateForFileCreation(date);
        //null
        dateUtil.dateForFileCreation(null);
    }

}