package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.db.entity.Runtime;
import com.usthealthproof.eplus.commons.batch.common.db.repository.RuntimeRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class RuntimeServiceTest {
    @Mock
    private ExecutionContext executionContext;

    @InjectMocks
    private RuntimeService runtimeService;

    @Mock
    AuditService auditService;

    @Mock
    private RuntimeRepository runtimeRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Runtime runtime=new Runtime();
        when(runtimeRepository.findByInterfaceId(any())).thenReturn(runtime);
        ReflectionTestUtils.setField(runtimeService, "auditService", auditService);
    }

    @Test
    void testReadRunTime() {
        log.info("inside testReadRunTime");
        runtimeService.readRuntime(executionContext);
    }

    @Test
    void testUpdateRunTime() {
        log.info("inside testReadRunTime");

        runtimeService.updateRuntime(executionContext);
    }


}