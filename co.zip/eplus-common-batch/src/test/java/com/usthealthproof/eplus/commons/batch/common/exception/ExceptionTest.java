package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@Slf4j
@ExtendWith(MockitoExtension.class)
class ExceptionTest {

    @InjectMocks
    private BatchDataException batchDataException;

    @InjectMocks
    private BatchProcessingException batchProcessingException;

    @InjectMocks
    private BatchRestCallException batchRestCallException;

    @InjectMocks
    private BatchRestServiceException batchRestServiceException;

    @Test
    void testBatchDataException() {
        log.info("inside testBatchDataException");
        String errorMessage = "Something went wrong";
        // Create an instance of CustomException with the error message
        BatchDataException exception = new BatchDataException(ErrorCodeConstant.UNKNOWN_EXCEPTION,errorMessage);
        // Assert that the exception message is correctly set
        assertEquals(errorMessage, exception.getMessage());
        batchDataException.getErrorCode();
        batchDataException.getMessage();
        batchDataException.hashCode();
    }
    @Test
    void testBatchProcessingException() {
        log.info("inside testBatchProcessingException");
        String errorMessage = "Something went wrong";
        // Create an instance of CustomException with the error message
        BatchProcessingException exception = new BatchProcessingException(errorMessage);
        // Assert that the exception message is correctly set
        assertEquals(errorMessage, exception.getMessage());
        batchProcessingException.getMessage();
        batchProcessingException.hashCode();
    }
    @Test
    void testBatchRestCallException() {
        log.info("inside testBatchRestCallException");
        String errorMessage = "Something went wrong";
        // Create an instance of CustomException with the error message
        Throwable throwable=new Throwable();
        BatchRestCallException exception = new BatchRestCallException(errorMessage,throwable);
        // Assert that the exception message is correctly set
        assertEquals(errorMessage, exception.getMessage());
        batchRestCallException.getMessage();
        batchRestCallException.hashCode();
    }
    @Test
    void testBatchRestServiceException() {
        log.info("inside testBatchRestServiceException");
        String errorMessage = "Something went wrong";
        // Create an instance of CustomException with the error message
        BatchRestServiceException exception = new BatchRestServiceException(ErrorCodeConstant.UNKNOWN_EXCEPTION,errorMessage);
        // Assert that the exception message is correctly set
        assertEquals(errorMessage, exception.getMessage());
        batchRestServiceException.getErrorCode();
        batchRestServiceException.hashCode();
    }

}