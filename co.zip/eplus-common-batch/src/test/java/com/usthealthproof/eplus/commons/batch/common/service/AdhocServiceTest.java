package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants;
import com.usthealthproof.eplus.commons.batch.common.db.entity.Adhoc;
import com.usthealthproof.eplus.commons.batch.common.db.repository.AdhocRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class AdhocServiceTest {
    @Mock
    private AdhocRepository adhocRepository;

    @InjectMocks
    private AdhocService adhocService; // This is the service that contains the method

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSetAdhocServiceErrorListIsEmpty() {
        log.info("inside testSetAdhocServiceErrorListIsEmpty");
        // Arrange
        List<Map<String, String>> errorList = new ArrayList<>();
        String adhocType = "someType";

        // Act
        adhocService.setAdhocTableEntries(errorList, adhocType);

        // Assert
        verify(adhocRepository, never()).saveAll(anyList());
    }

    @Test
    void testSetAdhocServiceErrorListWithData(){
        log.info("inside testSetAdhocServiceErrorListWithData");
        // Arrange
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put(AuditConstants.GRAPH_ID, "123");

        List<Map<String, String>> errorList = Collections.singletonList(errorMap);
        String adhocType = "someType";

        // Act
        adhocService.setAdhocTableEntries(errorList, adhocType);

        // Assert
        verify(adhocRepository, times(0)).saveAll(anyList());
    }

    @Test
    void testSetAdhocServiceErrorNoEmptyListIsEmpty() {
        log.info("inside testSetAdhocServiceErrorNoEmptyListIsEmpty");
        // Arrange
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put(AuditConstants.GRAPH_ID, "123");
        List<Map<String, String>> errorList = Collections.singletonList(errorMap);
        String adhocType = "someType";

        // Act
        adhocService.setAdhocTableEntries(errorList, adhocType);
    }



}