package com.usthealthproof.eplus.commons.batch.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.repeat.RepeatContext;

import static org.junit.jupiter.api.Assertions.*;
@Slf4j
@ExtendWith(MockitoExtension.class)
class TaskletExceptionHandlerTest {
    @InjectMocks
    private TaskletExceptionHandler taskletExceptionHandler;
    @Mock
    private RepeatContext repeatContext;
    @Mock
    private  Throwable throwable;
    @Test
    void testHandleException() {
        log.info("inside testHandleException");
        taskletExceptionHandler.handleException(repeatContext,throwable);
    }
}