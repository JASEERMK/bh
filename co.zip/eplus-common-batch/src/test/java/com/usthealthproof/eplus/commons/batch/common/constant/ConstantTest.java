package com.usthealthproof.eplus.commons.batch.common.constant;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
class ConstantTest {

    @Test
     void testPrivateConstructorAuditConstants() throws Exception {
        // Use reflection to access the private constructor
        Constructor<AuditConstants> constructor = AuditConstants.class.getDeclaredConstructor();
        constructor.setAccessible(true);  // Make the constructor accessible

        // Assert that the constructor throws IllegalStateException
        Exception exception = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertTrue(exception.getCause() instanceof IllegalStateException);
        assertEquals("Constant class", exception.getCause().getMessage());
    }

    @Test
     void testPrivateConstructorConstant() throws Exception {
        // Use reflection to access the private constructor
        Constructor<Constant> constructor = Constant.class.getDeclaredConstructor();
        constructor.setAccessible(true);  // Make the constructor accessible

        // because the constructor doesn't throw any exception
        Constant instance = constructor.newInstance();
        assertNotNull(instance);
    }

    @Test
     void constantTest() {
        log.info("inside constantTest");
        //AuditConstants
        assertEquals("Sales force login failed with maximum attempt 3", AuditConstants.ERROR_DETAIL_KEY_SF_LOGIN_MAX_ATTEMPT);
        assertEquals("Sales force login failed, Attempt : {0} ", AuditConstants.ERROR_DETAIL_KEY_SF_LOGIN_FAILED);
        assertEquals("PROVIDER_REQUEST_WRITE", AuditConstants.PROVIDER_REQUEST_WRITE);
        assertEquals("PROVIDER_RESPONSE_WRITE", AuditConstants.PROVIDER_RESPONSE_WRITE);
        assertEquals("PROVIDER_AUDIT_DATA_LOAD_STATUS_QUEUE", AuditConstants.PROVIDER_AUDIT_DATA_LOAD_STATUS);
        assertEquals("graphId", AuditConstants.GRAPH_ID);
        assertEquals("referenceId", AuditConstants.REFERENCE_ID);
        assertEquals("requestMessage", AuditConstants.REQUEST_MESSAGE);
        assertEquals("SUCCESS", AuditConstants.PROCESS_STATUS_SUCCESS_VALUE);
        assertEquals("ERROR", AuditConstants.PROCESS_STATUS_ERROR_VALUE);
        assertEquals("EXCEPTION", AuditConstants.PROCESS_STATUS_EXCEPTION_VALUE);
        assertEquals("PROVIDER", AuditConstants.ADHOC_PROVIDER_TYPE);
        assertEquals("Enrollment", AuditConstants.ADHOC_ENROLLMENT_TYPE);
        assertEquals("MEMBERPCP", AuditConstants.ADHOC_MEMBER_PCP_TYPE);
        assertEquals("false", AuditConstants.ADHOC_IS_EXECUTED_FALSE);

        //Constant
        assertEquals("", Constant.BLANK_STRING);
        assertEquals("AsyncThread-", Constant.THREAD_PREFIX);
        assertEquals("access_token", Constant.ACCESS_TOKEN_FROM_SERVICE);
        assertEquals("Bearer ", Constant.BEARER_TOKEN);
        assertEquals("runtime", Constant.RUNTIME);
        assertEquals("newRuntime", Constant.NEW_RUNTIME);
        assertEquals("accessToken", Constant.ACCESS_TOKEN);
        assertEquals("recordTypeMap", Constant.RECORD_TYPE_MAP);
        assertEquals("loginAttempt", Constant.LOGIN_ATTEMPT);
        assertEquals("message", Constant.MESSAGE);
        assertEquals("responseText", Constant.RESPONSE_TEXT);
        assertEquals("correlationId", Constant.CORRELATION_ID);
        assertEquals("ReadRunTimeStep", Constant.PROCESS_STEP_READ_RUNTIME);
        assertEquals("StoredProcedureStep", Constant.PROCESS_STEP_SP);
        assertEquals("CallLoginServiceStep", Constant.PROCESS_STEP_SF_LOGIN);
        assertEquals("GetRecordTypeCreationStep", Constant.PROCESS_STEP_RECORD_TYPE);
        assertEquals("DataLoadStep", Constant.PROCESS_STEP_SF_DATA_LOAD);
        assertEquals("UpdateLastRuntimeStep", Constant.PROCESS_STEP_UPDATE_RUNTIME);
        assertEquals("JobExecution", Constant.PROCESS_JOB);
        assertEquals("CountUpdateStep", Constant.PROCESS_STEP_UPDATE_COUNT);

    }

}