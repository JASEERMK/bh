package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.db.entity.OdsExtractError;
import com.usthealthproof.eplus.commons.batch.common.db.repository.AuditBatchRepository;
import com.usthealthproof.eplus.commons.batch.common.db.repository.OdsExtractErrorRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class AuditServiceTest {
    @InjectMocks
    private AuditService auditService;  // The class being tested
    // A spy to mock protected methods

    @Mock
    private AuditBatchRepository auditBatchRepository;

    @Mock
    OdsExtractErrorRepository odsExtractErrorRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAuditReadRunTimeSuccessStatus() {
        log.info("inside testAuditReadRunTimeSuccessStatus");
        Date runtime = new Date();
        // Act
        auditService.auditReadRunTimeSuccessStatus(runtime);
    }

    @Test
    void testAuditUpdateRunTimeSuccessStatus() {
        log.info("inside testAuditUpdateRunTimeSuccessStatus");

        Date date = new Date();
        // Act
        auditService.auditUpdateRunTimeSuccessStatus(date);
    }

    @Test
    void testAuditAddSPSuccessLog() {
        log.info("inside testAuditAddSPSuccessLog");
        // Act
        auditService.addSPSuccessLog();
    }

    @Test
    void testAuditAddSPErrorLog() {
        log.info("inside testAuditAddSPErrorLog");
        Date runTime = new Date();
        List<OdsExtractError> OdsExtractErrorList=new ArrayList<>();
        OdsExtractError odsExtractError=new OdsExtractError();
        odsExtractError.setErrorKey(123L);
        odsExtractError.setErrorLine("Eline");
        odsExtractError.setErrorMessage("Error");
        odsExtractError.setErrorNumber(19L);
        odsExtractError.setErrorSeverity("Critical");
        odsExtractError.setErrorProcedure("Procedure");
        odsExtractError.setErrorState("Open");
        odsExtractError.setRunDate(new Date());
        OdsExtractErrorList.add(odsExtractError);
        when(odsExtractErrorRepository.findByRunDateGreaterThanEqualAndErrorProcedureContains(any(),any())).thenReturn(OdsExtractErrorList);
        // Act
        auditService.addSPErrorLog(runTime,"Procedure","Step");
    }

    @Test
    void testAuditSalesForceLoginSuccessStatus() {
        log.info("inside testAuditSalesForceLoginSuccessStatus");
        // Act
        auditService.auditSalesForceLoginSuccessStatus();
    }

    @Test
    void testAuditSalesForceLoginFailureStatus() {
        log.info("inside testAuditSalesForceLoginFailureStatus");
        // Act
        auditService.auditSalesForceLoginFailureStatus("errorMessage","errorDetails");
    }

    @Test
    void testAuditSFDataLoadWriteError() {
        log.info("inside testAuditSFDataLoadWriteError");
        List<Map<String, String>> errorList = new ArrayList<>();
        // Act
        auditService.auditSFDataLoadWriteError(errorList,"Procedure","request");

        //Act with data
        errorList=createTestDataForErrorList();
        auditService.auditSFDataLoadWriteError(errorList,"Procedure","request");
    }

    @Test
    void testAuditExecuteQuerySuccessCountStatus() {
        log.info("inside testAuditExecuteQuerySuccessCountStatus");
        // Act
        auditService.auditExecuteQuerySuccessCountStatus(5);
    }

    @Test
    void testAuditExecuteQueryErrorCountStatus() {
        log.info("inside testAuditExecuteQueryErrorCountStatus");
        // Act
        auditService.auditExecuteQueryErrorCountStatus(7);
    }

    @Test
    void testAuditExecuteQueryTotalCountStatus() {
        log.info("inside testAuditExecuteQueryTotalCountStatus");
        // Act
        auditService.auditExecuteQueryTotalCountStatus(15L);
    }

    @Test
    void testAuditExecuteQueryDistinctCountStatus() {
        log.info("inside testAuditExecuteQueryDistinctCountStatus");
        // Act
        auditService.auditExecuteQueryDistinctCountStatus(5L);
    }

    @Test
    void testAuditBatchException() {
        log.info("inside testAuditBatchException");
        List<Map<String, String>> errorList = new ArrayList<>();
        Throwable throwable=new Throwable();
        // Act with out data
        auditService.auditBatchException("Process",errorList,throwable);
        ReflectionTestUtils.setField(auditService, "auditRequest", true);
        //Act with data
        errorList=createTestDataForErrorList();
        auditService.auditBatchException("Process",errorList,throwable);

    }

    @Test
    void testAuditException() {
        log.info("inside testAuditException");
        Throwable throwable=new Throwable();
        // Act
        auditService.auditException(throwable,"Process");
    }
    // Function to add test data to errorList
    private static List<Map<String, String>> createTestDataForErrorList() {
        List<Map<String, String>> errorList = new ArrayList<>();

        // Add first map with test data
        Map<String, String> errorMap1 = new HashMap<>();
        errorMap1.put("errorId", "101");
        errorMap1.put("errorMessage", "Null Pointer Exception");
        errorMap1.put("severity", "HIGH");
        errorList.add(errorMap1);

        // Add second map with test data
        Map<String, String> errorMap2 = new HashMap<>();
        errorMap2.put("errorId", "102");
        errorMap2.put("errorMessage", "Array Index Out of Bounds");
        errorMap2.put("severity", "MEDIUM");
        errorList.add(errorMap2);

        // Add third map with test data
        Map<String, String> errorMap3 = new HashMap<>();
        errorMap3.put("errorId", "103");
        errorMap3.put("errorMessage", "SQL Exception");
        errorMap3.put("severity", "LOW");
        errorList.add(errorMap3);

        return errorList;
    }



}