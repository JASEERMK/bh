package com.usthealthproof.eplus.commons.batch.common.service;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

    @InjectMocks
    LoginService loginService;
    @Mock
    private StepExecution stepExecution;

    @Mock
    private JobExecution jobExecution;

    private ExecutionContext executionContext;

    @BeforeEach
     void setUp() {
        // Initialize a mock ExecutionContext and JobExecution
        executionContext = new ExecutionContext();
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getExecutionContext()).thenReturn(executionContext);
    }

    @Test
     void testIsLoginAttemptExceeded_NoPreviousAttempt() {
        // Act
        boolean result = loginService.isLoginAttemptExceeded(stepExecution);
        // Assert: Since there are no previous attempts, it should return false and set the attempt to 2
        assertFalse(result);
        assertEquals(1, executionContext.get(Constant.LOGIN_ATTEMPT));
    }

    @Test
     void testIsLoginAttemptExceeded_LessThanThreshold() {
        // Arrange: Set the LOGIN_ATTEMPT in the context to 2
        executionContext.put(Constant.LOGIN_ATTEMPT, 2);

        // Act
        boolean result = loginService.isLoginAttemptExceeded(stepExecution);

        // Assert: The method should return false because attempts are less than or equal to the threshold
        assertTrue(result);
        assertEquals(2, executionContext.get(Constant.LOGIN_ATTEMPT));
    }

    @Test
     void testIsLoginAttemptExceeded_ExceededThreshold() {
        // Arrange: Set the LOGIN_ATTEMPT in the context to 3
        executionContext.put(Constant.LOGIN_ATTEMPT, 3);

        // Act
        boolean result = loginService.isLoginAttemptExceeded(stepExecution);

        // Assert: The method should return true since the login attempts exceeded the threshold (3)
        assertTrue(result);
    }



}