package com.usthealthproof.eplus.commons.batch.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchDataException;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchRestServiceException;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdLoadResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.StepExecution;
import org.springframework.web.reactive.function.client.WebClientException;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CommonUtilsTest {

    @InjectMocks
    private  CommonUtils commonUtils;

    @Mock
    private StepExecution stepExecution;

    @Test
    void testGetErrorMessageType() {
        log.info("inside testGetErrorMessageType");

        // for error type BatchRestServiceException
        BatchRestServiceException batchRestServiceException=new BatchRestServiceException(ErrorCodeConstant.UNKNOWN_EXCEPTION,"BatchRestServiceException");
        commonUtils.getErrorMessageType(batchRestServiceException);

        // for error type BatchDataException
        BatchDataException batchDataException=new BatchDataException(ErrorCodeConstant.UNKNOWN_EXCEPTION,"BatchDataException");
        commonUtils.getErrorMessageType(batchDataException);

        // for error type JobInterruptedException
        JobInterruptedException jobInterruptedException=new JobInterruptedException("JobInterruptedException");
        commonUtils.getErrorMessageType(jobInterruptedException);

        // for error type SQLException
        SQLException sqlException=new SQLException("SQLException");
        commonUtils.getErrorMessageType(sqlException);

        // for error type SQLException
        WebClientException webClientException = null;
        commonUtils.getErrorMessageType(webClientException);

        // for error type Throwable
        Throwable throwable=new Throwable("Throwable Exception");
        commonUtils.getErrorMessageType(throwable);

    }

    @Test
    void testGetErrorDetails() {
        log.info("inside testGetErrorDetails");
        // for error type Throwable
        Throwable throwable=new Throwable("Throwable Exception Message");
        commonUtils.getErrorDetails(throwable);

    }

    @Test
    void testGetErrorMessage() {
        log.info("inside testGetErrorMessage");
        // for error type Throwable
        Throwable throwable=new Throwable("Throwable Exception Message");
        StringBuilder errorMessage=new StringBuilder("Error Message");
        commonUtils.getErrorMessage(throwable,errorMessage);

    }

    @Test
    void testGetObjectAsString() throws JsonProcessingException {
        log.info("inside testGetObjectAsString");
        Throwable throwable=new Throwable("Throwable Exception Message");
        commonUtils.getObjectAsString(throwable);

        // Simulate exception from the dependency
        Object obj = new Object();
        // Call the method and verify it returns an empty string when exception is thrown
        String result = commonUtils.getObjectAsString(obj);
        assertEquals("", result);

    }

    @Test
    void testWriteDebugMessage() {
        log.info("inside testWriteDebugMessage");
        //mock
        //when(mockLogger.isDebugEnabled()).thenReturn(true);
        Throwable throwable=new Throwable("Throwable Exception Message");
        commonUtils.writeDebugMessage("Error Message",throwable);

    }

    @Test
    void testExtractDate() {
        log.info("inside testExtractDate");
        commonUtils.extractDate("01/01/2020");
        //empty
        commonUtils.extractDate("");

    }

    @Test
    void testExtractDateForDate() {
        log.info("inside testExtractDateForDate");
        Date date=new Date(1355252400000L);
        commonUtils.extractDate(date);
        date=null;
        commonUtils.extractDate(date);

    }

    @Test
    void testExtractDateFromDB() {
        log.info("inside testExtractDateFromDB");
        commonUtils.extractDateFromDB("01/01/2020");
        //null
        commonUtils.extractDateFromDB(null);


    }

    @Test
    void testReplaceNullToEmpty() {
        log.info("inside testReplaceNullToEmpty");
        commonUtils.replaceNullToEmpty(null);
        commonUtils.replaceNullToEmpty("test");

    }

    @Test
    void testCleanRecordTypeId() {
        log.info("inside testCleanRecordTypeId");
        commonUtils.cleanRecordTypeId("4567");

    }

    @Test
    void testGetThrowable() {
        log.info("inside testGetThrowable");
        commonUtils.getThrowable(stepExecution);

    }

    @Test
    void testValidateRecordTypeResponse() {
        log.info("inside testValidateRecordTypeResponse");
        RecordIdMainResponse recordIdMainResponse=new RecordIdMainResponse();
        RecordIdLoadResponse recordIdLoadResponse=new RecordIdLoadResponse();
        recordIdLoadResponse.setHttpStatusCode(200L);
        recordIdLoadResponse.setReferenceId("123");
        RecordIdLoadResponse recordIdLoadResponse2=new RecordIdLoadResponse();
        recordIdLoadResponse2.setHttpStatusCode(400L);
        recordIdLoadResponse2.setReferenceId("456");
        List<RecordIdLoadResponse> recordIdLoadResponses=new ArrayList<>();
        recordIdLoadResponses.add(recordIdLoadResponse);
        recordIdMainResponse.setCompositeResponse(recordIdLoadResponses);
        commonUtils.validateRecordTypeResponse(recordIdMainResponse);

    }

    @Test
    void testRemoveSpecialCharacter() {
        log.info("inside testRemoveSpecialCharacter");
        //testing in different cases
        String result=commonUtils.removeSpecialCharacter("123;'[]]");
        assertEquals("123",result);
        //for empty string
        commonUtils.removeSpecialCharacter("");
    }

    @Test
    void testValidateBooleanValue() {
        log.info("inside testValidateBooleanValue");
        //testing in different cases
        String result=commonUtils.validateBooleanValue("Yes");
        assertEquals("yes",result);
        assertEquals("false",commonUtils.validateBooleanValue(""));

    }

    @Test
    void testValidateBooleanValueYorN() {
        log.info("inside testValidateBooleanValueYorN");
        //testing in different cases
        String result=commonUtils.validateBooleanValueYorN("Y");
        assertEquals("true",result);
        assertEquals("false",commonUtils.validateBooleanValueYorN("Test"));

    }

    @Test
    void validateBooleanValueYesOrNo() {
        log.info("inside testGetErrorMessageType");
        //testing in different cases
        String result=commonUtils.validateBooleanValueYesOrNo("Yes");
        assertEquals("true",result);
        assertEquals("false",commonUtils.validateBooleanValueYesOrNo(""));

    }

    @Test
    public void testGetThrowableWhenNoExceptions() {
        // Scenario 1: Empty failure exceptions
        when(stepExecution.getFailureExceptions()).thenReturn(Collections.emptyList());

        Throwable result = commonUtils.getThrowable(stepExecution);

        assertNull(result); // Assert that the result is null
    }

    @Test
    public void testGetThrowableWhenNonCompletionException() {
        // Scenario 2: A non-CompletionException throwable
        Throwable sampleThrowable = new RuntimeException("Test Exception");
        when(stepExecution.getFailureExceptions()).thenReturn(List.of(sampleThrowable));

        Throwable result = commonUtils.getThrowable(stepExecution);

        assertNotNull(result); // Result should not be null
        assertEquals(sampleThrowable, result); // It should return the first exception
    }

    @Test
    public void testGetThrowableWhenCompletionException() {
        // Scenario 3: CompletionException with a cause
        Throwable causeThrowable = new RuntimeException("Root Cause");
        Throwable completionException = new CompletionException(causeThrowable);
        when(stepExecution.getFailureExceptions()).thenReturn(List.of(completionException));

        Throwable result = commonUtils.getThrowable(stepExecution);

        assertNotNull(result); // Result should not be null
        assertEquals(causeThrowable, result); // It should return the cause of CompletionException
    }

    @Test
    public void testGetThrowableWhenCompletionExceptionWithoutCause() {
        // Scenario 4: CompletionException without a cause
        Throwable completionException = new CompletionException(null);
        when(stepExecution.getFailureExceptions()).thenReturn(List.of(completionException));

        Throwable result = commonUtils.getThrowable(stepExecution);

        assertNull(result); // Since the cause is null
    }
}