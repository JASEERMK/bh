package com.usthealthproof.eplus.commons.batch.common.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class RestResponseUtilTest {
    @InjectMocks
    private RestResponseUtil restResponseUtil;
    @Mock
    private ClientResponse mockClientResponse;

    @Test
    void testGetUnAuthorizedException() {
        log.info("inside testDateForStoredProcedure");
        // Mock the body of the response (assuming the body is a String here)
        when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just("Mock response body"));
        restResponseUtil.getUnAuthorizedException(mockClientResponse);
    }

    @Test
    void testetSFRestErrorException() {
        log.info("inside testDateForStoredProcedure");
        when(mockClientResponse.bodyToMono(String.class)).thenReturn(Mono.just("Mock response body"));
        Object object=null;
        restResponseUtil.getSFRestErrorException(object,mockClientResponse);
    }
}