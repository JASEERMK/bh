package com.usthealthproof.eplus.commons.batch.common.model.request;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BodyTest {
    // Subclass of Body since Body is abstract
    static class ConcreteBody extends Body {
    }

    @Test
    void testSetCustomFields() {
        log.info("inside testSetCustomFields");
        ConcreteBody body = new ConcreteBody();
        body.setCustomFields("key1", "value1");

        // Verify that the map contains the correct values
        Map<String, Object> customFields = body.getCustomFields();
        assertNotNull(customFields);
        assertEquals(1, customFields.size());
        assertEquals("value1", customFields.get("key1"));
    }

    @Test
    void testGetCustomFields_whenEmpty() {
        log.info("inside testGetCustomFields_whenEmpty");
        ConcreteBody body = new ConcreteBody();

        // Verify that initially, customFields is null or empty
        assertNull(body.getCustomFields());

        body.setCustomFields("key1", "value1");
        assertNotNull(body.getCustomFields());
        assertEquals(1, body.getCustomFields().size());
    }

    @Test
     void testJacksonSerialization() throws Exception {
        log.info("inside testJacksonSerialization");
        // Use Jackson to serialize and deserialize the class
        ConcreteBody body = new ConcreteBody();
        body.setCustomFields("key1", "value1");
        body.setCustomFields("key2", 100);

        ObjectMapper mapper = new ObjectMapper();

        // Test serialization (customFields should not be ignored by @JsonIgnore)
        String json = mapper.writeValueAsString(body);
        assertTrue(json.contains("\"key1\":\"value1\""));
        assertTrue(json.contains("\"key2\":100"));

        // Test deserialization
        String jsonInput = "{\"key1\":\"value1\", \"key2\":100}";
        ConcreteBody deserializedBody = mapper.readValue(jsonInput, ConcreteBody.class);

        assertNotNull(deserializedBody.getCustomFields());
        assertEquals("value1", deserializedBody.getCustomFields().get("key1"));
        assertEquals(100, deserializedBody.getCustomFields().get("key2"));
    }

    @Test
     void testLombokGeneratedMethods() {
        log.info("inside testLombokGeneratedMethods");
        ConcreteBody body1 = new ConcreteBody();
        body1.setCustomFields("key1", "value1");

        ConcreteBody body2 = new ConcreteBody();
        body2.setCustomFields("key1", "value1");

        // Testing equals and hashCode
        assertEquals(body1, body2);
        assertEquals(body1.hashCode(), body2.hashCode());

        // Testing toString
        assertTrue(body1.toString().contains("customFields"));
    }

}