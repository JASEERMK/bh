package com.usthealthproof.eplus.commons.batch.common.exception;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ExceptionListenerTest {

    @InjectMocks
    private  ExceptionListener exceptionListener;
    @Mock
    ChunkContext chunkContextMock;
    @Mock
    StepContext stepContextMock;
    @Mock
    StepExecution stepExecutionMock;
    @Mock
    Throwable throwable;

    void initialise() {
        // Mock any further required data or objects
        when(chunkContextMock.getStepContext()).thenReturn(stepContextMock);
        when(stepContextMock.getStepExecution()).thenReturn(stepExecutionMock);
        when(chunkContextMock.getAttribute(any())).thenReturn(throwable);

    }

    @Test
    void testAfterChunkError() {
        log.info("inside testAfterChunkError");
        initialise();
        exceptionListener.afterChunkError(chunkContextMock);
    }

    @Test
    void testBeforeChunk() {
        log.info("inside testBeforeChunk");
        exceptionListener.beforeChunk(chunkContextMock);
    }

    @Test
    void testAfterChunk() {
        log.info("inside testAfterChunk");
        exceptionListener.afterChunk(chunkContextMock);
    }

}