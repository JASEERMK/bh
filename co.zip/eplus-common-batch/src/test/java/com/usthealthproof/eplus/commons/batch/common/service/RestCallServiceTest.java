package com.usthealthproof.eplus.commons.batch.common.service;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class RestCallServiceTest {
    @InjectMocks
    private RestCallService restCallService;  // Replace with your actual service class

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private StepExecution stepExecution;

    @Mock
    private JobExecution jobExecution;
    @Mock
    ExecutionContext executionContext;
    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    private static final String URL = "http://example.com/api";
    private static final String ACCESS_TOKEN = "dummyAccessToken";
    Class<String> responseClass = String.class;
    String expectedResponse = "Response";
    @Mock
    private WebClient.RequestHeadersUriSpec<?> requestHeadersUriSpecf;

    @BeforeEach
     void setUp() {

        // Setup the mocked StepExecution and JobExecution
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getExecutionContext()).thenReturn(executionContext);
        // Mock WebClient response
        when(webClient.method(any())).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(any(String.class), any(String[].class))).thenReturn(requestBodySpec); // Match the method signature
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(responseClass)).thenReturn(Mono.just(expectedResponse));
        when(requestBodySpec.contentType(any(MediaType.class))).thenReturn(requestBodySpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
    }

    @Test
     void testCallGetRequest_success() {
        Object request=new Object();
        // Act
        Object actualResponse =  restCallService.callGetRequest(URL, responseClass, request, stepExecution);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
     void testCallPostRequest_success() {
        Object request=new Object();
        // Act
        Object actualResponse =  restCallService.callPostRequest(URL, responseClass, request, stepExecution);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
     void testCallPatchRequest_success() {
        Object request=new Object();
        // Act
        Object actualResponse =  restCallService.callPatchRequest(URL, responseClass, request, stepExecution);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
     void testCallPutCSVRequest_success() {
        Object request=new Object();
        // Act
        Object actualResponse =  restCallService.callPutCSVRequest(URL, responseClass, request, stepExecution);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

}