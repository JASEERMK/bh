package com.usthealthproof.eplus.commons.batch.common.exception;

import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;

import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class JobAuditListenerTest {

    @InjectMocks
    private JobAuditListener jobAuditListener;
    @Mock
    private JobExecution mockJobExecution;

    @Mock
    private StepExecution mockStepExecution;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;

    @Test
    void testJobAuditListener() {
        log.info("inside testJobAuditListener");
        // Mocking the exception for the StepExecution
        Exception mockException = new Exception("Mock Exception");
        // Mocking StepExecution to return a list of failure exceptions
        when(mockStepExecution.getFailureExceptions()).thenReturn(List.of(mockException));
        // Mocking JobExecution to return a set of StepExecutions that includes the mockStepExecution
        Set<StepExecution> mockStepExecutions = Set.of(mockStepExecution);
        when(mockJobExecution.getStepExecutions()).thenReturn(mockStepExecutions);
        // Mock CommonUtils.getThrowable() to return the same exception
        when(mockStepExecution.getFailureExceptions()).thenReturn(List.of(mockException));
        // Call the method under test
        jobAuditListener.afterJob(mockJobExecution);
        // Verify that auditService.auditException() was called with the correct arguments
        verify(auditErrorMessageUtil).auditException(any(),any(),any());
    }
}