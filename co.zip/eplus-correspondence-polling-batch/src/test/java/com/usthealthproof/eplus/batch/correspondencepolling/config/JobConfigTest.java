package com.usthealthproof.eplus.batch.correspondencepolling.config;

import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Slf4j
class JobConfigTest {
    @Mock
    private AuditService auditService;

    @Mock
    private CorrespondenceService correspondenceService;

    @Mock
    private JobAuditListener jobAuditListener;
    @Mock
    JobRepository jobRepository;

    @InjectMocks
    private JobConfig jobConfig;
    @Mock
    TaskExecutorJobLauncher taskExecutorJobLauncher;
    @Mock Step stepMock;
    @Mock
    JobParameters param;
    @Mock
    JobExecution jobExecutionMock;
    @Mock
    AuditErrorMessageUtil auditErrorMessageUtil;
    @Mock
    AuditService auditServiceMock;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        ReflectionTestUtils.setField(jobConfig, "jobAuditListener", jobAuditListener);
        jobConfig = new JobConfig(correspondenceService, auditService,jobAuditListener,auditErrorMessageUtil);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        param = new JobParametersBuilder()
                .addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        jobExecutionMock=new JobExecution(new JobInstance(1L, "jobName"), param);


    }

    /**
     * Method under test: {@link JobConfig#getJobListenerCount()}
     */
    @Test
    public void testGetJobListenerCount() {
        log.info("inside testGetJobListenerCount");
        JobExecutionListener jobExecutionListener = jobConfig.getJobListenerCount();
        assertNotNull(jobExecutionListener);
        jobConfig.getJobListenerCount().beforeJob(jobExecutionMock);
        jobConfig.getJobListenerCount().afterJob(jobExecutionMock);
    }

    /**
     * Method under test: {@link JobConfig#taskExecutorJobLauncher(JobRepository)}
     */
    @Test
    public void testTaskExecutorJobLauncher() {
        log.info("inside testGetJobListenerCount");
        TaskExecutorJobLauncher launcher = jobConfig.taskExecutorJobLauncher(jobRepository);
        assertNotNull(launcher);
    }
   @Test
    void testProfileUpdateJob() throws Exception {
       log.info("inside testProfileUpdateJob");
       // Call the method to be test
        Job result = jobConfig.profileUpdateJob(
                stepMock,
                stepMock,jobRepository
        );
        assertEquals("CorrespondenceBatchJob", result.getName());
    }
}

