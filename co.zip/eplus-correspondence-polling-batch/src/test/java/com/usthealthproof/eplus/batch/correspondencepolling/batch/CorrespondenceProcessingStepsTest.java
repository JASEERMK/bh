package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import com.usthealthproof.eplus.commons.batch.common.exception.BatchDataException;
import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.batch.correspondencepolling.config.Config;
import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import com.usthealthproof.eplus.batch.correspondencepolling.model.CombinedCorrespondenceModel;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceGraphRequest;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceRecord;
import com.usthealthproof.eplus.batch.correspondencepolling.repository.CorrespondenceManagementRepository;
import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CorrespondenceProcessingStepsTest {
    @InjectMocks
    CorrespondenceProcessingSteps correspondenceProcessingSteps;
    @InjectMocks
    Config configMock;
    @Mock
    CorrespondenceService correspondenceService;
    @Mock
    AuditService auditService;
    @Mock
    LoginService loginService;
    @Mock
    CountUpdateListener countUpdateListener;
    @Mock
    CorrespondenceManagementRepository correspondenceManagementRepository;
    @Mock
    TaskletExceptionHandler taskletExceptionHandler;
    @Mock
    ExceptionListener exceptionListener;
    @Mock
    JobRepository jobRepositoryMock;
    @Mock
    private StepExecution stepExecution;
    @Mock
    private JobExecution jobExecution;
    @Mock
    private ExecutionContext executionContextMock;
    @Mock
    private PlatformTransactionManager transactionManager;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;
    @Mock
    private JobInstance jobInstance;
    @Mock
    private JobRepository jobRepository;

    private final String correspondenceRecordServiceUrl = "www.testingcorrespondence.com/";

    @BeforeEach
    public void setUp() {
        TransactionSynchronizationManager.initSynchronization();
        MockitoAnnotations.initMocks(this);
        correspondenceProcessingSteps = new CorrespondenceProcessingSteps(auditService, correspondenceManagementRepository, loginService, taskletExceptionHandler, exceptionListener, correspondenceService, auditErrorMessageUtil);
    }

    @AfterEach
    public void setDown() {
        TransactionSynchronizationManager.clear();
    }

    void initialise() {
        String stepName = "ProcessCorrespondenceDataStep";
        Integer timeout = 120;
        ReflectionTestUtils.setField(configMock, "connectionTimeout", timeout);
        ReflectionTestUtils.setField(correspondenceProcessingSteps, "correspondenceRecordServiceUrl", correspondenceRecordServiceUrl);
        ReflectionTestUtils.setField(correspondenceService, "correspondenceLoadURL", "www.testc.com/");
        when(stepExecution.getExecutionContext()).thenReturn(executionContextMock);
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        // Set the stepName in StepExecution
        when(stepExecution.getStepName()).thenReturn(stepName);
    }

    @Test
    void testProcessCorrespondenceData() throws JobInterruptedException {
        log.info("inside testProcessCorrespondenceData");
        initialise();
        //mock job id
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);

        List<CorrespondenceManagement> correspondenceIntegrationResult = setDummyValues("g");
        List<CorrespondenceManagement> correspondenceOdsResult = setDummyValues("s");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);
        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener,jobRepositoryMock, transactionManager).execute(stepExecution);

        ArgumentCaptor<CorrespondenceGraphRequest> argumentGraph = ArgumentCaptor.forClass(CorrespondenceGraphRequest.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);
        ArgumentCaptor<List<CombinedCorrespondenceModel>> argumentSplitRequest = ArgumentCaptor.forClass(List.class);

        verify(correspondenceService).addCorrespondenceService(argumentGraph.capture(), argumentStepExecution.capture(),argumentSplitRequest.capture());
        //checking size of the graph
        assertEquals(1, argumentGraph.getAllValues().size());
        //verifying reference id
        assertEquals("56547", argumentGraph.getValue().getCompositeRequest().get(0).getReferenceId());
        //verifying url
        assertEquals(correspondenceRecordServiceUrl + "56547", argumentGraph.getValue().getCompositeRequest().get(0).getUrl());
        //verifying state
        CorrespondenceRecord record = (CorrespondenceRecord) argumentGraph.getValue().getCompositeRequest().get(0).getBody();
        assertEquals("Sent", record.getCorrespondenceStatus());
        //checking stepname
        assertEquals("DataLoadStep", correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).getName());
    }
    @Test
    void testProcessCorrespondenceDataWithAnotherStatus() throws JobInterruptedException {
        log.info("inside testProcessCorrespondenceData");
        initialise();
        //mock job id
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);

        List<CorrespondenceManagement> correspondenceIntegrationResult = setDummyValues("g");
        //executing processCorrespondenceData() with status g
        List<CorrespondenceManagement> correspondenceOdsResult = setDummyValues("g");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);
        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);

        //executing processCorrespondenceData() with status t
        correspondenceOdsResult = setDummyValues("t");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);
        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);
        ArgumentCaptor<CorrespondenceGraphRequest> argumentGraph = ArgumentCaptor.forClass(CorrespondenceGraphRequest.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);
        ArgumentCaptor<List<CombinedCorrespondenceModel>> argumentSplitRequest = ArgumentCaptor.forClass(List.class);
        verify(correspondenceService, times(1)).addCorrespondenceService(argumentGraph.capture(), argumentStepExecution.capture(),argumentSplitRequest.capture());
    }

    @Test
    void testProcessCorrespondenceDataWithStatusC() throws JobInterruptedException {
        log.info("inside testProcessCorrespondenceDataWithStatusC");
        initialise();
        //mock job id
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);

        List<CorrespondenceManagement> correspondenceIntegrationResult = setDummyValues("g");
        List<CorrespondenceManagement> correspondenceOdsResult = setDummyValues("c");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);
        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);

        ArgumentCaptor<CorrespondenceGraphRequest> argumentGraph = ArgumentCaptor.forClass(CorrespondenceGraphRequest.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);
        ArgumentCaptor<List<CombinedCorrespondenceModel>> argumentSplitRequest = ArgumentCaptor.forClass(List.class);

        verify(correspondenceService).addCorrespondenceService(argumentGraph.capture(), argumentStepExecution.capture(),argumentSplitRequest.capture());
        //checking size of the graph
        assertEquals(1, argumentGraph.getAllValues().size());
        //verifying reference id
        assertEquals("56547", argumentGraph.getValue().getCompositeRequest().get(0).getReferenceId());
        //verifying url
        assertEquals(correspondenceRecordServiceUrl + "56547", argumentGraph.getValue().getCompositeRequest().get(0).getUrl());
        //verifying state
        CorrespondenceRecord record = (CorrespondenceRecord) argumentGraph.getValue().getCompositeRequest().get(0).getBody();
        assertEquals("Cancelled", record.getCorrespondenceStatus());
        //checking stepname
        assertEquals("DataLoadStep", correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).getName());
    }
    @Test
    void testProcessCorrespondenceDataWithStatusG() throws JobInterruptedException {
        log.info("inside testProcessCorrespondenceDataWithStatusG");
        initialise();
        //mock job id
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);

        List<CorrespondenceManagement> correspondenceIntegrationResult = setDummyValues("s");
        List<CorrespondenceManagement> correspondenceOdsResult = setDummyValues("g");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);
        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);

        ArgumentCaptor<CorrespondenceGraphRequest> argumentGraph = ArgumentCaptor.forClass(CorrespondenceGraphRequest.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);
        ArgumentCaptor<List<CombinedCorrespondenceModel>> argumentSplitRequest = ArgumentCaptor.forClass(List.class);

        verify(correspondenceService).addCorrespondenceService(argumentGraph.capture(), argumentStepExecution.capture(),argumentSplitRequest.capture());
        //checking size of the graph
        assertEquals(1, argumentGraph.getAllValues().size());
        //verifying reference id
        assertEquals("56547", argumentGraph.getValue().getCompositeRequest().get(0).getReferenceId());
        //verifying url
        assertEquals(correspondenceRecordServiceUrl + "56547", argumentGraph.getValue().getCompositeRequest().get(0).getUrl());
        //verifying state
        CorrespondenceRecord record = (CorrespondenceRecord) argumentGraph.getValue().getCompositeRequest().get(0).getBody();
        assertEquals("Generated", record.getCorrespondenceStatus());
        //checking stepname
        assertEquals("DataLoadStep", correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).getName());
    }

    @Test
    void sameStateTest() throws JobInterruptedException {
        log.info("inside sameStateTest");
        initialise();
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);
        //checking two requests with same state
        List<CorrespondenceManagement> correspondenceResult = setDummyValues("g");
        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceResult);

        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);

        //verify service is not called
        verifyNoMoreInteractions(correspondenceService);
    }

    @Test
    void emptyTest() throws JobInterruptedException {
        log.info("inside emptyTest");
        initialise();
        // Mock correspondenceIntegrationResult
        List<CorrespondenceManagement> correspondenceIntegrationResult = new ArrayList<>();
        // Mock correspondenceOdsResult
        List<CorrespondenceManagement> correspondenceOdsResult = new ArrayList<>();
        when(jobExecution.getJobInstance()).thenReturn(jobInstance);

        when(correspondenceService.getOdsCorrespondenceList()).thenReturn(correspondenceOdsResult);
        when(correspondenceManagementRepository.getIntegrationCorrespondenceList()).thenReturn(correspondenceIntegrationResult);

        //executing processCorrespondenceData()
        correspondenceProcessingSteps.processCorrespondenceData(countUpdateListener, jobRepositoryMock, transactionManager).execute(stepExecution);

        //verify service is not called since lists are empty
        verifyNoMoreInteractions(correspondenceService);
    }

    @Test
    void loginTest() throws JobInterruptedException {
        log.info("inside loginTest");
        initialise();
        //executing callLoginServiceStep()
        correspondenceProcessingSteps.callLoginServiceStep(jobRepositoryMock, transactionManager).execute(stepExecution);

        //verify it is executed
        verify(loginService).callLoginService(stepExecution);
    }

    private static List<CorrespondenceManagement> setDummyValues(String status) {
        List<CorrespondenceManagement> correspondenceResult = new ArrayList<>();
        CorrespondenceManagement correspondenceManagement = new CorrespondenceManagement();
        correspondenceManagement.setCorrespondenceId("56547");
        correspondenceManagement.setStatus(status);
        correspondenceManagement.setCreatedDate("03/03/1998");
        correspondenceManagement.setUpdatedDate("05/03/1998");
        correspondenceResult.add(correspondenceManagement);
        return correspondenceResult;
    }

}

