package com.usthealthproof.eplus.batch.correspondencepolling.model.request;

import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.batch.correspondencepolling.model.CombinedCorrespondenceModel;
import com.usthealthproof.eplus.batch.correspondencepolling.model.response.CorrespondenceBatchLoadResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
@Slf4j
public class GraphTests {
    @Mock
    CorrespondenceGraphRequest correspondenceGraphRequestMock;
    @Mock
    CorrespondenceRecord correspondenceRecordMock;
    @Mock
    Graphs graphsMock;
    @Mock
    CombinedCorrespondenceModel combinedCorrespondenceModelMock;

    @Test
    public void testGraphRequestsAndResponses() {

        CorrespondenceGraphRequest correspondenceGraphRequest=new CorrespondenceGraphRequest();
        List<CompositeRequest> compositeRequestList=new ArrayList<>();
        correspondenceGraphRequest.setCompositeRequest(compositeRequestList);
        correspondenceGraphRequest.setAllOrNone(false);
        correspondenceRecordMock.setCorrespondenceStatus("s");
        List<CorrespondenceGraphRequest> correspondenceGraphRequestList=new ArrayList<>();
        graphsMock.setCorrespondenceGraphRequest(correspondenceGraphRequestList);
        combinedCorrespondenceModelMock.setIntegrationCorrespondenceManagement(null);
        combinedCorrespondenceModelMock.setOdsCorrespondenceManagement(null);

        assertNotNull(correspondenceGraphRequest.getCompositeRequest());
        assertNotNull(correspondenceGraphRequest.getAllOrNone());
        assertNotNull(correspondenceGraphRequest.equals(correspondenceGraphRequest));
        assertNotNull(correspondenceGraphRequest.hashCode());
        assertNull(correspondenceRecordMock.getCorrespondenceStatus());
        assertNotNull(graphsMock.getCorrespondenceGraphRequest());
        assertNull(combinedCorrespondenceModelMock.getOdsCorrespondenceManagement());
        assertNull(combinedCorrespondenceModelMock.getIntegrationCorrespondenceManagement());


    }


}
