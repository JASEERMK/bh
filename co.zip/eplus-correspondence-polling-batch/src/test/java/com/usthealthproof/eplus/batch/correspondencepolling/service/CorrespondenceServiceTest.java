package com.usthealthproof.eplus.batch.correspondencepolling.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.GraphResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import com.usthealthproof.eplus.batch.correspondencepolling.model.CombinedCorrespondenceModel;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceGraphRequest;
import com.usthealthproof.eplus.batch.correspondencepolling.repository.CorrespondenceManagementRepository;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CorrespondenceServiceTest {
    @Mock
    CorrespondenceGraphRequest graphRequest;
    @Mock
    StepExecution stepExecution;
    @Mock
    JobExecution jobExecution;
    @Mock
    private AuditService auditService;
    @Mock
    private CorrespondenceManagementRepository correspondenceManagementRepository;
    @InjectMocks
    private CorrespondenceService correspondenceService;
    @Mock
    private JdbcTemplate jdbcTemplate;
    @Mock
    private RestCallService<GraphResponse> restCallService;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;
    @Captor
    private ArgumentCaptor<String> statusCapture;
    @Captor
    private ArgumentCaptor<String> dateCapture;
    @Captor
    private ArgumentCaptor<String> idCapture;
    @Mock
    private CompositeResponse response;

    @Mock
    private ArrayNode arrayNode;

    @Mock
    private JsonNode jsonNode;

    @BeforeEach
    public void setUp() {
        TransactionSynchronizationManager.initSynchronization();
        MockitoAnnotations.initMocks(this);
        correspondenceService = new CorrespondenceService(correspondenceManagementRepository, auditService, jdbcTemplate, restCallService,auditErrorMessageUtil);
    }

    @AfterEach
    public void setDown() {
        TransactionSynchronizationManager.clear();
    }

    /**
     * Method under test: {@link CorrespondenceService#addCorrespondenceService(CorrespondenceGraphRequest, StepExecution, List)} (graphRequest, StepExecution, List)}
     */
    void initialise() {
        ReflectionTestUtils.setField(correspondenceService, "auditRequest", false);
        ReflectionTestUtils.setField(correspondenceService, "correspondenceLoadURL", "www.testc.com/");
        when(stepExecution.getJobExecution()).thenReturn(jobExecution);
        when(jobExecution.getJobId()).thenReturn(12345l);
    }

    @Test
    public void testAddCorrespondenceService() {
        log.info("inside testAddCorrespondenceService");
        initialise();
        GraphResponse graphResponse = new GraphResponse();
        List<CompositeResponse> graphs=new ArrayList<>();
        graphs.add(setDummyValuesCompositeResponse("success"));
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(200);
        compositeResponse.setReferenceId("567");
        graphs.add(compositeResponse);
        graphResponse.setCompositeResponse(graphs);
        when(restCallService.callPostRequest(anyString(), eq(GraphResponse.class), eq(graphRequest), eq(stepExecution))).thenReturn(graphResponse);
        List<CombinedCorrespondenceModel> splitListModel = setDummyValues();

        //executing addCorrespondenceService()
        correspondenceService.addCorrespondenceService(graphRequest, stepExecution, splitListModel);
        verify(correspondenceManagementRepository).updateCorrespondenceStatus(statusCapture.capture(), dateCapture.capture(), idCapture.capture());
        //checking status
        assertEquals("S", statusCapture.getValue().toUpperCase());
        //checking corresponcence id
        assertEquals("345", idCapture.getValue().toUpperCase());
    }
    @Test
    public void testAddCorrespondenceServiceWithErrorAndSuccess() {
        log.info("inside testAddCorrespondenceService");
        initialise();
        GraphResponse graphResponse = new GraphResponse();
        List<CompositeResponse> graphs=new ArrayList<>();
        graphs.add(setDummyValuesCompositeResponse("success"));
        graphs.add(setDummyValuesCompositeResponse("error"));
        when(restCallService.callPostRequest(anyString(), eq(GraphResponse.class), eq(graphRequest), eq(stepExecution))).thenReturn(graphResponse);
        List<CombinedCorrespondenceModel> splitListModel = setDummyValues();
        //executing addCorrespondenceService()
        correspondenceService.addCorrespondenceService(graphRequest, stepExecution, splitListModel);
    }


    @Test
    public void testAddCorrespondenceServiceWithError() {
        log.info("inside testAddCorrespondenceServiceWithError");
        initialise();
        ReflectionTestUtils.setField(correspondenceService, "auditRequest", true);
        GraphResponse graphResponse = new GraphResponse();
        List<CompositeResponse> graphs=new ArrayList<>();
        // Graph graph1=new Graph();
        //graph1.setIsSuccessful(true);
        //graph1.setGraphId("123");
        GraphResponse graphResponse1=new GraphResponse();
        graphResponse1.setCompositeResponse(setDummyValues("success"));
        //graph1.setGraphResponse(graphResponse1);
        //graphs.add(graph1);
        graphResponse.setCompositeResponse(graphs);
        when(restCallService.callPostRequest(anyString(), eq(GraphResponse.class), eq(graphRequest), eq(stepExecution))).thenReturn(graphResponse);
        List<CombinedCorrespondenceModel> splitListModel = setDummyValues();

        //executing addCorrespondenceService()
        correspondenceService.addCorrespondenceService(graphRequest, stepExecution, splitListModel);

        //verify it is executed as an error
        //verify(auditService).auditSFDataLoadWriteError(any(), any(), any());
    }

    @Test
    public void testAddCorrespondenceServiceEmptyTest() {
        log.info("inside testAddCorrespondenceServiceEmptyTest");
        initialise();
        GraphResponse graphResponse = new GraphResponse();
        when(restCallService.callPostRequest(anyString(), eq(GraphResponse.class), eq(graphRequest), eq(stepExecution))).thenReturn(graphResponse);
        List<CombinedCorrespondenceModel> splitListModel = new ArrayList<>();

        //executing addCorrespondenceService()
        correspondenceService.addCorrespondenceService(graphRequest, stepExecution, splitListModel);

        //verify not calling repository
        verifyNoMoreInteractions(correspondenceManagementRepository);

    }


    @Test
    public void testUpdateSFDataLoadSuccessAndErrorCountAudit() {
        log.info("inside testUpdateSFDataLoadSuccessAndErrorCountAudit");
        initialise();
        //assigning values
        ReflectionTestUtils.setField(correspondenceService, "errorCounter", new AtomicInteger(2));
        ReflectionTestUtils.setField(correspondenceService, "successCounter", new AtomicInteger(4));
        //executing updateSFDataLoadSuccessAndErrorCountAudit()
        correspondenceService.updateSFDataLoadSuccessAndErrorCountAudit(stepExecution);
        //verifying auditExecuteQueryCountStatus executed 2 times
        verify(auditService, times(2)).auditExecuteQueryCountStatus(anyString(),anyLong(),anyLong(),anyString(),anyString());

        //reseting
        correspondenceService.resetCounter();

    }

    @Test
    public void testGetOdsCorrespondenceList() throws DataAccessException {
        log.info("inside testAddCorrespondenceService");
        List<CorrespondenceManagement> actualOdsCorrespondenceList = correspondenceService.getOdsCorrespondenceList();
        assertTrue(actualOdsCorrespondenceList.isEmpty());

        //verify it is executed
        verify(jdbcTemplate).query(Mockito.<String>any(), Mockito.<RowMapper<CorrespondenceManagement>>any());
    }

    private static List<CompositeResponse> setDummyValues(String status) {
        List<CompositeResponse> correspondenceResult = new ArrayList<>();
        CompositeResponse correspondenceManagementSplit = new CompositeResponse();
        correspondenceManagementSplit.setHttpStatusCode(200);
        if (status.equals("error")) {
            correspondenceManagementSplit.setHttpStatusCode(400);
            ArrayNode arrayNode = JsonNodeFactory.instance.arrayNode();
            ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
            objectNode.put("message", "This is an Error message");
            arrayNode.add(objectNode);
            correspondenceManagementSplit.setBody(arrayNode);
        }
        correspondenceManagementSplit.setReferenceId("345");
        correspondenceResult.add(correspondenceManagementSplit);
        return correspondenceResult;
    }

    private static CompositeResponse setDummyValuesCompositeResponse(String status) {
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(200);
        if (status.equals("error")) {
            compositeResponse.setHttpStatusCode(400);
            ArrayNode arrayNode = JsonNodeFactory.instance.arrayNode();
            ObjectNode objectNode = JsonNodeFactory.instance.objectNode();
            objectNode.put("message", "This is an Error message");
            arrayNode.add(objectNode);
            compositeResponse.setBody(arrayNode);
        }
        compositeResponse.setReferenceId("345");
        return compositeResponse;
    }

    private static List<CombinedCorrespondenceModel> setDummyValues() {
        List<CombinedCorrespondenceModel> correspondenceResult = new ArrayList<>();
        CombinedCorrespondenceModel correspondenceManagementSplit = new CombinedCorrespondenceModel();
        CorrespondenceManagement correspondence1 = new CorrespondenceManagement();
        correspondence1.setCorrespondenceId("345");
        correspondence1.setCreatedDate("2022-01-01");
        correspondence1.setUpdatedDate("2022-01-02");
        correspondence1.setStatus("g");
        correspondenceManagementSplit.setIntegrationCorrespondenceManagement(correspondence1);
        CorrespondenceManagement correspondence2 = new CorrespondenceManagement();
        correspondence2.setCorrespondenceId("345");
        correspondence2.setCreatedDate("2022-01-01");
        correspondence2.setUpdatedDate("2022-05-02");
        correspondence2.setStatus("s");
        correspondenceManagementSplit.setOdsCorrespondenceManagement(correspondence2);
        correspondenceResult.add(correspondenceManagementSplit);
        return correspondenceResult;
    }

    @Test
    public void testAddCorrespondenceServiceWithErrorScenario() {
        log.info("inside testAddCorrespondenceServiceScenario()");
        initialise();
        ReflectionTestUtils.setField(correspondenceService, "auditRequest", true);
        GraphResponse graphResponse = new GraphResponse();
        List<CompositeResponse> graphs=new ArrayList<>();
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(200);
        compositeResponse.setReferenceId("567");
        graphs.add(compositeResponse);
        graphResponse.setCompositeResponse(graphs);
        when(restCallService.callPostRequest(anyString(), eq(GraphResponse.class), eq(graphRequest), eq(stepExecution))).thenReturn(graphResponse);
        List<CombinedCorrespondenceModel> splitListModel = setDummyValues();
        correspondenceService.addCorrespondenceService(graphRequest, stepExecution, splitListModel);
    }

    @Test
    void testCheckResponse() throws Exception {
        log.info("inside testCheckResponse()");
        GraphResponse response = mock(GraphResponse.class);
        List<Map<String, String>> errorList = Collections.emptyList();
        Method method = CorrespondenceService.class.getDeclaredMethod("checkResponse", GraphResponse.class, List.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(correspondenceService, response, errorList);
        assertTrue(result, "The result should be true when the error list is empty");
    }

    @Test
    public void testAuditCorrespondenceDataLoadStatus() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        log.info("inside testAuditCorrespondenceDataLoadStatus()");
        GraphResponse graphResponse = new GraphResponse();
        List<Map<String, String>> errorList = new ArrayList<>();
        List<CombinedCorrespondenceModel> splitListModel = new ArrayList<>();
        Map<String,String> map = new HashMap<>();
        map.put("referenceId","1234");
        errorList.add(map);
        Method method = CorrespondenceService.class.getDeclaredMethod("auditCorrespondenceDataLoadStatus", List.class, List.class, String.class);
        method.setAccessible(true);
        method.invoke(correspondenceService,splitListModel,errorList,"12234");
    }

    @Test
    public void testSetCorrespondenceDataLoadErrorStatus() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        log.info("inside testSetCorrespondenceDataLoadErrorStatus()");
        GraphResponse graphResponse = new GraphResponse();
        List<Map<String, String>> errorList = new ArrayList<>();
        List<CompositeResponse> graphs = new ArrayList<>();
        graphs.add(setDummyValuesCompositeResponse("success"));
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(404);
        graphs.add(compositeResponse);
        graphResponse.setCompositeResponse(graphs);
        Method method = CorrespondenceService.class.getDeclaredMethod("setCorrespondenceDataLoadErrorStatus", GraphResponse.class, List.class);
        method.setAccessible(true);
        method.invoke(correspondenceService,graphResponse,errorList);
    }

    @Test
    public void testGetErrorMessage() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        log.info("inside testGetErrorMessage()");
        GraphResponse graphResponse = new GraphResponse();
        List<Map<String, String>> errorList = new ArrayList<>();
        List<CompositeResponse> graphs = new ArrayList<>();
        graphs.add(setDummyValuesCompositeResponse("success"));
        CompositeResponse compositeResponse = new CompositeResponse();
        compositeResponse.setHttpStatusCode(404);
        graphs.add(compositeResponse);
        graphResponse.setCompositeResponse(graphs);
        Method method = CorrespondenceService.class.getDeclaredMethod("getErrorMessage", CompositeResponse.class);
        method.setAccessible(true);
        method.invoke(correspondenceService,compositeResponse);
    }

    @Test
    void testGetErrorMessageWithValidMessage() throws Exception {
        log.info("inside testGetErrorMessageWithValidMessage()");
        Method method = CorrespondenceService.class.getDeclaredMethod("getErrorMessage", CompositeResponse.class);
        method.setAccessible(true);

        when(response.getBody()).thenReturn(arrayNode);
        when(arrayNode.isEmpty()).thenReturn(false);
        when(arrayNode.get(0)).thenReturn(jsonNode);
        when(jsonNode.get(anyString())).thenReturn(jsonNode);
        when(jsonNode.asText()).thenReturn("Error occurred");

        String result = (String) method.invoke(correspondenceService, response);

        assertEquals("Error occurred", result);
    }

    @Test
    void testGetErrorMessageWthNoMessage() throws Exception {
        log.info("inside testGetErrorMessageWthNoMessage()");
        Method method = CorrespondenceService.class.getDeclaredMethod("getErrorMessage", CompositeResponse.class);
        method.setAccessible(true);

        when(response.getBody()).thenReturn(arrayNode);
        when(arrayNode.isEmpty()).thenReturn(true);

        String result = (String) method.invoke(correspondenceService, response);

        assertEquals("", result);
    }


    @Test
    void testGetErrorMessageWithNullMessageField() throws Exception {
        log.info("inside testGetErrorMessageWithNullMessageField()");
        Method method = CorrespondenceService.class.getDeclaredMethod("getErrorMessage", CompositeResponse.class);
        method.setAccessible(true);

        when(response.getBody()).thenReturn(arrayNode);
        when(arrayNode.isEmpty()).thenReturn(false);
        when(arrayNode.get(0)).thenReturn(jsonNode);
        when(jsonNode.get(anyString())).thenReturn(jsonNode);

        String result = (String) method.invoke(correspondenceService, response);

        assertNull(result);
    }

}