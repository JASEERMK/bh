package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CorrespondenceConstantsTest {

    @Test
    void constantTest() {
        assertEquals("yyyy-MM-dd HH:mm:ss", CorrespondenceConstants.CORRESPONDENCE_SF_DATE_FORMAT);
    }
}
