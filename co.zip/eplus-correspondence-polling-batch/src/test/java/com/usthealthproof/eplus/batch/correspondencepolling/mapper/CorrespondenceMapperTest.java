package com.usthealthproof.eplus.batch.correspondencepolling.mapper;

import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Slf4j
class CorrespondenceMapperTest {

    @InjectMocks
    CorrespondenceMapper correspondenceMapper;
    @Mock
    ResultSet rs;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void correspondenceMapperTest() throws SQLException {
        log.info("inside correspondenceMapperTest");
        // Mock the result set values
        when(rs.getString("CORRESPONDENCE_ID")).thenReturn("12345");
        when(rs.getString("STATUS")).thenReturn("ACTIVE");
        // Call the mapRow() method with the mocked result set
        CorrespondenceManagement result = correspondenceMapper.mapRow(rs, 1);
        // Perform assertions on the mapped result
        assertEquals("12345", result.getCorrespondenceId());
        assertEquals("ACTIVE", result.getStatus());

    }

}