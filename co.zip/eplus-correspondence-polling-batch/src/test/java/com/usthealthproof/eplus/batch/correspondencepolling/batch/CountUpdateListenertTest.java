package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepExecution;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class CountUpdateListenertTest {
    @InjectMocks
    CountUpdateListener countUpdateListenerMock;
    @Mock
    StepExecution stepExecutionMock;
    @Mock
    CorrespondenceService correspondenceServiceMock;
    @BeforeEach
    public void setUp() {
        countUpdateListenerMock=new CountUpdateListener(correspondenceServiceMock);
    }
    @Test
    public void testCountUpdate() {
        countUpdateListenerMock.beforeStep(stepExecutionMock);
        countUpdateListenerMock.afterStep(stepExecutionMock);

    }
}
