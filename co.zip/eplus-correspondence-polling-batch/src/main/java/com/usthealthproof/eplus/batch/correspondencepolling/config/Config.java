package com.usthealthproof.eplus.batch.correspondencepolling.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;

import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.THREAD_PREFIX;

/**
 * @author 210409
 */
@Configuration
@EnableAsync
public class Config {

    @Value("${batch.timeout}")
    private Integer connectionTimeout;

    @Bean(name = "asyncExecutor")
    public TaskExecutor asyncExecutor(@Value("${task.executor.thread-pool.size}") String poolSize,
                                      @Value("${batch.interface-id}") String interfaceId) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(Integer.parseInt(poolSize));
        executor.setMaxPoolSize(Integer.MAX_VALUE);
        executor.setQueueCapacity(Integer.MAX_VALUE);
        executor.setThreadNamePrefix( interfaceId + THREAD_PREFIX);
        executor.initialize();
        return executor;
    }

    @Bean
    public WebClient webClient() {
        final ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
        return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies).build();
    }

    private HttpClient getHttpClient() {
        ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(1000).maxIdleTime(Duration.ofSeconds(20))
                .maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
                .evictInBackground(Duration.ofSeconds(120)).build();
        return HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS,  connectionTimeout * 1000).doOnConnected(
                conn -> conn.addHandlerLast(new ReadTimeoutHandler(connectionTimeout)).addHandlerLast(new WriteTimeoutHandler(connectionTimeout)));
    }
}
