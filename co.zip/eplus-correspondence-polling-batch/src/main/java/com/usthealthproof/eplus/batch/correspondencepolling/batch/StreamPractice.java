package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import java.util.*;
import java.util.stream.Collectors;

public class StreamPractice {
    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(10, 20, 30, 40);
        Set<Integer> seen=new HashSet<>();
        Optional<Integer> list= numbers.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst();
        System.out.println("even numbers: " + list);
    }
    }
