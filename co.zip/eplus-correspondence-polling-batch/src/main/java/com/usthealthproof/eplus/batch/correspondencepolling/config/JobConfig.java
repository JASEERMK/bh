package com.usthealthproof.eplus.batch.correspondencepolling.config;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.CollectionUtils;

import java.util.List;

import static com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants.CORRESPONDENCE_BATCH_END_STEP;
import static com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants.CORRESPONDENCE_BATCH_START_STEP;
import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;

@Configuration
@Slf4j
public class JobConfig {

    @Autowired
    public JobConfig(CorrespondenceService correspondenceService, AuditService auditService,JobAuditListener jobAuditListener,AuditErrorMessageUtil auditErrorMessageUtil) {
        this.correspondenceService = correspondenceService;
        this.auditService = auditService;
        this.jobAuditListener = jobAuditListener;
        this.auditErrorMessageUtil= auditErrorMessageUtil;
    }
    @Autowired
    private JobAuditListener jobAuditListener;

    private final CorrespondenceService correspondenceService;

    private final AuditService auditService;

    private final AuditErrorMessageUtil auditErrorMessageUtil;

    protected static final Step OVERRIDDEN_STEP_BY_EXPRESSION = null;

    @Bean
    public Job profileUpdateJob(@Qualifier("callLoginServiceStep") Step callLoginServiceStep,
                                @Qualifier("processCorrespondenceData") Step processCorrespondenceData,
                                JobRepository jobRepository) {
        Job job = null;
        try {
            job = new JobBuilder("CorrespondenceBatchJob", jobRepository)
                    .incrementer(new RunIdIncrementer())
                    .listener(getJobListenerCount())
                    .listener(jobAuditListener)
                    .start(callLoginServiceStep)
                    .next(processCorrespondenceData)
                    .build();
        } catch (Exception e) {
            log.error("Exception while running the job ", e);
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditException(" ",e, Constant.PROCESS_JOB);
            if(!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }        }
        return job;
    }

    public JobExecutionListener getJobListenerCount() {
        return new JobExecutionListener() {
            @Override
            public void beforeJob(JobExecution jobExecution) {
                correspondenceService.resetCounter();
                log.info("Correspondence Batch Job Started");
                String jobId= String.valueOf(jobExecution.getJobId());
                auditService.auditStepStatus(jobId, CORRESPONDENCE_BATCH_START_STEP,PROCESS_STATUS_SUCCESS_VALUE,null,null);
            }

            @Override
            public void afterJob(JobExecution jobExecution) {
                correspondenceService.resetCounter();
                log.info("Correspondence Batch Job Ended");
                String jobId= String.valueOf(jobExecution.getJobId());
                auditService.auditStepStatus(jobId,CORRESPONDENCE_BATCH_END_STEP,PROCESS_STATUS_SUCCESS_VALUE,null,null);

            }
        };
    }
    @Scheduled(cron = "${batch.schedule}")
    public void launchJob() throws Exception {
        JobParameters param = new JobParametersBuilder().addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        taskExecutorJobLauncher(null)
                .run(profileUpdateJob(OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        null), param);
    }

    @Bean
    public TaskExecutorJobLauncher taskExecutorJobLauncher(JobRepository jobRepository) {
        TaskExecutorJobLauncher launcher = new TaskExecutorJobLauncher();
        launcher.setJobRepository(jobRepository);
        return launcher;
    }


}
