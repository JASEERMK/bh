package com.usthealthproof.eplus.batch.correspondencepolling.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.commons.batch.common.model.request.Body;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CorrespondenceRecord extends Body {

	@JsonProperty("UST_EPLUS__Correspondence_Status__c")
	private String correspondenceStatus;

}
