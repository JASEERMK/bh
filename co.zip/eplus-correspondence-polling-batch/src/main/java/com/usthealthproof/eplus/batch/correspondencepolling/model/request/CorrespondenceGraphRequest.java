package com.usthealthproof.eplus.batch.correspondencepolling.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import lombok.Data;

import java.util.List;

@Data
public class CorrespondenceGraphRequest {

    private Boolean allOrNone = false;

    @JsonProperty("compositeRequest")
    private List<CompositeRequest> compositeRequest;

}
