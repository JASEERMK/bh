package com.usthealthproof.eplus.batch.correspondencepolling.repository;

import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CorrespondenceManagementRepository extends JpaRepository<CorrespondenceManagement, Integer> {

    @Query(value = "SELECT CORRESPONDENCE_ID ,STATUS,UPDATED_DATE,CREATED_DATE FROM EPLUS_CORRESPONDENCE_MGMT WHERE  STATUS IN('t','g') ORDER BY CORRESPONDENCE_ID", nativeQuery = true)
    List<CorrespondenceManagement> getIntegrationCorrespondenceList();

    @Modifying
    @Query(value = "UPDATE EPLUS_CORRESPONDENCE_MGMT SET STATUS=:status ,UPDATED_DATE=:updateDate WHERE CORRESPONDENCE_ID=:correspondenceId", nativeQuery = true)
    void updateCorrespondenceStatus(@Param("status") String status,
                                    @Param("updateDate") String updateDate,
                                    @Param("correspondenceId") String correspondenceId);
    String FIND_DISTINCT_MEMBERS= "SELECT COUNT(DISTINCT CORRESPONDENCE_ID) FROM EPLUS_CORRESPONDENCE_MGMT";
    @Query(value = FIND_DISTINCT_MEMBERS, nativeQuery = true)
    long distinctCount();
}
