package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchDataException;
import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.batch.correspondencepolling.model.CombinedCorrespondenceModel;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceGraphRequest;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceRecord;
import com.usthealthproof.eplus.batch.correspondencepolling.repository.CorrespondenceManagementRepository;
import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.CollectionUtils;

import java.util.*;

import static com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants.CORRESPONDENCE_NO_DATA_FOUND;
import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_ERROR_VALUE;
import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class CorrespondenceProcessingSteps {

    @Autowired
    public CorrespondenceProcessingSteps(AuditService auditService, CorrespondenceManagementRepository repository,
                                         LoginService loginService, TaskletExceptionHandler taskletExceptionHandler,
                                         ExceptionListener exceptionListener, CorrespondenceService correspondenceService, AuditErrorMessageUtil auditErrorMessageUtil) {
        this.auditService = auditService;
        this.repository = repository;
        this.loginService = loginService;
        this.taskletExceptionHandler = taskletExceptionHandler;
        this.exceptionListener = exceptionListener;
        this.correspondenceService = correspondenceService;
        this.auditErrorMessageUtil = auditErrorMessageUtil;
    }

    private final AuditService auditService;

    private final CorrespondenceManagementRepository repository;

    private final LoginService loginService;

    private final TaskletExceptionHandler taskletExceptionHandler;

    private final ExceptionListener exceptionListener;

    private final CorrespondenceService correspondenceService;

    private final AuditErrorMessageUtil auditErrorMessageUtil;

    private static final String GENERATED = "Generated";

    private static final String SENT = "Sent";

    private static final String CANCELLED = "Cancelled";

    @Value("${correspondence.record.service.url}")
    private String correspondenceRecordServiceUrl;

    /**
     * @return Step for calling login service for getting token
     */
    @Bean
    @Qualifier("callLoginServiceStep")
	public Step callLoginServiceStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {

        log.info("Inside callLoginServiceStep() in CorrespondenceProcessingSteps class");
        return new StepBuilder(Constant.PROCESS_STEP_SF_LOGIN, jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    log.info("Step : " + Constant.PROCESS_STEP_SF_LOGIN);
                    log.info("Received time zone id{}, display name {} ", TimeZone.getDefault().toZoneId(), TimeZone.getDefault().getDisplayName());
                    log.info("Current time {}", new Date());
                    loginService.callLoginService(chunkContext.getStepContext().getStepExecution());
                    return RepeatStatus.FINISHED;
                }, transactionManager).listener(exceptionListener).exceptionHandler(taskletExceptionHandler).build();
    }

    /**
     * @return Step for reading current runtime
     */
    @Bean
	@Qualifier("processCorrespondenceData")
    public Step processCorrespondenceData(CountUpdateListener countUpdateListener,JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        log.info("Inside processCorrespondenceData() in CorrespondenceProcessingSteps class");
        return new StepBuilder(Constant.PROCESS_STEP_SF_DATA_LOAD, jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    log.info("Step : ProcessCorrespondenceDataStep");
                    String stepName = chunkContext.getStepContext().getStepName();
                    String jobId=getJobId(chunkContext.getStepContext().getStepExecution());
                    List<CorrespondenceManagement> correspondenceIntegrationResult = getCorrespondenceIntegrationResult(stepName, jobId);
                    List<CorrespondenceManagement> correspondenceOdsResult = getCorrespondenceOdsResult(stepName, jobId);
                    if(CollectionUtils.isEmpty(correspondenceIntegrationResult) || CollectionUtils.isEmpty(correspondenceOdsResult)) {
                         auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SF_DATA_LOAD,PROCESS_STATUS_SUCCESS_VALUE,CORRESPONDENCE_NO_DATA_FOUND,null);
                        return RepeatStatus.FINISHED;
                    }
                    List<CombinedCorrespondenceModel> combinedCorrespondenceModels = new ArrayList<>();
                    for (CorrespondenceManagement correspondenceIntegrationDetails : correspondenceIntegrationResult) {
                        for (CorrespondenceManagement correspondenceOdsDetails : correspondenceOdsResult) {
                            if (String.valueOf(correspondenceIntegrationDetails.getCorrespondenceId())
                                    .equals(String.valueOf(correspondenceOdsDetails.getCorrespondenceId()))
                                    && !(correspondenceOdsDetails.getStatus()).equals(correspondenceIntegrationDetails.getStatus())) {
                                CombinedCorrespondenceModel combinedCorrespondenceModel = new CombinedCorrespondenceModel();
                                combinedCorrespondenceModel.setOdsCorrespondenceManagement(correspondenceOdsDetails);
                                combinedCorrespondenceModel.setIntegrationCorrespondenceManagement(correspondenceIntegrationDetails);
                                combinedCorrespondenceModels.add(combinedCorrespondenceModel);
                                break;
                            }
                        }
                    }

                    log.info("List to be updated {} ", combinedCorrespondenceModels.size());
                    auditService.auditExecuteQueryCountStatus(jobId,combinedCorrespondenceModels.size(), 0,PROCESS_STATUS_SUCCESS_VALUE, CorrespondenceConstants.CORRESPONDENCECOUNT);
                    List<List<CombinedCorrespondenceModel>> splitList = getSplitList(combinedCorrespondenceModels);

                    splitList.forEach(splitListModel -> {
                        log.debug("Split List {}", splitListModel.size());
                        CorrespondenceGraphRequest request = createCorrespondenceRequest(splitListModel, chunkContext.getStepContext().getStepExecution());
                        correspondenceService.addCorrespondenceService(request, chunkContext.getStepContext().getStepExecution(), splitListModel);
                    });
                    return RepeatStatus.FINISHED;
                }, transactionManager)
                .listener(exceptionListener)
                .listener(countUpdateListener)
                .exceptionHandler(taskletExceptionHandler)
                .build();
    }

    private List<List<CombinedCorrespondenceModel>> getSplitList(List<CombinedCorrespondenceModel> combinedCorrespondenceModels) {
        return ListUtils.partition(combinedCorrespondenceModels, 25);
    }

    private List<CorrespondenceManagement> getCorrespondenceIntegrationResult(String stepName, String jobId) {
        List<CorrespondenceManagement> correspondenceIntegrationResult = repository.getIntegrationCorrespondenceList();
        if (CollectionUtils.isEmpty(correspondenceIntegrationResult)) {
            log.info("No rows available integration Table");
        }
        log.info("Integration DB count {} ", correspondenceIntegrationResult.size());
        return correspondenceIntegrationResult;
    }

    private List<CorrespondenceManagement> getCorrespondenceOdsResult(String stepName, String jobId) {
        List<CorrespondenceManagement> correspondenceOdsResult = correspondenceService.getOdsCorrespondenceList();
        if (CollectionUtils.isEmpty(correspondenceOdsResult)) {
            log.info("No rows available in Ods table");
        }
        log.info("Ods count {} ", correspondenceOdsResult.size());
        return correspondenceOdsResult;
    }

    private CorrespondenceGraphRequest createCorrespondenceRequest(List<CombinedCorrespondenceModel> combinedCorrespondenceModels, StepExecution stepExecution) {
        List<CompositeRequest> compositeRequestList = new ArrayList<>();
        String externalId = null;
        String jobId = String.valueOf(stepExecution.getJobExecution().getJobId());
        for (CombinedCorrespondenceModel combinedCorrespondenceModel:combinedCorrespondenceModels) {
            CompositeRequest request = new CompositeRequest();
            externalId = combinedCorrespondenceModel.getOdsCorrespondenceManagement().getCorrespondenceId();
            request.setReferenceId(formatRefId(externalId));
            request.setUrl(correspondenceRecordServiceUrl.concat(externalId));
            String processStep = stepExecution.getStepName();
            CorrespondenceRecord correspondenceRecord = getCorrespondenceInfo(combinedCorrespondenceModel.getOdsCorrespondenceManagement().getStatus());
            if(null!=correspondenceRecord.getCorrespondenceStatus()){
                request.setBody(correspondenceRecord);
                compositeRequestList.add(request);
            } else{
                log.error("Invalid correspondence status for the referenceId {}",externalId);
                auditService.auditStepStatus(jobId, processStep, PROCESS_STATUS_ERROR_VALUE, " ", externalId );
            }
        }
        CorrespondenceGraphRequest correspondenceGraphRequest = new CorrespondenceGraphRequest();
        correspondenceGraphRequest.setCompositeRequest(compositeRequestList);
        return correspondenceGraphRequest;
    }

    /**
     * Correspondence records - getting status for update in ODS
     *
     */
    private CorrespondenceRecord getCorrespondenceInfo(String currentStatusCode) {
        CorrespondenceRecord correspondenceRecord = new CorrespondenceRecord();
        switch (currentStatusCode) {
            case "g" -> correspondenceRecord.setCorrespondenceStatus(GENERATED);
            case "s" -> correspondenceRecord.setCorrespondenceStatus(SENT);
            case "c" -> correspondenceRecord.setCorrespondenceStatus(CANCELLED);
            default -> {return correspondenceRecord;}
        }
        return correspondenceRecord;
    }
    private String formatRefId(String referenceId) {
        return CommonUtils.removeSpecialCharacter(referenceId.replace("-", "_"));
    }
    private  String getJobId(StepExecution stepExecution){
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        return jobId;
    }

}
