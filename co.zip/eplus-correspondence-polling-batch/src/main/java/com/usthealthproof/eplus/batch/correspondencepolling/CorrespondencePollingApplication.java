package com.usthealthproof.eplus.batch.correspondencepolling;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.TimeZone;

/**
 * @author 210409
 */
@EnableScheduling
@SpringBootApplication(scanBasePackages = {"com.usthealthproof.eplus.batch.correspondencepolling","com.usthealthproof.eplus.commons.batch.common"})
@EntityScan(basePackages = {"com.usthealthproof.eplus.batch.correspondencepolling.entity","com.usthealthproof.eplus.commons.batch.common.db.entity"})
@EnableJpaRepositories(basePackages = {"com.usthealthproof.eplus.batch.correspondencepolling.repository","com.usthealthproof.eplus.commons.batch.common.db.repository"})
public class CorrespondencePollingApplication {

    @Value("${batch.time-zone}")
    String batchTimezone;

    public static void main(String[] args) {
        SpringApplication.run(CorrespondencePollingApplication.class, args);
    }

    @PostConstruct
    public void setTimeZone() {
        TimeZone.setDefault(TimeZone.getTimeZone(batchTimezone));
    }

}
