package com.usthealthproof.eplus.batch.correspondencepolling.mapper;

import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
@Slf4j
public class CorrespondenceMapper implements RowMapper<CorrespondenceManagement> {


    @Override
    public CorrespondenceManagement mapRow(ResultSet rs, int rowNum) throws SQLException {

        log.debug("Inside mapRow() in CorrespondenceMapper class");
        CorrespondenceManagement entity = new CorrespondenceManagement();
        entity.setCorrespondenceId(rs.getString("CORRESPONDENCE_ID"));
        entity.setStatus(rs.getString("STATUS"));
        return entity;
    }
}
