package com.usthealthproof.eplus.batch.correspondencepolling.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.GraphResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.batch.correspondencepolling.constant.CorrespondenceConstants;
import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import com.usthealthproof.eplus.batch.correspondencepolling.mapper.CorrespondenceMapper;
import com.usthealthproof.eplus.batch.correspondencepolling.model.CombinedCorrespondenceModel;
import com.usthealthproof.eplus.batch.correspondencepolling.model.request.CorrespondenceGraphRequest;
import com.usthealthproof.eplus.batch.correspondencepolling.repository.CorrespondenceManagementRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.*;
import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.*;

@Slf4j
@Service
public class CorrespondenceService {

    @Autowired
    CorrespondenceService(CorrespondenceManagementRepository repository, AuditService auditService,
                          JdbcTemplate jdbcTemplate,
                          RestCallService<GraphResponse> restCallService, AuditErrorMessageUtil auditErrorMessageUtil) {
        this.repository = repository;
        this.auditService = auditService;
        this.jdbcTemplate = jdbcTemplate;
        this.restCallService = restCallService;
        this.auditErrorMessageUtil=auditErrorMessageUtil;
    }

    private final CorrespondenceManagementRepository repository;

    private final AuditService auditService;

    private final JdbcTemplate jdbcTemplate;

    private final RestCallService<GraphResponse> restCallService;

    private AuditErrorMessageUtil auditErrorMessageUtil;

    @Value("${salesforce.url.load-url}")
    private String correspondenceLoadURL;

    @Value("${correspondence.database.ods}")
    private String odsDatabase;

    @Value("${batch.audit.request}")
    private boolean auditRequest;

    /**
     * errorCounter
     */
    private AtomicInteger errorCounter = new AtomicInteger();

    /**
     * dataloadSuccessCounter
     */
    private AtomicInteger successCounter = new AtomicInteger();

    public void addCorrespondenceService(CorrespondenceGraphRequest graphRequest, StepExecution stepExecution,
                                         List<CombinedCorrespondenceModel> splitListModel) {

        log.info("Inside addCorrespondenceService() in CorrespondenceService class");
        if(log.isDebugEnabled()) {
            log.debug("Correspondence Request", CommonUtils.getObjectAsString(graphRequest));
        }
        GraphResponse graphLoadResponse = restCallService.callPostRequest(correspondenceLoadURL,
                GraphResponse.class, graphRequest, stepExecution);
        List<Map<String, String>> errorList = new ArrayList<>();
        String jobId= getJobId(stepExecution);
        if (graphLoadResponse == null || CollectionUtils.isEmpty(graphLoadResponse.getCompositeResponse())) {
            log.error("Service Response body is empty or null");
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put(REFERENCE_ID, "");
            errorMap.put("responseText", "Service Response is empty");
            errorList.add(errorMap);
            auditException(jobId,errorList, stepExecution.getStepName(),graphRequest);
        }
        else if (graphRequest.getCompositeRequest().size() != graphLoadResponse.getCompositeResponse().size() && graphLoadResponse.getCompositeResponse().size() == 1) {
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put(REFERENCE_ID, "");
            errorMap.put("responseText", CommonUtils.getObjectAsString(graphLoadResponse.getCompositeResponse().get(0).getBody()));
            errorList.add(errorMap);
            auditException(jobId,errorList, stepExecution.getStepName(),graphRequest);
        }
        else {
            boolean isSuccess = checkResponse(graphLoadResponse, errorList);
            if (!isSuccess) {
                log.error("Service Failed, Logging error");
                auditException(jobId,errorList, stepExecution.getStepName(),graphRequest);
            }
            auditCorrespondenceDataLoadStatus(splitListModel, errorList, jobId);
        }
        log.debug("addCorrespondenceService response {}", graphLoadResponse);
        log.debug("addCorrespondenceService completed");

    }
    private void auditException(String jobId,List<Map<String, String>> errorList, String stepName,CorrespondenceGraphRequest graphRequest){
        String request=null;
        if (auditRequest) {
            request = CommonUtils.getObjectAsString(graphRequest);
        }
        List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditSFDataLoadWriteError(jobId,errorList, stepName,request);
        if(!CollectionUtils.isEmpty(auditBatchList)) {
            auditService.auditException(auditBatchList);
        }
    }

    private void auditCorrespondenceDataLoadStatus(List<CombinedCorrespondenceModel> splitListModel, List<Map<String, String>> errorList, String jobId) {

        log.info("Inside auditCorrespondenceDataLoadStatus() in CorrespondenceService class");
        List<String> errorIdList = errorList.stream().map(m -> m.get(REFERENCE_ID)).toList();
        splitListModel.forEach(combinedCorrespondenceModel -> {
            String currentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern(CorrespondenceConstants.CORRESPONDENCE_SF_DATE_FORMAT));
            CorrespondenceManagement odsData = combinedCorrespondenceModel.getOdsCorrespondenceManagement();
            log.debug("Data to be updated {} {} {} ", odsData.getStatus(), currentDate, odsData.getCorrespondenceId());
            if (!errorIdList.contains(odsData.getCorrespondenceId())) {
                repository.updateCorrespondenceStatus(odsData.getStatus(), currentDate, odsData.getCorrespondenceId());
            }
        });
    }

    private boolean checkResponse(GraphResponse response, List<Map<String, String>> errorList) {

        log.info("Inside checkResponse in CorrespondenceService class");
        setCorrespondenceDataLoadErrorStatus(response, errorList);
        return CollectionUtils.isEmpty(errorList);
    }

    private void setCorrespondenceDataLoadErrorStatus(GraphResponse graphLoadResponse, List<Map<String, String>> errorList) {

        log.info("Inside setCorrespondenceDataLoadErrorStatus() in CorrespondenceService class");
        graphLoadResponse.getCompositeResponse().stream().forEach(compositeResponse -> {
            String correlationId = compositeResponse.getReferenceId();
            if (compositeResponse.getHttpStatusCode().toString().startsWith("2")) {
                log.debug("Service call is success for:{} ", compositeResponse.getReferenceId());
                successCounter.incrementAndGet();
            } else {
                errorCounter.incrementAndGet();
                String errorMessage = getErrorMessage(compositeResponse);
                log.error("Service call is error for:{} ", compositeResponse.getReferenceId());
                Map<String, String> errorMap = new HashMap<>();
                errorMap.put(REFERENCE_ID, compositeResponse.getReferenceId());
                errorMap.put(RESPONSE_TEXT, CommonUtils.getObjectAsString(compositeResponse));
                errorMap.put(CORRELATION_ID, correlationId);
                if (StringUtils.hasLength(errorMessage)) {
                    errorMap.put(MESSAGE, errorMessage);
                }
                errorList.add(errorMap);
            }
        });
    }
    private String getErrorMessage(CompositeResponse response) {
        if (response.getBody() instanceof ArrayNode node && !node.isEmpty()) {
            JsonNode jsonNode = node.get(0).get(MESSAGE);
            if (jsonNode != null) {
                String message = jsonNode.asText();
                log.error("Error for Correspondence: {}, error: {}", response.getReferenceId(), message);
                return message;
            }

        }
        return "";
    }

    public void updateSFDataLoadSuccessAndErrorCountAudit(StepExecution stepExecution) {
        String jobId= getJobId(stepExecution);
        int sCount = successCounter.get();
        int fCount = errorCounter.get();
        if (( sCount > 0 ) || ( fCount > 0 )) {
            auditService.auditExecuteQueryCountStatus(jobId,0,sCount,PROCESS_STATUS_SUCCESS_VALUE,CorrespondenceConstants.CORRESPONDENCE_SUCCESS_COUNT);
            auditService.auditExecuteQueryCountStatus(jobId,0, fCount,PROCESS_STATUS_ERROR_VALUE,CorrespondenceConstants.CORRESPONDENCE_FAILURE_COUNT);
        }
    }

    public void resetCounter() {
        successCounter = new AtomicInteger();
        errorCounter = new AtomicInteger();
    }
    private  String getJobId(StepExecution stepExecution){
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        return jobId;
    }

    @Transactional
    public List<CorrespondenceManagement> getOdsCorrespondenceList() {
        return jdbcTemplate.query("SELECT CORRESPONDENCE_FACT_KEY as CORRESPONDENCE_ID,"
                + "CURRENT_STATUS_CODE as STATUS FROM " + odsDatabase + ".dbo.CORRESPONDENCE "
                + "WHERE CURRENT_STATUS_CODE <>'t' and CORRESPONDENCE_FACT_KEY in "
                + "(Select correspondence_id from EPLUS_CORRESPONDENCE_MGMT   WHERE  STATUS IN('t','g')) "
                + "ORDER BY CORRESPONDENCE_FACT_KEY", new CorrespondenceMapper());

    }

}
