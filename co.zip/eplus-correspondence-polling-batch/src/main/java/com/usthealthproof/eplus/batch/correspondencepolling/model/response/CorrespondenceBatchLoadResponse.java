package com.usthealthproof.eplus.batch.correspondencepolling.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CorrespondenceBatchLoadResponse {

	private List<Graph> graphs;
}
