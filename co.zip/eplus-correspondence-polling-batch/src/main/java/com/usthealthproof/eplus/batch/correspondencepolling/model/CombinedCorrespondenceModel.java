package com.usthealthproof.eplus.batch.correspondencepolling.model;

import com.usthealthproof.eplus.batch.correspondencepolling.entity.CorrespondenceManagement;
import lombok.Data;

@Data
public class CombinedCorrespondenceModel {

    private CorrespondenceManagement odsCorrespondenceManagement;

    private CorrespondenceManagement integrationCorrespondenceManagement;


}

