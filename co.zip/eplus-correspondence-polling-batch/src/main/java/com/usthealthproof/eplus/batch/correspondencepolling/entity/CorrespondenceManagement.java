package com.usthealthproof.eplus.batch.correspondencepolling.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "EPLUS_CORRESPONDENCE_MGMT")
public class CorrespondenceManagement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CORRESPONDENCE_ID")
    private String correspondenceId;

    @Column(name = "CREATED_DATE")
    private String createdDate;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    @Column(name = "STATUS")
    private String status;

}
