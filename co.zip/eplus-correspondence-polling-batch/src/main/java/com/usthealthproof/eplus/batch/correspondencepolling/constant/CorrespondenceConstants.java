package com.usthealthproof.eplus.batch.correspondencepolling.constant;

public class CorrespondenceConstants {

    private CorrespondenceConstants() {}

    public static final String CORRESPONDENCE_SF_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String CORRESPONDENCE_FAILURE_COUNT = "CorrespondenceFailureCount";
    public static final String CORRESPONDENCE_SUCCESS_COUNT = "CorrespondenceSuccessCount";
    public static final String CORRESPONDENCECOUNT = "Correspondenceount";
    public static final String CORRESPONDENCE_BATCH_START_STEP = "CorrespondenceBatchStart";
    public static final String CORRESPONDENCE_BATCH_END_STEP = "CorrespondenceBatchEnd";
    public static final String CORRESPONDENCE_NO_DATA_FOUND = "No changes in correspondence status in the source system";




}
