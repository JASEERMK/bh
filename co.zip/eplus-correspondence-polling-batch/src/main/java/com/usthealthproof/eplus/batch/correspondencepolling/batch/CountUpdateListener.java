package com.usthealthproof.eplus.batch.correspondencepolling.batch;

import com.usthealthproof.eplus.batch.correspondencepolling.service.CorrespondenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author 210409
 *
 */
@Slf4j
@Component
@StepScope
public class CountUpdateListener implements StepExecutionListener {

    @Autowired
    public CountUpdateListener(CorrespondenceService correspondenceService) {
        this.correspondenceService = correspondenceService;
    }

    private final CorrespondenceService correspondenceService;

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        correspondenceService.updateSFDataLoadSuccessAndErrorCountAudit(stepExecution);
        return null;
    }
}
