package com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception;

import org.springframework.http.HttpStatus;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = -2625891751125517298L;

	private HttpStatus status;

	public ResponseValidationException() {
	}

	public ResponseValidationException(String message, HttpStatus status) {
		super(message);
		this.status = status;
	}

	public ResponseValidationException(String message) {
		super(message);
	}

	public HttpStatus getStatus() {
		return status;
	}

}
