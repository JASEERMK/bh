package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
@Schema(description = "Object for holding response from external service")
public class PaginatedResponseModel<T> {

    private PaginationModel page;
    List<T> results;

}
