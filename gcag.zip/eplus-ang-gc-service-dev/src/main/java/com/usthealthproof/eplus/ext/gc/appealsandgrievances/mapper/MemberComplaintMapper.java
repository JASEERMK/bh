package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.sun.jdi.InternalException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.InternalClaims;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsDetailsResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class MemberComplaintMapper {
    public List<AppealsOrGrievanceSummary> memberSearchResponseMapper(List<ServiceAppealsSummaryResponse> serviceAppealsSearchResponse) throws Exception {
        log.info("Inside memberAppealSearchResponseMapper() in mapper class");

        return serviceAppealsSearchResponse.stream().map(memberAppeal -> {
            AppealsOrGrievanceSummary angsSummary = new AppealsOrGrievanceSummary();

            angsSummary.setComplaintID(memberAppeal.getComplaintID());
            angsSummary.setStatus(memberAppeal.getStatus());
            angsSummary.setPriority(memberAppeal.getComplaintClass());
            angsSummary.setComplaintCategory(memberAppeal.getComplaintCategory());
            angsSummary.setReceivedDate(memberAppeal.getReceivedDateTime());

            return angsSummary;
        }).collect(Collectors.toList());
    }

    public AppealsOrGrievanceDetails memberDetailsResponseMapper(ServiceMemberAppealsDetailsResponse detailsResponse) throws Exception {
        log.info("Inside memberAppealDetailsResponseMapper() in mapper class");
        AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
        appealsOrGrievanceDetails.setComplaintID(detailsResponse.getComplaintID());
        appealsOrGrievanceDetails.setComplaintCategory(detailsResponse.getComplaintCategory());
        appealsOrGrievanceDetails.setComplaintSubCategory(detailsResponse.getComplaintSubCategory());
        appealsOrGrievanceDetails.setPriority(detailsResponse.getComplaintClass());
        appealsOrGrievanceDetails.setReceivedDate(detailsResponse.getCreatedDateTime());
        appealsOrGrievanceDetails.setCreatedDate(detailsResponse.getNotificationDateTime());


        if (appealsOrGrievanceDetails.getReceivedDate() != null) {
            LocalDate currentDate = LocalDate.now();
            String receivedDate = appealsOrGrievanceDetails.getReceivedDate();
            String[] receivedDateSplitted = receivedDate.split("T");
            LocalDate receivedDateConverted = LocalDate.parse(receivedDateSplitted[0]);
            long caseAge = ChronoUnit.DAYS.between(receivedDateConverted, currentDate);
            if (caseAge < 0) {
                log.info("caseAge value is: {} as the receivedDate is greater than currentDate", caseAge);
                throw new InternalException();
            }
            appealsOrGrievanceDetails.setCaseAge(String.valueOf((int) caseAge));
        }
        appealsOrGrievanceDetails.setComplaintStatus(detailsResponse.getStatus());
        appealsOrGrievanceDetails.setLevel(detailsResponse.getLevel());
        appealsOrGrievanceDetails.setContactChannel(detailsResponse.getNotificationMethod());
        appealsOrGrievanceDetails.setRequestor(detailsResponse.getWhoInitiatedComplaint());
        appealsOrGrievanceDetails.setDueDate(detailsResponse.getDueDateTime());
        appealsOrGrievanceDetails.setServiceType(detailsResponse.getLevelOfService());
        appealsOrGrievanceDetails.setResolutionDate(detailsResponse.getResolutionDateTime());
        appealsOrGrievanceDetails.setResolutionCategory(detailsResponse.getResolutionCategory());
        appealsOrGrievanceDetails.setResolutionSubCategory(detailsResponse.getResolutionSubCategory());
        appealsOrGrievanceDetails.setResolutionNotes(detailsResponse.getResolutionNote());
        appealsOrGrievanceDetails.setIncidentDate(detailsResponse.getDateTimeOfIncident());
        appealsOrGrievanceDetails.setResponsibleDepartment(detailsResponse.getResponsibleDepartment());
        appealsOrGrievanceDetails.setStaffName(detailsResponse.getResponsibleStaff());
        if (detailsResponse.getParticipants() != null) {
            appealsOrGrievanceDetails.setContactName(detailsResponse.getParticipants().get(0).getName());
            appealsOrGrievanceDetails.setContactNumber(detailsResponse.getParticipants().get(0).getPhone());
        }
        if (detailsResponse.getInternalClaims() != null) {
            for (InternalClaims result : detailsResponse.getInternalClaims()) {
                appealsOrGrievanceDetails.setClaimId(result.getClaimNumber());
                appealsOrGrievanceDetails.setAuthorizationId(result.getInternalAuthorizationID());
            }
        }
        log.info("appealsOrGrievanceDetails: {} ", appealsOrGrievanceDetails);
        return appealsOrGrievanceDetails;

    }
}
