package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeAltruistaRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

@Component
@Slf4j
public class MemberComplaintIntakeMapper {
    @Value("${gc.config.responsible-staff}")
    private String responsibleStaff;
    @Value("${gc.config.intake-staff}")
    private String intakeStaff;
    @Value("${gc.config.work-queue-referral}")
    private boolean workQueueReferral;
    @Value("${gc.config.work-queue-dept-name}")
    private String workQueueDeptName;

    @Value("${gc.config.intake-department}")
    private String intakeDepartment;

    private static final String SUPPLEMENTAL_INFORMATION_NAME = "External Claim, Tracking, or Case Number";
    private static final String SUPPLEMENTAL_INFORMATION_VALUE = "N/A";

    public IntakeAltruistaRequest setAltruistaRequest(IntakeRequest intakeRequest, String lobBenId) throws Exception {
        IntakeAltruistaRequest intakeAltruistaRequest=new IntakeAltruistaRequest();
        intakeAltruistaRequest.setClientPatientID(intakeRequest.memberId);
        if (intakeRequest.getMemberId() != null && intakeRequest.getIssueDate() != null) {
            intakeAltruistaRequest.setLobBenID(lobBenId);
        }
        intakeAltruistaRequest.setWhoInitiatedComplaint(intakeRequest.getSubmitterType());
        intakeAltruistaRequest.setProviderID(intakeRequest.getSubmitterId());
        intakeAltruistaRequest.setComplaintType(intakeRequest.getComplaintType());
        intakeAltruistaRequest.setComplaintClass(intakeRequest.getComplaintClass());
        intakeAltruistaRequest.setComplaintCategory(intakeRequest.getComplaintCategory());
        if (null != intakeRequest.getAppealsDetail() && null != intakeRequest.getAppealType()) {
            setClaimsAndAuth(intakeAltruistaRequest,intakeRequest.getAppealsDetail(), intakeRequest.getAppealType());
        }
        intakeAltruistaRequest.setDateTimeOfIncident(intakeRequest.getIssueDate());
        intakeAltruistaRequest.setInitialComplaintNote(intakeRequest.getComplaintDescription());
        intakeAltruistaRequest.setIntakeStaff(intakeRequest.getIntakeStaff());
        intakeAltruistaRequest.setResponsibleStaff(intakeRequest.getResponsibleStaff());
        if (null != intakeRequest.getWorkQueue()) {
            setWorkQueue(intakeAltruistaRequest,intakeRequest);
        }
        intakeAltruistaRequest.setNotificationMethod(intakeRequest.getNotificationMethod());
        intakeAltruistaRequest.setIntakeDepartment(intakeDepartment);
        intakeAltruistaRequest.setStatus(AppealsAndGrievanceConstants.OPEN);
        intakeAltruistaRequest.setNotificationDateTime(setNotificationDateTime());
        intakeAltruistaRequest.setResponsibleDepartment(intakeRequest.getResponsibleDepartment());
        intakeAltruistaRequest.setLevelOfService(intakeRequest.getLevelOfService());

        IntakeAltruistaRequest.SupplementalInformation[] supplementalInformation = new IntakeAltruistaRequest.SupplementalInformation[1];
        IntakeAltruistaRequest.SupplementalInformation information = intakeAltruistaRequest.new SupplementalInformation();
        information.setName(SUPPLEMENTAL_INFORMATION_NAME);
        information.setValue(new String[]{SUPPLEMENTAL_INFORMATION_VALUE});
        supplementalInformation[0] = information;
        intakeAltruistaRequest.setIntakeSupplementalInformation(supplementalInformation);
        return intakeAltruistaRequest;
    }

    private String setNotificationDateTime() {
        OffsetDateTime currentDate = OffsetDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String formattedDate = currentDate.format(formatter);
        return formattedDate;
    }

    private void setClaimsAndAuth(IntakeAltruistaRequest intakeAltruistaRequest,IntakeRequest.AppealsDetail appealsDetail, String appealType) {
        String id = appealsDetail.getId();
        if (appealType.equalsIgnoreCase(AppealsAndGrievanceConstants.ANG_CLAIM)) {
            IntakeAltruistaRequest.InternalClaim internalClaim = intakeAltruistaRequest.new InternalClaim();
            internalClaim.setClaimNumber(id);
            intakeAltruistaRequest.setInternalClaims(Arrays.asList(internalClaim));
        } else if (appealType.equalsIgnoreCase(AppealsAndGrievanceConstants.ANG_AUTHERIZATION)) {
            IntakeAltruistaRequest.InternalAuthorization internalAuthorization = intakeAltruistaRequest.new InternalAuthorization();
            internalAuthorization.setAuthorizationID(id);
            internalAuthorization.setIsPrimary("true");
            intakeAltruistaRequest.setInternalAuthorizations(Arrays.asList(internalAuthorization));
        }
    }

    private void setWorkQueue(IntakeAltruistaRequest intakeAltruistaRequest,IntakeRequest intakeRequest) {
        IntakeAltruistaRequest.WorkQueue workQueue = intakeAltruistaRequest.new WorkQueue();
        workQueue.setDepartmentName(workQueueDeptName);
        workQueue.setCareStaffUserName(intakeRequest.getWorkQueue().getCareStaffUserName());
        IntakeAltruistaRequest.WorkQueue[] workQueues = new IntakeAltruistaRequest.WorkQueue[1];
        workQueues[0] = workQueue;
        intakeAltruistaRequest.setWorkQueues(workQueues);
        intakeAltruistaRequest.setIsWorkQueueReferral("true");
    }
}
