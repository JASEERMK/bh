package com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.PaginatedResponseModel;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.*;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
@Slf4j
public class Validator {
    public void validateMemberAppealsAndGrievancesSummary(String memberId, String complaintType) {
        log.info("Inside validateMemberAppealsAndGrievancesSummary() in validator class");

        if (StringUtils.isBlank(memberId)) {
            throw new RequestValidationException(AppealsAndGrievanceConstants.MEMBER_ID_NOT_FOUND);
        }
        if (StringUtils.isBlank(complaintType)) {
            throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND);
        }
    }

    public void validateMemberAppealsAndGrievancesDetails(String complaintId) {
        log.info("Inside validateMemberAppealsAndGrievancesDetails() in validator class");

        if (isBlank(complaintId)) {
            log.info("Invalid request ie. complaintId is empty/null/blank");
            throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_ID_NOT_FOUND);
        }

    }

    public void validateProviderAppealsSummary(String providerId,String providerType,String complaintType) {
        log.info("Inside validateProviderAppealsSummary()");

        if (StringUtils.isBlank(providerId)) {
            throw new RequestValidationException(AppealsAndGrievanceConstants.PROVIDER_ID_NOT_FOUND);
        }
        if (StringUtils.isBlank(complaintType)) {
            throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND);
        }
        if (StringUtils.isBlank(providerType)) {
            throw new RequestValidationException(AppealsAndGrievanceConstants.PROVIDER_TYPE_NOT_FOUND);
        }

    }

    public void validateServiceMemberAppealsResponse(PaginatedResponseModel<ServiceAppealsSummaryResponse> serviceServiceMemberAppeals) {
        log.info("Inside validateServiceMemberAppealsResponse() in validator class ");
        if (null != serviceServiceMemberAppeals || null != serviceServiceMemberAppeals.getPage() || null != serviceServiceMemberAppeals.getPage().getPageCount()) {
            int pageCount = Integer.parseInt(serviceServiceMemberAppeals.getPage().getPageCount());
            if (pageCount > 1) {
                throw new ResponseValidationException(PAGE_LIMIT_EXCEED, HttpStatus.BAD_REQUEST);
            }
        }
        if (null == serviceServiceMemberAppeals || serviceServiceMemberAppeals.getResults() == null || serviceServiceMemberAppeals.getResults().size() == 0) {
            throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND, HttpStatus.NO_CONTENT);
        }
    }

    public void validateServiceMemberAppealsDetailsResponse(ServiceMemberAppealsDetailsResponse serviceMemberAppealsDetailsResponse) {
        log.info("Inside validateServiceMemberAppealsResponse() in validator class ");
        if (serviceMemberAppealsDetailsResponse == null) {
            throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    public void validateIntakeRequest(IntakeRequest intakeRequest) {
        log.info("Inside validateIntakeRequest() in validator class ");

        if(StringUtils.isBlank(intakeRequest.getMemberId())) {
            throw new RequestValidationException(WRONG_MEMBER_ID);
        }

        if(StringUtils.isBlank(intakeRequest.getSubmitterType())) {
            throw new RequestValidationException(WRONG_SUBMITTER_TYPE);
        }

        if(StringUtils.isBlank(intakeRequest.getComplaintType())) {
            throw new RequestValidationException(WRONG_COMPLAINT_TYPE);
        }

        if(StringUtils.isBlank(intakeRequest.getComplaintClass())) {
            throw new RequestValidationException(WRONG_COMPLAINT_CLASS);
        }

        if(StringUtils.isBlank(intakeRequest.getComplaintCategory())) {
            throw new RequestValidationException(WRONG_COMPLAINT_CATEGORY);
        }

        if(StringUtils.isNotBlank(intakeRequest.getAppealType())) {

            if (!StringUtils.containsAny(intakeRequest.getAppealType(),
                    "Authorization", "Claim")) {
                throw new RequestValidationException(WRONG_APPEAL_TYPE);
            }

            if(intakeRequest.getAppealsDetail() == null
                    || StringUtils.isBlank(intakeRequest.getAppealsDetail().getId())) {
                throw new RequestValidationException(WRONG_APPEAL_ID_NOT_FOUND);
            }
            if(StringUtils.isBlank(intakeRequest.getLevelOfService())) {
                throw new RequestValidationException(WRONG_LEVEL_OF_SERVICE);
            }

        }

        if(StringUtils.isBlank(intakeRequest.getIssueDate())) {
            throw new RequestValidationException(WRONG_ISSUE_DATE);
        }

    }

    public void validateIntakeResponse(IntakeResponse intakeResponse) {
        log.info("Inside validateIntakeResponse() in validator class ");
        if (intakeResponse == null) {
            throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND, HttpStatus.NO_CONTENT);
        }
    }

    public void validatememberEligibilityResponse(MemberEligibilityResponse memberEligibilityResponse) {
        log.info("Inside MemberEligibilityResponse() in validator class ");
        if (memberEligibilityResponse == null) {
            throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND, HttpStatus.NO_CONTENT);
        }
    }

    public boolean hasSubmitterDetails(IntakeRequest request) {
        if(request.getSubmitterDetails() == null) {
            return false;
        }
        if(StringUtils.isNotBlank(request.getSubmitterDetails().getFirstName()) ||
        StringUtils.isNotBlank(request.getSubmitterDetails().getLastName())) {
            return true;
        }
        if(request.getSubmitterDetails().getSubmitterAddress() == null) {
            return false;
        }
        IntakeRequest.Address address = request.getSubmitterDetails().getSubmitterAddress();
        if(StringUtils.isAllBlank(address.getAddress(), address.getState(), address.getCity(), address.getPhoneNumber())) {
            return false;
        }
        return true;
    }

    public boolean hasRepresentativeDetails(IntakeRequest request) {
        if(request.getRepresentativeDetails() == null) {
            return false;
        }
        if(StringUtils.isNotBlank(request.getRepresentativeDetails().getFirstName()) ||
                StringUtils.isNotBlank(request.getRepresentativeDetails().getLastName())) {
            return true;
        }
        if(request.getRepresentativeDetails().getRepresentativeAddress() == null) {
            return false;
        }
        IntakeRequest.Address address = request.getRepresentativeDetails().getRepresentativeAddress();
        if(StringUtils.isAllBlank(address.getAddress(), address.getState(), address.getCity(), address.getPhoneNumber())) {
            return false;
        }
        return true;
    }

}
