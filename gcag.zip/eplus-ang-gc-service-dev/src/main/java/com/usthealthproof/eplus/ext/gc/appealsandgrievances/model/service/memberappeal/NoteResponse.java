package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Member Note response received from the external service")
public class NoteResponse {
    private String identifier;
    private String createdDateTime;
    private String createdBy;

}
