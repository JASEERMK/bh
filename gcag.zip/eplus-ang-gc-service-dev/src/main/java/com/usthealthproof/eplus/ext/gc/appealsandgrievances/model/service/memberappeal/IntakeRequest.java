package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Intake Request")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IntakeRequest {
    @JsonProperty(required = true)
    @Schema(description = "Member Id")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Id is not in valid format")
    public String memberId;
//    @Schema(description = "Preffered Language")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Preffered Language is not in valid format")
//    public String prefferedLanguage;
    @Schema(description = "Submitter Type")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Type is not in valid format")
    public String submitterType;
    @Schema(description = "Submitter Details")
    @Valid
    public SubmitterDetails submitterDetails;
//    @Schema(description = "Member Behalf")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Behalf is not in valid format")
//    public String memberBehalf;
    @Schema(description = "Submitter Id")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Id is not in valid format")
    public String submitterId;
    @Schema(description = "Representative Details")
    @Valid
    public RepresentativeDetails representativeDetails;
//    @Schema(description = "Primary PhoneNumber")
//    @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Primary PhoneNumber should be Numeric")
//    public String primaryPhoneNumber;

    @JsonProperty(required = true)
    @Schema(description = "Complaint Type")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Type is not in valid format")
    public String complaintType;

    @JsonProperty(required = true)
    @Schema(description = "Complaint Type")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Class is not in valid format")
    public String complaintClass;

    @Schema(description = "Complaint Category")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Category is not in valid format")
    public String complaintCategory;

    @JsonProperty(required = true)
    @Schema(description = "Appeal Type")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Appeal Type is not in valid format")
    public String appealType;

    @Schema(description = "Appeals Detail")
    @Valid
    public AppealsDetail appealsDetail;
//    @Schema(description = "Grievances Detail")
//    @Valid
//    public GrievancesDetail grievancesDetail;
    @Schema(description = "Issue Date")
    @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Issue Date is not in valid format")
    public String issueDate;
    @Schema(description = "Complaint Description")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Description is not in valid format")
    public String complaintDescription;
    @Schema(description = "Intake Staff")
    @Pattern(regexp = "^[a-zA-Z0-9 .!@#$%^&*()_+|=-]*$", message = "Invalid Request: Intake Staff is not in valid format")
    public String intakeStaff;
    @Schema(description = "Responsible Staff")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Responsible Staff is not in valid format")
    public String responsibleStaff;
    @Schema(description = "WorkQueue")
    @Valid
    public WorkQueue workQueue;

    @JsonProperty(required = true)
    @Schema(description = "Notification Method")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Notification Method is not in valid format")
    public String notificationMethod;

//    @JsonProperty(required = true)
//    @Schema(description = "Priority")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Priority is not in valid format")
//    public String priority;

//    @Schema(description = "Intake Department")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Intake Department is not in valid format")
//    public String intakeDepartment;

    @Schema(description = "Responsible Department")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Responsible Department is not in valid format")
    public String responsibleDepartment;

    @Schema(description = "Level Of Service")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Level Of Service is not in valid format")
    public String levelOfService;


//    @Data
//    public static class GrievancesDetail {
//        @Schema(description = "Complaint Category")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Category is not in valid format")
//        public String complaintCategory;
//        @Schema(description = "Complaint SubCategory")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint SubCategory is not in valid format")
//        public String complaintSubCategory;
//        @Schema(description = "Complaint RelatedTo")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint RelatedTo is not in valid format")
//        public String complaintRelatedTo;
//        @Schema(description = "Complaint Againt Details")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Againt  Details is not in valid format")
//        public String complaintAgaintDetails;
//    }

    @Data
    public static class Address {
        @Schema(description = "Address")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Address is not in valid format")
        public String address;
        @Schema(description = "City")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: City is not in valid format")
        public String city;
        @Schema(description = "State")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: State is not in valid format")
        public String state;
        @Schema(description = "Zip")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Zip is not in valid format")
        public String zip;
        @Schema(description = "Phone Number")
        @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Phone Number should be Numeric")
        public String phoneNumber;
    }

    @Data
    public static class SubmitterDetails {
        @Schema(description = "First Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: First Name is not in valid format")
        public String firstName;
        @Schema(description = "Last Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Last Name is not in valid format")
        public String lastName;
        @Schema(description = "Submitter Address")
        @Valid
        public Address submitterAddress;
        @Schema(description = "Submitter Relationship")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Relationship is not in valid format")
        public String submitterRelationship;
    }

    @Data
    public static class RepresentativeDetails {
        @Schema(description = "First Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: First Name is not in valid format")
        public String firstName;
        @Schema(description = "Last Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Last Name is not in valid format")
        public String lastName;
        @Schema(description = "Representative Address")
        @Valid
        public Address representativeAddress;
    }

    @Data
    public static class AppealsDetail {
        @Schema(description = "Appeal Type")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Appeal Type is not in valid format")
        public String appealType;
        @Schema(description = "Id")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Id is not in valid format")
        public String id;
        @Schema(description = "Service Start Date")
        @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Service Start Date is not in valid format")
        public String serviceStartDate;
    }

    @Data
    public static class WorkQueue {
        @Schema(description = "Department Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Department Name is not in valid format")
        public String departmentName;
        @Schema(description = "Care Staff Name")
        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Care Staff Name is not in valid format")
        public String careStaffUserName;
    }
}