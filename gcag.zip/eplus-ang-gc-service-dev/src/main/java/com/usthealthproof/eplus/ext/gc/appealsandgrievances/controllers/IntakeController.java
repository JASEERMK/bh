package com.usthealthproof.eplus.ext.gc.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.error.ErrorResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.service.IntakeService;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/ang")
@Tag(name = "Intake")
@Validated
@Slf4j
public class IntakeController {

    @Autowired
    Validator validator;
    @Autowired
    IntakeService intakeService;

    @PostMapping(value = "/intake", produces = {MediaType.APPLICATION_JSON_VALUE})
    @Operation(summary = "Records the claim intake", method = "POST", description = "Service for recording the claim from the intake details provided by the user in request body", responses = {
            @ApiResponse(responseCode = "200", description = "Intake Response", content = {
                    @Content(schema = @Schema(implementation = IntakeResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @ResponseBody
    public ResponseEntity<IntakeResponse> recordClaimIntake(@Valid @RequestBody IntakeRequest intakeRequest, HttpServletRequest httpServletRequest) throws Exception {

        log.info("Inside recordClaimIntake()");
        log.info("Intake request {}", intakeRequest);
        validator.validateIntakeRequest(intakeRequest);
        return new ResponseEntity<>(intakeService.recordClaimIntake(intakeRequest), HttpStatus.OK);

    }

}
