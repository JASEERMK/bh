package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.error;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Problem Details class")
@Component
public class ProblemDetails implements Serializable {

	private static final long serialVersionUID = 1320284191861196169L;
	@Schema(description = "Error informations")
	private List<String> errors;
	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status;

}
