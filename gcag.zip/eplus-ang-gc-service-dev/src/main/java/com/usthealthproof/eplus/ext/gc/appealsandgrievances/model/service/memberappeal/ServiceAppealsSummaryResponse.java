package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
//@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Appeals Summary response received from the external service")
public class ServiceAppealsSummaryResponse {

	private String complaintID;
	private String complaintCategory;
	private String complaintClass;
	private String status;
	private String receivedDateTime;

}
