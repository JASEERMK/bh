package com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper.MemberComplaintIntakeMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper.NoteMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.LoginResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.*;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.util.RestResponseUtil;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Repository
@Slf4j
public class IntakeDao {
    @Autowired
    MemberComplaintIntakeMapper memberComplaintIntakeMapper;

    @Autowired
    NoteMapper noteMapper;
    @Autowired
    private WebClient webClient;
    @Autowired
    IntakeMemberEligibilityDao intakeMemberEligibilityDao;
    @Autowired
    private APIUtils apiUtils;
    @Autowired
    private Validator validator;
    @Value("${gc.url.service.ang-intake}")
    private String angIntake;

    public IntakeResponse recordClaimIntake(IntakeRequest intakeRequest) throws Exception {

        try {
            log.info("Calling Altruita service");
            log.info("Inside getMemberAppeals() in DAO class");
            LoginResponse loginResponse = apiUtils.login();
            log.info("Token Received : " + loginResponse.getAccessToken());
            // Map intake request to altruista request
            String lobBenId = intakeMemberEligibilityDao.callMemberEligibility(intakeRequest.getMemberId()
                    , intakeRequest.getIssueDate(), loginResponse);
            IntakeAltruistaRequest intakeAltruistaRequest = memberComplaintIntakeMapper.setAltruistaRequest(intakeRequest, lobBenId);
            ObjectMapper objectMapper = new ObjectMapper();
            log.info("intakeAltruistaRequest {}", objectMapper.writeValueAsString(intakeAltruistaRequest));
            IntakeResponse intakeResponse = null;
            intakeResponse = webClient.post().uri(uriBuilder -> uriBuilder.path(angIntake).build()).contentType(MediaType.APPLICATION_JSON).
                    header("Authorization", "Bearer " + loginResponse.getAccessToken()).
                    body(BodyInserters.fromValue(intakeAltruistaRequest)).
                    retrieve().
                    onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException).
                    onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequestIntake).
                    bodyToMono(IntakeResponse.class).block();
            validator.validateIntakeResponse(intakeResponse);
            addComplaintNote(intakeResponse.getComplaintID(), intakeRequest, loginResponse);
            return intakeResponse;
        } catch (WebClientResponseException webClientResponseException) {
            log.info("Failed to receive the Intake response {}");
            throw webClientResponseException;
        } catch (Exception exception) {
            log.info("Failed to receive the Intake response for the request");
            throw exception;
        }
    }

    public NoteResponse addComplaintNote(String complaintId, IntakeRequest intakeRequest, LoginResponse loginResponse) throws Exception {

        try {
            log.info("Calling Altruita service");
            log.info("Inside addComplaintNote() in DAO class");
            // Map intake request to altruista request
            NoteRequest noteRequest = null;
//            intakeAltruistaRequest = memberComplaintIntakeMapper.setAltruistaRequest(intakeRequest);
            if(validator.hasSubmitterDetails(intakeRequest)) {
                noteRequest = noteMapper.createNote(intakeRequest.getSubmitterDetails());
            } else if(validator.hasRepresentativeDetails(intakeRequest)) {
                noteRequest = noteMapper.createNote(intakeRequest.getRepresentativeDetails());
            } else {
                return null;
            }

            ObjectMapper objectMapper = new ObjectMapper();
            log.info("intakeAltruistaRequest {}", objectMapper.writeValueAsString(noteRequest));
            NoteResponse noteResponse = null;
            noteResponse = webClient.post().uri(uriBuilder -> uriBuilder.path(angIntake+ "/" + complaintId + "/Note").build()).contentType(MediaType.APPLICATION_JSON).
                    header("Authorization", "Bearer " + loginResponse.getAccessToken()).
                    body(BodyInserters.fromValue(noteRequest)).
                    retrieve().
                    onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException).
                    onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequestIntake).
                    bodyToMono(NoteResponse.class).block();
//            validator.validateIntakeResponse(noteResponse);
            return noteResponse;
        } catch (WebClientResponseException webClientResponseException) {
            log.info("Failed to receive the Intake response {}");
            throw webClientResponseException;
        } catch (Exception exception) {
            log.info("Failed to receive the Intake response for the request");
            throw exception;
        }
    }

}
