package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
@JsonIgnoreProperties(ignoreUnknown = true)
public class IntakeAltruistaRequest {
    private String lobBenID;
    private String clientPatientID;
    private String whoInitiatedComplaint;
//    private Participant[] participants;
    private String providerID;
//    private Aor aor;
    private String complaintType;
    private String complaintClass;
    private String complaintCategory;
//    private String complaintSubCategory;
//    private String complaintAgainst;
//    private String complaintAgainstDetail;

    private List<InternalClaim> internalClaims;
    private List<InternalAuthorization> internalAuthorizations;

    private String dateTimeOfIncident;
    private String initialComplaintNote;
    private String intakeStaff;
    private String responsibleStaff;

    private String isWorkQueueReferral;
    private WorkQueue[] workQueues;
    private String notificationMethod;
    private String intakeDepartment;
    private String status;
    private String notificationDateTime;
    private String responsibleDepartment;

    private String levelOfService;

    private SupplementalInformation[] intakeSupplementalInformation;

//    @Data
//    public class Aor {
//        private String firstName;
//        private String lastName;
//        private String address;
//        private String city;
//        private String state;
//        private String zip;
//        private String phoneNumber;
//    }

    @Data
    public class InternalAuthorization {
        private String authorizationID;
        private String isPrimary;
    }

    @Data
    public class InternalClaim {
        private String claimNumber;
    }

//    @Data
//    public class Participant {
//        private String name;
//        private String type;
//        private String relationship;
//        private String phone;
//        private String zip;
//        private String notes;
//    }

    @Data
    public class WorkQueue {
        private String departmentName;
        private String careStaffUserName;
    }

    @Data
    public class SupplementalInformation {
        private String name;
        private String[] value;
    }
}
