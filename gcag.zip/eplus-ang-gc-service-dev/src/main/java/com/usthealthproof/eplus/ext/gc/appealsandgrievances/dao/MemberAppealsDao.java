package com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.LoginResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.PaginatedResponseModel;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsDetailsResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.util.RestResponseUtil;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator.Validator;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.List;
import java.util.function.Consumer;

import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.*;

@Repository
@Slf4j
public class MemberAppealsDao {

	@Autowired
	private WebClient webClient;
	@Autowired
	private APIUtils apiUtils;
	@Autowired
	private Validator validator;

	@Value("${gc.url.service.ang-member-summary}")
	private String angMemberSummary;

	@Value("${gc.url.service.ang-provider-summary}")
	private String angProviderSummary;
	@Value("${gc.url.service.ang-detail}")
	private String angDetail;
	@Value("${gc.config.ang-pagesize}")
	private String pageSize;

	public List<ServiceAppealsSummaryResponse> getMemberAppealsSummary(String memberId, String complaintType) throws Exception {
		log.info("Inside getMemberAppeals() in DAO class");
		LoginResponse loginResponse = apiUtils.login();
		log.info("Token Received : " + loginResponse.getAccessToken());
		List<ServiceAppealsSummaryResponse> serviceMemberAppealsSummaryRespons = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders(loginResponse);
			log.info("Going to call the GC AppealsByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			PaginatedResponseModel<ServiceAppealsSummaryResponse> paginatedResponseModel = webClient
					.get()
					.uri(uriBuilder -> uriBuilder.path(angMemberSummary)
								.queryParam(CLIENT_PATIENT_ID, memberId)
								.queryParam(COMPLAINT_TYPE, complaintType)
								.queryParam(PAGE_SIZE, pageSize) // Add this line to set the page size
							.build())
					.headers(httpHeaders1 -> {
						httpHeaders1.setBearerAuth(loginResponse.getAccessToken());
					})
					.retrieve()
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException)
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequest)
					.bodyToMono(new ParameterizedTypeReference<PaginatedResponseModel<ServiceAppealsSummaryResponse>>() {
					}).block();
			validator.validateServiceMemberAppealsResponse(paginatedResponseModel);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the GuidingCare Member Summary service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the Member Complaints response for the request with memberId: {} or complaintType {}",
					memberId, complaintType);
			serviceMemberAppealsSummaryRespons = paginatedResponseModel.getResults();
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Member Complaint response for the request with memberId: {} or complaintType {}",
					memberId, complaintType);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Member Complaint response for the request with memberId: {} or complaintType {}",
					memberId, complaintType);
			throw exception;
		}
		return serviceMemberAppealsSummaryRespons;
	}

	public List<ServiceAppealsSummaryResponse> getProviderAppealsSummary(String providerId, String complaintType, @Pattern(regexp = "^[0-9//]*$", message = "Invalid Request: Created From Date is not in valid format") String createdFromDate, @Pattern(regexp = "^[0-9\\\\/]*$", message = "Invalid Request: Created Start Date is not in valid format") String createdToDate) throws Exception {
		log.info("Inside geProviderAppeals() in DAO class");
		LoginResponse loginResponse = apiUtils.login();
		log.info("Token Received : " + loginResponse.getAccessToken());
		List<ServiceAppealsSummaryResponse> serviceMemberAppealsSummaryRespons = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders(loginResponse);
			log.info("Going to call the GC AppealsByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			PaginatedResponseModel<ServiceAppealsSummaryResponse> paginatedResponseModel = webClient
					.get()
					.uri(uriBuilder -> uriBuilder.path(angProviderSummary)
							.queryParam(PROVIDER_ID, providerId)
							.queryParam(COMPLAINT_TYPE, complaintType)
							.queryParam(COMPLAINT_CREATED_FROM_DATE, apiUtils.getFormattedGCApplicationDate(createdFromDate))
							.queryParam(COMPLAINT_CREATED_TO_DATE, apiUtils.getFormattedGCApplicationDate(createdToDate))
							.queryParam(PAGE_SIZE, pageSize) // Add this line to set the page size
							.build())
					.headers(httpHeaders1 -> {
						httpHeaders1.setBearerAuth(loginResponse.getAccessToken());
					})
					.retrieve()
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException)
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequest)
					.bodyToMono(new ParameterizedTypeReference<PaginatedResponseModel<ServiceAppealsSummaryResponse>>() {
					}).block();
			validator.validateServiceMemberAppealsResponse(paginatedResponseModel);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the GuidingCare Provider Summary service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the Provider Complaints response for the request with providerId: {} or complaintType {}",
					providerId, complaintType);
			serviceMemberAppealsSummaryRespons = paginatedResponseModel.getResults();
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Provider Complaint response for the request with providerId: {} or complaintType {}",
					providerId, complaintType);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Provider Complaint response for the request with providerId: {} or complaintType {}",
					providerId, complaintType);
			throw exception;
		}
		return serviceMemberAppealsSummaryRespons;
	}

	public ServiceMemberAppealsDetailsResponse getMemberAppealsDetails(String complaintId) throws Exception {
		log.info("Inside getMemberAppealsDetails() in DAO class");
		LoginResponse loginResponse = apiUtils.login();
		log.info("Token Received : " + loginResponse.getAccessToken());
		ServiceMemberAppealsDetailsResponse serviceMemberAppealsDetailsResponse = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders(loginResponse);
			log.info("Going to call the GC AppealsByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			serviceMemberAppealsDetailsResponse = webClient.get()
					.uri(uriBuilder -> uriBuilder.path(angDetail)
							.path("/" + complaintId)
							.path("/Detail")
							.build())
					.headers(headers -> headers.setBearerAuth(loginResponse.getAccessToken()))
					.retrieve()
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException)
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequest)
					.bodyToMono(ServiceMemberAppealsDetailsResponse.class)
					.block();

			validator.validateServiceMemberAppealsDetailsResponse(serviceMemberAppealsDetailsResponse);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the Complaint Details service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the Complaint response for the request with complaintId: {} ",
					complaintId);
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Complaint response for the request with complaintId: {} ",
					complaintId);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Complaint response for the request with complaintId: {}",
					complaintId);
			throw exception;
		}
		return serviceMemberAppealsDetailsResponse;
	}

	public ServiceMemberAppealsDetailsResponse addComplaintNote(String complaintId) throws Exception {
		log.info("Inside getMemberAppealsDetails() in DAO class");
		LoginResponse loginResponse = apiUtils.login();
		log.info("Token Received : " + loginResponse.getAccessToken());
		ServiceMemberAppealsDetailsResponse serviceMemberAppealsDetailsResponse = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders(loginResponse);
			log.info("Going to call the GC AppealsByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			serviceMemberAppealsDetailsResponse = webClient.get()
					.uri(uriBuilder -> uriBuilder.path(angDetail)
							.path("/" + complaintId)
							.path("/Note")
							.build())
					.headers(headers -> headers.setBearerAuth(loginResponse.getAccessToken()))
					.retrieve()
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException)
					.onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequest)
					.bodyToMono(ServiceMemberAppealsDetailsResponse.class)
					.block();

			validator.validateServiceMemberAppealsDetailsResponse(serviceMemberAppealsDetailsResponse);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the Complaint Details service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the Complaint response for the request with complaintId: {} ",
					complaintId);
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Complaint response for the request with complaintId: {} ",
					complaintId);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Complaint response for the request with complaintId: {}",
					complaintId);
			throw exception;
		}
		return serviceMemberAppealsDetailsResponse;
	}
}
