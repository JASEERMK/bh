package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Member Appeals or Grievance Summary")
@JsonInclude(value = Include.NON_EMPTY)
public class AppealsOrGrievanceSummary {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "complaint Sub Category")
	private String complaintSubCategory;
	@Schema(description = "Priority Requested")
	private String priority;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Receive Date time")
	private String receivedDate;

}
