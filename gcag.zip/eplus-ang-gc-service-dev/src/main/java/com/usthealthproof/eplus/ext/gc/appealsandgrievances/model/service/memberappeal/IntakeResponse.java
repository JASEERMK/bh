package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Member Intale response received from the external service")
public class IntakeResponse {
    private String complaintID;
    private String level;
    private String status;
    private String statusReason;
    private String complaintType;
    private String createdDateTime;
}
