package com.usthealthproof.eplus.ext.gc.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.IntakeDao;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class IntakeService {
    @Autowired
    private IntakeDao intakeDao;


    public IntakeResponse recordClaimIntake(IntakeRequest intakeRequest) throws Exception {
        log.info("Intake Request {}",
                intakeRequest);
        return intakeDao.recordClaimIntake(intakeRequest);
    }
}
