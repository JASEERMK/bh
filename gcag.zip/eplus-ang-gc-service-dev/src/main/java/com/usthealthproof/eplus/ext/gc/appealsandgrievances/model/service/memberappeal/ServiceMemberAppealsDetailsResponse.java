package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.InternalClaims;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.Participants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
//@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Member Appeals Details response received from the external service")
public class ServiceMemberAppealsDetailsResponse {
    private String complaintID;
    private String complaintCategory;
    private String complaintClass;
    private String createdDateTime;
    private String notificationDateTime;
    private String caseAge;
    private String level;
    private String status;
    private String complaintSubCategory;
    private String notificationMethod;
    private String whoInitiatedComplaint;
    private String dueDateTime;
    private String levelOfService;
    private String resolutionDateTime;
    private String resolutionCategory;
    private String resolutionSubCategory;
    private String resolutionNote;
    private String dateTimeOfIncident;
    private String responsibleDepartment;
    private String responsibleStaff;
    private List<InternalClaims> internalClaims;
    private List<Participants> participants;

}
