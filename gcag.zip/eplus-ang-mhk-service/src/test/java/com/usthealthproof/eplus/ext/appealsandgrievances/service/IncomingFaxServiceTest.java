package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.IncomingFaxDAO;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class IncomingFaxServiceTest {
    @InjectMocks
    private IncomingFaxService incomingFaxService;

    @Mock
    private IncomingFaxDAO incomingFaxDAO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testCreateIncomingFax(){
        IncomingFaxRequest incomingFaxRequest = new IncomingFaxRequest();
        IncomingFaxResponse incomingFaxResponse = new IncomingFaxResponse();
        when(incomingFaxDAO.createIncomingFax(incomingFaxRequest)).thenReturn(incomingFaxResponse);
        IncomingFaxResponse actualResponse = incomingFaxService.createIncomingFax(incomingFaxRequest);

        // Then
        assertEquals(incomingFaxResponse, actualResponse);
        // Verify that the DAO method was called with the correct arguments
        verify(incomingFaxDAO, times(1)).createIncomingFax(incomingFaxRequest);

    }
}
