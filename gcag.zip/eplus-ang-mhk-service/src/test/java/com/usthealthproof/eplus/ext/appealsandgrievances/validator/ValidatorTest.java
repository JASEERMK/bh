package com.usthealthproof.eplus.ext.appealsandgrievances.validator;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ValidatorTest {
    @InjectMocks
    Validator validator;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(validator, "faxQueueNames", "queue1,queue2");

    }
    @Test
    void testValidateMemberAppealsAndGrievancesSummary() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberAppealsAndGrievancesSummary(null,null));
    }
    @Test
    void testValidateMemberAppealsAndGrievancesSummary_NullMemberID() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberAppealsAndGrievancesSummary(null,"appeal"));
    }
    @Test
    void testValidateMemberAppealsAndGrievancesSummary_NullComplaintType() {
        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberAppealsAndGrievancesSummary("2100060-01",null));
    }
    @Test
    void testValidComplaintType() {
        // Test with valid complaint types
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.DENTAL_APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.MEDICAL_APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.RX_MEDICAL_APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.RX_RETAIL_APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.VISION_APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.APPEAL));
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesSummary("memberId", AppealsAndGrievanceConstants.GRIEVANCE_TYPE));
    }
    @Test
    void testValidateMemberAppealsAndGrievancesDetails_NullComplaintID() {

        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberAppealsAndGrievancesDetails(null));
    }
    @Test
    void testValidateMemberAppealsAndGrievancesDetails_InValidComplaintID() {

            // when and then - verify the output
        assertDoesNotThrow(() -> validator.validateMemberAppealsAndGrievancesDetails("D12578"));
    }
    @Test
    void testValidateMemberAppealsAndGrievancesDetails_EmptyComplaintID() {

        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateMemberAppealsAndGrievancesDetails(""));
    }
    @Test
    void testValidateProviderAppealsSummary_NullProviderID() {

        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateProviderAppealsSummary(null,"appeal"));
    }
    @Test
    void testValidateProviderAppealsSummary_NullComplaintType() {

        // when and then - verify the output
        assertThrows(RequestValidationException.class, () -> validator.validateProviderAppealsSummary("P13689",null));
    }
    @Test
    void testValidProviderId() {
        assertDoesNotThrow(() -> validator.validateProviderAppealsSummary("P13689", "appeal"));
    }
    @Test
    void testNullServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceMemberAppealsResponse(null));
    }

    @Test
    void testEmptyServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceMemberAppealsResponse(new ServiceMemberAppealsResponse[0]));
    }

    @Test
    void testNonEmptyServiceMemberAppeals() {
        ServiceMemberAppealsResponse[] data = {new ServiceMemberAppealsResponse(), new ServiceMemberAppealsResponse()};
        assertDoesNotThrow(() -> validator.validateServiceMemberAppealsResponse(data));
    }

    @Test
    void testValidateServiceProviderAppealsResponse_NullServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceProviderAppealsResponse(null));
    }

    @Test
    void testValidateServiceProviderAppealsResponse_EmptyServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceProviderAppealsResponse(new ServiceProviderAppealsResponse[0]));
    }

    @Test
    void testValidateServiceProviderAppealsResponse_NonEmptyServiceMemberAppeals() {
        ServiceProviderAppealsResponse[] data = {new ServiceProviderAppealsResponse(), new ServiceProviderAppealsResponse()};
        assertDoesNotThrow(() -> validator.validateServiceProviderAppealsResponse(data));
    }
    @Test
    void testValidateServiceMemberGrievanceResponse_NullServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceMemberGreivanceResponse(null));
    }

    @Test
    void testValidateServiceMemberGrievanceResponse_EmptyServiceMemberAppeals() {
        assertThrows(ResponseValidationException.class, () -> validator.validateServiceMemberGreivanceResponse(new ServiceMemberGreivancesResponse[0]));
    }

    @Test
    void testValidateServiceMemberGrievanceResponse_NonEmptyServiceMemberAppeals() {
        ServiceMemberGreivancesResponse[] data = {new ServiceMemberGreivancesResponse(), new ServiceMemberGreivancesResponse()};
        assertDoesNotThrow(() -> validator.validateServiceMemberGreivanceResponse(data));
    }
    @Test
    void testValidateIncomingFaxRequest_MissingDocument() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument(null);
        request.setDocumentName("docName");
        request.setName("queue1");
        request.setIncomingFaxNumber("123456");
        request.setReceivedDateTime("2024-06-11");

        assertThrows(RequestValidationException.class, () -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testValidateIncomingFaxRequest_MissingDocumentName() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument("document");
        request.setDocumentName(null);
        request.setName("queue1");
        request.setIncomingFaxNumber("123456");
        request.setReceivedDateTime("2024-06-11");

        assertThrows(RequestValidationException.class, () -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testValidateIncomingFaxRequest_MissingName() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument("document");
        request.setDocumentName("docName");
        request.setName(null);
        request.setIncomingFaxNumber("123456");
        request.setReceivedDateTime("2024-06-11");

        assertThrows(RequestValidationException.class, () -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testValidateIncomingFaxRequest_MissingFactNumber() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument("document");
        request.setDocumentName("docName");
        request.setName("queue1");
        request.setIncomingFaxNumber(null);
        request.setReceivedDateTime("2024-06-11");

        assertThrows(RequestValidationException.class, () -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testValidateIncomingFaxRequest_ValidRequest() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument("documentContent");
        request.setDocumentName("docName");
        request.setName("queue1");
        request.setIncomingFaxNumber("123456");
        request.setReceivedDateTime("2024-06-11T12:00:00Z");

        assertDoesNotThrow(() -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testValidateIncomingFaxRequest_InvalidIncomingFaxNumber() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        request.setDocument("documentContent");
        request.setDocumentName("docName");
        request.setName("queue1");
        request.setIncomingFaxNumber("null");  // Invalid incoming fax number
        request.setReceivedDateTime("2024-06-11T12:00:00Z");

        assertThrows(RequestValidationException.class, () -> validator.validateIncomingFaxRequest(request));
    }
    @Test
    void testInvalidUTCDateFormat() {
        String inputDate = "2024-06-11 12:00:00";
        assertThrows(RequestValidationException.class, () -> ReflectionTestUtils.invokeMethod(validator, "validateDateFormat", inputDate, null, "ReceivedDateTime"));
    }
    @Test
    void testValidUTCDateFormat() {
        String inputDate = "2024-06-11T12:00:00Z";
        assertDoesNotThrow(() -> ReflectionTestUtils.invokeMethod(validator, "validateDateFormat", inputDate, null, "ReceivedDateTime"));
    }
    @Test
    void testInvalidGeneralDateFormatWithTime() {
        String inputDate = "2024/06/11 12:00:00";
        String dateFormat = "yyyy-MM-dd'T'HH:mm:ss";
        assertThrows(RequestValidationException.class, () -> ReflectionTestUtils.invokeMethod(validator, "validateDateFormat", inputDate, dateFormat, "ReceivedDateTime"));
    }

    @Test
    void testValidateIncomingFaxResponse_Null(){
        assertThrows(ResponseValidationException.class, () -> validator.validateIncomingFaxResponse(null));
    }
//@Test
//void testValidateIncomingFaxResponse_NonEmpty() {
//
//    IncomingFaxResponse[] data = {new IncomingFaxResponse(), new IncomingFaxResponse()};
//    assertDoesNotThrow(() -> validator.validateIncomingFaxResponse(data));
//}

    @Test
    void testValidateIncomingFaxResponse_BothIdsEmpty() {
        IncomingFaxResponse response = new IncomingFaxResponse();
        response.setIncomingId("");
        response.setDocumentId("");
        assertThrows(ResponseValidationException.class, () ->
                validator.validateIncomingFaxResponse(response));
    }
    @Test
    void testValidateIncomingFaxResponse_BothIdsNonEmpty(){

        IncomingFaxResponse response = new IncomingFaxResponse();
        response.setIncomingId("validIncomingID");
        response.setDocumentId("ValidDocumentID");
        assertDoesNotThrow(() ->
                validator.validateIncomingFaxResponse(response));
    }
}
