package com.usthealthproof.eplus.ext.appealsandgrievances;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;
@SpringBootTest
public class AppealsGrievancesServicesApplicationTest {
    @Test
    void testMain() {
        AppealsGrievancesServicesApplication.main(new String[]{"args"});
        assertTrue(true);
    }

}
