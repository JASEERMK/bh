package com.usthealthproof.eplus.ext.appealsandgrievances.exception;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ErrorResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import static org.assertj.core.api.Assertions.assertThat;
@ExtendWith(MockitoExtension.class)
public class AppealsAndGrievanceExceptionHandlerTest {
	@InjectMocks
	AppealsAndGrievanceExceptionHandler handler;
	@Mock
	WebRequest webRequest;
	@Mock
	HttpMethod httpMethod;

	@Test
	void testInvalidRequestHandler()
	{
		ResponseEntity<ErrorResponse> errorResponse = handler.requestValidationExceptionHandler(new RequestValidationException("message"));
		assertThat(errorResponse).isNotNull();
	}

	@Test
	void testNotFoundExceptionHandler()
	{
		ResponseEntity<ErrorResponse> errorResponse = handler.responseValidationExceptionHandler(new ResponseValidationException("message"));
		assertThat(errorResponse).isNotNull();
	}

	@Test
	void testNoResourceFoundExceptionHandler()
	{
		ResponseEntity<ErrorResponse> errorResponse = handler.noResourceFoundException(new NoResourceFoundException(httpMethod,"/v1/ang/mem"), webRequest);
		assertThat(errorResponse).isNotNull();
	}

}
