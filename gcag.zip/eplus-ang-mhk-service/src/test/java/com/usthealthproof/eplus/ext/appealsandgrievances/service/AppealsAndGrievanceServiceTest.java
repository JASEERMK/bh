package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.MemberAppealsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.MemberGrievanceDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberGrievanceMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class AppealsAndGrievanceServiceTest {

    @InjectMocks
    private AppealsAndGrievanceService appealsAndGrievanceService;

    @Mock
    private MemberAppealsDao memberAppealsDao;

    @Mock
    private MemberGrievanceDao memberGrievanceDao;

    @Mock
    private MemberAppealsMapper memberAppealsMapper;

    @Mock
    private MemberGrievanceMapper memberGrievanceMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("JUnit Test case for AppealsAndGrievanceSummary in service")
    void testGetAppealsOrGrievanceSummary() throws Exception {

        AppealsOrGrievanceSummary appealsOrGrievanceSummary = new AppealsOrGrievanceSummary();
        appealsOrGrievanceSummary.setComplaintID("D1234567");
        appealsOrGrievanceSummary.setComplaintCategory("Medical Necessity");
        appealsOrGrievanceSummary.setComplaintSubCategory("GrievanceSubType1");
        appealsOrGrievanceSummary.setPriority("Medium");
        appealsOrGrievanceSummary.setStatus("open");
        appealsOrGrievanceSummary.setReceivedDate("2022-07-05T12:27:21.000+0000");
        List<AppealsOrGrievanceSummary> summaryList = List.of(appealsOrGrievanceSummary);

        // Test for "Appeal"
        ServiceMemberAppealsResponse[] appealsResponses = new ServiceMemberAppealsResponse[]{};
        given(memberAppealsDao.getMemberAppeals("validMemberId", null)).willReturn(appealsResponses);
        given(memberAppealsMapper.memberAppealSearchResponseMapper(appealsResponses)).willReturn(summaryList);

        List<AppealsOrGrievanceSummary> result = appealsAndGrievanceService.getAppealsOrGrievanceSummary("validMemberId", "Appeal");
        assertEquals(summaryList, result);

        // Test for "Grievance"
        ServiceMemberGreivancesResponse[] grievancesResponses = new ServiceMemberGreivancesResponse[]{};
        given(memberGrievanceDao.getMemberGrievances("validMemberId")).willReturn(grievancesResponses);
        given(memberGrievanceMapper.memberGrievancesSearchMapper(grievancesResponses)).willReturn(summaryList);

        result = appealsAndGrievanceService.getAppealsOrGrievanceSummary("validMemberId", "Grievance");
        assertEquals(summaryList, result);

        // Test for invalid complaint type
        assertThrows(RequestValidationException.class, () -> appealsAndGrievanceService.getAppealsOrGrievanceSummary("validMemberId", "InvalidType"));
    }

    @Test
    @DisplayName("JUnit Test case for AppealsAndGrievanceDetails in service")
    void testGetAppealsOrGrievanceDetails_Grievance() throws Exception {
        String memberId = "123";
        String complaintId = "G123";
        AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
        ServiceMemberGreivancesResponse[] grievancesResponses = new ServiceMemberGreivancesResponse[]{};

        //Test for Grievance
        given(memberGrievanceDao.getMemberGrievances(memberId)).willReturn(grievancesResponses);
        given(memberGrievanceMapper.memberGreivanceDetailsMapper(complaintId, grievancesResponses)).willReturn(appealsOrGrievanceDetails);
        AppealsOrGrievanceDetails result = appealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId, memberId);
        assertEquals(appealsOrGrievanceDetails, result);

    }
    @Test
    @DisplayName("JUnit Test case for getAppealsOrGrievanceDetails with invalid memberId")
    void testGetAppealsOrGrievanceDetails_InvalidMemberID() throws Exception {
        String memberId = "InvalidMemberId";
        String complaintId = "G123";
        AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
        ServiceMemberGreivancesResponse[] appealsResponses = new ServiceMemberGreivancesResponse[]{};

        //Test for Grievance
        given(memberGrievanceDao.getMemberGrievances(memberId)).willReturn(appealsResponses);
        given(memberGrievanceMapper.memberGreivanceDetailsMapper(complaintId, appealsResponses)).willReturn(appealsOrGrievanceDetails);
        AppealsOrGrievanceDetails result = appealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId, memberId);
        assertEquals(appealsOrGrievanceDetails, result);

    }
    @Test
    @DisplayName("JUnit Test case for getAppealsOrGrievanceDetails with invalid memberId and complaintId")
    void testGetAppealsOrGrievanceDetails_BothInvalidID() throws Exception {
        String memberId = "InvalidMemberId";
        String complaintId = "InvalidComplaintId";
        AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
        ServiceMemberGreivancesResponse[] appealsResponses = new ServiceMemberGreivancesResponse[]{};

        //Test for Grievance
        given(memberGrievanceDao.getMemberGrievances(memberId)).willReturn(appealsResponses);
        given(memberGrievanceMapper.memberGreivanceDetailsMapper(complaintId, appealsResponses)).willReturn(appealsOrGrievanceDetails);
        AppealsOrGrievanceDetails result = appealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId, memberId);
        assertEquals(appealsOrGrievanceDetails, result);

    }
    @Test
    @DisplayName("JUnit Test case for getAppealsOrGrievanceDetails with invalid complaintType")
    void testGetAppealsOrGrievanceDetailsWithInvalidId() throws Exception {
        String complaintId = "";
        String memberId = "";

        ServiceMemberAppealsResponse[] appealsResponses = new ServiceMemberAppealsResponse[]{};
        AppealsOrGrievanceDetails expectedDetails = new AppealsOrGrievanceDetails();

        given(memberAppealsDao.getMemberAppeals(anyString(), anyString())).willReturn(appealsResponses);
        given(memberAppealsMapper.memberAppealDetailsResponseMapper(appealsResponses)).willReturn(expectedDetails);
        AppealsOrGrievanceDetails result = appealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId, memberId);
        assertEquals(expectedDetails, result);
    }

}
