package com.usthealthproof.eplus.ext.appealsandgrievances.constants;

import org.springframework.stereotype.Component;

@Component
public class AppealsAndGrievanceConstantsTest {
    public static final String COMPLAINT_CATEGORY = "GrievanceType1";
    public static final String COMPLAINT_ID = "G123";
    public static final String PRIORITY = "Medium";
    public static final String COMPLAINT_SUB_CATEGORY = "GrievanceSubType1";
    public static final String STATUS = "Open";
    public static final String RECEIVE_DATE = "2019-01-01";
    public static final String ENDPOINT_APPEALS_AND_GRIEVANCE = "/v1/ang/member/complaints";
    public static final String ENDPOINT_APPEALS_AND_GRIEVANCE_DETAILS = "/v1/ang/member/complaint/details";
    public static final String ENDPOINT_INTAKE_CONTROLLER = "/v1/ang/intake";
    public static final String COMPLAINT_ID_PROVIDER = "D1234567";
    public static final String STATUS_PROVIDER = "Canceled";
    public static final String REQUEST_TYPE_PROVIDER = "Retrospective Review";
    public static final String COMPLAINT_TYPE_PROVIDER = "Post Service";
    public static final String RECEIVED_DATE_PROVIDER = "2022-07-05T12:27:21.000+0000";
    public static final String COMPLAINT_CATEGORY_PROVIDER = "Medical Necessity";
    public static final String MEMBER_NAME_PROVIDER = "Jones, Archie";
    public static final String MEMBER_ID_PROVIDER = "210000600-06";
    public static final String PROVIDE_ID = "P0000678";
    public static final String ENDPOINT_PROVIDER_APPEALS= "/v1/ang/provider/complaints";
    public static final String ENDPOINT_PROVIDER_APPEALS_DETAILS= "/v1/ang/provider/complaint/details";
}
