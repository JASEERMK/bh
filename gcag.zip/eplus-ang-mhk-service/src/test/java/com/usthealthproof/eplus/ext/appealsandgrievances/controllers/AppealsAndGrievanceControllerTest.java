package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.appealsandgrievances.configuration.AppealsAndGrievanceConfig;
import com.usthealthproof.eplus.ext.appealsandgrievances.configuration.SpringSecurityConfig;
import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstantsTest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProblemDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.AppealsAndGrievanceService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.ValidatorTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@WebMvcTest(AppealsAndGrievanceController.class)

public class AppealsAndGrievanceControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AppealsAndGrievanceService appealsAndGrievanceService;

    @MockBean
    private Validator validator;

    private List<AppealsOrGrievanceSummary> summaryList;
    @MockBean
    private ProblemDetails problemDetails;

    @BeforeEach
    void setUp() {
        AppealsOrGrievanceSummary appealsOrGrievanceSummary = new AppealsOrGrievanceSummary();
        appealsOrGrievanceSummary.setComplaintCategory(AppealsAndGrievanceConstantsTest.COMPLAINT_CATEGORY);
        appealsOrGrievanceSummary.setComplaintID(AppealsAndGrievanceConstantsTest.COMPLAINT_ID);
        appealsOrGrievanceSummary.setPriority(AppealsAndGrievanceConstantsTest.PRIORITY);
        appealsOrGrievanceSummary.setComplaintSubCategory(AppealsAndGrievanceConstantsTest.COMPLAINT_SUB_CATEGORY);
        appealsOrGrievanceSummary.setStatus(AppealsAndGrievanceConstantsTest.STATUS);
        appealsOrGrievanceSummary.setReceivedDate(AppealsAndGrievanceConstantsTest.RECEIVE_DATE);

        summaryList = List.of(appealsOrGrievanceSummary);
    }

    @AfterEach
    void tearDown() {
        summaryList = null;
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for valid inputs")
    void testGetMemberAppealsOrGrievancesSummary_ValidInputs() throws Exception {
        when(appealsAndGrievanceService.getAppealsOrGrievanceSummary(anyString(), anyString())).thenReturn(summaryList);

        mockMvc.perform(get("/v1/ang/member/complaints")
                        .param("memberId", "validMemberId")
                        .param("complaintType", "validComplaintType"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").exists());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for empty results")
    void testGetMemberAppealsOrGrievancesSummary_EmptyResults() throws Exception {
        when(appealsAndGrievanceService.getAppealsOrGrievanceSummary(anyString(), anyString())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/v1/ang/member/complaints")
                        .param("memberId", "validMemberId")
                        .param("complaintType", "validComplaintType"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for service returns null")
    void testGetMemberAppealsOrGrievancesSummary_ServiceReturnsNull() throws Exception {
        when(appealsAndGrievanceService.getAppealsOrGrievanceSummary(anyString(), anyString())).thenReturn(null);

        mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_APPEALS_AND_GRIEVANCE)
                        .param("memberId", "validMemberId")
                        .param("complaintType", "validComplaintType"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").doesNotExist());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid Input Param")
    void testInvalidInputParam() throws Exception {
        // when - action or the behaviour
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_APPEALS_AND_GRIEVANCE));
        // then - verify the output
        response.andDo(print())
                .andExpect(status().isBadRequest());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getAppealsAndGrievance - Invalid Pattern")
    void testInvalidPattern() throws Exception {
        // Given - Setup
        String invalidMemberId = "123>"; // Invalid pattern
        String invalidComplaintType = "InvalidType";

        // When - Action
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_APPEALS_AND_GRIEVANCE)
                .param("memberId", invalidMemberId)
                .param("complaintType", invalidComplaintType));

        // Then - Verification
        response.andDo(print())
                .andExpect(status().isBadRequest());// Assuming invalid pattern results in a Bad Request status
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Valid Input Params in Appeals and Grievance Details")
    void testGetMemberAppealsOrGrievancesDetails_ValidInputs() throws Exception {
        AppealsOrGrievanceDetails mockDetails = new AppealsOrGrievanceDetails();

        when(appealsAndGrievanceService.getAppealsOrGrievanceDetails(anyString(), anyString())).thenReturn(mockDetails);

        ResultActions response = mockMvc.perform((get(AppealsAndGrievanceConstantsTest.ENDPOINT_APPEALS_AND_GRIEVANCE_DETAILS))
                .param("complaintId", "G123")
                .param("memberId", "123"));

        response.andDo(print())
                .andExpect(status().isOk());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for getAppealsAndGrievance in Appeals and Grievance Details - Invalid Pattern")
    void testGetMemberAppealsOrGrievancesDetails_InvalidInputs() throws Exception {
        // Given - Setup
        String invalidComplaintId = "G123>"; // Invalid pattern
        String invalidMemberId = "123</";

        // When - Action
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_APPEALS_AND_GRIEVANCE_DETAILS)
                .param("complaintId", invalidComplaintId)
                .param("memberId", invalidMemberId));

        // Then - Verification
        response.andDo(print())
                .andExpect(status().isBadRequest());// Assuming invalid pattern results in a Bad Request status
    }
}
