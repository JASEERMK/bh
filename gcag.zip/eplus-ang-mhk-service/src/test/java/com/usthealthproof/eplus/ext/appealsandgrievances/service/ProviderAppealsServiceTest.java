package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.ProviderAppealsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.ProviderAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsSummary;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProviderAppealsServiceTest {
    @InjectMocks
    private ProviderAppealsService providerAppealsService;
    @Mock
    private ProviderAppealsMapper providerAppealsMapper;

    @Mock
    private ProviderAppealsDao providerAppealsDao;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetProviderAppealDetails() throws Exception{
        ProviderAppealsDetails providerAppealsDetails = new ProviderAppealsDetails();
        ServiceProviderAppealsResponse[] serviceProviderAppealsResponses = new ServiceProviderAppealsResponse[]{};

        when(providerAppealsDao.getProviderAppeals(null,"G123")).thenReturn(serviceProviderAppealsResponses);
        when(providerAppealsMapper.providerAppealsDetailsResponseMapper(serviceProviderAppealsResponses)).thenReturn(providerAppealsDetails);

        ProviderAppealsDetails result = providerAppealsService.getProviderAppealDetails("G123");
        assertEquals(providerAppealsDetails, result);
    }
    @Test
    void testGetProviderAppealsSummary() throws Exception{
        List<ProviderAppealsSummary> providerAppealsSummaries = new ArrayList<>();
        ServiceProviderAppealsResponse[] serviceProviderAppealsResponses = new ServiceProviderAppealsResponse[]{};

        when(providerAppealsDao.getProviderAppeals("1234",null)).thenReturn(serviceProviderAppealsResponses);
        when(providerAppealsMapper.providerAppealsSearchResponseMapper(serviceProviderAppealsResponses)).thenReturn(providerAppealsSummaries);

        List<ProviderAppealsSummary> result = providerAppealsService.getProviderAppealsSummary("1234");
        assertEquals(providerAppealsSummaries,result);

    }
}
