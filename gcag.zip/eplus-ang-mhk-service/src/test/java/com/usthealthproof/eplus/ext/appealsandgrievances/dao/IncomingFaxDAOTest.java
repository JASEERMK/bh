package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.IncomingFaxDAO;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.IncomingFaxService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest
@MockitoSettings(strictness = Strictness.LENIENT)
public class IncomingFaxDAOTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private Validator validator;

    @InjectMocks
    private IncomingFaxDAO incomingFaxDAO;

    private IncomingFaxRequest incomingFaxRequest;

    private IncomingFaxResponse incomingFaxResponse;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(incomingFaxDAO, "incomingFaxURI", "validIncomingFaxURI");
        ReflectionTestUtils.setField(incomingFaxDAO, "webClient", webClient);

        // Setup WebClient mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any(Consumer.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.contentType(any(MediaType.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.accept(any(MediaType.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        incomingFaxRequest = new IncomingFaxRequest();
        incomingFaxResponse = new IncomingFaxResponse();
    }
    @Test
    void testCreateIncomingFaxSuccess() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        IncomingFaxResponse response = new IncomingFaxResponse();
        response.setIncomingId("12345");
        response.setDocumentId("67890");

        // Mocking API utils and validator
        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(IncomingFaxResponse.class)).thenReturn(Mono.just(response));

        IncomingFaxResponse result = incomingFaxDAO.createIncomingFax(request);

        verify(validator).validateIncomingFaxResponse(response);
        assertEquals(AppealsAndGrievanceConstants.SUCCESS, result.getStatus());
        assertEquals("12345", result.getIncomingId());
        assertEquals("67890", result.getDocumentId());
    }
    @Test
    void testCreateIncomingFaxWebClientResponseException() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        WebClientResponseException responseException = WebClientResponseException.create(
                404, "Not Found", null, null, null);

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(IncomingFaxResponse.class)).thenReturn(Mono.error(responseException));

        WebClientResponseException thrownException = assertThrows(WebClientResponseException.class,
                () -> incomingFaxDAO.createIncomingFax(request));

        assertEquals(404, thrownException.getStatusCode().value());
    }

    @Test
    void testCreateIncomingFaxException() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        Exception exception = new RuntimeException("Test exception");

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(IncomingFaxResponse.class)).thenReturn(Mono.error(exception));

        Exception thrownException = assertThrows(Exception.class,
                () -> incomingFaxDAO.createIncomingFax(request));

        assertEquals("Test exception", thrownException.getMessage());
    }
    @Test
    void testCreateIncomingFax_httpStatus() {
        IncomingFaxRequest request = new IncomingFaxRequest();
        HttpClientErrorException httpStatusCodeException = HttpClientErrorException.create(
                HttpStatus.NOT_FOUND, "Not Found", null, null, null);


        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(IncomingFaxResponse.class)).thenReturn(Mono.error(httpStatusCodeException));

        HttpStatusCodeException thrownException = assertThrows(HttpStatusCodeException.class,
                () -> incomingFaxDAO.createIncomingFax(request));

        assertEquals(HttpStatus.NOT_FOUND, thrownException.getStatusCode());
        assertEquals("404 Not Found", thrownException.getMessage());
    }
    @Test
    void setRequestFieldsForIncomingFaxTest() {

        IncomingFaxRequest incomingFaxRequest = mock(IncomingFaxRequest.class);
        when(incomingFaxRequest.getName()).thenReturn("Name");
        when(incomingFaxRequest.getIncomingFaxNumber()).thenReturn("123456");
        when(incomingFaxRequest.getOutgoingFaxNumber()).thenReturn("654321");
        when(incomingFaxRequest.getReceivedDateTime()).thenReturn("2024-06-12T12:00:00");
        when(incomingFaxRequest.getNumberOfPages()).thenReturn("5");
        when(incomingFaxRequest.getDocument()).thenReturn("base64encodedstring");
        when(incomingFaxRequest.getDocumentName()).thenReturn("document.pdf");

        IncomingFaxDAO incomingFaxDAO = new IncomingFaxDAO();

        MultiValueMap<String, Object> result = ReflectionTestUtils.invokeMethod(
                incomingFaxDAO, "setRequestFieldsForIncomingFax", incomingFaxRequest);

        // Assertions
        assertEquals("Name", result.getFirst("name"));
        assertEquals("123456", result.getFirst("incomingFaxNumber"));
        assertEquals("654321", result.getFirst("OutgoingFaxNumber"));
        assertEquals("2024-06-12T12:00:00", result.getFirst("receivedDatetime"));
        assertEquals("5", result.getFirst("numberOfPages"));

        assertNotNull(result.getFirst("document"));

    }
}
