package com.usthealthproof.eplus.ext.appealsandgrievances.dao.util;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProblemDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class APIUtilsTest {
    @Mock
    private APIUtils apiUtils;
    ProblemDetails problemDetails = new ProblemDetails();
    private String usernameKey;
    private String passwordKey;
    private String userName;
    private String password;
    @BeforeEach
    void setUp() {

        apiUtils = new APIUtils();
        problemDetails = new ProblemDetails();
        problemDetails.setErrors(Arrays.asList("Error message"));

        // Inject values into apiUtils instance using ReflectionTestUtils
        ReflectionTestUtils.setField(apiUtils, "usernameKey", "usernameKey");
        ReflectionTestUtils.setField(apiUtils, "passwordKey", "passwordKey");
        ReflectionTestUtils.setField(apiUtils, "userName", "testUser");
        ReflectionTestUtils.setField(apiUtils, "password", "testPassword");

    }
    @Test
    void testCreateProblemDetails1() {
        // Given
        String status = "error";
        String errorMsg = "Error message";
        ProblemDetails expectedProblemDetails = new ProblemDetails();
        expectedProblemDetails.setStatus(status);
        expectedProblemDetails.setErrors(Arrays.asList(errorMsg));

        ProblemDetails result = apiUtils.createProblemDetails(status, errorMsg);

        Assertions.assertEquals(expectedProblemDetails.getErrors(), result.getErrors());
        Assertions.assertEquals(expectedProblemDetails.getStatus(), result.getStatus());
    }
    @Test
    void testGetHeaders(){
        HttpHeaders httpHeaders = new HttpHeaders();
        apiUtils.getHeaders().accept(httpHeaders);
        assertEquals("testUser", httpHeaders.getFirst("usernameKey"));
        assertEquals("testPassword", httpHeaders.getFirst("passwordKey"));

    }
}
