package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstantsTest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProblemDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.AppealsAndGrievanceService;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.ProviderAppealsService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@WebMvcTest(ProviderAppealsController.class)
public class ProviderAppealsControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AppealsAndGrievanceService appealsAndGrievanceService;

    @MockBean
    private Validator validator;

    private List<ProviderAppealsSummary> providerAppealsSummaries;
    @MockBean
    private ProblemDetails problemDetails;
    @MockBean
    private ProviderAppealsService providerAppealsService;
    @BeforeEach
    void setUp() {
        ProviderAppealsSummary providerAppealsSummary = new ProviderAppealsSummary();
        providerAppealsSummary.setComplaintID(AppealsAndGrievanceConstantsTest.COMPLAINT_ID_PROVIDER);
        providerAppealsSummary.setStatus(AppealsAndGrievanceConstantsTest.STATUS_PROVIDER);
        providerAppealsSummary.setRequestType(AppealsAndGrievanceConstantsTest.REQUEST_TYPE_PROVIDER);
        providerAppealsSummary.setComplaintType(AppealsAndGrievanceConstantsTest.COMPLAINT_TYPE_PROVIDER);
        providerAppealsSummary.setReceivedDate(AppealsAndGrievanceConstantsTest.RECEIVED_DATE_PROVIDER);
        providerAppealsSummary.setComplaintCategory(AppealsAndGrievanceConstantsTest.COMPLAINT_CATEGORY_PROVIDER);
        providerAppealsSummary.setMemberName(AppealsAndGrievanceConstantsTest.MEMBER_NAME_PROVIDER);
        providerAppealsSummary.setMemberId(AppealsAndGrievanceConstantsTest.MEMBER_ID_PROVIDER);

        providerAppealsSummaries = List.of(providerAppealsSummary);
    }

    @AfterEach
    void tearDown() {
        providerAppealsSummaries = null;
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Valid Provider Appeals Summary Request")
    void testGetProviderAppealsSummary_ValidRequest() throws Exception {
        List<ProviderAppealsSummary> mockResponse = new ArrayList<>();
        when(providerAppealsService.getProviderAppealsSummary(anyString())).thenReturn(mockResponse);

        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS)
                .param("providerId", "P00678")
                .param("complaintType", "appeal")
                .contentType(MediaType.APPLICATION_JSON));

        response.andDo(print())
                .andExpect(status().isOk());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid Provider Appeals Summary Request")
    void testGetProviderAppealsSummary_InvalidRequest() throws Exception {
        // Perform the request with invalid parameters
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS)
                .param("providerId", "<P00678>")
                .param("complaintType", "<abc>")
                .contentType(MediaType.APPLICATION_JSON));

        response.andDo(print())
                .andExpect(status().isBadRequest());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid ProviderID Request")
    void testGetProviderAppealsSummary_InvalidProviderId() throws Exception {
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS)
                        .param("providerId", "<P123>")
                        .param("complaintType", AppealsAndGrievanceConstantsTest.COMPLAINT_TYPE_PROVIDER))
                .andExpect(status().isBadRequest());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid ComplaintType Request")
    void testGetProviderAppealsSummary_InvalidComplaintType() throws Exception {
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS)
                        .param("providerId",AppealsAndGrievanceConstantsTest.PROVIDE_ID)
                        .param("complaintType", "<abc>"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid Provider Appeals Summary Request")
    void testGetProviderAppealsDetails_InvalidRequest() throws Exception {
        // Perform the request with invalid parameters
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS_DETAILS)
                .param("complaintId", "<D123>")
                .contentType(MediaType.APPLICATION_JSON));

        response.andDo(print())
                .andExpect(status().isBadRequest());
    }
    @Test
    @WithMockUser(value = "user")
    @DisplayName("JUnit test for - Invalid Provider Appeals Summary Request")
    void testGetProviderAppealsDetails_ValidRequest() throws Exception {
        // Perform the request with invalid parameters
        ResultActions response = mockMvc.perform(get(AppealsAndGrievanceConstantsTest.ENDPOINT_PROVIDER_APPEALS_DETAILS)
                .param("complaintId", "D12345678")
                .contentType(MediaType.APPLICATION_JSON));

        response.andDo(print())
                .andExpect(status().isOk());
    }


}
