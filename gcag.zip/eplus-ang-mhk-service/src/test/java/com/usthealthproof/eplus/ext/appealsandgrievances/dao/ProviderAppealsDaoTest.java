package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberGrievanceMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsSearchRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ProviderAppealsDaoTest {
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private Validator validator;
    @Mock
    private MemberGrievanceMapper memberGrievanceMapper;
    @InjectMocks
    private ProviderAppealsDao providerAppealsDao;
    @Value("${medhok.service.providerAppealsUri}")
    private String providerAppealsURI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(providerAppealsDao, "providerAppealsURI", "http://localhost:8080/provider/appeals");
        ReflectionTestUtils.setField(providerAppealsDao, "webClient", webClient);

        // Setup WebClient mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodySpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any(Consumer.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
    }

    @Test
    @DisplayName("JUnit test case for ProviderAppealsDao in DAO")
    void testGetProviderAppeals() throws Exception{
        String providerId = "12345";
        String complaintId = "67891";
        ServiceProviderAppealsSearchRequest request = new ServiceProviderAppealsSearchRequest();
        request.setProviderID(providerId);
        ServiceProviderAppealsResponse[] serviceProviderAppealsResponse = new ServiceProviderAppealsResponse[1];
        //Mocking API utils and validator
        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceProviderAppealsResponse[].class)).thenReturn(Mono.just(serviceProviderAppealsResponse));

        ServiceProviderAppealsResponse[] result = providerAppealsDao.getProviderAppeals(providerId,complaintId);

        verify(validator).validateServiceProviderAppealsResponse(serviceProviderAppealsResponse);
        assertNotNull(result);
        assertEquals(serviceProviderAppealsResponse, result);
    }
    @Test
    @DisplayName("JUnit test case for ProviderAppealsDao in DAO")
    void testGetProviderAppeals_() throws Exception{
        String providerId = "12345";
        String complaintId = "";
        ServiceProviderAppealsSearchRequest request = new ServiceProviderAppealsSearchRequest();
        request.setProviderID(providerId);
        ServiceProviderAppealsResponse[] serviceProviderAppealsResponse = new ServiceProviderAppealsResponse[1];
        //Mocking API utils and validator
        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceProviderAppealsResponse[].class)).thenReturn(Mono.just(serviceProviderAppealsResponse));

        ServiceProviderAppealsResponse[] result = providerAppealsDao.getProviderAppeals(providerId,complaintId);

        verify(validator).validateServiceProviderAppealsResponse(serviceProviderAppealsResponse);
        assertNotNull(result);
        assertEquals(serviceProviderAppealsResponse, result);
    }
    @Test
    @DisplayName("JUnit test case for MemberGrievanceDao_WebClientResponseException in DAO")
    void testGetProviderAppeals_WebClientResponseException() throws Exception {
        String provideId = "12345";
        String complaintId = "67891";
        ServiceProviderAppealsSearchRequest request = new ServiceProviderAppealsSearchRequest();
        request.setProviderID(provideId);
        WebClientResponseException responseException = WebClientResponseException.create(
                404, "Not Found", null, null, null);

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceProviderAppealsResponse[].class)).thenReturn(Mono.error(responseException));

        WebClientResponseException thrownException = assertThrows(WebClientResponseException.class,
                () -> providerAppealsDao.getProviderAppeals(provideId,complaintId));

        assertEquals(404, thrownException.getStatusCode().value());
    }
    @Test
    @DisplayName("JUnit test case for MemberGrievanceDao_Exception in DAO")
    void testGetMemberGrievancesException() {
        String providerId = "12345";
        String complaintId = "67891";
        ServiceProviderAppealsSearchRequest request = new ServiceProviderAppealsSearchRequest();
        request.setProviderID(providerId);
        Exception exception = new RuntimeException("Test exception");

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceProviderAppealsResponse[].class)).thenReturn(Mono.error(exception));

        Exception thrownException = assertThrows(Exception.class,
                () -> providerAppealsDao.getProviderAppeals(providerId,complaintId));

        assertEquals("Test exception", thrownException.getMessage());
    }
}
