package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberGrievanceMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
public class MemberGrievanceDaoTest {
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private Validator validator;
    @Mock
    private MemberGrievanceMapper memberGrievanceMapper;
    @InjectMocks
    private MemberGrievanceDao memberGrievanceDao;
    @Value("${medhok.service.memberGrievanceUri}")
    private String memberGreivanceURI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(memberGrievanceDao, "memberGreivanceURI", "validMemberGrievanceURI");
        ReflectionTestUtils.setField(memberGrievanceDao, "webClient", webClient);

        // Setup WebClient mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any(Consumer.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
    }
    @Test
    @DisplayName("JUnit test case for MemberGrievanceDao in DAO")
    void testGetMemberGrievancesSuccess() throws Exception {
        String memberId = "12345";
        ServiceMemberGreivancesRequest request = new ServiceMemberGreivancesRequest();
        request.setMemberID(memberId);
        ServiceMemberGreivancesResponse[] response = new ServiceMemberGreivancesResponse[1];

        // Mocking API utils and validator
        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceMemberGreivancesResponse[].class)).thenReturn(Mono.just(response));

        ServiceMemberGreivancesResponse[] result = memberGrievanceDao.getMemberGrievances(memberId);

        verify(validator).validateServiceMemberGreivanceResponse(response);
        assertNotNull(result);
        assertEquals(response, result);
    }
    @Test
    @DisplayName("JUnit test case for MemberGrievanceDao_WebClientResponseException in DAO")
    void testGetMemberGrievancesSuccess_WebClientResponseException() throws Exception {
        String memberId = "12345";
        ServiceMemberGreivancesRequest request = new ServiceMemberGreivancesRequest();
        request.setMemberID(memberId);
        WebClientResponseException responseException = WebClientResponseException.create(
                404, "Not Found", null, null, null);

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceMemberGreivancesResponse[].class)).thenReturn(Mono.error(responseException));

        WebClientResponseException thrownException = assertThrows(WebClientResponseException.class,
                () -> memberGrievanceDao.getMemberGrievances(memberId));

        assertEquals(404, thrownException.getStatusCode().value());
    }
    @Test
    @DisplayName("JUnit test case for MemberGrievanceDao_Exception in DAO")
    void testGetMemberGrievancesException() {
        String memberId = "12345";
        ServiceMemberGreivancesRequest request = new ServiceMemberGreivancesRequest();
        request.setMemberID(memberId);
        Exception exception = new RuntimeException("Test exception");

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(responseSpec.bodyToMono(ServiceMemberGreivancesResponse[].class)).thenReturn(Mono.error(exception));

        Exception thrownException = assertThrows(Exception.class,
                () -> memberGrievanceDao.getMemberGrievances(memberId));

        assertEquals("Test exception", thrownException.getMessage());
    }
}
