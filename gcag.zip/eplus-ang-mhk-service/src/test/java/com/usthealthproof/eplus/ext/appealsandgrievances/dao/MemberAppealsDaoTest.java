package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MemberAppealsDaoTest {
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private MemberAppealsMapper memberAppealsMapper;

    @Mock
    private Validator validator;

    @InjectMocks
    private MemberAppealsDao memberAppealsDao;

    private IncomingFaxRequest incomingFaxRequest;

    private IncomingFaxResponse incomingFaxResponse;
    @Value("${medhok.service.memberAppealsUri}")
    private String memberAppealsURI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(memberAppealsDao, "memberAppealsURI", "validMemberAppealURI");
        ReflectionTestUtils.setField(memberAppealsDao, "webClient", webClient);

        // Setup WebClient mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.headers(any(Consumer.class))).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
    }

    @Test
    @DisplayName("JUnit test case for MemberAppealsDao in DAO")
    void testGetMemberAppealsSuccess() throws Exception {
        String memberId = "12345";
        String complaintId = "67890";
        ServiceMemberAppealsRequest request = new ServiceMemberAppealsRequest();
        ServiceMemberAppealsResponse[] response = new ServiceMemberAppealsResponse[1];

        // Mocking API utils, mapper and validator
        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(memberAppealsMapper.memberAppealsRequestMapper(memberId, complaintId)).thenReturn(request);
        when(responseSpec.bodyToMono(ServiceMemberAppealsResponse[].class)).thenReturn(Mono.just(response));

        ServiceMemberAppealsResponse[] result = memberAppealsDao.getMemberAppeals(memberId, complaintId);

        verify(validator).validateServiceMemberAppealsResponse(response);
        assertNotNull(result);
        assertEquals(response, result);
    }
    @Test
    @DisplayName("JUnit test case for MemberAppealsDao_WebClientResponseException in DAO")
    void testGetMemberAppealsWebClientResponseException() {
        String memberId = "12345";
        String complaintId = "67890";
        ServiceMemberAppealsRequest request = new ServiceMemberAppealsRequest();
        WebClientResponseException responseException = WebClientResponseException.create(
                404, "Not Found", null, null, null);

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(memberAppealsMapper.memberAppealsRequestMapper(memberId, complaintId)).thenReturn(request);
        when(responseSpec.bodyToMono(ServiceMemberAppealsResponse[].class)).thenReturn(Mono.error(responseException));

        WebClientResponseException thrownException = assertThrows(WebClientResponseException.class,
                () -> memberAppealsDao.getMemberAppeals(memberId, complaintId));

        assertEquals(404, thrownException.getStatusCode().value());
    }

    @Test
    @DisplayName("JUnit test case for MemberAppealsDao_Exception in DAO")
    void testGetMemberAppealsException() {
        String memberId = "12345";
        String complaintId = "67890";
        ServiceMemberAppealsRequest request = new ServiceMemberAppealsRequest();
        Exception exception = new RuntimeException("Test exception");

        when(apiUtils.getHeaders()).thenReturn(httpHeaders -> {});
        when(memberAppealsMapper.memberAppealsRequestMapper(memberId, complaintId)).thenReturn(request);
        when(responseSpec.bodyToMono(ServiceMemberAppealsResponse[].class)).thenReturn(Mono.error(exception));

        Exception thrownException = assertThrows(Exception.class,
                () -> memberAppealsDao.getMemberAppeals(memberId, complaintId));

        assertEquals("Test exception", thrownException.getMessage());
    }
}
