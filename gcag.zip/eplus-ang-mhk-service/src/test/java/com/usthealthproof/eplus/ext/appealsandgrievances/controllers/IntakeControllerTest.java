package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import com.usthealthproof.eplus.ext.appealsandgrievances.configuration.SpringSecurityConfig;
import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstantsTest;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProblemDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.AppealsAndGrievanceService;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.IncomingFaxService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.ValidatorTest;
import io.micrometer.core.instrument.config.validate.ValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;


@WebMvcTest(IntakeController.class)
@Import(SpringSecurityConfig.class)
public class IntakeControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IncomingFaxService incomingFaxService;

    @MockBean
    private Validator validator;

    private IncomingFaxRequest incomingFaxRequest;
    private IncomingFaxResponse incomingFaxResponse;
    @Autowired
    private ObjectMapper objectMapper;
    @MockBean
    private ProblemDetails problemDetails;
    @BeforeEach
    public void setup() {
        incomingFaxRequest = new IncomingFaxRequest();
        incomingFaxResponse = new IncomingFaxResponse();
    }

    @Test
    @WithMockUser(value = "user")
    void testCreateIncomingFax_ValidInput() throws Exception {
        when(incomingFaxService.createIncomingFax(any(IncomingFaxRequest.class))).thenReturn(incomingFaxResponse);
        mockMvc.perform(post(AppealsAndGrievanceConstantsTest.ENDPOINT_INTAKE_CONTROLLER)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(incomingFaxRequest)))
                .andExpect(status().isOk());
    }

}






