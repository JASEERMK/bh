package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.User;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Member Appeals response received from the external service")
public class ServiceMemberAppealsResponse {

	private String caseNumber;
	private String category;
	private String subCategory;
	private String priority;
	private String status;
	private String receivedDate;
	private String decisionDate;
	private String intakeMode;
	private String appealType;
	private User updateUser;
	//Added as part of CPB-6161
	private String dueDate;
	private String intakeDate;
}
