package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Error Response class")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorResponse implements Serializable {

	private static final long serialVersionUID = 7575353493481964506L;
	@Schema(description = "Object to hold the error details")
	private ProblemDetails problemDetails;

}
