package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.net.URI;
import java.util.function.Consumer;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsSearchRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ProviderAppealsDao {

	@Autowired
	private WebClient webClient;
	@Autowired
	private APIUtils apiUtils;
	@Autowired
	Validator validator;

	@Value("${medhok.service.providerAppealsUri}")
	private String providerAppealsURI;

	public ServiceProviderAppealsResponse[] getProviderAppeals(String providerId, String complaintId) throws Exception {
		log.info("Inside getProviderAppeals() in DAO");

		ServiceProviderAppealsSearchRequest serviceProviderAppealsSearchRequest = new ServiceProviderAppealsSearchRequest();
		serviceProviderAppealsSearchRequest.setProviderID(providerId);
		ServiceProviderAppealsResponse[] serviceProviderAppealsResponses = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders();
			log.info("Going to call the MedHok ProviderDisputes service");
			long startServiceRequestTime = System.currentTimeMillis();
			if (StringUtils.isNotBlank(complaintId)) {
				URI providerAppealsURIs = URI.create(providerAppealsURI);
				URI uriWithQueryParam = UriComponentsBuilder.fromUri(providerAppealsURIs).queryParam("case", complaintId).build()
						.toUri();
				serviceProviderAppealsResponses = webClient.post().uri(uriWithQueryParam).headers(httpHeaders)
						.bodyValue(serviceProviderAppealsSearchRequest).retrieve()
						.bodyToMono(ServiceProviderAppealsResponse[].class).block();
			} else {
				serviceProviderAppealsResponses = webClient.post().uri(providerAppealsURI).headers(httpHeaders)
						.bodyValue(serviceProviderAppealsSearchRequest).retrieve()
						.bodyToMono(ServiceProviderAppealsResponse[].class).block();
			}
			validator.validateServiceProviderAppealsResponse(serviceProviderAppealsResponses);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the MedHok ProviderDisputes service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the ProviderAppeals responses for the request with requestId: {} and complaintId: {}",
					serviceProviderAppealsSearchRequest, complaintId);
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed receiving the ProviderAppeals responses for the request with requestId: {} and complaintId: {}",
					serviceProviderAppealsSearchRequest, complaintId);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed receiving the ProviderAppeals responses for the request with requestId: {}and complaintId: {}",
					serviceProviderAppealsSearchRequest, complaintId);
			throw exception;
		}
		return serviceProviderAppealsResponses;
	}

}
