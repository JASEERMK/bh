package com.usthealthproof.eplus.ext.appealsandgrievances.mapper;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.Member;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MemberAppealsMapper {

	public ServiceMemberAppealsRequest memberAppealsRequestMapper(String memberId, String complaintId) {
		log.info("Inside memberAppealsRequestMapper() in Mapper class");

		ServiceMemberAppealsRequest serviceMemberAppealsRequest = new ServiceMemberAppealsRequest();
		Member member = new Member();
		member.setMemberId(memberId);
		serviceMemberAppealsRequest.setMember(member);
		serviceMemberAppealsRequest.setCaseNumber(complaintId);
		return serviceMemberAppealsRequest;
	}

	public List<AppealsOrGrievanceSummary> memberAppealSearchResponseMapper(
			ServiceMemberAppealsResponse[] serviceAppealsSearchResponse) throws Exception {
		log.info("Inside memberAppealSearchResponseMapper() in mapper class");

		return Arrays.stream(serviceAppealsSearchResponse).map(memberAppeal -> {
			AppealsOrGrievanceSummary appealsSummary = new AppealsOrGrievanceSummary();
			appealsSummary.setComplaintID(memberAppeal.getCaseNumber());
			appealsSummary.setStatus(memberAppeal.getStatus());
			appealsSummary.setPriority(memberAppeal.getPriority());
			appealsSummary.setComplaintCategory(memberAppeal.getCategory());
			appealsSummary.setComplaintSubCategory(memberAppeal.getSubCategory());
			appealsSummary.setReceivedDate(memberAppeal.getReceivedDate());
			return appealsSummary;
		}).collect(Collectors.toList());
	}

	public AppealsOrGrievanceDetails memberAppealDetailsResponseMapper(
			ServiceMemberAppealsResponse[] serviceMemberAppealsResponses) throws Exception {
		log.info("Inside memberAppealDetailsResponseMapper() in mapper class");

		if (serviceMemberAppealsResponses.length > 1) {
			log.info("ServiceMemberAppealsResponse size greater than one");
			throw new Exception(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED);
		} else {
			return Arrays.stream(serviceMemberAppealsResponses).map(memberAppeal -> {
				AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
				appealsOrGrievanceDetails.setComplaintID(memberAppeal.getCaseNumber());
				appealsOrGrievanceDetails.setComplaintCategory(memberAppeal.getCategory());
				appealsOrGrievanceDetails.setComplaintSubCategory(memberAppeal.getSubCategory());
				appealsOrGrievanceDetails.setPriority(memberAppeal.getPriority());
				appealsOrGrievanceDetails.setStatus(memberAppeal.getStatus());
				appealsOrGrievanceDetails.setReceivedDate(memberAppeal.getReceivedDate());
				appealsOrGrievanceDetails.setCreatedDate(memberAppeal.getIntakeDate());

				if (StringUtils.equalsIgnoreCase(memberAppeal.getStatus(), "Resolved") && (
						StringUtils.isNotBlank(memberAppeal.getDueDate()) && StringUtils.isNotBlank(
								memberAppeal.getIntakeDate()))) {
					String dueDate = memberAppeal.getDueDate();
					String[] dueDateSplitted = dueDate.split("T");
					String intakeDate = memberAppeal.getIntakeDate();
					String[] intakeDateSplitted = intakeDate.split("T");
					LocalDate dueDateConverted = LocalDate.parse(dueDateSplitted[0]);
					LocalDate intakeDateConverted = LocalDate.parse(intakeDateSplitted[0]);
					long caseAge = ChronoUnit.DAYS.between(intakeDateConverted, dueDateConverted);
					if (caseAge < 0) {
						log.info("caseAge value is: {} as the intakeDate is greater than dueDate", caseAge);
						throw new InternalException();
					}
					appealsOrGrievanceDetails.setCaseAge(String.valueOf((int) caseAge));
				} else if (StringUtils.isNotBlank(memberAppeal.getIntakeDate())) {
					LocalDate currentDate = LocalDate.now();
					String intakeDate = memberAppeal.getIntakeDate();
					String[] intakeDateSplitted = intakeDate.split("T");
					LocalDate intakeDateConverted = LocalDate.parse(intakeDateSplitted[0]);
					long caseAge = ChronoUnit.DAYS.between(intakeDateConverted, currentDate);
					if (caseAge < 0) {
						log.info("caseAge value is: {} as the intakeDate is greater than currentDate", caseAge);
						throw new InternalException();
					}
					appealsOrGrievanceDetails.setCaseAge(String.valueOf((int) caseAge));
				}

				appealsOrGrievanceDetails.setComplaintStatus(memberAppeal.getStatus());
				appealsOrGrievanceDetails.setContactChannel(memberAppeal.getIntakeMode());
				appealsOrGrievanceDetails.setServiceType(memberAppeal.getAppealType());
				if (null != memberAppeal.getUpdateUser()) {
					appealsOrGrievanceDetails.setStaffName(memberAppeal.getUpdateUser().getLastName());
				}
				return appealsOrGrievanceDetails;
			}).findFirst().orElseThrow(() -> {
				log.info("No data found for the requested complaintId");
				throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND);
			});
		}
	}
}
