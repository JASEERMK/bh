package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ErrorResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.IncomingFaxService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/ang")
@Tag(name = "Intake")
@Validated
@Slf4j
@SecurityRequirement(name = "Appeals and Grievances")
public class IntakeController {

    @Autowired
    IncomingFaxService incomingFaxService;
    @Autowired
    Validator validator;

    @Operation(summary = "Store incoming Fax", method = "POST", description = "Service to create Provider Disputes, Member Appeals and Member Grievances", responses = {
            @ApiResponse(responseCode = "200", description = "IncomingFax Response", content = {
                    @Content(array = @ArraySchema(schema = @Schema(implementation = IncomingFaxResponse.class))) }),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @PostMapping(value = "/intake", produces = { MediaType.APPLICATION_JSON_VALUE })

    public ResponseEntity<IncomingFaxResponse> createIncomingFax(@RequestBody IncomingFaxRequest incomingFaxRequest) {
        validator.validateIncomingFaxRequest(incomingFaxRequest);
        log.info("Inside createIncomingFax() in controller");
        return new ResponseEntity<>(incomingFaxService.createIncomingFax(incomingFaxRequest), HttpStatus.OK);
    }
}
