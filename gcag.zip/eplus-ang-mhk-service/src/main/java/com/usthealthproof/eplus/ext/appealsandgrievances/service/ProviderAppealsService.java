package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.ProviderAppealsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.ProviderAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProviderAppealsService {

	@Autowired
	Validator validator;
	@Autowired
	ProviderAppealsDao providerAppealsDao;
	@Autowired
	ProviderAppealsMapper providerAppealsMapper;

	public List<ProviderAppealsSummary> getProviderAppealsSummary(String providerId) throws Exception {
		log.info("Inside getAppealsSummary() in service class");
		ServiceProviderAppealsResponse[] serviceProviderAppealsSearchResponses = providerAppealsDao.getProviderAppeals(providerId,
				null);
		return providerAppealsMapper.providerAppealsSearchResponseMapper(serviceProviderAppealsSearchResponses);
	}

	public ProviderAppealsDetails getProviderAppealDetails(String complaintId) throws Exception {
		log.info("Inside getProviderAppealsDetails() in service class");
		ServiceProviderAppealsResponse[] serviceProviderAppealsDetailsResponses = providerAppealsDao.getProviderAppeals(null,
				complaintId);
		return providerAppealsMapper.providerAppealsDetailsResponseMapper(serviceProviderAppealsDetailsResponses);
	}

}
