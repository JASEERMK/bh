package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding Member Grievance request received for the external service")
public class ServiceMemberGreivancesRequest {

	private String memberID;
	private String fromDate;
	private String thruDate;
}
