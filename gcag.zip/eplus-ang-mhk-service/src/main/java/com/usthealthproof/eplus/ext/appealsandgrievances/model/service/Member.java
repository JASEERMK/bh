package com.usthealthproof.eplus.ext.appealsandgrievances.model.service;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding member details received from the external service")
public class Member {

	private String memberId;
	private String firstName;
	private String lastName;
	private String fullName;

}
