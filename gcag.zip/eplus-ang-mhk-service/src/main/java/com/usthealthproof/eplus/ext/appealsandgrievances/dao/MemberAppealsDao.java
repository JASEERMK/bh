package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.util.function.Consumer;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class MemberAppealsDao {

	@Autowired
	private WebClient webClient;
	@Autowired
	private APIUtils apiUtils;
	@Autowired
	private Validator validator;
	@Autowired
	private MemberAppealsMapper memberAppealsMapper;

	@Value("${medhok.service.memberAppealsUri}")
	private String memberAppealsURI;

	public ServiceMemberAppealsResponse[] getMemberAppeals(String memberId, String complaintId) throws Exception {
		log.info("Inside getMemberAppeals() in DAO class");

		ServiceMemberAppealsRequest serviceMemberAppealsRequest = memberAppealsMapper.memberAppealsRequestMapper(memberId,
				complaintId);
		ServiceMemberAppealsResponse[] serviceMemberAppealsResponses = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders();
			log.info("Going to call the MedHok AppealsByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			serviceMemberAppealsResponses = webClient.post().uri(memberAppealsURI).headers(httpHeaders)
					.bodyValue(serviceMemberAppealsRequest).retrieve().bodyToMono(ServiceMemberAppealsResponse[].class).block();
			validator.validateServiceMemberAppealsResponse(serviceMemberAppealsResponses);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the MedHok AppealsByCriteria service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			log.info("Successfully received the Member Appeals response for the request with memberId: {} or complaintId {}",
					memberId, complaintId);
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Member Appeals response for the request with memberId: {} or complaintId {}",
					memberId, complaintId);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Member Appeals response for the request with memberId: {} or complaintId {}",
					memberId, complaintId);
			throw exception;
		}
		return serviceMemberAppealsResponses;
	}

}
