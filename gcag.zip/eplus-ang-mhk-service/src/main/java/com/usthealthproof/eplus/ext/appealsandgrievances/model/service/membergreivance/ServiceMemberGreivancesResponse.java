package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding Member Grievance response received from the external service")
public class ServiceMemberGreivancesResponse {

	private String grievanceNo;
	private String grievanceType;
	private String grievanceSubType;
	private String priority;
	private String grievanceStatus;
	private String caseReceivedDate;
	private String caseCreateDate;
	// As part of API-98
	private String intakeDate;
	private String requestedBy;
	private String caseDueDate;
	private String dateOfOccurance;
	private String finalResolutionCaseNote;

}
