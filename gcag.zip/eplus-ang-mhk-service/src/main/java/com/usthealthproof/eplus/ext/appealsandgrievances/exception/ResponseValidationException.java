package com.usthealthproof.eplus.ext.appealsandgrievances.exception;

public class ResponseValidationException extends RuntimeException {

	private static final long serialVersionUID = -2625891751125517298L;

	public ResponseValidationException(String message) {
		super(message);
	}

}
