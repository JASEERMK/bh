package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.Member;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.User;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding Provider Appeals response received from the external service")
public class ServiceProviderAppealsResponse {

	private String caseNumber;
	private String category;
	private String subCategory;
	private String priority;
	private String status;
	private String receivedDate;
	private String dueDate;
	private String intakeMode;
	private String requestType;
	private Aor aor;
	private User updateUser;
	private String statusReason;
	private String product;
	private String decisionDate;
	private String disputeType;
	private Member member;

}
