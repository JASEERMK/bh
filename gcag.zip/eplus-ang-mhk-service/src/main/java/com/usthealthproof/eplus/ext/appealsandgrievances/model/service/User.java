package com.usthealthproof.eplus.ext.appealsandgrievances.model.service;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding user details received from the external service")
public class User {
	private String lastName;
	private String firstName;
}
