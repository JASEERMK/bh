package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal;

import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.Member;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Object for holding Member Appeals request for calling the external service")
public class ServiceMemberAppealsRequest {

	private Member member;
	private String fromDate;
	private String thruDate;
	private String caseNumber;

}
