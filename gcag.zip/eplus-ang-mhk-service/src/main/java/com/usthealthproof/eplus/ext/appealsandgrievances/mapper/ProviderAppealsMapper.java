package com.usthealthproof.eplus.ext.appealsandgrievances.mapper;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.Aor;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsSummary;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ProviderAppealsMapper {

	public List<ProviderAppealsSummary> providerAppealsSearchResponseMapper(
			ServiceProviderAppealsResponse[] serviceProviderAppealsSearchResponses) throws Exception {
		log.info("Inside providerAppealsSearchResponseMapper() in mapper class");

		return Arrays.stream(serviceProviderAppealsSearchResponses).map(providerAppeals -> {
			ProviderAppealsSummary providerAppealsSummary = new ProviderAppealsSummary();
			providerAppealsSummary.setComplaintID(providerAppeals.getCaseNumber());
			providerAppealsSummary.setStatus(providerAppeals.getStatus());
			providerAppealsSummary.setRequestType(providerAppeals.getRequestType());
			providerAppealsSummary.setComplaintType(providerAppeals.getDisputeType());
			providerAppealsSummary.setReceivedDate(providerAppeals.getReceivedDate());
			providerAppealsSummary.setComplaintCategory(providerAppeals.getCategory());
			if (null != providerAppeals.getMember()) {
				providerAppealsSummary.setMemberId(providerAppeals.getMember().getMemberId());
				providerAppealsSummary.setMemberName(providerAppeals.getMember().getFullName());
			}
			return providerAppealsSummary;
		}).collect(Collectors.toList());
	}

	public ProviderAppealsDetails providerAppealsDetailsResponseMapper(
			ServiceProviderAppealsResponse[] serviceProviderAppealsDetails) throws Exception {
		log.info("Inside providerAppealsDetailsResponseMapper() in Mapper class");

		if (serviceProviderAppealsDetails.length > 1) {
			log.info("ServiceProviderAppealsResponse size greater than one");
			throw new ResponseValidationException(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED);
		}
		ServiceProviderAppealsResponse serviceProviderAppealResponse = serviceProviderAppealsDetails[0];
		ProviderAppealsDetails providerAppeals = new ProviderAppealsDetails();
		providerAppeals.setComplaintID(serviceProviderAppealResponse.getCaseNumber());
		providerAppeals.setComplaintCategory(serviceProviderAppealResponse.getCategory());
		providerAppeals.setComplaintSubCategory(serviceProviderAppealResponse.getSubCategory());
		providerAppeals.setPriority(serviceProviderAppealResponse.getPriority());
		providerAppeals.setComplaintStatus(serviceProviderAppealResponse.getStatus());
		providerAppeals.setReceivedDate(serviceProviderAppealResponse.getReceivedDate());
		providerAppeals.setDueDate(serviceProviderAppealResponse.getDueDate());
		providerAppeals.setIntakeMode(serviceProviderAppealResponse.getIntakeMode());
		providerAppeals.setRequestType(serviceProviderAppealResponse.getRequestType());
		if (null != serviceProviderAppealResponse.getUpdateUser()) {
			providerAppeals.setOwnerFirstName(serviceProviderAppealResponse.getUpdateUser().getFirstName());
			providerAppeals.setOwnerLastName(serviceProviderAppealResponse.getUpdateUser().getLastName());
		}
		providerAppeals.setComplaintStatusReason(serviceProviderAppealResponse.getStatusReason());
		providerAppeals.setProduct(serviceProviderAppealResponse.getProduct());
		providerAppeals.setDecisionDate(serviceProviderAppealResponse.getDecisionDate());
		if (StringUtils.isBlank(serviceProviderAppealResponse.getDecisionDate()) && StringUtils.isNotBlank(
				serviceProviderAppealResponse.getReceivedDate())) {
			LocalDate sysDate = LocalDate.now();
			String reveiveDateTime = serviceProviderAppealResponse.getReceivedDate();
			String[] dateTimeSplitted = reveiveDateTime.split("T");
			String dateString = dateTimeSplitted[0];

			LocalDate receivedDate = LocalDate.parse(dateString);

			long caseAge = ChronoUnit.DAYS.between(receivedDate, sysDate);
			if (caseAge < 0) {
				log.info("caseAge value is: {} as the receivedDate is greater than currentDate", caseAge);
				throw new Exception(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED);
			}
			providerAppeals.setComplaintAge(String.valueOf((int) caseAge));
		} else if (StringUtils.isNotBlank(serviceProviderAppealResponse.getReceivedDate()) && StringUtils.isNotBlank(
				serviceProviderAppealResponse.getDecisionDate())) {
			String receiveDateTime = serviceProviderAppealResponse.getReceivedDate();
			String[] dateTimeSplitted = receiveDateTime.split("T");
			String recveiveDate = dateTimeSplitted[0];

			String decisionDateTime = serviceProviderAppealResponse.getDecisionDate();
			String[] decisionDateSplitted = decisionDateTime.split("T");
			String dateString = decisionDateSplitted[0];

			LocalDate receivedDateConverted = LocalDate.parse(recveiveDate);
			LocalDate decisionDate = LocalDate.parse(dateString);

			long caseAge = ChronoUnit.DAYS.between(receivedDateConverted, decisionDate);
			if (caseAge < 0) {
				log.info("caseAge value is: {} as the receivedDate is greater than decisionDate", caseAge);
				throw new Exception(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED);
			}
			providerAppeals.setComplaintAge(String.valueOf((int) caseAge));
		}
		providerAppeals.setComplaintType(serviceProviderAppealResponse.getDisputeType());
		if (null != serviceProviderAppealResponse.getMember()) {
			providerAppeals.setMemberId(serviceProviderAppealResponse.getMember().getMemberId());
			providerAppeals.setMemberName(serviceProviderAppealResponse.getMember().getFullName());
		}
		if (null != serviceProviderAppealResponse.getAor()) {
			Aor aor = serviceProviderAppealResponse.getAor();
			String firstName = "";
			String lastName = "";
			if (StringUtils.isNotBlank(aor.getFirstName())) {
				firstName = aor.getFirstName();
				providerAppeals.setRequesterFirstName(firstName);
			}
			if (StringUtils.isNotBlank(aor.getLastName())) {
				lastName = aor.getLastName();
				providerAppeals.setRequesterLastName(lastName);
			}
			if (StringUtils.isNotBlank(firstName) && StringUtils.isNotBlank(lastName)) {
				providerAppeals.setRequesterName(firstName + " " + lastName);
			} else if (StringUtils.isNotBlank(firstName)) {
				providerAppeals.setRequesterName(firstName);
			} else {
				providerAppeals.setRequesterName(lastName);
			}
		}
		return providerAppeals;
	}
}
