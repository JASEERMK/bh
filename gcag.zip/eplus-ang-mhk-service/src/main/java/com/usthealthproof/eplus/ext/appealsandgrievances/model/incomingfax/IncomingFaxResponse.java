package com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response object for Incoming Fax Service")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IncomingFaxResponse {

    @Schema(description = "Response Status, possible values are SUCCESS/FAILURE")
    private String status;
    @Schema(description = "Incoming ID")
    private String incomingId;
    @Schema(description = "Base 64 encoded ID returned from the service")
    private String documentId;


}
