package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import java.util.List;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ErrorResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.ProviderAppealsSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.ProviderAppealsService;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/ang")
@RestController
@Validated
@Tag(name = "Provider Appeals")
@Slf4j
@SecurityRequirement(name = "Appeals and Grievances")
public class ProviderAppealsController {

	@Autowired
	Validator validator;
	@Autowired
	ProviderAppealsService providerAppealsService;

	/**
	 * Service retrieves Provider Appeals summary for given providerId
	 *
	 * @param providerId
	 * @param complaintType
	 * @return ProviderAppeals List
	 */
	@Operation(summary = "Get Provider Appeals summary", method = "GET", description = "Service for retrieving all Appeals summary based on complaint type of a provider", responses = {
			@ApiResponse(responseCode = "200", description = "Appeals/Grievances summary response", content = {
					@Content(array = @ArraySchema(schema = @Schema(implementation = ProviderAppealsSummary.class))) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/provider/complaints", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<ProviderAppealsSummary>> getProviderAppealsSummary(
			@RequestParam(value = "providerId", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: providerId is not in valid format") String providerId,
			@RequestParam(value = "complaintType", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: complaintType is not in valid format") String complaintType)
			throws Exception {
		log.info("Inside getProviderAppealsSummary() in controller class");
		validator.validateProviderAppealsSummary(providerId, complaintType);
		return new ResponseEntity<>(providerAppealsService.getProviderAppealsSummary(providerId), HttpStatus.OK);
	}

	/**
	 * Service retrieves Provider Appeals details for given complaintId
	 *
	 * @param complaintId
	 *
	 * @return ProviderAppeals
	 */
	@Operation(summary = "Get Provider Appeals details", description = "Service for retrieving provider Appeals details of a particular complaint ", responses = {
			@ApiResponse(responseCode = "200", description = "Appeals/Grievances details response", content = {
					@Content(schema = @Schema(implementation = ProviderAppealsDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/provider/complaint/details", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<ProviderAppealsDetails> getProviderAppealsDetails(
			@RequestParam(value = "complaintId", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: complaintId is not in valid format") String complaintId)
			throws Exception {
		log.info("Inside getProviderAppealsDetails() in controller class");
		validator.validateMemberAppealsAndGrievancesDetails(complaintId);
		return new ResponseEntity<>(providerAppealsService.getProviderAppealDetails(complaintId), HttpStatus.OK);
	}
}
