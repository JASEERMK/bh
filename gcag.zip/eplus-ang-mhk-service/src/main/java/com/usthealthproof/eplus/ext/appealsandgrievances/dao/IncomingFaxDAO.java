package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Base64;
import java.util.function.Consumer;

import static org.apache.commons.lang3.StringUtils.strip;

@Repository
@Slf4j
public class IncomingFaxDAO {

    @Value("${medhok.service.incomingFaxUri}")
    private String incomingFaxURI;
    @Autowired
    private WebClient webClient;
    @Autowired
    private Validator validator;
    @Autowired
    private APIUtils apiUtils;

    public IncomingFaxResponse createIncomingFax(IncomingFaxRequest incomingFaxRequest) {
        log.info("Inside createIncomingFax() in DAO");

        IncomingFaxResponse incomingFaxResponse = null;
        try {
            MultiValueMap<String, Object> requestFieldMap = setRequestFieldsForIncomingFax(incomingFaxRequest);
            Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders();
            log.info("Going to call the MedHok Intake service");
            long startServiceRequestTime = System.currentTimeMillis();
            incomingFaxResponse = webClient.post().uri(incomingFaxURI).headers(httpHeaders)
                    .contentType(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromMultipartData(requestFieldMap)).retrieve().bodyToMono(IncomingFaxResponse.class)
                    .block();

            long endServiceRequestTime = System.currentTimeMillis();
            log.info("Execution time of the MedHok Intake service : {} ms", endServiceRequestTime - startServiceRequestTime);
            validator.validateIncomingFaxResponse(incomingFaxResponse);
            incomingFaxResponse.setStatus(AppealsAndGrievanceConstants.SUCCESS);
            log.info("Incoming ID: {} Document ID: {}", incomingFaxResponse.getIncomingId(), incomingFaxResponse.getDocumentId());
            log.info("Succesfully received the IncomingFax details for the request : {}", incomingFaxRequest);
        } catch (HttpStatusCodeException httpStatusCodeException) {
            log.info("Failed to receive the IncomingFax details for the request : {}", incomingFaxRequest);
            throw httpStatusCodeException;
        } catch (Exception exception) {
            log.info("Failed to receive the IncomingFax details for the request : {}", incomingFaxRequest);
            throw exception;
        }
        return incomingFaxResponse;
    }

    private MultiValueMap<String, Object> setRequestFieldsForIncomingFax(IncomingFaxRequest incomingFaxRequest)
            throws IllegalStateException {
        log.info("Inside setRequestFieldsForIncomingFax() in DAO");

        MultiValueMap<String, Object> requestFieldMap = new LinkedMultiValueMap<>();
        if (StringUtils.isNotBlank(incomingFaxRequest.getName())) {
            requestFieldMap.add("name", strip(incomingFaxRequest.getName()));
        }
        if (StringUtils.isNotBlank(incomingFaxRequest.getIncomingFaxNumber())) {
            requestFieldMap.add("incomingFaxNumber", strip(incomingFaxRequest.getIncomingFaxNumber()));
        }
        if (StringUtils.isNotBlank(incomingFaxRequest.getOutgoingFaxNumber())) {
            requestFieldMap.add("OutgoingFaxNumber", strip(incomingFaxRequest.getOutgoingFaxNumber()));
        }
        if (StringUtils.isNotBlank(incomingFaxRequest.getReceivedDateTime())) {
            requestFieldMap.add("receivedDatetime", strip(incomingFaxRequest.getReceivedDateTime()));
        }
        if (StringUtils.isNotBlank(incomingFaxRequest.getNumberOfPages()) && !StringUtils.equals(
                incomingFaxRequest.getNumberOfPages(), "0")) {
            requestFieldMap.add("numberOfPages", strip(incomingFaxRequest.getNumberOfPages()));
        } else {
            requestFieldMap.add("numberOfPages", "1");
        }
        if (null != incomingFaxRequest.getDocument()) {
            byte[] documentBytes = Base64.getDecoder().decode(incomingFaxRequest.getDocument().getBytes());
            HttpHeaders documentHeader = new HttpHeaders();
            documentHeader.setContentType(MediaType.APPLICATION_PDF);
            final ByteArrayResource documentByteArrayResource = new ByteArrayResource(documentBytes) {
                @Override
                public String getFilename() {
                    return incomingFaxRequest.getDocumentName();
                }
            };
            final HttpEntity<ByteArrayResource> partsEntity = new HttpEntity<>(documentByteArrayResource, documentHeader);
            requestFieldMap.add("document", partsEntity);
        }
        log.info("Successfully mapped the incoming requests into the map for requesting the service");
        return requestFieldMap;
    }

}
