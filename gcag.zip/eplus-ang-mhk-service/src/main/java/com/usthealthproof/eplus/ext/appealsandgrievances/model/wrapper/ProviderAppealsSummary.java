package com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Provider Appeals Summary")
@JsonInclude(value = Include.NON_EMPTY)
public class ProviderAppealsSummary {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Request Type")
	private String requestType;
	@Schema(description = "Complaint Type")
	private String complaintType;
	@Schema(description = "Receive Date time")
	private String receivedDate;
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "Member Name")
	private String memberName;
	@Schema(description = "Member Id")
	private String memberId;

}
