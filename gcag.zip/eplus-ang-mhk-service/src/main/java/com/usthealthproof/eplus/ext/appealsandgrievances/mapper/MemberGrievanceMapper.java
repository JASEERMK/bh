package com.usthealthproof.eplus.ext.appealsandgrievances.mapper;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MemberGrievanceMapper {
	@Autowired
	Validator validator;

	public List<AppealsOrGrievanceSummary> memberGrievancesSearchMapper(
			ServiceMemberGreivancesResponse[] serviceGreivanceResponses) throws Exception {
		log.info("Inside memberGreivanceSearchMapper() in mapper class");

		return Arrays.stream(serviceGreivanceResponses).map(memberGreivance -> {
			AppealsOrGrievanceSummary grievanceSummary = new AppealsOrGrievanceSummary();
			grievanceSummary.setComplaintID(memberGreivance.getGrievanceNo());
			grievanceSummary.setStatus(memberGreivance.getGrievanceStatus());
			grievanceSummary.setPriority(memberGreivance.getPriority());
			grievanceSummary.setComplaintCategory(memberGreivance.getGrievanceType());
			grievanceSummary.setComplaintSubCategory(memberGreivance.getGrievanceSubType());
			grievanceSummary.setReceivedDate(memberGreivance.getIntakeDate());
			return grievanceSummary;
		}).collect(Collectors.toList());
	}

	public AppealsOrGrievanceDetails memberGreivanceDetailsMapper(String complaintId,
			ServiceMemberGreivancesResponse[] serviceGreivanceResponses) throws Exception {
		log.info("Inside memberGreivanceDetailsMapper() in mapper class");

		Optional<ServiceMemberGreivancesResponse> memberGreivance = Arrays.stream(serviceGreivanceResponses).filter(
				memberGreivanceDetails -> StringUtils.equalsIgnoreCase(complaintId, memberGreivanceDetails.getGrievanceNo()))
				.findFirst();
		AppealsOrGrievanceDetails memberGreivanceDetailsResponse = new AppealsOrGrievanceDetails();
		memberGreivanceDetailsResponse.setComplaintID(memberGreivance.get().getGrievanceNo());
		memberGreivanceDetailsResponse.setComplaintCategory(memberGreivance.get().getGrievanceType());
		memberGreivanceDetailsResponse.setComplaintSubCategory(memberGreivance.get().getGrievanceSubType());
		memberGreivanceDetailsResponse.setPriority(memberGreivance.get().getPriority());
		memberGreivanceDetailsResponse.setStatus(memberGreivance.get().getGrievanceStatus());
		memberGreivanceDetailsResponse.setReceivedDate(memberGreivance.get().getIntakeDate());
		memberGreivanceDetailsResponse.setCreatedDate(memberGreivance.get().getCaseCreateDate());
		memberGreivanceDetailsResponse.setComplaintStatus(memberGreivance.get().getGrievanceStatus());
		//		As part of API-98
		memberGreivanceDetailsResponse.setRequestor(memberGreivance.get().getRequestedBy());
		memberGreivanceDetailsResponse.setResolutionDate(memberGreivance.get().getCaseDueDate());
		memberGreivanceDetailsResponse.setResolutionCategory(memberGreivance.get().getGrievanceType());
		memberGreivanceDetailsResponse.setResolutionSubCategory(memberGreivance.get().getGrievanceSubType());
		memberGreivanceDetailsResponse.setIncidentDate(memberGreivance.get().getDateOfOccurance());
		memberGreivanceDetailsResponse.setResolutionNotes(memberGreivance.get().getFinalResolutionCaseNote());
		if (StringUtils.equalsIgnoreCase(memberGreivance.get().getGrievanceStatus(), "Resolved") && (
				StringUtils.isNotBlank(memberGreivance.get().getCaseDueDate()) && StringUtils.isNotBlank(
						memberGreivance.get().getIntakeDate()))) {
			String caseDueDate = memberGreivance.get().getCaseDueDate();
			String[] caseDueDateSplitted = caseDueDate.split("T");
			String intakeDate = memberGreivance.get().getIntakeDate();
			String[] intakeDateSplitted = intakeDate.split("T");
			LocalDate caseDueDateConverted = LocalDate.parse(caseDueDateSplitted[0]);
			LocalDate intakeDateConverted = LocalDate.parse(intakeDateSplitted[0]);
			long caseAge = ChronoUnit.DAYS.between(intakeDateConverted, caseDueDateConverted);
			if (caseAge < 0) {
				log.info("caseAge value is: {} as the intakeDate is greater than caseDueDate", caseAge);
				throw new InternalException();
			}
			memberGreivanceDetailsResponse.setCaseAge(String.valueOf((int) caseAge));
		}else if (StringUtils.isNotBlank(memberGreivance.get().getIntakeDate())){
			LocalDate currentDate = LocalDate.now();
			String intakeDate = memberGreivance.get().getIntakeDate();
			String[] intakeDateSplitted = intakeDate.split("T");
			LocalDate intakeDateConverted = LocalDate.parse(intakeDateSplitted[0]);
			long caseAge = ChronoUnit.DAYS.between(intakeDateConverted, currentDate);
			if (caseAge < 0) {
				log.info("caseAge value is: {} as the intakeDate is greater than currentDate", caseAge);
				throw new InternalException();
			}
			memberGreivanceDetailsResponse.setCaseAge(String.valueOf((int) caseAge));
		}
		return memberGreivanceDetailsResponse;
	}

}
