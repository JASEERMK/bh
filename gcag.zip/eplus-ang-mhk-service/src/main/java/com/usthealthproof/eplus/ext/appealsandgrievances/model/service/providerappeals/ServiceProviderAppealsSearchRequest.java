package com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals;

import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
public class ServiceProviderAppealsSearchRequest {

	@Schema(description = "providerId")
	private String providerID;
}
