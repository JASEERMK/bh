package com.usthealthproof.eplus.ext.appealsandgrievances.constants;

public final class AppealsAndGrievanceConstants {

	private AppealsAndGrievanceConstants() {
	}

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String MEMBER_ID_NOT_FOUND = "Invalid Request: MemberId is mandatory";
	public static final String COMPLAINT_TYPE_NOT_FOUND = "Invalid Request: ComplaintType is mandatory";
	public static final String INVALID_COMPLAINT_TYPE = "Invalid complaint type";
	public static final String COMPLAINT_ID_NOT_FOUND = "complaint id is not found in the request";
	public static final String PROVIDER_ID_COMPLAINT_TYPE_NOT_FOUND = "Provider id or Complaint Type is not found in the request";
	public static final String EXCEPTION_OCCURRED = "Something went wrong, please check the log for more details.";
	public static final String NO_DATA_FOUND = "No data found";
	public static final String DENTAL_APPEAL = "DentalAppeal";
	public static final String RX_MEDICAL_APPEAL = "PharmacyMedicalAppeal";
	public static final String MEDICAL_APPEAL = "MedicalAppeal";
	public static final String RX_RETAIL_APPEAL = "PharmacyRetailAppeal";
	public static final String VISION_APPEAL = "VisionAppeal";
	public static final String GRIEVANCE_TYPE = "Grievance";
	public static final String APPEAL = "APPEAL";
	public static final String SIZE_GREATER = "Size of response greter than one";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";
	public static final String PROVIDER_ID_NOT_FOUND = "Invalid Request: ProviderId is mandatory";
}
