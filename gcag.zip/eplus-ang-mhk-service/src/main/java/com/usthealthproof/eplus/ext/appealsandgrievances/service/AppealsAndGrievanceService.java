package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.MemberAppealsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.MemberGrievanceDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberAppealsMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.mapper.MemberGrievanceMapper;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AppealsAndGrievanceService {

	@Autowired
	MemberAppealsDao memberAppealsDao;
	@Autowired
	MemberGrievanceDao memberGrievanceDao;
	@Autowired
	Validator validator;
	@Autowired
	private MemberAppealsMapper memberAppealsMapper;
	@Autowired
	private MemberGrievanceMapper memberGrievanceMapper;

	public List<AppealsOrGrievanceSummary> getAppealsOrGrievanceSummary(String memberId, String complaintType) throws Exception {
		log.info("Inside getAppealsOrGrievanceSummary() in service class");

		if (StringUtils.equalsIgnoreCase(complaintType, "Appeal")) {
			log.info("call for memberAppealsSearchDAO");
			ServiceMemberAppealsResponse[] serviceMemberSearchAppealsResponses = memberAppealsDao.getMemberAppeals(memberId,
					null);
			return memberAppealsMapper.memberAppealSearchResponseMapper(serviceMemberSearchAppealsResponses);
		} else if (StringUtils.equalsIgnoreCase(complaintType, "Grievance")) {
			log.info("Call for memberGreivanceSearch");
			ServiceMemberGreivancesResponse[] serviceMemberGreivancesSearchResponses = memberGrievanceDao
					.getMemberGrievances(memberId);
			return memberGrievanceMapper.memberGrievancesSearchMapper(serviceMemberGreivancesSearchResponses);
		} else {
			throw new RequestValidationException("Invalid Request: Please provide a valid complaintType");
		}

	}

	public AppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId, String memberId) throws Exception {
		log.info("Inside getAppealsOrGrievanceDetails() in service class");

		if (StringUtils.isNotBlank(memberId) && StringUtils.isNotBlank(complaintId)) {
			log.info("Going for memberGreivanceDetails call");
			ServiceMemberGreivancesResponse[] serviceMemberGreivancesDetailsResponses = memberGrievanceDao
					.getMemberGrievances(memberId);
			return memberGrievanceMapper.memberGreivanceDetailsMapper(complaintId, serviceMemberGreivancesDetailsResponses);
		} else {
			log.info("Going for memberAppealsDetails call");
			ServiceMemberAppealsResponse[] serviceMemberDetailsAppealsResponses = memberAppealsDao.getMemberAppeals(memberId,
					complaintId);
			return memberAppealsMapper.memberAppealDetailsResponseMapper(serviceMemberDetailsAppealsResponses);
		}
	}
}
