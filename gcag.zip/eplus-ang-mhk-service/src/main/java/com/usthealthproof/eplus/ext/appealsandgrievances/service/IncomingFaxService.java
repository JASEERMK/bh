package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.IncomingFaxDAO;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class IncomingFaxService {

    @Autowired
    IncomingFaxDAO incomingFaxDAO;

    public IncomingFaxResponse createIncomingFax(IncomingFaxRequest incomingFaxRequest) {
        log.info("Inside createIncomingFax() in Service");
        return incomingFaxDAO.createIncomingFax(incomingFaxRequest);
    }

}