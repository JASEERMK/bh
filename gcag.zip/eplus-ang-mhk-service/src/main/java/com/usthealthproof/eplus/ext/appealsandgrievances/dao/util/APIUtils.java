package com.usthealthproof.eplus.ext.appealsandgrievances.dao.util;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProblemDetails;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class APIUtils {

	@Value("${medhok.usernameKey}")
	private String usernameKey;
	@Value("${medhok.passwordKey}")
	private String passwordKey;
	@Value("${medhok.service.username}")
	private String userName;
	@Value("${medhok.service.password}")
	private String password;

	public ProblemDetails createProblemDetails(String status, String errorMsg) {
		log.info("Inside createProblemDetails() in APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(Arrays.asList(errorMsg));
		return problemDetails;
	}

	public Consumer<HttpHeaders> getHeaders() {
		log.info("Inside getHeaders()");

			return httpHeaders -> {
				httpHeaders.set(usernameKey, userName);
				httpHeaders.set(passwordKey, password);
			};
	}

}
