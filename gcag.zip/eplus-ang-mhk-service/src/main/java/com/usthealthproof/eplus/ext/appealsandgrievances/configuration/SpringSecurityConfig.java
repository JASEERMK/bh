package com.usthealthproof.eplus.ext.appealsandgrievances.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SpringSecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        //		http.authorizeHttpRequests((authz) -> authz.anyRequest().authenticated()).httpBasic();
        http.csrf(csrf -> csrf.disable());
        //		http.headers().httpStrictTransportSecurity().includeSubDomains(true).maxAgeInSeconds(36000);
        http.headers(headers -> headers.httpStrictTransportSecurity(
                hsts -> hsts.includeSubDomains(true).preload(true).maxAgeInSeconds(0)));
        return http.build();
    }
}
