package com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Request object Intake service")
public class IncomingFaxRequest {

    @Schema(description = "Fax Queue Name")
    private String name;
    @Schema(description = "Total pages in the attachment")
    private String numberOfPages;
    @Schema(description = "Incoming Fax Number")
    private String incomingFaxNumber;
    @Schema(description = "Outgoing Fax Number")
    private String outgoingFaxNumber;
    @Schema(description = "DateTime format is yyyy-MM-dd'T'HH:mm:ssZ")
    private String receivedDateTime;
    @Schema(description = "Actual document file")
    private String document;
    @Schema(description = "Actual document File Name")
    private String documentName;

}
