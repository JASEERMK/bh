package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.util.function.Consumer;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.util.APIUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class MemberGrievanceDao {

	@Autowired
	private WebClient webClient;
	@Autowired
	private APIUtils apiUtils;
	@Autowired
	private Validator validator;

	@Value("${medhok.service.memberGrievanceUri}")
	private String memberGreivanceURI;

	public ServiceMemberGreivancesResponse[] getMemberGrievances(String memberId) throws Exception {
		log.info("Inside getMemberGrievances() in DAO class");

		ServiceMemberGreivancesRequest serviceMemberGreivancesRequest = new ServiceMemberGreivancesRequest();
		serviceMemberGreivancesRequest.setMemberID(memberId);
		ServiceMemberGreivancesResponse[] serviceMemberGreivancesResponses = null;
		try {
			Consumer<HttpHeaders> httpHeaders = apiUtils.getHeaders();
			log.info("Going to call the MedHok GrievanceByCriteria service");
			long startServiceRequestTime = System.currentTimeMillis();
			serviceMemberGreivancesResponses = webClient.post().uri(memberGreivanceURI).headers(httpHeaders)
					.bodyValue(serviceMemberGreivancesRequest).retrieve().bodyToMono(ServiceMemberGreivancesResponse[].class)
					.block();
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Execution time of the MedHok GrievanceByCriteria service : {} ms",
					endServiceRequestTime - startServiceRequestTime);
			validator.validateServiceMemberGreivanceResponse(serviceMemberGreivancesResponses);
			log.info("Successfully received the Grievance responses for the request with memberId: {}", memberId);
		} catch (WebClientResponseException webClientResponseException) {
			log.info("Failed to receive the Grievance responses for the request with memberId: {}", memberId);
			throw webClientResponseException;
		} catch (Exception exception) {
			log.info("Failed to receive the Grievance responses for the request with memberId: {}", memberId);
			throw exception;
		}
		return serviceMemberGreivancesResponses;
	}

}
