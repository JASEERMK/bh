package com.usthealthproof.eplus.ext.appealsandgrievances.model.wrapper;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Provider Appeals Details")
@JsonInclude(value = Include.NON_EMPTY)
public class ProviderAppealsDetails {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "complaint Sub Category")
	private String complaintSubCategory;
	@Schema(description = "Priority")
	private String priority;
	@Schema(description = "Complaint Status")
	private String complaintStatus;
	@Schema(description = "Receive Date time")
	private String receivedDate;
	@Schema(description = "Due Date")
	private String dueDate;
	@Schema(description = "Intake Mode")
	private String intakeMode;
	@Schema(description = "Request Type")
	private String requestType;
	@Schema(description = "Requester Last Name")
	private String requesterLastName;
	@Schema(description = "Owner First Name")
	private String ownerFirstName;
	@Schema(description = "Owner Last Name")
	private String ownerLastName;
	@Schema(description = "Complaint Type")
	private String complaintType;
	@Schema(description = "Complaint Status Reason")
	private String complaintStatusReason;
	@Schema(description = "Product")
	private String product;
	@Schema(description = "Decision Date")
	private String decisionDate;
	@Schema(description = "Complaint Age")
	private String complaintAge;
	@Schema(description = "Member Name")
	private String memberName;
	@Schema(description = "Member Id")
	private String memberId;
	//Added as part of CPB-4503
	@Schema(description = "Requester First Name Id")
	private String requesterFirstName;
	@Schema(description = "Requester Name")
	private String requesterName;
}
