package com.usthealthproof.eplus.ext.appealsandgrievances.validator;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.incomingfax.IncomingFaxResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.membergreivance.ServiceMemberGreivancesResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.service.providerappeals.ServiceProviderAppealsResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTimeZone;
import org.joda.time.format.ISODateTimeFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Arrays;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.containsIgnoreCase;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
@Slf4j
public class Validator {

	@Value("${medhok.faxQueueNames}")
	private String faxQueueNames;

	public void validateMemberAppealsAndGrievancesSummary(String memberId, String complaintType) {
		log.info("Inside validateMemberAppealsAndGrievancesSummary() in validator class");

		if (StringUtils.isBlank(memberId)) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.MEMBER_ID_NOT_FOUND);
		}
		if (StringUtils.isBlank(complaintType)) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND);
		}
		if (!StringUtils.equalsAnyIgnoreCase(complaintType, AppealsAndGrievanceConstants.DENTAL_APPEAL,
				AppealsAndGrievanceConstants.MEDICAL_APPEAL, AppealsAndGrievanceConstants.RX_MEDICAL_APPEAL,
				AppealsAndGrievanceConstants.RX_RETAIL_APPEAL, AppealsAndGrievanceConstants.VISION_APPEAL,
				AppealsAndGrievanceConstants.APPEAL, AppealsAndGrievanceConstants.GRIEVANCE_TYPE)) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.INVALID_COMPLAINT_TYPE);
		}

	}

	public void validateMemberAppealsAndGrievancesDetails(String complaintId) {
		log.info("Inside validateMemberAppealsAndGrievancesDetails() in validator class");

		if (isBlank(complaintId)) {
			log.info("Invalid request ie. complaintId is empty/null/blank");
			throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_ID_NOT_FOUND);
		}
	}

	public void validateProviderAppealsSummary(String providerId, String complaintType) {
		log.info("Inside validateProviderAppealsSummary()");

		if (StringUtils.isBlank(providerId)) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.PROVIDER_ID_NOT_FOUND);
		}
		if (StringUtils.isBlank(complaintType)) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND);
		}
	}

	public void validateServiceMemberAppealsResponse(ServiceMemberAppealsResponse[] serviceServiceMemberAppeals) {
		log.info("Inside validateServiceMemberAppealsResponse() in validator class ");

		if (null == serviceServiceMemberAppeals || serviceServiceMemberAppeals.length == 0) {
			throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND);
		}
	}

	public void validateServiceProviderAppealsResponse(ServiceProviderAppealsResponse[] providerServiceAppeals) {
		log.info("Inside validateServiceProviderAppealsResponse() in validator class ");

		if (null == providerServiceAppeals || providerServiceAppeals.length == 0) {
			throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND);
		}
	}

	public void validateServiceMemberGreivanceResponse(ServiceMemberGreivancesResponse[] serviceMemberGreivanceResponse) {
		log.info("Inside validateServiceMemberGreivanceResponse() in validator class");

		if (null == serviceMemberGreivanceResponse || serviceMemberGreivanceResponse.length == 0) {
			throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND);
		}
	}

	//As part of cpb-4068
	public void validateIncomingFaxRequest(IncomingFaxRequest incomingFaxRequest) throws RequestValidationException {
		log.info("Inside validateIncomingFaxRequest() in validator class");

		List<String> faxQueueNamesList = Arrays.asList(StringUtils.split(faxQueueNames, ","));

		if (isBlank(incomingFaxRequest.getDocument())) {
			throw new RequestValidationException("Missing Document File : Please provide a valid pdf document");
		}
		if (isBlank(incomingFaxRequest.getDocumentName())) {
			throw new RequestValidationException("Missing Document File Name");
		}
		if (isBlank(incomingFaxRequest.getName())) {
			throw new RequestValidationException("Missing Name");
		} else {
			if (faxQueueNamesList.isEmpty()) {
				throw new RequestValidationException("No Fax Queue Name is configured in the configuration file");
			}
			if (!faxQueueNamesList.contains(incomingFaxRequest.getName())) {
				throw new RequestValidationException(
						"Invalid Fax Queue Name provided, expected values are: " + faxQueueNamesList.toString());
			}
		}
		if (isBlank(incomingFaxRequest.getIncomingFaxNumber())
				|| containsIgnoreCase(incomingFaxRequest.getIncomingFaxNumber(), "null")) {
			throw new RequestValidationException("Missing IncomingFaxNumber");
		}
		if (isBlank(incomingFaxRequest.getReceivedDateTime())) {
			throw new RequestValidationException("Missing Date received");
		} else {
			validateDateFormat(incomingFaxRequest.getReceivedDateTime(), null, "ReceivedDateTime");
		}
	}

	private void validateDateFormat(String inputDate, String dateFormat, String fieldName) throws RequestValidationException {
		log.info("Inside validateDateFormat()");

		if (isBlank(dateFormat)) {
			//			Block for validating UTC date format
			DateTimeZone utc = DateTimeZone.UTC; // 2021-03-15T11:22:16-0400
			try {
				ISODateTimeFormat.dateTimeNoMillis().parseDateTime(inputDate).withZone(utc);
			} catch (Exception e) {
				throw new RequestValidationException("Invalid format for the field: " + fieldName
						+ ". Expected date format should be yyyy-MM-dd'T'HH:mm:ssZ OR Invalid date");
			}
		} else {
			//			Block for validating general date format
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateFormat).withResolverStyle(ResolverStyle.STRICT);
			String modifiedDate = StringUtils.strip(inputDate);
			try {
				LocalDate.parse(modifiedDate, dateFormatter);
			} catch (Exception e) {
				throw new RequestValidationException("Invalid format for the field: " + fieldName
						+ ". Expected date format should be yyyy-MM-dd OR Invalid date");
			}
		}
	}

	public void validateIncomingFaxResponse(IncomingFaxResponse incomingFaxResponse) {
		log.info("Inside validateIncomingFaxResponse()");
		if (null == incomingFaxResponse || (StringUtils.isBlank(incomingFaxResponse.getIncomingId()) && StringUtils.isBlank(
				incomingFaxResponse.getDocumentId()))) {
			throw new ResponseValidationException(AppealsAndGrievanceConstants.NO_DATA_FOUND);
		}
	}
}
