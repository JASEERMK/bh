package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Provider Appeals or Grievance Summary")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderAppealsOrGrievanceSummary {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Request Type")
	private String requestType;
	@Schema(description = "Complaint Type")
	private String complaintType;
	@Schema(description = "Receive Date time")
	private String receivedDate;
	@Schema(description = "Complaint Category")
	private String complaintCategory;

}
