package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.util.DateUtils;

@Repository
public class ProviderAppealsAndGrievanceSummaryDao {

	private String appealsOrGrievanceSummaryURI = "";
	@Autowired
	private DateUtils dateUtils;
	@Autowired
	private WebClient webClient;

	private static final Logger log = LoggerFactory.getLogger(ProviderAppealsAndGrievanceSummaryDao.class);

	public List<ProviderAppealsOrGrievanceSummary> getAppealsOrGrievanceSummary(String providerId, String complaintType) {
		try {

			log.info("Calling Altruita service");

			List<ProviderAppealsOrGrievanceSummary> appealsOrGrievanceSummaryList = getAppealsOrGrievanceSummaryList(
					complaintType);
			if (appealsOrGrievanceSummaryList.isEmpty()) {
				throw new NoDataFoundException();
			}
			log.info("Retrievd results successfully");
			//providerAppealsOrGrievanceSummaryResponse.setProviderAppealsOrGrievanceSummaryList(appealsOrGrievanceSummaryList);
			return appealsOrGrievanceSummaryList;

		} catch (WebClientResponseException clientResponseException) {

			log.info("Status Code : {} ,RawStatusCode : {}, Status Text : {}", clientResponseException.getStatusCode(),

					clientResponseException.getStatusCode().value(), clientResponseException.getStatusText());

			throw clientResponseException;

		} catch (WebClientException clientException) {

			log.info("Failed to receive the PNC document for the request : {} and the clientException is: ",

					 clientException);

			throw clientException;

		}catch (NoDataFoundException noDataFoundException) {
			throw noDataFoundException;
		} catch (Exception e) {
			throw new InternalException(e);
		}
	}

	// Creates list using the result set obtained from altruista
	private List<ProviderAppealsOrGrievanceSummary> getAppealsOrGrievanceSummaryList(String complaintType) {
		log.info("Started retrieving the results from Altruista");
		List<ProviderAppealsOrGrievanceSummary> appealsOrGrievanceSummaryList = new ArrayList();
		ProviderAppealsOrGrievanceSummary appealsOrGrievanceSummary = new ProviderAppealsOrGrievanceSummary();
		// Filter results according to complaint type
		//if (complaintType.trim().equalsIgnoreCase(AppealsAndGrievanceConstants.APPEAL)) {

			appealsOrGrievanceSummary.setComplaintID("123");
			appealsOrGrievanceSummary.setStatus("Approved");
			appealsOrGrievanceSummary.setRequestType("First Level");
			appealsOrGrievanceSummary.setComplaintType("Pre-Service");
			appealsOrGrievanceSummary.setReceivedDate("10/01/2022");
			appealsOrGrievanceSummary.setComplaintCategory("complaintCategory");
			appealsOrGrievanceSummaryList.add(appealsOrGrievanceSummary);

		/*
		 * } else if
		 * (complaintType.trim().equalsIgnoreCase(AppealsAndGrievanceConstants.GRIEVANCE
		 * )) {
		 * 
		 * appealsOrGrievanceSummary.setComplaintID("456");
		 * appealsOrGrievanceSummary.setStatus("Approved");
		 * appealsOrGrievanceSummary.setRequestType("First Level");
		 * appealsOrGrievanceSummary.setComplaintType("Pre-Service");
		 * appealsOrGrievanceSummary.setReceivedDate("10/01/2022");
		 * appealsOrGrievanceSummary.setComplaintCategory("complaintCategory"); }
		 */

		return appealsOrGrievanceSummaryList;

	}
}
