package com.usthealthproof.eplus.ext.appealsandgrievances.validator;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest.AppealsDetail;

@Component
public class Validator {
	private static final Logger log = LoggerFactory.getLogger(Validator.class);

	public void validateMemberAppealsAndGrievancesSummary(String memberId, String complaintType) {
		log.info("Valdation of parameters started");
		isNullOrEmpty(memberId, (AppealsAndGrievanceConstants.MEMBER_ID_NOT_FOUND));
		validateComplaintType(complaintType);
		log.info("Valdation of parameters completed");
	}

	private void validateComplaintType(String complaintType) {
		isNullOrEmpty(complaintType, (AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND));

		if (!(complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.DENTAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.MEDICAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.RX_MEDICAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.RX_RETAIL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.VISION_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.GRIEVANCE_TYPE))) {
			throw new RequestValidationException(AppealsAndGrievanceConstants.INVALID_COMPLAINT_TYPE);
		}
	}

	public void validateMemberAppealsAndGrievancesDetails(String complaintId) {
		log.info("Valdation of parameters started");
		isNullOrEmpty(complaintId, (AppealsAndGrievanceConstants.COMPLAINT_ID_NOT_FOUND));
		log.info("Valdation of parameters completed");
	}

	/*
	 * Validates all the mandatory fields provided in the request
	 */
	public void validateIntake(IntakeRequest intakeRequest) {

		isNullOrEmpty(intakeRequest.getMemberName(), AppealsAndGrievanceConstants.MEMBER_NAME_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getMemberId(), AppealsAndGrievanceConstants.MEMBER_ID_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getPrefferedLanguage(), AppealsAndGrievanceConstants.PREFERRED_LANGUAGE_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getSubmitterType(), AppealsAndGrievanceConstants.SUBMITTER_TYPE_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getPrimaryPhoneNumber(), AppealsAndGrievanceConstants.PRIMARY_PHONENO_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getPriority(), AppealsAndGrievanceConstants.PRIORITY_REQUESTED_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getIssueDate(), AppealsAndGrievanceConstants.ISSUE_DATE_NOT_FOUND);
		isNullOrEmpty(intakeRequest.getComplaintDescription(), AppealsAndGrievanceConstants.COMPLAINT_DESC_NOT_FOUND);
		IntakeRequest.SubmitterDetails submitterDetails = intakeRequest.getSubmitterDetails();
		if (null != submitterDetails) {
			isNullOrEmpty(submitterDetails.getFirstName(), AppealsAndGrievanceConstants.SUBMITTER_NAME_NOT_FOUND);
		}

		IntakeRequest.RepresentativeDetails representativeDetails = intakeRequest.getRepresentativeDetails();
		if (null != representativeDetails) {
			isNullOrEmpty(representativeDetails.getFirstName(),
					AppealsAndGrievanceConstants.REPRESENTATIVE_NAME_NOT_FOUND);
		}

		String complaintType = intakeRequest.getComplaintType();
		isNullOrEmpty(complaintType, AppealsAndGrievanceConstants.COMPLAINT_TYPE_NOT_FOUND);

		AppealsDetail appealsDetail = intakeRequest.getAppealsDetail();
		if(null != appealsDetail) {
		if (complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.APPEAL)|
				complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.MEDICAL_APPEAL)	) {
			isNullOrEmpty(appealsDetail.getAppealType(), AppealsAndGrievanceConstants.APPEAL_TYPE_NOT_FOUND);
			isNullOrEmpty(appealsDetail.getId(), AppealsAndGrievanceConstants.APPEAL_ID_NOT_FOUND);
			isNullOrEmpty(intakeRequest.getLevelOfService(), AppealsAndGrievanceConstants.LEVEL_OF_SERVICE_NOT_FOUND);
		}
	}}

	private void isNullOrEmpty(String param, String message) {

		if (null == param || StringUtils.isEmpty(param)) {
			log.error("Mandatory field " + param + " is null or empty");
			throw new RequestValidationException(message);
		}
	}

	public void validateProviderAppealsAndGrievancesSummary(String providerId, String complaintType) {
		log.info("Valdation of parameters started");
		isNullOrEmpty(providerId, (AppealsAndGrievanceConstants.PROVIDER_ID_NOT_FOUND));
		validateComplaintType(complaintType);
		log.info("Valdation of parameters completed");
	}

}
