package com.usthealthproof.eplus.ext.appealsandgrievances.exception;

public class InternalException extends RuntimeException {

	public InternalException(String message) {
		super(message);
	}

	public InternalException() {

	}

	public InternalException(Exception e) {
	}
}
