package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.ProviderAppealsAndGrievanceDetailsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.ProviderAppealsAndGrievanceSummaryDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

@Service
public class ProviderAppealsAndGrievanceService {

	@Autowired
	Validator validator;
	@Autowired
	ProviderAppealsAndGrievanceSummaryDao appealsAndGrievanceSummaryDao;
	@Autowired
	ProviderAppealsAndGrievanceDetailsDao appealsAndGrievanceDetailsDao;

	private static final Logger log = LoggerFactory.getLogger(ProviderAppealsAndGrievanceService.class);

	public List<ProviderAppealsOrGrievanceSummary> getAppealsOrGrievanceSummary(String providerId,
			String complaintType) {
		log.info("Inside getAppealsOrGrievanceSummary()");
		validator.validateProviderAppealsAndGrievancesSummary(providerId, complaintType);
		return appealsAndGrievanceSummaryDao.getAppealsOrGrievanceSummary(providerId, complaintType);
	}

	public ProviderAppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId) {
		log.info("Inside getAppealsOrGrievanceDetails()");
		validator.validateMemberAppealsAndGrievancesDetails(complaintId);
		return appealsAndGrievanceDetailsDao.getAppealsOrGrievanceDetails(complaintId);
	}

}
