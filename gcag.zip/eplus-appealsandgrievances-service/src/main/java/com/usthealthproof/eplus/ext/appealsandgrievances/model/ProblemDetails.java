package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Problem Details class")
@Component
public class ProblemDetails implements Serializable {
	private static final long serialVersionUID = 1375014372202494792L;
	@Schema(description = "Error informations")
	private List<String> errors;
	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status;
}
