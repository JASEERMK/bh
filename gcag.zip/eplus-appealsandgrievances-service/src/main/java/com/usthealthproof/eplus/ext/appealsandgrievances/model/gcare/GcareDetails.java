package com.usthealthproof.eplus.ext.appealsandgrievances.model.gcare;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Member Appeals or Grievance Details")
@JsonInclude(value = JsonInclude.Include.NON_EMPTY)
public class GcareDetails {
    @Schema(description = "Appeal ID / Grievance ID")
    private String complaintID;
    @Schema(description = "Complaint Category")
    private String complaintCategory;
    @Schema(description = "Priority Requested")
    private String priority;
    @Schema(description = "Created Date")
    private String createdDate;
    @Schema(description = "Received Date <Date timestamp>")
    private String receivedDate;
    @Schema(description = "Case Age")
    private String caseAge;
    @Schema(description = "Appeal Level")
    private String level;
    @Schema(description = "Complaint Status")
    private String complaintStatus;
    @Schema(description = "Complaint Sub Category")
    private String complaintSubCategory;
    @Schema(description = "Contact Channel")
    private String contactChannel;
    @Schema(description = " Requestor")
    private String requestor;
    @Schema(description = "Due Date <Date timestamp>")
    private String dueDate;
    @Schema(description = "Service Type")
    private String serviceType;
    @Schema(description = "Resolution Date")
    private String resolutionDate;
    @Schema(description = "Resolution Category")
    private String resolutionCategory;
    @Schema(description = "Resolution SubCategory")
    private String resolutionSubCategory;
    @Schema(description = "Resolution Notes")
    private String resolutionNotes;
    @Schema(description = "Incident Date")
    private String incidentDate;
    @Schema(description = "Claim ID")
    private String claimId;
    @Schema(description = "Authorization ID")
    private String authorizationId;
    @Schema(description = "Responsible Department")
    private String responsibleDepartment;
    @Schema(description = "Staff Name")
    private String staffName;
    @Schema(description = "Contact Name")
    private String contactName;
    @Schema(description = "Contact number")
    private String contactNumber;
}
