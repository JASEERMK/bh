package com.usthealthproof.eplus.ext.appealsandgrievances.constants;

public final class AppealsAndGrievanceConstants {

	private AppealsAndGrievanceConstants() {
	}

	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	
	public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

	/* Appeals and Grievance Summary and Details mandatory parameters */
	public static final String MEMBER_ID_NOT_FOUND = "Member id is not found in the request";
	public static final String COMPLAINT_TYPE_NOT_FOUND = "Complaint type is not found in the request";
	public static final String INVALID_COMPLAINT_TYPE = "Invalid complaint type";
	public static final String COMPLAINT_ID_NOT_FOUND = "complaint id is not found in the request";
	public static final String INTAKE_STAFF_NOT_FOUND = "Intake Staff not found in the request";
	public static final String PROVIDER_ID_NOT_FOUND = "Provider id is not found in the request";
	/* Exceptions */
	public static final String EXCEPTION_OCCURRED = "Something went wrong, please check the log for more details.";
	public static final String NO_DATA_FOUND = "No data found";

	/* Complaint Types */
	public static final String DENTAL_APPEAL = "DentalAppeal";
	public static final String RX_MEDICAL_APPEAL = "PharmacyMedicalAppeal";
	public static final String MEDICAL_APPEAL = "MedicalAppeal";
	public static final String RX_RETAIL_APPEAL = "PharmacyRetailAppeal";
	public static final String VISION_APPEAL = "VisionAppeal";
	public static final String GRIEVANCE_TYPE = "Grievance";
	public static final String APPEAL = "APPEAL";

	/* Responsible Dept */
	public static final String AG_MEMBER_APPEAL = "AG Member Appeals";
	public static final String AG_GRIEVANCES = "AG Grievances";

	/* Intake Mandatory parameters */
	public static final String PREFERRED_LANGUAGE_NOT_FOUND = "Preferred Language is not found in the request";
	public static final String SUBMITTER_TYPE_NOT_FOUND = "Submitter type is not found in the request";
	public static final String SUBMITTER_NAME_NOT_FOUND = "Submitter name is not found in the request";
	public static final String MEMBER_NAME_NOT_FOUND = "Member name is not found in the request";
	public static final String MEMBER_BEHALF_NOT_FOUND = "Member behalf is not found in the request";
	public static final String REPRESENTATIVE_NAME_NOT_FOUND = "Representative name is not found in the request";
	public static final String PRIMARY_PHONENO_NOT_FOUND = "Primary phone number is not found in the request";
	public static final String PRIORITY_REQUESTED_NOT_FOUND = "Priority requested is not found in the request";
	public static final String ISSUE_DATE_NOT_FOUND = "Issue date is not found in the request";
	public static final String COMPLAINT_DESC_NOT_FOUND = "Complaint description is not found in the request";
	public static final String APPEAL_TYPE_NOT_FOUND = "Appeal type(Claim/Authoriation) is not found in the request";
	public static final String APPEAL_ID_NOT_FOUND = "Appeal id(Claim/Authoriation) is not found in the request";
	public static final String LEVEL_OF_SERVICE_NOT_FOUND = "Level Of Service is not found in the request";
	public static final String memberAppealsOrgrievancesSummary = "memberAppealsOrgrievancesSummary";
	public static final String memberAppealsOrgrievancesDetails = "memberAppealsOrgrievancesDetails";
	public static final String NOTIFICATION_METHOD = "Phone";
	public static final String OPEN = "Open";
	public static final String INTAKE_STAFF = "API_USER";
	public static final String INTAKE_DEPARTMENT = "Member Services";
	public static final String WORKQUEUE = "A&G Work Queue";
	public static final String COMPLAINT_CATEGORY = "Complaint Category is not found";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String memberAppealsOrgrievancesSummaryApi = "{\"page\":\r\n" + 
			"{\"pageCount\":23,\"pageNo\":1,\"pageSize\":25,\"links\":{\"next\":{\"href\":\"https://{api_base_url}/Member/ALT123456/ServicePlan?status=Current&pageNo=4&pageSize=5\"},\r\n" + 
			"\"prev\":{\"href\":\"https://{api_base_url}/Member/ALT123456/ServicePlan?status=Current&pageNo=2&pageSize=5\"},\r\n" + 
			"\"self\":{\"href\":\"https://{api_base_url}/Member/ALT123456/ServicePlan?status=Current&pageNo=3&pageSize=5\"}},\r\n" + 
			"\"totalRecordCount\":351},\r\n" + 
			"\"results\":[{\"complaintClass\":\"Expedited Pre-Service\",\"complaintAgainst\":\"Provider\",\"level\":1,\"authorizations\":\r\n" + 
			"[{\"authorizationClass\":\"Inpatient\",\"isInternal\":\"true\",\"isPrimary\":\"false\",\"authorizationID\":\"AUTH123456\",\"authorizationType\":\r\n" + 
			"\"Inpatient - Acute Hospitalization\"}],\"eligibility\":[{\"code\":\"AHI\",\"level\":1,\"desc\":\"Altruists Health Insurance\"}],\r\n" + 
			"\"uniqueEligibilityID\":\"eligibility15abcdefg20190101\",\"resolutionCategory\":\"\",\"eligibilityStartDate\":\"2020-01-01T00:00:00\",\r\n" + 
			"\"episodeType\":\"COB\",\"receivedDateTime\":\"2019-12-11T00:25:30Z\",\"complaintID\":\"COMP654789\",\"dueDateTime\":\"2020-04-01T15:13:28Z\",\r\n" + 
			"\"complaintOwner\":\"jsmith\",\"resolutionSubCategory\":\"\",\"complaintType\":\"Appeal\",\"lobBenID\":22002,\"claims\":[{\"isInternal\":\"true\",\"claimNumber\":\"CLAIM12345\"}],\r\n" + 
			"\"links\":[{\"method\":\"GET\",\"rel\":\"Activity Details\",\"href\":\"https://{api_base_url}/Complaint/654789/ActivityDetails\"}],\r\n" + 
			"\"eligibilityEndDate\":\"2021-12-31T00:00:00\",\"complaintAgainstDetails\":\"PROV_1(If `complaintAgainst` is Provider)\",\"resolutionDateTime\":\"2019-12-11T06:57:09Z\",\r\n" + 
			"\"complaintCategory\":\"Administrative Appeal\",\"status\":\"Pending\",\"complaintSubCategory\":\"ComplaintSubCategory\"}]}";

	public static final String memberAppealsOrgrievancesDetailsApi = "{\r\n" + "    \"clientPatientID\": \"ALT123456\",\r\n"
			+ "    \"carrierMemberID\": \"CMI123456\",\r\n" + "    \"lobBenID\": 9,\r\n" + "    \"level\": 1,\r\n"
			+ "    \"eligibilityStartDate\": \"2021-08-15T00:00:00\",\r\n"
			+ "    \"uniqueEligibilityID\": \"ASGYTJ12364789\",\r\n" + "    \"complaintType\": \"Appeal\",\r\n"
			+ "    \"complaintClass\": \"complaintClass\",\r\n" + "    \"complaintCategory\": \"compCategory\",\r\n"
			+ "    \"complaintSubCategory\": \"complaintSubCategory\",\r\n" + "    \"status\": \"Open\",\r\n"
			+ "    \"statusReason\": \"\",\r\n" + "    \"complaintCurrentOwnerStatus\": \"Active\",\r\n"
			+ "    \"dueDateTime\": \"2021-05-05T12:32:21Z\",\r\n" + "    \"notificationDateTime\": \"2021-08-15T14:50:51Z\",\r\n"
			+ "    \"notificationMethod\": \"Phone\",\r\n" + "    \"createdDateTime\": \"2021-08-15T14:50:51Z\",\r\n"
			+ "    \"isExtended\": true,\r\n" + "    \"dateTimeOfIncident\": \"2021-08-15T14:50:51Z\",\r\n"
			+ "    \"intakeDepartment\": \"Appeal Department\",\r\n" + "    \"intakeStaff\": \"jsmith\",\r\n"
			+ "    \"complaintAgainst\": \"Other\",\r\n"
			+ "    \"complaintAgainstDetails\": \"John Smith (If the `complaintAgainst` = Other)\",\r\n"
			+ "    \"responsibleDepartment\": \"Appeal Department\",\r\n" + "    \"responsibleStaff\": \"staff\",\r\n"
			+ "    \"isWorkQueueReferral\": true,\r\n" + "    \"workQueues\": [\r\n" + "        {\r\n"
			+ "            \"departmentName\": \"Medical Directors\",\r\n" + "            \"careStaffUserName\": [\r\n"
			+ "                \"\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"levelOfService\": \"Retrospective\",\r\n" + "    \"whoInitiatedComplaint\": \"Provider\",\r\n"
			+ "    \"providerID\": \"PROV_1\",\r\n" + "    \"networkStatus\": \"Non-Par\",\r\n"
			+ "    \"updatedRequesterForExpeditedTimeframe\": \"\",\r\n"
			+ "    \"entityThatProcessedAuthorizationOrClaim\": \"\",\r\n" + "    \"didSponsorAppealALJDecision\": \"true\",\r\n"
			+ "    \"isComplaintNoteInternal\": \"true\",\r\n" + "    \"initialComplaintNote\": \"complaintNotes\",\r\n"
			+ "    \"intakeSupplementalInformation\": [\r\n" + "        {\r\n" + "            \"name\": \"\",\r\n"
			+ "            \"value\": [\r\n" + "                \"\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"internalAuthorizations\": [\r\n" + "        {\r\n" + "            \"authorizationID\": \"AUTH12345\",\r\n"
			+ "            \"authorizationClass\": \"Inpatient\",\r\n"
			+ "            \"authorizationType\": \"Inpatient - Acute Medical\",\r\n"
			+ "            \"authStatus\": \"Open\",\r\n" + "            \"isPrimary\": \"true\",\r\n"
			+ "            \"link\": {\r\n"
			+ "                \"href\": \"http://apidemo.guidingcare.com/Authorization/AUTH12345/Detail\",\r\n"
			+ "                \"rel\": \"Authorization Detail\",\r\n" + "                \"method\": \"GET\"\r\n"
			+ "            }\r\n" + "        }\r\n" + "    ],\r\n" + "    \"externalAuthorizations\": [\r\n" + "        {\r\n"
			+ "            \"externalAuthorizationID\": \"ASTR123456\",\r\n"
			+ "            \"serviceStartDate\": \"2021-08-15T00:00:00\",\r\n"
			+ "            \"serviceEndDate\": \"2021-08-18T00:00:00\",\r\n"
			+ "            \"authorizationExternalSource\": \"Authorization Portal\",\r\n"
			+ "            \"authRelatedEligibility\": \"Medicaid\",\r\n" + "            \"serviceType\": \"Emergency\",\r\n"
			+ "            \"decisionStatus\": \"Approved\",\r\n" + "            \"relatedDiagnosis\": [\r\n"
			+ "                \"A123.0\"\r\n" + "            ],\r\n" + "            \"relatedMedication\": [\r\n"
			+ "                \"123456987\"\r\n" + "            ],\r\n" + "            \"relatedProcedures\": [\r\n"
			+ "                \"12001\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"internalClaims\": [\r\n" + "        {\r\n" + "            \"claimNumber\": \"CLAIM1234\",\r\n"
			+ "            \"link\": {\r\n"
			+ "                \"href\": \"http://apidemo.guidingcare.com/Claim/CLAIM1234/Detail\",\r\n"
			+ "                \"rel\": \"Claim Detail\",\r\n" + "                \"method\": \"GET\"\r\n" + "            }\r\n"
			+ "        }\r\n" + "    ],\r\n" + "    \"externalClaims\": [\r\n" + "        {\r\n"
			+ "            \"claimNumber\": \"CLAIM1234\",\r\n" + "            \"serviceStartDate\": \"2021-08-15T00:00:00\",\r\n"
			+ "            \"serviceEndDate\": \"2021-08-15T00:00:00\",\r\n"
			+ "            \"claimExternalSource\": \"Facets\",\r\n" + "            \"providerID\": \"PROV_12\",\r\n"
			+ "            \"visitType\": \"Emergency\",\r\n" + "            \"reasonForVisit\": \"Fever\",\r\n"
			+ "            \"denialReason\": \"No supporting documents\",\r\n"
			+ "            \"entityThatProcessedClaim\": \"\",\r\n" + "            \"relatedDiagnosis\": [\r\n"
			+ "                \"A123.0\"\r\n" + "            ],\r\n" + "            \"relatedMedication\": [\r\n"
			+ "                \"123456987\"\r\n" + "            ],\r\n" + "            \"relatedProcedures\": [\r\n"
			+ "                \"12001\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n" + "    \"aor\": {\r\n"
			+ "        \"aorType\": \"AOR On File\",\r\n" + "        \"aorRequestedDateTime\": \"2021-08-15T14:50:51Z\",\r\n"
			+ "        \"aorReceivedDateTime\": \"2021-08-15T14:50:51Z\",\r\n" + "        \"firstName\": \"John\",\r\n"
			+ "        \"lastName\": \"Smith\",\r\n" + "        \"relationship\": \"Spouse\",\r\n"
			+ "        \"address\": \"123 Blackstone way\",\r\n" + "        \"city\": \"Richardson\",\r\n"
			+ "        \"state\": \"MI\",\r\n" + "        \"zip\": \"12345\",\r\n"
			+ "        \"phoneNumber\": \"1234567890\",\r\n" + "        \"aorNote\": \"\",\r\n"
			+ "        \"isAorNoteInternal\": true\r\n" + "    },\r\n" + "    \"wol\": {\r\n"
			+ "        \"wolType\": \"WOL Requested\",\r\n" + "        \"wolRequestedDateTime\": \"2021-08-15T14:50:51Z\",\r\n"
			+ "        \"wolReceivedDateTime\": \"2021-08-15T14:50:51Z\",\r\n" + "        \"firstName\": \"John\",\r\n"
			+ "        \"lastName\": \"Smith\",\r\n" + "        \"relationship\": \"Spouse\",\r\n"
			+ "        \"address\": \"123 Blackstone way\",\r\n" + "        \"city\": \"Richardson\",\r\n"
			+ "        \"state\": \"MI\",\r\n" + "        \"zip\": \"12345-1254\",\r\n"
			+ "        \"phoneNumber\": \"1234567890\",\r\n" + "        \"wolNote\": \"\",\r\n"
			+ "        \"isWolNoteInternal\": true\r\n" + "    },\r\n" + "    \"providers\": [\r\n" + "        {\r\n"
			+ "            \"providerID\": \"PROV_12345\",\r\n" + "            \"providerRole\": \"\",\r\n"
			+ "            \"providerPhone\": \"1234567890\",\r\n" + "            \"providerAlternatePhone\": \"1234567890\",\r\n"
			+ "            \"providerFax\": \"1234567890\",\r\n" + "            \"externalReviewerName\": \"\",\r\n"
			+ "            \"externalReviewerTitle\": \"\"\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"providerSupplementalInformation\": [\r\n" + "        {\r\n" + "            \"name\": \"\",\r\n"
			+ "            \"value\": [\r\n" + "                \"\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"authorizationMedicalDirector\": \"jsmith\",\r\n" + "    \"complaintMedicalDirector\": \"jsmith\",\r\n"
			+ "    \"externalReviewer\": \"John Smith\",\r\n" + "    \"reviewSentDateTime\": \"2021-05-24T00:23:12Z\",\r\n"
			+ "    \"reviewReturnDateTime\": \"2021-05-21T14:21:12Z\",\r\n" + "    \"reviewerDetailNote\": \"\",\r\n"
			+ "    \"isReviewerDetailNotesInternal\": \"true\",\r\n" + "    \"reviewerSupplementalInformation\": [\r\n"
			+ "        {\r\n" + "            \"name\": \"\",\r\n" + "            \"value\": [\r\n" + "                \"\"\r\n"
			+ "            ]\r\n" + "        }\r\n" + "    ],\r\n" + "    \"isPossibleQOC\": \"true\",\r\n"
			+ "    \"acceptAsQOC\": \"true\",\r\n" + "    \"QOCInvestigativeOutcome\": \"\",\r\n"
			+ "    \"QOCCoordinator\": \"jsmith\",\r\n" + "    \"QOCScore\": \"\",\r\n"
			+ "    \"QOCInvestigativeReason\": \"\",\r\n" + "    \"QOCNotes\": \"\",\r\n"
			+ "    \"isQOCNotesInternal\": \"true\",\r\n" + "    \"QOCSupplementalInformation\": [\r\n" + "        {\r\n"
			+ "            \"name\": \"\",\r\n" + "            \"value\": [\r\n" + "                \"\"\r\n"
			+ "            ]\r\n" + "        }\r\n" + "    ],\r\n" + "    \"additionalInformationRequestedDetail\": [\r\n"
			+ "        {\r\n" + "            \"type\": \"Provider\",\r\n"
			+ "            \"contact\": \"PROV_1 (If `type` = Provider)\",\r\n"
			+ "            \"contactNumber\": \"1234567890\",\r\n"
			+ "            \"requestedInformationDateTime\": \"2021-08-19T06:28:47Z\",\r\n"
			+ "            \"receivedInformationDateTime\": \"2021-08-19T06:28:47Z\",\r\n"
			+ "            \"requestNotes\": \"string\",\r\n" + "            \"isRequestNotesInternal\": true\r\n"
			+ "        }\r\n" + "    ],\r\n" + "    \"isAdditionalInfoComplete\": \"true\",\r\n"
			+ "    \"additionalInfoSupplementalInformation\": [\r\n" + "        {\r\n" + "            \"name\": \"\",\r\n"
			+ "            \"value\": [\r\n" + "                \"\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"episodeType\": \"\",\r\n" + "    \"episodeName\": \"\",\r\n" + "    \"episodeDescription\": \"\",\r\n"
			+ "    \"isEpisodeDescriptionInternal\": \"true\",\r\n" + "    \"episodeSupplementalInformation\": [\r\n"
			+ "        {\r\n" + "            \"name\": \"\",\r\n" + "            \"value\": [\r\n" + "                \"\"\r\n"
			+ "            ]\r\n" + "        }\r\n" + "    ],\r\n" + "    \"isResolved\": \"true\",\r\n"
			+ "    \"resolutionCategory\": \"resolutionCategory\",\r\n"
			+ "    \"resolutionSubCategory\": \"resolutionSubCategory\",\r\n"
			+ "    \"resolutionDateTime\": \"2021-05-24T01:21:41Z\",\r\n"
			+ "    \"effectuationDateTime\": \"2021-01-23T01:23:14Z\",\r\n"
			+ "    \"oralNotificationDateTime\": \"2021-01-12T00:21:21Z\",\r\n"
			+ "    \"writtenNotificationDateTime\": \"2021-01-12T00:21:21Z\",\r\n"
			+ "    \"reimbursementDate\": \"2021-05-24T00:00:00\",\r\n" + "    \"resolutionNote\": \"resolutionNote\",\r\n"
			+ "    \"isResolutionNoteInternal\": \"true\",\r\n" + "    \"resolutionSupplementalInformation\": [\r\n"
			+ "        {\r\n" + "            \"name\": \"\",\r\n" + "            \"value\": [\r\n" + "                \"\"\r\n"
			+ "            ]\r\n" + "        }\r\n" + "    ],\r\n" + "    \"participants\": [\r\n" + "        {\r\n"
			+ "            \"name\": \"Mary Brown\",\r\n" + "            \"type\": \"\",\r\n" + "            \"role\": \"\",\r\n"
			+ "            \"relationship\": \"Spouse\",\r\n" + "            \"phone\": \"555-555-5555\",\r\n"
			+ "            \"email\": \"mary@gmail.com\",\r\n"
			+ "            \"participantNote\": \"Sample note is entered here.\",\r\n"
			+ "            \"isParticipantNoteInternal\": \"true\"\r\n" + "        }\r\n" + "    ],\r\n"
			+ "    \"participantSupplementalInformation\": [\r\n" + "        {\r\n" + "            \"name\": \"\",\r\n"
			+ "            \"value\": [\r\n" + "                \"\"\r\n" + "            ]\r\n" + "        }\r\n" + "    ]\r\n"
			+ "}";

	public static final String intkeResponse = "{\r\n" + "    \"complaintID\": \"COMP654789\",\r\n" + "    \"level\": 1,\r\n"
			+ "    \"status\": \"Open\",\r\n" + "    \"statusReason\": \"reason\",\r\n" + "    \"complaintType\": \"Appeal\",\r\n"
			+ "    \"createdDateTime\": \"2020-04-15T02:13:50Z\"\r\n" + "}";
}
