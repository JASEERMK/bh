package com.usthealthproof.eplus.ext.appealsandgrievances.model.gcare;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Member Appeals or Grievance Summary")
@JsonInclude(value = JsonInclude.Include.NON_EMPTY)
public class GcareSummary {
    @Schema(description = "Appeal ID / Grievance ID")
    private String complaintID;
    @Schema(description = "Complaint Category")
    private String complaintCategory;
    @Schema(description = "Complaint Sub Category")
    private String complaintSubCategory;
    @Schema(description = "Priority Requested")
    private String priority;
    @Schema(description = "Status")
    private String status;
    @Schema(description = "Received Date <Date timestamp>")
    private String receivedDate;
}
