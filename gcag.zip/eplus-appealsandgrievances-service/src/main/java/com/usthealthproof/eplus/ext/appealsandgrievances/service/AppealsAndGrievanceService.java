package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.AppealsAndGrievanceDetailsDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.dao.AppealsAndGrievanceSummaryDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

@Service
public class AppealsAndGrievanceService {

	@Autowired
	AppealsAndGrievanceSummaryDao appealsAndGrievanceSummaryDao;
	@Autowired
	AppealsAndGrievanceDetailsDao appealsAndGrievanceDetailsDao;
	@Autowired
	Validator validator;

	private static final Logger log = LoggerFactory.getLogger(AppealsAndGrievanceService.class);

	public List<AppealsOrGrievanceSummary> getAppealsOrGrievanceSummary(String memberId, String complaintType) {
		log.info("Inside getAppealsOrGrievanceSummary()");
		validator.validateMemberAppealsAndGrievancesSummary(memberId, complaintType);
		return appealsAndGrievanceSummaryDao.getAppealsOrGrievanceSummary(memberId, complaintType);
	}

	public AppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId) {
		log.info("Inside getAppealsOrGrievanceDetails()");
		validator.validateMemberAppealsAndGrievancesDetails(complaintId);
		return appealsAndGrievanceDetailsDao.getAppealsOrGrievanceDetails(complaintId);
	}

}
