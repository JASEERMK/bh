package com.usthealthproof.eplus.ext.appealsandgrievances.constants;

public class DummyResponse {
	public static final String intakeResponse1 = "{\r\n" + "    \"createdDateTime\": \"2020-04-15T02:13:50Z\",\r\n"
			+ "    \"complaintID\": \"COMP654789\",\r\n" + "    \"level\": 1,\r\n" + "    \"status\": \"Open\",\r\n"
			+ "    \"statusReason\": \"\",\r\n" + "    \"complaintType\": \"Appeal\"\r\n" + "}";

	public static final String intakeResponse2 = "{\r\n" + "    \"createdDateTime\": \"2022-01-15T02:13:50Z\",\r\n"
			+ "    \"complaintID\": \"COMP987654\",\r\n" + "    \"level\": 1,\r\n" + "    \"status\": \"Open\",\r\n"
			+ "    \"statusReason\": \"\",\r\n" + "    \"complaintType\": \"Grievance\"\r\n" + "}";

	public static final String memberEligibilityResponse = "[\r\n" + "    {\r\n" + "        \"memberFirstName\": \"Jason\",\r\n"
			+ "        \"memberLastName\": \"Smith\",\r\n" + "        \"gender\": \"M\",\r\n"
			+ "        \"memberDOB\": \"2020-12-21T12:43:53.118Z\",\r\n" + "        \"clientPatientId\": \"ALT123456\",\r\n"
			+ "        \"medicareID\": \"MCR123456\",\r\n" + "        \"eligibilities\": [\r\n" + "            {\r\n"
			+ "                \"lobBenID\": 15,\r\n"
			+ "                \"uniqueEligibilityID\": \"eligibility17abcdefg20190101\",\r\n"
			+ "                \"eligiblityRecords\": [\r\n" + "                    {\r\n"
			+ "                        \"level\": 1,\r\n" + "                        \"code\": \"01\",\r\n"
			+ "                        \"desc\": \"Demo HealthCare\"\r\n" + "                    },\r\n"
			+ "                    {\r\n" + "                        \"level\": 2,\r\n"
			+ "                        \"code\": \"NY\",\r\n" + "                        \"desc\": \"New York\"\r\n"
			+ "                    },\r\n" + "                    {\r\n" + "                        \"level\": 3,\r\n"
			+ "                        \"code\": \"MA00\",\r\n"
			+ "                        \"desc\": \"New York Medicare Advantage\"\r\n" + "                    }\r\n"
			+ "                ],\r\n" + "                \"startDate\": \"2020-01-01\",\r\n"
			+ "                \"endDate\": \"2020-12-31\",\r\n" + "                \"status\": \"Active\",\r\n"
			+ "                \"eligibilityPath\": \"Demo HealthCare (01) >> New York (NY) >> New York Medicare Advantage (MA00)\"\r\n"
			+ "            }\r\n" + "        ]\r\n" + "    }\r\n" + "]";

}
