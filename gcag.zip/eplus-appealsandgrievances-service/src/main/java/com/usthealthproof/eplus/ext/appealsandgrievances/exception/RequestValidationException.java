package com.usthealthproof.eplus.ext.appealsandgrievances.exception;

public class RequestValidationException extends RuntimeException {

	private static final long serialVersionUID = -2625891751125517298L;

	public RequestValidationException() {
	}

	public RequestValidationException(String message) {
		super(message);
	}

}
