package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Intake Request")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IntakeRequest {

	@Schema(description = "Member Name")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Name is not in valid format")
	public String memberName;
	@JsonProperty(required = true)
	@Schema(description = "Member Id")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Id is not in valid format")
	public String memberId;
	@Schema(description = "Preffered Language")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Preffered Language is not in valid format")
	public String prefferedLanguage;
	@Schema(description = "Submitter Type")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Type is not in valid format")
	public String submitterType;
	@Schema(description = "Submitter Details")
	@Valid
	public SubmitterDetails submitterDetails;
	@Schema(description = "Member Behalf")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Behalf is not in valid format")
	public String memberBehalf;
	@Schema(description = "Representative Details")
	@Valid
	public RepresentativeDetails representativeDetails;
	@Schema(description = "Primary PhoneNumber")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Primary PhoneNumber should be Numeric")
	public String primaryPhoneNumber;

	@JsonProperty(required = true)
	@Schema(description = "Complaint Type")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Type is not in valid format")
	public String complaintType;
	@Schema(description = "Appeals Detail")
	@Valid
	public AppealsDetail appealsDetail;
	@Schema(description = "Grievances Detail")
	@Valid
	public GrievancesDetail grievancesDetail;
	@JsonProperty(required = true)
	@Schema(description = "Priority")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Priority is not in valid format")
	public String priority;
	@Schema(description = "Issue Date")
	@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Issue Date is not in valid format")
	public String issueDate;
	@Schema(description = "Complaint Description")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Description is not in valid format")
	public String complaintDescription;

	@Schema(description = "Complaint Category")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Category is not in valid format")
	public String complaintCategory;
	@Schema(description = "Intake Staff")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Intake Staff is not in valid format")
	public String intakeStaff;
	@JsonProperty(required = true)
	@Schema(description = "Notification DateTime")
	@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Notification DateTime is not in valid format")
	public String notificationDateTime;

	public IntakeRequest() {
	}

	@Data
	public static class GrievancesDetail {
		@Schema(description = "Complaint SubCategory")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint SubCategory is not in valid format")
		public String complaintSubCategory;
		@Schema(description = "Complaint RelatedTo")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint RelatedTo is not in valid format")
		public String complaintRelatedTo;
		@Schema(description = "Provider Details")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Provider Details is not in valid format")
		public String providerDetails;
	}

	@Data
	public static class Address {
		@Schema(description = "Address")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Address is not in valid format")
		public String address;
		@Schema(description = "City")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: City is not in valid format")
		public String city;
		@Schema(description = "State")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: State is not in valid format")
		public String state;
		@Schema(description = "Zip")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Zip is not in valid format")
		public String zip;
		@Schema(description = "Phone Number")
		@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Phone Number should be Numeric")
		public String phoneNumber;
	}

	@Data
	public static class SubmitterDetails {
		@Schema(description = "First Name")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: First Name is not in valid format")
		public String firstName;
		@Schema(description = "Last Name")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Last Name is not in valid format")
		public String lastName;
		@Schema(description = "Submitter Address")
		@Valid
		public Address submitterAddress;
		@Schema(description = "Submitter Id")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Id is not in valid format")
		public String submitterId;
		@Schema(description = "Submitter Relationship")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Submitter Relationship is not in valid format")
		public String submitterRelationship;
	}

	@Data
	public static class RepresentativeDetails {
		@Schema(description = "First Name")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: First Name is not in valid format")
		public String firstName;
		@Schema(description = "Last Name")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Last Name is not in valid format")
		public String lastName;
		@Schema(description = "Representative Address")
		@Valid
		public Address representativeAddress;
	}

	@Data
	public static class AppealsDetail {
		@Schema(description = "Appeal Type")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Appeal Type is not in valid format")
		public String appealType;
		@Schema(description = "Id")
		@Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Id is not in valid format")
		public String id;
		@Schema(description = "Service Start Date")
		@Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Service Start Date is not in valid format")
		public String serviceStartDate;
	}
}