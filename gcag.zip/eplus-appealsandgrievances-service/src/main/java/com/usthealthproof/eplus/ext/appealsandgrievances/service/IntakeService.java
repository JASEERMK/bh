package com.usthealthproof.eplus.ext.appealsandgrievances.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ext.appealsandgrievances.dao.IntakeDao;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.Validator;

@Service
public class IntakeService {

	@Autowired
	private IntakeDao intakeDao;

	@Autowired
	private Validator validator;

	public IntakeResponse recordClaimIntake(IntakeRequest intakeRequest) {
		validator.validateIntake(intakeRequest);
		return intakeDao.recordClaimIntake(intakeRequest);
	}
}
