package com.usthealthproof.eplus.ext.appealsandgrievances.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.configuration.AppealsAndGrievanceConfig;
import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;

@Component
public class DateUtils {
	@Autowired
	private AppealsAndGrievanceConfig appealsAndGrievanceConfig;

	public String getFormattedApplicationDate(String applicationDate) {
		if (StringUtils.isNotBlank(applicationDate)) {
			return LocalDate
					.parse(applicationDate, DateTimeFormatter.ofPattern(AppealsAndGrievanceConstants.DATE_FORMAT))
					.format(DateTimeFormatter.ofPattern(appealsAndGrievanceConfig.getApplicationDateFormat()));

		}

		return null;
	}

}
