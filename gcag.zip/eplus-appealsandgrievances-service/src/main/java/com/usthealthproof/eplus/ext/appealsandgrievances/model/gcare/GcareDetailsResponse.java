package com.usthealthproof.eplus.ext.appealsandgrievances.model.gcare;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Gcare Details response received from the external service")
public class GcareDetailsResponse {
    private String complaintID;
    private String complaintCategory;
    private String priority;
    private String createdDate;
    private String receivedDate;
    private String caseAge;
    private String level;
    private String complaintStatus;
    private String complaintSubCategory;
    private String contactChannel;
    private String requestor;
    private String dueDate;
    private String serviceType;
    private String resolutionDate;
    private String resolutionCategory;
    private String resolutionSubCategory;
    private String resolutionNotes;
    private String incidentDate;
    private String claimId;
    private String authorizationId;
    private String responsibleDepartment;
    private String staffName;
    private String contactName;
    private String contactNumber;

}
