package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceDetails;
@Repository
public class ProviderAppealsAndGrievanceDetailsDao {
	@Autowired
	ProviderAppealsOrGrievanceDetails appealsOrGrievanceDetails;
	@Autowired
	private WebClient webClient;

	private static final Logger log = LoggerFactory.getLogger(ProviderAppealsAndGrievanceDetailsDao.class);

	public ProviderAppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId) {
		try {

			// Call altruista request
			log.info("Started retrieving results from altruista");
			getData();
			if (null == appealsOrGrievanceDetails) {
				throw new NoDataFoundException();
			}
		} catch (WebClientResponseException clientResponseException) {

			log.info("Status Code : {} ,RawStatusCode : {}, Status Text : {}", clientResponseException.getStatusCode(),

					clientResponseException.getStatusCode().value(), clientResponseException.getStatusText());

			throw clientResponseException;

		} catch (WebClientException clientException) {

			log.info("Failed to receive the PNC document for the request : {} and the clientException is: ",

					 clientException);

			throw clientException;

		}catch (NoDataFoundException noDataFoundException) {
			throw noDataFoundException;
		} catch (Exception e) {
			throw new InternalException(e);
		}
		log.info("Retrieved altruista response successfully");
		return appealsOrGrievanceDetails;
	}

	private void getData() {

		appealsOrGrievanceDetails.setComplaintID("123");
		appealsOrGrievanceDetails.setComplaintCategory("complaitCategory");
		appealsOrGrievanceDetails.setComplaintSubCategory("complaintSubCategory");
		appealsOrGrievanceDetails.setPriority("priority");
		appealsOrGrievanceDetails.setComplaintStatus("Approved");
		appealsOrGrievanceDetails.setReceivedDate("11/11/2022");
		appealsOrGrievanceDetails.setDueDate("12/11/2022");
		appealsOrGrievanceDetails.setIntakeMode("intakeMode");
		appealsOrGrievanceDetails.setRequestType("requestType");
		appealsOrGrievanceDetails.setRequesterLastName("George");
		appealsOrGrievanceDetails.setOwnerFirstName("Tom");
		appealsOrGrievanceDetails.setOwnerLastName("Cruise");
		appealsOrGrievanceDetails.setComplaintType("complaintType");
		appealsOrGrievanceDetails.setComplaintStatusReason("complaintStatusReason");
		appealsOrGrievanceDetails.setProduct("product");
		appealsOrGrievanceDetails.setDecisionDate("12/11/2022");
		appealsOrGrievanceDetails.setComplaintAge("complaintAge");

	}
}
