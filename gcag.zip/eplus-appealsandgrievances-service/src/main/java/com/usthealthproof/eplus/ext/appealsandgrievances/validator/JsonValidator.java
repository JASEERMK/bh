package com.usthealthproof.eplus.ext.appealsandgrievances.validator;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JsonValidator {

	public void complaintDetailsValidator(JSONObject complaint, String complaintId) {
		log.info("Inside authDetailsValidator()");
		if (null == complaint) {
			throw new NoDataFoundException();
		}
	}

	public JSONObject getJsonObj(JSONObject parentObj, String jsonVar) {
		log.info("Inside getJsonObj()");
		String obj = null;

		if (null != parentObj) {
			obj = parentObj.optString(jsonVar);
			if (null != obj) {
				return new JSONObject(obj);
			}
		}
		return null;
	}

	public JSONArray getJsonArray(JSONObject parentObj, String jsonVar) {
		log.info("Inside getJsonArray()");
		JSONArray obj = null;

		if (null != parentObj) {
			obj = parentObj.getJSONArray(jsonVar);
			if (null != obj) {
				return obj;
			}
		}
		return null;
	}

}
