package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import java.time.OffsetDateTime;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
@JsonIgnoreProperties(ignoreUnknown = true)
public class IntakeAltruistaRequest {

	private String clientPatientID;
	private String carrierMemberID;
	private long lobBenID;
	private OffsetDateTime eligibilityStartDate;
	private String uniqueEligibilityID;
	private String complaintType;
	private String complaintClass;
	private String complaintCategory;
	private String complaintSubCategory;
	private String status;
	private String statusReason;
	private OffsetDateTime notificationDateTime;
	private String notificationMethod;
	private boolean isExtended;
	private String dateTimeOfIncident;
	private String intakeDepartment;
	private String intakeStaff;
	private String complaintAgainst;
	private String complaintAgainstDetails;
	private String responsibleDepartment;
	private String responsibleStaff;
	private boolean isWorkQueueReferral;
	private WorkQueue[] workQueues;
	private String levelOfService;
	private String whoInitiatedComplaint;
	private String providerID;
	private String networkStatus;
	private String updatedRequesterForExpeditedTimeframe;
	private String entityThatProcessedAuthorizationOrClaim;
	private String didSponsorAppealedALJDecision;
	private String initialComplaintNote;
	private String isComplaintNoteInternal;
	private SupplementalInformation[] intakeSupplementalInformation;
	private InternalAuthorization[] internalAuthorizations;
	private ExternalAuthorization[] externalAuthorizations;
	private InternalClaim[] internalClaims;
	private ExternalClaim[] externalClaims;
	private Aor aor;
	private WOL wol;
	private Provider[] providers;
	private SupplementalInformation[] providerSupplementalInformation;
	private String authorizationMedicalDirector;
	private String complaintMedicalDirector;
	private String externalReviewer;
	private OffsetDateTime reviewSentDateTime;
	private OffsetDateTime reviewReturnDateTime;
	private String reviewerDetailNote;
	private String isReviewerDetailNoteInternal;
	private SupplementalInformation[] reviewerSupplementalInformation;
	private String isPossibleQOC;
	private String acceptAsQOC;
	private String qocInvestigativeOutcome;
	private String qocCoordinator;
	private String qocScore;
	private String qocInvestigativeReason;
	private String qocNotes;
	private String isQOCNotesInternal;
	private SupplementalInformation[] qocSupplementalInformation;
	private String isAdditionalInfoComplete;
	private AdditionalInformationRequestedDetail[] additionalInformationRequestedDetail;
	private SupplementalInformation[] additionalInfoSupplementalInformation;
	private String episodeType;
	private String episodeName;
	private String episodeNameDescription;
	private String episodeDescription;
	private String isEpisodeDescriptionInternal;
	private SupplementalInformation[] episodeSupplementalInformation;
	private String isResolved;
	private String resolutionCategory;
	private String resolutionSubCategory;
	private OffsetDateTime resolutionDateTime;
	private OffsetDateTime effectuationDateTime;
	private OffsetDateTime oralNotificationDateTime;
	private OffsetDateTime writtenNotificationDateTime;
	private OffsetDateTime reimbursementDate;
	private String isInterestPaidOnReconsideration;
	private String resolutionNote;
	private String isResolutionNoteInternal;
	private SupplementalInformation[] resolutionSupplementalInformation;
	private Participant[] participants;
	private SupplementalInformation[] participantSupplementalInformation;

	@Data
	public class SupplementalInformation {
		private String name;
		private String[] value;
	}

	@Data
	public class AdditionalInformationRequestedDetail {
		private String type;
		private String contact;
		private String contactNumber;
		private OffsetDateTime requestedInformationDateTime;
		private OffsetDateTime receivedInformationDateTime;
		private String requestNotes;
		private boolean isRequestNotesInternal;
	}

	@Data
	public class Aor {
		private String aorType;
		private OffsetDateTime aorRequestedDateTime;
		private OffsetDateTime aorReceivedDateTime;
		private String firstName;
		private String lastName;
		private String relationship;
		private String address;
		private String city;
		private String state;
		private String zip;
		private String phoneNumber;
		private String aorNote;
		private boolean isAorNoteInternal;
	}

	@Data
	public class ExternalAuthorization {
		private String externalAuthorizationID;
		private OffsetDateTime serviceStartDate;
		private OffsetDateTime serviceEndDate;
		private String authorizationExternalSource;
		private String authRelatedEligibility;
		private String serviceType;
		private String decisionStatus;
		private String[] relatedDiagnosis;
		private String[] relatedMedication;
		private String[] relatedProcedures;
	}

	@Data
	public class ExternalClaim {
		private String claimNumber;
		private OffsetDateTime serviceStartDate;
		private OffsetDateTime serviceEndDate;
		private String claimExternalSource;
		private String providerID;
		private String visitType;
		private String reasonForVisit;
		private String denialReason;
		private String entityThatProcessedClaim;
		private String[] relatedDiagnosis;
		private String[] relatedMedication;
		private String[] relatedProcedures;
	}

	@Data
	public class InternalAuthorization {
		private String authorizationID;
		private String isPrimary;
	}

	@Data
	public class InternalClaim {
		private String claimNumber;
	}

	@Data
	public class Participant {
		private String name;
		private String type;
		private String role;
		private String relationship;
		private String phone;
		private String zip;
		private String email;
		private String participantNote;
		private String isParticipantNoteInternal;
	}

	@Data
	public class Provider {
		private String providerID;
		private String providerRole;
		private String providerPhone;
		private String providerAlternatePhone;
		private String providerFax;
		private String externalReviewerName;
		private String externalReviewerTitle;
	}

	@Data
	public class WOL {
		private String wolType;
		private OffsetDateTime wolRequestedDateTime;
		private OffsetDateTime wolReceivedDateTime;
		private String firstName;
		private String lastName;
		private String relationship;
		private String address;
		private String city;
		private String state;
		private String zip;
		private String phoneNumber;
		private String wolNote;
		private boolean isWOLNoteInternal;
	}

	@Data
	public class WorkQueue {
		private String departmentName;
		private String[] careStaffUserName;
	}
}
