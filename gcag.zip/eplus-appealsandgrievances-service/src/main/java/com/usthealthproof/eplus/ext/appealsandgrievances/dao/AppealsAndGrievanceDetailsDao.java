package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.util.DateUtils;
import com.usthealthproof.eplus.ext.appealsandgrievances.validator.JsonValidator;

@Repository
public class AppealsAndGrievanceDetailsDao {
	@Autowired
	AppealsOrGrievanceDetails appealsOrGrievanceDetails;
	@Autowired
	DateUtils dateUtils;
	@Autowired
	JsonValidator jsonValidator;
	@Autowired
	private WebClient webClient;


	private static final Logger log = LoggerFactory.getLogger(AppealsAndGrievanceDetailsDao.class);

	public AppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId) {
		try {

			// Call altruista request
			//webClient.get().uri("").retrieve();
			log.info("Started retrieving results from altruista");
			getData(complaintId);
			if (null == appealsOrGrievanceDetails) {
				throw new NoDataFoundException();
			}}
			catch (WebClientResponseException clientResponseException) {

				log.info("Status Code : {} ,RawStatusCode : {}, Status Text : {}", clientResponseException.getStatusCode(),

						clientResponseException.getStatusCode().value(), clientResponseException.getStatusText());

				throw clientResponseException;

			} catch (WebClientException clientException) {

				log.info("Failed to receive the PNC document for the request : {} and the clientException is: ",

						 clientException);

				throw clientException;

		} catch (NoDataFoundException noDataFoundException) {
			throw noDataFoundException;
		} catch (Exception e) {
			throw new InternalException(e);
		}
		log.info("Retrieved altruista response successfully");
		return appealsOrGrievanceDetails;
	}

	private void getData(String complaintId) {
		JSONObject complaint = new JSONObject(AppealsAndGrievanceConstants.memberAppealsOrgrievancesDetailsApi);
		jsonValidator.complaintDetailsValidator(complaint, complaintId);
		appealsOrGrievanceDetails.setComplaintID(complaintId);
		JSONArray participantsList = jsonValidator.getJsonArray(complaint, "participants");
		JSONArray claimsList = jsonValidator.getJsonArray(complaint, "internalClaims");

		if (null != complaint) {
			setComplaintParameters(complaint);
		}

		if (null != participantsList) {
			setParticipantParameters(participantsList);
		}

		if (null != claimsList) {
			setClaimParameters(claimsList);
		}
	}

	private void setParticipantParameters(JSONArray participantsList) {
		if (participantsList.length() > 0) {

			JSONObject participant = participantsList.getJSONObject(0);
			appealsOrGrievanceDetails.setContactName(participant.optString("name"));
			appealsOrGrievanceDetails.setContactNumber(participant.optString("phone"));
		}
	}

	private void setComplaintParameters(JSONObject complaint) {

		appealsOrGrievanceDetails.setComplaintCategory(complaint.optString("complaintCategory"));
		appealsOrGrievanceDetails.setPriority(complaint.optString("complaintClass"));
		appealsOrGrievanceDetails.setCreatedDate(dateUtils.getFormattedApplicationDate(complaint.optString("createdDateTime")));
		appealsOrGrievanceDetails
				.setReceivedDate(dateUtils.getFormattedApplicationDate(complaint.optString("notificationDateTime")));
		appealsOrGrievanceDetails.setCaseAge(dateUtils.getFormattedApplicationDate(complaint.optString("notificationDateTime")));
		appealsOrGrievanceDetails.setLevel(complaint.optString("level"));
		appealsOrGrievanceDetails.setComplaintStatus(complaint.optString("status"));
		appealsOrGrievanceDetails.setComplaintSubCategory(complaint.optString("complaintSubCategory"));
		appealsOrGrievanceDetails.setContactChannel(complaint.optString("notificationMethod"));
		appealsOrGrievanceDetails.setRequestor(complaint.optString("whoInitiatedComplaint"));
		appealsOrGrievanceDetails.setDueDate(dateUtils.getFormattedApplicationDate(complaint.optString("dueDateTime")));
		appealsOrGrievanceDetails.setServiceType(complaint.optString("levelOfService"));
		appealsOrGrievanceDetails
				.setResolutionDate(dateUtils.getFormattedApplicationDate(complaint.optString("resolutionDateTime")));
		appealsOrGrievanceDetails.setResolutionCategory(complaint.optString("resolutionCategory"));
		appealsOrGrievanceDetails.setResolutionSubCategory(complaint.optString("resolutionSubCategory"));
		appealsOrGrievanceDetails.setResolutionNotes(complaint.optString("resolutionNote"));
		appealsOrGrievanceDetails
				.setIncidentDate(dateUtils.getFormattedApplicationDate(complaint.optString("dateTimeOfIncident")));
		appealsOrGrievanceDetails.setResponsibleDepartment(complaint.optString("responsibleDepartment"));
		appealsOrGrievanceDetails.setStaffName(complaint.optString("responsibleStaff"));
		appealsOrGrievanceDetails.setComplaintNotes(complaint.optString("initialComplaintNote"));
	}

	private void setClaimParameters(JSONArray claimsList) {

		JSONObject claim = claimsList.getJSONObject(0);
		appealsOrGrievanceDetails.setClaimId(claim.optString("claimNumber"));
		appealsOrGrievanceDetails.setAuthorizationId(claim.optString("internalAuthorizationID"));
	}
}