package com.usthealthproof.eplus.ext.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.appealsandgrievances.model.ErrorResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.ProviderAppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.service.ProviderAppealsAndGrievanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/v1/ang/")
@RestController
@Validated
@Tag(name = "Provider Appeals and Grievances")
public class ProviderAppealsAndGrievanceController {

	@Autowired
	ProviderAppealsAndGrievanceService providerAppealsAndGrievanceService;

	private static final Logger log = LoggerFactory.getLogger(ProviderAppealsAndGrievanceController.class);

	@GetMapping(value = "provider/complaints", produces = { MediaType.APPLICATION_JSON_VALUE })

	@Operation(summary = "Get Provider Appeals/Grievances summary", method = "GET", description = "Service for retrieving all Appeals/Grievances summary based on complaint type of a provider", responses = {
			@ApiResponse(responseCode = "200", description = "Appeals/Grievances summary response", content = {
					@Content(array = @ArraySchema(schema = @Schema(implementation = ProviderAppealsOrGrievanceSummary.class))) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<List<ProviderAppealsOrGrievanceSummary>> getProviderAppealsOrgrievancesSummary(

			@RequestParam(value = "providerId", required = true) @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: providerId is not in valid format") String providerId,
			@RequestParam(value = "complaintType", required = true) @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: complaintType is not in valid format") String complaintType) {
		log.info("Inside getMemberAppealsOrgrievancesSummary()");
		return new ResponseEntity<>(providerAppealsAndGrievanceService.getAppealsOrGrievanceSummary(providerId, complaintType),
				HttpStatus.OK);
	}

	@GetMapping(value = "provider/complaint/details", produces = { MediaType.APPLICATION_JSON_VALUE })

	@Operation(summary = "Get Provider Appeals/Grievances details", description = "Service for retrieving provider Appeals/Grievances details of a particular complaint ", responses = {

			@ApiResponse(responseCode = "200", description = "Appeals/Grievances details response", content = {
					@Content(schema = @Schema(implementation = ProviderAppealsOrGrievanceDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	public ResponseEntity<ProviderAppealsOrGrievanceDetails> getProviderAppealsOrgrievancesDetails(

			@RequestParam(value = "complaintId", required = true) @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: complaintId is not in valid format") String complaintId) {

		log.info("Inside getMemberAppealsOrgrievancesDetails()");
		return new ResponseEntity<>(providerAppealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId), HttpStatus.OK);

	}
}
