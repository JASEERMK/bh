package com.usthealthproof.eplus.ext.appealsandgrievances.exception;

public class NoDataFoundException extends RuntimeException {
	public NoDataFoundException(Throwable throwable) {
		super(throwable);
	}

	public NoDataFoundException() {
	}
}
