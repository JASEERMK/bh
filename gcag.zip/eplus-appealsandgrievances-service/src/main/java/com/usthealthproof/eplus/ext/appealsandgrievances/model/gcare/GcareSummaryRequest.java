package com.usthealthproof.eplus.ext.appealsandgrievances.model.gcare;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Gcare Summary response received from the external service")
public class GcareSummaryRequest {
    private String memberId;
    private String complaintType;
}
