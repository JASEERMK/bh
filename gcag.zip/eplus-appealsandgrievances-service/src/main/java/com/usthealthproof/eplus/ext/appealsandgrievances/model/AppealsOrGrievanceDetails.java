package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Member Appeal")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppealsOrGrievanceDetails {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "complaint Sub Category")
	private String complaintSubCategory;
	@Schema(description = "Priority")
	private String priority;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Receive Date time")
	private String receivedDate;
	@Schema(description = "Created Date")
	private String createdDate;
	@Schema(description = "Case Age")
	private String caseAge;
	@Schema(description = "Appeal Level")
	private String level;
	@Schema(description = "Complaint Status")
	private String complaintStatus;
	@Schema(description = "Contact Channel")
	private String contactChannel;
	@Schema(description = "Requestor")
	private String requestor;
	@Schema(description = "Due Date")
	private String dueDate;
	@Schema(description = "Service Type")
	private String serviceType;
	@Schema(description = "Resolution Date")
	private String resolutionDate;
	@Schema(description = "Resolution Category")
	private String resolutionCategory;
	@Schema(description = "Resolution Sub Category")
	private String resolutionSubCategory;
	@Schema(description = "Resolution Notes")
	private String resolutionNotes;
	@Schema(description = "Incident Date")
	private String incidentDate;
	@Schema(description = "Claim Number")
	private String claimId;
	@Schema(description = "Authorization Id")
	private String authorizationId;
	@Schema(description = "Responsible Department")
	private String responsibleDepartment;
	@Schema(description = "Staff Name")
	private String staffName;
	@Schema(description = "Contact Name")
	private String contactName;
	@Schema(description = "Contact Number")
	private String contactNumber;
	@Schema(description = "Complaint Notes")
	private String complaintNotes;

}
