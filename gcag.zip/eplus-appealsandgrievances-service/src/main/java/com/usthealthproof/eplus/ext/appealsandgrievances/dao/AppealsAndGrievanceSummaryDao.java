package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.AppealsOrGrievanceSummaryResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.util.DateUtils;

@Repository
public class AppealsAndGrievanceSummaryDao {

	private static final Logger log = LoggerFactory.getLogger(AppealsAndGrievanceSummaryDao.class);

	// @Value("${altruista.memberAppealsOrgrievancesSummaryApi}")
	private String appealsOrGrievanceSummaryURI = "";
	// @Value("${altruista.memberAppealsOrgrievancesDetailsApi}")
	private String appealsOrGrievanceDetailsURI = "";

	@Autowired
	private DateUtils dateUtils;
	@Autowired
	private AppealsOrGrievanceSummary appealsOrGrievanceSummaryResponse;
	@Autowired
	private WebClient webClient;

	public List<AppealsOrGrievanceSummary> getAppealsOrGrievanceSummary(String memberId, String complaintType) {
		try {

			log.info("Calling Altruita service");
			appealsOrGrievanceSummaryURI = modifyUrl(memberId);

			/*
			 * ResponseEntity<String> appealsOrGrievanceSummaryResponse = webClient.get().uri("").retrieve();
			 */

			List<AppealsOrGrievanceSummary> appealsOrGrievanceSummaryList = getAppealsOrGrievanceSummaryList(complaintType);
			if (appealsOrGrievanceSummaryList.isEmpty()) {
				throw new NoDataFoundException();
			}
			log.info("Retrievd results successfully");
			return appealsOrGrievanceSummaryList;
		}
			catch (WebClientResponseException clientResponseException) {

				log.info("Status Code : {} ,RawStatusCode : {}, Status Text : {}", clientResponseException.getStatusCode(),

						clientResponseException.getStatusCode().value(), clientResponseException.getStatusText());

				throw clientResponseException;

			} catch (WebClientException clientException) {

				log.info("Failed to receive the PNC document for the request : {} and the clientException is: ",

						 clientException);

				throw clientException;
		} catch (NoDataFoundException noDataFoundException) {
			throw noDataFoundException;
		} catch (Exception e) {
			throw new InternalException(e);
		}
	}

	// Modify Base url with required altruista url
	private String modifyUrl(String memberId) {
		return appealsOrGrievanceSummaryURI + "?clientPatientID=" + memberId;
	}

	// Creates list using the result set obtained from altruista
	private List<AppealsOrGrievanceSummary> getAppealsOrGrievanceSummaryList(String complaintType) {
		log.info("Started retrieving the results from Altruista");
		List<AppealsOrGrievanceSummary> appealsOrGrievanceSummaryList = new ArrayList();
		JSONObject apiResult = new JSONObject(AppealsAndGrievanceConstants.memberAppealsOrgrievancesSummaryApi);
		if (null == apiResult.getJSONArray("results")) {
			throw new NoDataFoundException();
		}
		JSONArray results = apiResult.getJSONArray("results");
		for (int i = 0; i < results.length(); i++) {
			AppealsOrGrievanceSummary appealsOrGrievanceSummary = new AppealsOrGrievanceSummary();
			JSONObject complaint = results.getJSONObject(i);
			// Filter results according to complaint type
		//	if (complaintType.trim().equalsIgnoreCase(complaint.getString("complaintType"))) {

				appealsOrGrievanceSummary.setComplaintID(complaint.optString("complaintID"));
				appealsOrGrievanceSummary.setComplaintCategory(complaint.optString("complaintCategory"));
				appealsOrGrievanceSummary.setComplaintSubCategory(complaint.optString("complaintSubCategory"));
				appealsOrGrievanceSummary.setPriority(complaint.optString("complaintClass"));
				appealsOrGrievanceSummary
						.setReceivedDate(dateUtils.getFormattedApplicationDate(complaint.optString("receivedDateTime")));
				appealsOrGrievanceSummary.setStatus(complaint.optString("status"));

				appealsOrGrievanceSummaryList.add(appealsOrGrievanceSummary);
		//	}

		}

		return appealsOrGrievanceSummaryList;

	}

}
