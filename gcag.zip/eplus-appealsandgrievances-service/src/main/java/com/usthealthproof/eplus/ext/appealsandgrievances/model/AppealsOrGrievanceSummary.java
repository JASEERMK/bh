package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Member Appeals or Grievance Summary")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppealsOrGrievanceSummary {

	@Schema(description = "Appeal/Grievance Number")
	private String complaintID;
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "complaint Sub Category")
	private String complaintSubCategory;
	@Schema(description = "Priority Requested")
	private String priority;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Receive Date time")
	private String receivedDate;

}
