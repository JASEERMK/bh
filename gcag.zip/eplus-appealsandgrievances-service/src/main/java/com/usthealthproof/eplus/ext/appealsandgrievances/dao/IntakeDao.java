package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.text.ParseException;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.usthealthproof.eplus.ext.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.InternalException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.NoDataFoundException;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest.Aor;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest.InternalAuthorization;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest.InternalClaim;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest.Participant;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeAltruistaRequest.WorkQueue;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest.Address;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest.GrievancesDetail;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest.RepresentativeDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.model.IntakeRequest.SubmitterDetails;
import com.usthealthproof.eplus.ext.appealsandgrievances.util.DateUtils;

@Repository
public class IntakeDao {

	// @Value("${altruista.intakeApi}")
	// private String intakeApi = "";

	@Autowired
	private IntakeAltruistaRequest intakeAltruistaRequest;
	@Autowired
	private IntakeResponse intakeResponse;
	@Autowired
	DateUtils dateUtils;
	@Autowired
	IntakeMemberEligibilityDao intakeMemberEligibilityDao;

	private static final Logger log = LoggerFactory.getLogger(IntakeDao.class);

	public IntakeResponse recordClaimIntake(IntakeRequest intakeRequest) {

		try {
			log.info("Calling Altruita service");

			// Map intake request to altruista request
			intakeAltruistaRequest = setAltruistaRequest(intakeRequest);

			// Convert altruista req obj to json
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			String intakeAltruistaRequestJson = ow.writeValueAsString(intakeAltruistaRequest);

			// Call Altruista API
			/*
			 * ResponseEntity<String> appealsOrGrievanceSummaryResponse = webClient.post().uri("").retrieve();
			 */
			HttpEntity<String> request = new HttpEntity<String>(intakeAltruistaRequestJson);
			getData();
			if (null == intakeResponse) {
				throw new NoDataFoundException();
			}
			return intakeResponse;
		}
			catch (WebClientResponseException clientResponseException) {

				log.info("Status Code : {} ,RawStatusCode : {}, Status Text : {}", clientResponseException.getStatusCode(),

						clientResponseException.getStatusCode().value(), clientResponseException.getStatusText());

				throw clientResponseException;

			} catch (WebClientException clientException) {

				log.info("Failed to receive the PNC document for the request : {} and the clientException is: ",

						 clientException);

				throw clientException;

		} catch (NoDataFoundException noDataFoundException) {
			throw noDataFoundException;

		} catch (RequestValidationException requestValidationException) {
			throw requestValidationException;
		} catch (Exception ex) {
			System.out.println(ex);
			throw new InternalException(ex);
		}
	}

	private void getData() {
		JSONObject intakeJson = new JSONObject(AppealsAndGrievanceConstants.intkeResponse);
		intakeResponse.setComplaintID(intakeJson.optString("complaintID"));
		intakeResponse.setLevel(intakeJson.optString("level"));
		intakeResponse.setStatus(intakeJson.optString("status"));
		intakeResponse.setStatusReason(intakeJson.optString("statusReason"));
		intakeResponse.setComplaintType(intakeJson.optString("complaintType"));
		intakeResponse.setCreatedDateTime(dateUtils.getFormattedApplicationDate(intakeJson.optString("createdDateTime")));
	}

	private IntakeAltruistaRequest setAltruistaRequest(IntakeRequest intakeRequest) throws ParseException, Exception {

		setParameters(intakeRequest);
		setSubmitterDetails(intakeRequest);
		setWorkQueue(intakeRequest.getComplaintType());
		if (null != intakeRequest.memberBehalf) {
			setAorDetails(intakeRequest);
		}
		if (null != intakeRequest.getAppealsDetail()) {

			setClaimsAndAuth(intakeRequest.getAppealsDetail().getId());
		}

		if (null != intakeRequest.getGrievancesDetail()) {

			setGrievanceDetails(intakeRequest.getGrievancesDetail());
		}
		return intakeAltruistaRequest;

	}

	private void setGrievanceDetails(GrievancesDetail grievancesDetail) {
		intakeAltruistaRequest.setComplaintSubCategory(grievancesDetail.getComplaintSubCategory());
		intakeAltruistaRequest.setComplaintAgainst(grievancesDetail.complaintRelatedTo);
		intakeAltruistaRequest.setComplaintAgainstDetails(grievancesDetail.providerDetails);

	}

	private void setAorDetails(IntakeRequest intakeRequest) {
		Aor aor = intakeAltruistaRequest.new Aor();
		RepresentativeDetails representativeDetails = intakeRequest.getRepresentativeDetails();
	

		if (null != representativeDetails) {
			aor.setFirstName(representativeDetails.getFirstName());
			aor.setLastName(representativeDetails.getLastName());
			Address representativeAddress = representativeDetails.getRepresentativeAddress();
			if (null != representativeAddress) {
				aor.setAddress(representativeAddress.getAddress());
				aor.setCity(representativeAddress.getCity());
				aor.setState(representativeAddress.getState());
				aor.setZip(representativeAddress.getZip());
				aor.setPhoneNumber(representativeAddress.getPhoneNumber());
			}
			intakeAltruistaRequest.setAor(aor);
		}
	}

	private void setClaimsAndAuth(String id) {

		InternalClaim internalClaim = intakeAltruistaRequest.new InternalClaim();
		internalClaim.setClaimNumber(id);
		InternalClaim[] internalClaims = new InternalClaim[1];
		internalClaims[0] = internalClaim;
		intakeAltruistaRequest.setInternalClaims(internalClaims);

		InternalAuthorization internalAuthorization = intakeAltruistaRequest.new InternalAuthorization();
		internalAuthorization.setAuthorizationID(id);
		InternalAuthorization[] internalAuthorizations = new InternalAuthorization[1];
		internalAuthorizations[0] = internalAuthorization;
		intakeAltruistaRequest.setInternalAuthorizations(internalAuthorizations);
	}

	private void setParameters(IntakeRequest intakeRequest) throws ParseException, Exception {
		/*
		 * intakeAltruistaRequest.setLobBenID(
		 * intakeMemberEligibilityDao.callMemberEligibility(intakeRequest.getMemberId(),
		 * intakeRequest.getIssueDate()));
		 */
		intakeAltruistaRequest.setNotificationMethod(AppealsAndGrievanceConstants.NOTIFICATION_METHOD);
		intakeAltruistaRequest.setIntakeDepartment(AppealsAndGrievanceConstants.INTAKE_DEPARTMENT);
		intakeAltruistaRequest.setClientPatientID(intakeRequest.memberId);
		intakeAltruistaRequest.setWhoInitiatedComplaint(intakeRequest.getSubmitterType());
		intakeAltruistaRequest.setComplaintType(intakeRequest.getComplaintType());
		intakeAltruistaRequest.setComplaintClass(intakeRequest.getPriority());
		intakeAltruistaRequest.setDateTimeOfIncident(intakeRequest.getIssueDate());
		intakeAltruistaRequest.setInitialComplaintNote(intakeRequest.getComplaintDescription());
		intakeAltruistaRequest.setResponsibleStaff(setDept(intakeRequest.getComplaintType()));
		intakeAltruistaRequest.setComplaintCategory(intakeRequest.getComplaintCategory());
		intakeAltruistaRequest.setStatus(AppealsAndGrievanceConstants.OPEN);
		intakeAltruistaRequest.setIntakeStaff(AppealsAndGrievanceConstants.INTAKE_STAFF);

	}

	private void setSubmitterDetails(IntakeRequest intakeRequest) {
		SubmitterDetails submitterDetails = intakeRequest.submitterDetails;
		if (null != intakeRequest.submitterDetails) {
			intakeAltruistaRequest.setProviderID(submitterDetails.submitterId);
			Participant participant = intakeAltruistaRequest.new Participant();
			participant.setName(submitterDetails.getFirstName() + " " + submitterDetails.getLastName());
			participant
					.setParticipantNote(submitterDetails.submitterAddress.address + "," + submitterDetails.submitterAddress.city);
			participant.setZip(submitterDetails.submitterAddress.zip);
			participant.setPhone(submitterDetails.submitterAddress.phoneNumber);
			participant.setRelationship(submitterDetails.submitterRelationship);
			Participant[] participants = new Participant[1];
			participants[0] = participant;
			intakeAltruistaRequest.setParticipants(participants);
		}
	}

	private void setWorkQueue(String complaintType) {
		WorkQueue workQueue = intakeAltruistaRequest.new WorkQueue();
		workQueue.setDepartmentName(setDept(complaintType));
		WorkQueue[] workQueues = new WorkQueue[1];
		workQueues[0] = workQueue;
		intakeAltruistaRequest.setWorkQueues(workQueues);
	}

	private String setDept(String complaintType) {

		if (complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.DENTAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.MEDICAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.RX_MEDICAL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.RX_RETAIL_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.VISION_APPEAL)
				|| complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.APPEAL)) {

			return AppealsAndGrievanceConstants.AG_MEMBER_APPEAL;
		} else if (complaintType.equalsIgnoreCase(AppealsAndGrievanceConstants.GRIEVANCE_TYPE)) {
			return AppealsAndGrievanceConstants.AG_GRIEVANCES;
		}
		return null;
	}
}
