package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Response objects containing appeals/grievance summary")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppealsOrGrievanceSummaryResponse {
	@Schema(description = "List containing appeals/grievance summary")
	private List<AppealsOrGrievanceSummary> appealsOrGrievanceSummaryList;
}
