package com.usthealthproof.eplus.ext.appealsandgrievances.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Repository;

import com.usthealthproof.eplus.ext.appealsandgrievances.constants.DummyResponse;
import com.usthealthproof.eplus.ext.appealsandgrievances.exception.RequestValidationException;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class IntakeMemberEligibilityDao {

	public String callMemberEligibility(String clientPatientID, String issueDate) throws ParseException, Exception {

		log.info("Calling Member Eligibility Altruita service");
		// call GET https://{api_base_url}/Member/Eligibility?clientPatientID=ALT12345
		// HTTP/1.1

		String membEligibilityResponse = DummyResponse.memberEligibilityResponse;
		return getLobId(membEligibilityResponse, issueDate);

	}

	private String getLobId(String membEligibilityResponse, String issueDate) throws ParseException, Exception {
		JSONArray jsonArr = new JSONArray(membEligibilityResponse);
		for (int i = 0; i < jsonArr.length(); i++) {
			JSONObject memberEligibility = jsonArr.getJSONObject(i);
			JSONArray eligibilities = memberEligibility.getJSONArray("eligibilities");
			String lobId = getLobId(eligibilities, issueDate);
			if (null != lobId) {
				return lobId;
			} else {
				throw new RequestValidationException("LobId is not present");
			}
		}
		return null;
	}

	private String getLobId(JSONArray eligibilities, String issueDate) throws ParseException, Exception {
		for (int j = 0; j < eligibilities.length(); j++) {
			JSONObject eligibility = eligibilities.getJSONObject(j);
			String startDate = eligibility.optString("startDate");
			String endDate = eligibility.optString("endDate");
			boolean flag = checkDate(startDate, endDate, issueDate);
			if (flag == true) {
				return eligibility.optString("lobBenID");
			}
		}
		return null;
	}
	
	private boolean checkDate(String startDate, String endDate, String issueDate) throws ParseException, Exception {
		Date startDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
		Date endDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
		Date issueDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(issueDate);
		if (startDate1.equals(issueDate1) | startDate1.before(issueDate1)) {
			if (endDate1.equals(issueDate1) | endDate1.after(issueDate1)) {

				return true;
			}

		}
		return false;
	}

}

