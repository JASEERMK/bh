package com.usthealthproof.eplus.ext.appealsandgrievances.model.gcare;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Object for holding Guiding Care Details request for calling the external service")
public class GcareDetailsRequest {
    private String complaintID;
}
