package com.usthealthproof.eplus.ext.appealsandgrievances.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Component
@Data
@Schema(description = "Intake Response")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IntakeResponse {

	@Schema(description = "Appeal/Grievance Number")
	public String complaintID;
	@Schema(description = "Created Date Time")
	public String createdDateTime;
	@Schema(description = "Level")
	public String level;
	@Schema(description = "Status")
	public String status;
	@Schema(description = "Status Reason")
	public String statusReason;
	@Schema(description = "Compliant type")
	public String complaintType;
}
