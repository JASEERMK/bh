package com.usthealthproof.eplus.batch.enrollment.config;

import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import com.usthealthproof.eplus.commons.batch.enrollment.config.JobConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Slf4j
class JobConfigurationTest {

    @Mock
    private JobAuditListener jobAuditListener;
    @Mock
    JobRepository jobRepository;

    @InjectMocks
    private JobConfiguration jobConfig;
    @Mock
    private JobLauncher jobLauncher;
    @Mock
    AuditService auditService;
    @Mock
    Job jobMock;

    @Mock
    EnrollmentService enrollmentService;
    @Mock
    JobExecution jobExecutionMock;
    @Mock
    private PlatformTransactionManager transactionManager;
    @Mock
    TaskExecutorJobLauncher taskExecutorJobLauncher;
    @Mock Step stepMock;
    @Mock
    JobParameters param;

    @BeforeEach
    public void setUp() throws JobInstanceAlreadyCompleteException, JobExecutionAlreadyRunningException, JobParametersInvalidException, JobRestartException {
        MockitoAnnotations.initMocks(this);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        ReflectionTestUtils.setField(jobConfig, "jobAuditListener", jobAuditListener);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        param = new JobParametersBuilder()
                .addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        jobExecutionMock=new JobExecution(new JobInstance(1L, "jobName"), param);


    }

    /**
     * Method under test: {@link JobConfiguration#getJobListenerCount()}
     */
    @Test
    public void testGetJobListenerCount() {
        log.info("inside testGetJobListenerCount");
        JobExecutionListener jobExecutionListener = jobConfig.getJobListenerCount();
        assertNotNull(jobExecutionListener);
        jobConfig.getJobListenerCount().beforeJob(jobExecutionMock);
        jobConfig.getJobListenerCount().afterJob(jobExecutionMock);
    }

    /**
     * Method under test: {@link JobConfiguration#taskExecutorJobLauncher(JobRepository)}
     */
    @Test
    public void testTaskExecutorJobLauncher() {
        log.info("inside testGetJobListenerCount");
        TaskExecutorJobLauncher launcher = jobConfig.taskExecutorJobLauncher(jobRepository);
        assertNotNull(launcher);
    }

    //@Test
    void testLaunchJob() throws Exception {
        Exception exception = new Exception("Test exception");
        jobConfig.launchJob();
        Mockito.verify(auditService).auditException(exception, "Some message");

    }

    @Test
    void profileUpdateJobTest() throws Exception {

        // Call the method to be tested
        Job result = jobConfig.profileUpdateJob(
                stepMock,
                stepMock,stepMock,stepMock,stepMock,stepMock,
                jobRepository,
                transactionManager,
                auditService
        );
        assertEquals("enrollmentBatchJob", result.getName());
    }

}