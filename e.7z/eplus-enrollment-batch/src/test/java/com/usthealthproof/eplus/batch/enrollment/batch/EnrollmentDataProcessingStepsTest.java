package com.usthealthproof.eplus.batch.enrollment.batch;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.SkippedItemsExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import com.usthealthproof.eplus.batch.enrollment.util.*;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.EnrollmentDataProcessingSteps;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.RepositoryPagedItemReader;
import com.usthealthproof.eplus.commons.batch.enrollment.util.CommonUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudEnrollmentAdapterMapping;
import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudMappingUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.util.MappingUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@TestPropertySource(properties = {
        "batch.execution.chunk-size=10"
})

class EnrollmentDataProcessingStepsTest {
    @Mock
    static JobExecution jobExecutionMock;
    @InjectMocks
    HealthCloudMappingUtil healthCloudMappingUtil;
    @Mock
    EnrollmentDataProcessingSteps enrollmentDataProcessingSteps;
    @Mock
    ExecutionContext executionContextMock;
    @Mock
    CommonUtil commonUtil;
    @Mock
    AccountDetailsRepository accountDetailsRepositoryMock;
    @Mock
    private EnrollmentService enrollmentServiceMock;
    @Spy
    private Environment envMock;
    @Mock
    private SkippedItemsExceptionListener skippedItemsExceptionListenerMock;
    @Mock
    HealthCloudEnrollmentAdapterMapping clientMapping;
    @Mock
    TestUtil testUtil;
    @Mock
    private ItemWriter<List<AccountRequest>> itemWriter;

    @Mock
    @Qualifier("asyncExecutor")
    private TaskExecutor taskExecutor;

    @Mock
    private Step step;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private PlatformTransactionManager platformTransactionManager;

    @Mock
    RepositoryPagedItemReader repositoryPagedItemReader;

    @Qualifier("enrollmentMappingUtil")
    @Mock
    MappingUtil mappingUtil;

    protected static final String OVERRIDDEN_BY_EXPRESSION = "5";

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        enrollmentDataProcessingSteps = new EnrollmentDataProcessingSteps(accountDetailsRepositoryMock, enrollmentServiceMock, envMock, skippedItemsExceptionListenerMock);
    }

    @Test
    public void testWrite() throws Exception {
        Map<String, String> recordTypeIdMap = new HashMap<>();
        recordTypeIdMap.put("enrollmentRecordTypeId","12345");
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RECORD_TYPE_MAP)).thenReturn(recordTypeIdMap);
        String accountEnrollmentUrl = "/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
        ReflectionTestUtils.setField(healthCloudMappingUtil, "accountEnrollmentUrl", accountEnrollmentUrl);
        doNothing().when(clientMapping).updateMemberInfo(any(),any());
        MemberEnrollment memberRequest1 = testUtil.setMemberEnrollment();
        AccountRequest request1 = healthCloudMappingUtil.createMemberBatchRequest(memberRequest1, jobExecutionMock);
        AccountRequest request2 = healthCloudMappingUtil.createMemberBatchRequest(memberRequest1, jobExecutionMock);

        // Create a mock ItemWriter
        ItemWriter<List<AccountRequest>> itemWriterMock = mock(ItemWriter.class);

        // Set up the stepExecutionMock on the itemWriterMock using @BeforeStep method
        List<AccountRequest> accountRequests = new ArrayList<>();
        accountRequests.add(request1);
        accountRequests.add(request2);

        // Create a Chunk object with the test data
        Chunk<List<AccountRequest>> chunk = new Chunk<>(Collections.singletonList(accountRequests));

        // Call the method to test
        enrollmentDataProcessingSteps.write().write(chunk);
        assertEquals(1, chunk.getItems().size());
        ArgumentCaptor<Graphs> argumentCaptor = ArgumentCaptor.forClass(Graphs.class);
        ArgumentCaptor<StepExecution> argumentCaptor1 = ArgumentCaptor.forClass(StepExecution.class);
        // Create an empty Chunk object
        Chunk<List<AccountRequest>> emptyChunk = new Chunk<>(Collections.emptyList());
        // Call the write method with the empty chunk
        enrollmentDataProcessingSteps.write().write(emptyChunk);

        // Prepare test data
        List<AccountRequest> accountRequestsList = new ArrayList<>();
        // Create a Chunk object with the test data
        Chunk<List<AccountRequest>> chunkList = new Chunk<>(Collections.singletonList(accountRequestsList));

        // Throw an exception when the write method is called
        doThrow(new RuntimeException("Failed to write data")).when(itemWriterMock).write(chunkList);

        // Call the write method
        assertThrows(RuntimeException.class, () -> itemWriterMock.write(chunkList));
    }

    @Test
    void testReader() throws Exception {
        // Call the method to be tested
        RepositoryPagedItemReader result = enrollmentDataProcessingSteps.reader("1");
        // Verify initialization
        assertEquals(0, result.getCurrentItemCount());
    }

    @Test
    public void testProcess() throws Exception {
        // initialise();
        List<MemberEnrollment> enrollmentList=new ArrayList<>();
        MemberEnrollment memberEnrollment= new MemberEnrollment();
        memberEnrollment.setMemberNumber("12345");
        enrollmentList.add(memberEnrollment);
        List<AccountRequest> result=enrollmentDataProcessingSteps.processor(mappingUtil).process(enrollmentList);
        assertNotNull(result);
    }
    @Test

    public void testSupplierLoadStepException() throws Exception {
        when(envMock.getProperty("batch.execution.chunk-size")).thenReturn("100");
        assertThrows(NumberFormatException.class, ()->
        {
            enrollmentDataProcessingSteps.supplierLoadStep(itemWriter,taskExecutor,jobRepository,platformTransactionManager,mappingUtil);
        });
    }

    @Test
    public void testGetPartitionerStep() throws NoSuchMethodException, NoSuchFieldException, IllegalAccessException, InvocationTargetException {
        Method method = EnrollmentDataProcessingSteps.class.getDeclaredMethod("getPartitionerStep", Step.class,TaskExecutor.class, JobRepository.class);
        method.setAccessible(true);
        Step steps = (Step) method.invoke(enrollmentDataProcessingSteps,step,taskExecutor,jobRepository);

        assertNotNull(steps);
        assertEquals("stepPartition_enrollment",steps.getName());
        assertEquals(2147483647,steps.getStartLimit());
        assertEquals(Boolean.FALSE,steps.isAllowStartIfComplete());
    }

}