package com.usthealthproof.eplus.batch.enrollment.batch;

import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.CountUpdateListener;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepExecution;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CountUpdateListenerTest {

    @InjectMocks
    CountUpdateListener countUpdateListenerMock;
    @Mock
    StepExecution stepExecutionMock;
    @Mock
    EnrollmentService enrollmentService;


    @Test
    public void testCountUpdate() {
        countUpdateListenerMock.beforeStep(stepExecutionMock);
        countUpdateListenerMock.afterStep(stepExecutionMock);

    }
}