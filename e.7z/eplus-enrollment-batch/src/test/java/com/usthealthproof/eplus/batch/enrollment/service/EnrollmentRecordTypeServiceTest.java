package com.usthealthproof.eplus.batch.enrollment.service;

import com.usthealthproof.eplus.commons.batch.common.exception.BatchRestServiceException;
import com.usthealthproof.eplus.commons.batch.common.model.request.RecordIdRequest;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentRecordTypeService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClientException;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
class EnrollmentRecordTypeServiceTest {

    @InjectMocks
    EnrollmentRecordTypeService enrollmentRecordTypeServiceMock;

    @Mock
    private RestCallService<RecordIdMainResponse> restCallServiceMock;
    @Mock
    private AuditService auditService;
    @Mock
    JobExecution jobExecutionMock;

    @Mock
    ChunkContext chunkContextMock;
    @Mock
    StepContext stepContextMock;
    @Mock
    StepExecution stepExecutionMock;
    @Spy
    RecordIdRequest recordIdRequestMock;
    @Spy
    RecordIdMainResponse mockedResponse;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    void initialise() {
        ReflectionTestUtils.setField(enrollmentRecordTypeServiceMock, "enrollmentRecordTypeUrl", "testEnrollmentRecordTypeUrl");
        ReflectionTestUtils.setField(enrollmentRecordTypeServiceMock, "recordTypeUrl", "testrecordTypeUrl");
        // Mock any further required data or objects
        when(chunkContextMock.getStepContext()).thenReturn(stepContextMock);
        when(stepContextMock.getStepExecution()).thenReturn(stepExecutionMock);
        when(restCallServiceMock.callPostRequest(anyString(), any(),any(),any())).thenReturn(mockedResponse);
    }
    @Test
    public void testGetRecordTypeIdSet() throws InterruptedException, ExecutionException {
        initialise();

        // Call the method asynchronously
        CompletableFuture<RecordIdMainResponse> future = enrollmentRecordTypeServiceMock.getRecordTypeIdSet(chunkContextMock);
        // Wait for the asynchronous task to complete
        RecordIdMainResponse responseEntity = future.get();
        // Verify that the method was called with the correct parameters
        verify(restCallServiceMock).callPostRequest(anyString(), any(),any(),any()); // Use the mocked instance here
        // Assert the expected result
        assertEquals(mockedResponse, responseEntity);
    }

    // Custom WebClientException for testing purposes
    private static class MockedWebClientException extends WebClientException {
        public MockedWebClientException(String message) {
            super(message);
        }
    }
    @Test
    public void testCallService_WhenWebClientExceptionThrown() {
        // Mock data
        RecordIdRequest mockedRequest = new RecordIdRequest();

        // Mock behavior

        when(stepContextMock.getStepExecution()).thenReturn(stepExecutionMock);
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(restCallServiceMock.callPostRequest(any(), eq(RecordIdMainResponse.class), any(), any()))
                .thenThrow(new MockedWebClientException("Mocked WebClientException"));

        // Ensure that a StepExecution is bound to the thread
        StepSynchronizationManager.register(stepExecutionMock);

        // Test and assert that BatchRestServiceException is thrown
        assertThrows(BatchRestServiceException.class,
                () -> enrollmentRecordTypeServiceMock.callService(mockedRequest, new ChunkContext(stepContextMock)));

        // Verify that the restCallService.callPostRequest method was called with correct parameters
        verify(restCallServiceMock).callPostRequest(any(), eq(RecordIdMainResponse.class), any(), any());

        // Unbind the StepExecution
        StepSynchronizationManager.close();
    }


}