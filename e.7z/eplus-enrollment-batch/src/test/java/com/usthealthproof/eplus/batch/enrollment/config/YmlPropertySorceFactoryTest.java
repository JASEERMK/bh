package com.usthealthproof.eplus.batch.enrollment.config;

import com.usthealthproof.eplus.commons.batch.enrollment.config.YamlPropertySourceFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class YmlPropertySorceFactoryTest {
    @InjectMocks
    private YamlPropertySourceFactory ymlPropertySourceFactory;

    @Mock
    EncodedResource encodedResource;

    @Test
    public void testCreatePropertySource() throws IOException {
        // Mock the EncodedResource and Resource
        EncodedResource mockEncodedResource = Mockito.mock(EncodedResource.class);
        Resource mockResource = Mockito.mock(Resource.class);

        // Define the YAML content
        String yamlContent = "spring:\n  profiles: dev\nsomeProperty: someValue";
        ByteArrayInputStream yamlInputStream = new ByteArrayInputStream(yamlContent.getBytes());

        // Set up the mock behavior
        when(mockEncodedResource.getResource()).thenReturn(mockResource);
        when(mockResource.getInputStream()).thenReturn(yamlInputStream);
        when(mockResource.getFilename()).thenReturn("mocked-file.yaml");

        // Set the system property for the active profile
        System.setProperty("spring.profiles.active", "dev");

        // Call the method under test
        PropertySource<?> propertySource = ymlPropertySourceFactory.createPropertySource("testName", mockEncodedResource);

        // Assertions
        assertNotNull(propertySource);
        assertEquals("mocked-file.yaml", propertySource.getName());
        assertEquals("someValue", propertySource.getProperty("someProperty"));
    }
}
