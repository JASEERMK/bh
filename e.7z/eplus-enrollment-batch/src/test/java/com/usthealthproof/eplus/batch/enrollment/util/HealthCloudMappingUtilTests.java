package com.usthealthproof.eplus.batch.enrollment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.batch.enrollment.enums.MemberTestEnum;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;

import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.healthcloud.PlanInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.util.CommonUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudEnrollmentAdapterMapping;
import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudMappingUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class HealthCloudMappingUtilTests {
    @InjectMocks
    HealthCloudMappingUtil healthCloudMappingUtil;
    @Mock
    JobExecution jobExecutionMock;
    @Mock
    ExecutionContext executionContextMock;
    @Mock
    HealthCloudEnrollmentAdapterMapping clientMapping;

    @Spy
    CommonUtil commonUtil;

    @Mock
    TestUtil testUtil;

    @Test

    void enrollmentTesting() throws JsonProcessingException, ParseException {
        log.info("inside enrollmentTesting");
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> recordTypeIdMap = new HashMap<>();
        recordTypeIdMap.put("enrollmentRecordTypeId","12345");
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RECORD_TYPE_MAP)).thenReturn(recordTypeIdMap);
        String accountEnrollmentUrl = "/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
        ReflectionTestUtils.setField(healthCloudMappingUtil, "accountEnrollmentUrl", accountEnrollmentUrl);
        ReflectionTestUtils.setField(commonUtil,"showTruncated","true");
        MemberEnrollment memberEnrollment = testUtil.setMemberEnrollment();
        doNothing().when(clientMapping).updateMemberInfo(any(),any());
        AccountRequest memberRequest = healthCloudMappingUtil.createMemberBatchRequest(memberEnrollment, jobExecutionMock);

        MemberInfo memberInfo = (MemberInfo) memberRequest.getCompositeRequest().get(0).getBody();
        String jsonString = objectMapper.writeValueAsString(memberInfo);
        JsonNode jsonNode = objectMapper.readTree(jsonString);
        
        PlanInfo planInfo = (PlanInfo) memberRequest.getCompositeRequest().get(1).getBody();
        String jsonStringPlan = objectMapper.writeValueAsString(planInfo);
        JsonNode jsonNodePlan = objectMapper.readTree(jsonStringPlan);

        LowIncomeSubsidy lis = (LowIncomeSubsidy) memberRequest.getCompositeRequest().get(2).getBody();
        String jsonStringLis = objectMapper.writeValueAsString(lis);
        JsonNode jsonNodeLis = objectMapper.readTree(jsonStringLis);

        // testing graph id
        assertThat(memberRequest.getGraphId()).isEqualTo(memberEnrollment.getMemberNumber());
        // testing url
        assertThat(memberRequest.getCompositeRequest().get(0).getUrl()).isEqualTo(accountEnrollmentUrl + memberEnrollment.getMemberNumber());

        //testing Lis
        assertNotNull(lis);
        assertNull(jsonNodeLis.get("UST_EPLUS__Member__r").textValue());
        assertEquals(MemberTestEnum.LIS_LEVEL.getValue(),jsonNodeLis.get("UST_EPLUS__LIS_Level__c").textValue());
        assertEquals(MemberTestEnum.LIS_START_DATE.getValue(),jsonNodeLis.get("UST_EPLUS__Start_Date__c").textValue());
        assertEquals(MemberTestEnum.END_DATE.getValue(),jsonNodeLis.get("UST_EPLUS__End_Date__c").textValue());

        //testing planInfo
        assertNotNull(planInfo);
        assertEquals(MemberTestEnum.PLAN_START_DATE.getValue(),jsonNodePlan.get("EffectiveFrom").textValue());
        assertEquals(MemberTestEnum.PLAN_END_DATE.getValue(),jsonNodePlan.get("EffectiveTo").textValue());
        assertNull(jsonNodePlan.get("Member").textValue());
        assertEquals(MemberTestEnum.LOB.getValue(),jsonNodePlan.get("UST_EPLUS__Line_of_Business__c").textValue());
        assertEquals(MemberTestEnum.CURRENT_PLAN.getValue(),jsonNodePlan.get("UST_EPLUS__Is_Current_Plan__c").textValue());
        assertEquals(MemberTestEnum.BENEFIT_NETWORK.getValue(),jsonNodePlan.get("UST_EPLUS__BenefitNetwork__c").textValue());
        assertEquals(MemberTestEnum.IS_VALID_PLAN.getValue(),jsonNodePlan.get("UST_EPLUS__Is_Valid_Plan__c").textValue());
        assertEquals(MemberTestEnum.IS_VOID_PLAN.getValue(),jsonNodePlan.get("UST_EPLUS__Is_Void_Plan__c").textValue());
        assertEquals(MemberTestEnum.PLAN_ID.getValue(),jsonNodePlan.get("UST_EPLUS__Member_Plan_ID__c").textValue());
        assertEquals(MemberTestEnum.PLAN_DESC.getValue(),jsonNodePlan.get("UST_EPLUS__Plan_Description__c").textValue());
        // testing memberInfo
        testMemberInfo(memberInfo, jsonNode);
    }

    @Test
    void enrollmentTestingCaseNull() throws ParseException, JsonProcessingException {
        log.info("inside testCreateMemberBatchRequest");
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> recordTypeIdMap = new HashMap<>();
        recordTypeIdMap.put("enrollmentRecordTypeId","12345");
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RECORD_TYPE_MAP)).thenReturn(recordTypeIdMap);
        String accountEnrollmentUrl = "/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
        ReflectionTestUtils.setField(healthCloudMappingUtil, "accountEnrollmentUrl", accountEnrollmentUrl);
        ReflectionTestUtils.setField(commonUtil,"showTruncated","true");
        doNothing().when(clientMapping).updateMemberInfo(any(),any());
        MemberEnrollment memberEnrollment = testUtil.setMemberEnrollment();
        memberEnrollment.setBenefitNetworkName(null);
        memberEnrollment.setAccountName(null);
        memberEnrollment.setPlanId(null);
        memberEnrollment.setPlanYear(null);
        memberEnrollment.setMemberPlanName(null);
        AccountRequest memberRequest = healthCloudMappingUtil.createMemberBatchRequest(memberEnrollment, jobExecutionMock);

        PlanInfo planInfo = (PlanInfo) memberRequest.getCompositeRequest().get(1).getBody();
        String jsonStringPlan = objectMapper.writeValueAsString(planInfo);
        JsonNode jsonNodePlan = objectMapper.readTree(jsonStringPlan);

        //testing planInfo
        assertNotNull(planInfo);
        assertEquals("false",jsonNodePlan.get("UST_EPLUS__Is_Current_Plan__c").textValue());
        assertEquals(null,jsonNodePlan.get("UST_EPLUS__Benefit_Network__c"));
        assertEquals(null,jsonNodePlan.get("UST_EPLUS__Member_Plan_ID__c").textValue());

    }


    private static void testMemberInfo(MemberInfo memberInfo, JsonNode jsonNode) {
        assertNotNull(memberInfo);
        assertEquals(MemberTestEnum.MEMBER_NUMBER.getValue(), jsonNode.get("UST_EPLUS__Member_ID__c").textValue());
        assertEquals(MemberTestEnum.MEMBER_GENDER.getValue(), jsonNode.get("UST_EPLUS__MemberGender__c").textValue());
        assertEquals(MemberTestEnum.FIRST_NAME.getValue(), jsonNode.get("FirstName").textValue());
        assertEquals(MemberTestEnum.LAST_NAME.getValue(), jsonNode.get("Lastname").textValue());
        assertEquals(MemberTestEnum.PHONE.getValue(), jsonNode.get("Phone").textValue());
        assertEquals(MemberTestEnum.EMAIL.getValue(), jsonNode.get("PersonEmail").textValue());
        assertEquals(MemberTestEnum.BIRTH_DATE.getValue(), jsonNode.get("PersonBirthDate").textValue());
        assertEquals(MemberTestEnum.UDT_ONE.getValue(), jsonNode.get("UST_EPLUS__UDT1__c").textValue());
        assertEquals(MemberTestEnum.UDT_TWO.getValue(), jsonNode.get("UST_EPLUS__UDT2__c").textValue());
        assertEquals(MemberTestEnum.UDT_THREE.getValue(), jsonNode.get("UST_EPLUS__UDT3__c").textValue());
        assertEquals(MemberTestEnum.MEMBER_LOB.getValue(), jsonNode.get("UST_EPLUS__Line_of_Business__c").textValue());
        assertEquals(MemberTestEnum.PRODUCT.getValue(), jsonNode.get("UST_EPLUS__Product__c").textValue());
        assertEquals(MemberTestEnum.STATE.getValue(), jsonNode.get("UST_EPLUS__State__c").textValue());
        assertEquals(MemberTestEnum.IS_EMPLOYEE.getValue(), jsonNode.get("UST_EPLUS__VIP__c").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue(), jsonNode.get("PersonMailingLatitude").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue(), jsonNode.get("PersonMailingLongitude").textValue());
        assertEquals(MemberTestEnum.MEDICARE_ENROLEE.getValue(), jsonNode.get("UST_EPLUS__Medicare_Enrollee__c").textValue());
        assertEquals(MemberTestEnum.ELIGIBILITY_STATUS.getValue(), jsonNode.get("UST_EPLUS__Medicaid_Eligibility_Status__c").textValue());
        assertEquals(MemberTestEnum.LANGUAGE.getValue(), jsonNode.get("UST_EPLUS__Preferred_Language__c").textValue());
        assertEquals("", jsonNode.get("UST_EPLUS__Subscriber__c").textValue());
        assertEquals(MemberTestEnum.PARENT_MEMBER.getValue(), jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());
        assertEquals(MemberTestEnum.RLTP_TO_MEMBER.getValue(), jsonNode.get("UST_EPLUS__Relationship_to_Subscriber__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET.getValue(), jsonNode.get("PersonMailingStreet").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS1.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_1__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS2.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_2__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS3.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_3__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_CITY.getValue(), jsonNode.get("PersonMailingCity").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STATE.getValue(), jsonNode.get("PersonMailingState").textValue());
        assertEquals(MemberTestEnum.SHIPPING_COUNTY.getValue(), jsonNode.get("UST_EPLUS__County_Mailing_Address__C").textValue());
        assertEquals(MemberTestEnum.SHIPPING_COUNTRY.getValue(), jsonNode.get("PersonMailingCountry").textValue());
        assertEquals(MemberTestEnum.SHIPPING_POSTAL_CODE.getValue(), jsonNode.get("PersonMailingPostalCode").textValue());
        assertEquals(MemberTestEnum.BILLING_CITY.getValue(), jsonNode.get("personOtherCity").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET.getValue(), jsonNode.get("personOtherStreet").textValue());
        assertEquals(MemberTestEnum.BILLING_STATE.getValue(), jsonNode.get("personOtherState").textValue());
        assertEquals(MemberTestEnum.BILLING_COUNTY.getValue(), jsonNode.get("UST_EPLUS__County_Permanent_Address__C").textValue());
        assertEquals(MemberTestEnum.BILLING_COUNTRY.getValue(), jsonNode.get("personOtherCountry").textValue());
        assertEquals(MemberTestEnum.BILLING_POSTAL_CODE.getValue(), jsonNode.get("personOtherPostalCode").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS1.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_1__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS2.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_2__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS3.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_3__c").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue(), jsonNode.get("PersonOtherLatitude").toString());
        assertEquals(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue(), jsonNode.get("PersonOtherLongitude").toString());
        assertNotEquals(MemberTestEnum.SSN.getValue(), jsonNode.get("UST_EPLUS__SSN_Digest__c").textValue());
        assertNotEquals(MemberTestEnum.SSN.getValue(), jsonNode.get("UST_EPLUS__SSN_Masked__c").textValue());
        assertEquals(MemberTestEnum.MBI_ID.getValue(), jsonNode.get("UST_EPLUS__MBI_ID__c").textValue());
        assertEquals(MemberTestEnum.HOH_NAME.getValue(), jsonNode.get("UST_EPLUS__Head_of_Household_Name__c").textValue());
        assertEquals(MemberTestEnum.HOH_SSNID.getValue(), jsonNode.get("UST_EPLUS__HOH_ID__c").textValue());
        assertEquals(MemberTestEnum.INSULIN_IND.getValue(), jsonNode.get("UST_EPLUS__DIABETES__pc").textValue());
        assertEquals(MemberTestEnum.DISABLED.getValue(), jsonNode.get("UST_EPLUS__Disabled__c").textValue());
        assertEquals(MemberTestEnum.IN_HOSPICE.getValue(), jsonNode.get("UST_EPLUS__In_Hospice__c").textValue());
        assertEquals(MemberTestEnum.IN_HOSPICE_DATE.getValue(), jsonNode.get("UST_EPLUS__Hospice_Date__c").textValue());
        assertEquals(MemberTestEnum.LAST_HRA_DATE.getValue(), jsonNode.get("UST_EPLUS__Last_HRA_Date__pc").textValue());
        assertEquals(MemberTestEnum.RE_DETERMINATION_DATE.getValue(), jsonNode.get("UST_EPLUS__Redetermination_Date__pc").textValue());
        assertEquals(MemberTestEnum.MEDICAID_CASE.getValue(), jsonNode.get("UST_EPLUS__Medicaid_Case__pc").textValue());
        assertEquals(MemberTestEnum.HOH_ADDRESS.getValue(), jsonNode.get("UST_EPLUS__HOH_Address__c").textValue());
        assertEquals(MemberTestEnum.IS_HRA_NEEDED.getValue(), jsonNode.get("UST_EPLUS__HRA_Needed__pc").textValue());
        assertEquals(MemberTestEnum.IS_ESRDC.getValue(), jsonNode.get("UST_EPLUS__ESRD__pc").textValue());
        assertEquals(MemberTestEnum.IS_COPD.getValue(), jsonNode.get("UST_EPLUS__COPD__pc").textValue());
        assertEquals(MemberTestEnum.ASSIGNED_LAB.getValue(), jsonNode.get("UST_EPLUS__Assigned_Lab__pc").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_ONE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_1__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_TWO.getValue(), jsonNode.get("UST_EPLUS__Other_ID_2__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_THREE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_3__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_FOUR.getValue(), jsonNode.get("UST_EPLUS__Other_ID_4__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_FIVE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_5__c").textValue());
        assertEquals(MemberTestEnum.RECORD_TYPE_ID.getValue(), jsonNode.get("RecordTypeId").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET.getValue(), jsonNode.get("UST_EPLUS__Mailing_street_without_space__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_CITY.getValue(), jsonNode.get("UST_EPLUS__Mailing_city_without_space__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STATE.getValue(), jsonNode.get("UST_EPLUS__Mailing_state_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET.getValue(), jsonNode.get("UST_EPLUS__Permanent_street_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_CITY.getValue(), jsonNode.get("UST_EPLUS__Permanent_city_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STATE.getValue(), jsonNode.get("UST_EPLUS__Permanent_state_without_space__c").textValue());
        assertEquals(MemberTestEnum.PARENT_MEMBER.getValue(), jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());
        assertNull(jsonNode.get("UST_EPLUS__Subscriber__r"));

    }

    @Test
    void nullTest() {
        log.info("inside nullTest");
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        MemberEnrollment memberRequest = new MemberEnrollment();
        AccountRequest accountInfo = healthCloudMappingUtil.createMemberBatchRequest(memberRequest, jobExecutionMock);
        assertNull(accountInfo);
    }


}