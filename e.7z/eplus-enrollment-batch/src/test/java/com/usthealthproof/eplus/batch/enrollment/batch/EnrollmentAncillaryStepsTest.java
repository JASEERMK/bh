package com.usthealthproof.eplus.batch.enrollment.batch;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdLoadResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.commons.batch.common.service.RuntimeService;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentRecordTypeService;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import com.usthealthproof.eplus.commons.batch.enrollment.util.CommonUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.CountUpdateListener;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.EnrollmentAncillarySteps;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;


@Slf4j
@ExtendWith(MockitoExtension.class)
class EnrollmentAncillaryStepsTest {

    @InjectMocks
    EnrollmentAncillarySteps enrollmentAncillarySteps;

    @Mock
    AuditService auditService;

    @Mock
    private StepBuilder stepBuilder;

    @Mock
    private ExecutionContext executionContext;

    @Mock
    private ChunkContext chunkContextMock;
    @Mock
    private StepContext stepContextMock;

    @Mock
    JobExecution jobExecutionMock;
    @Mock
    private static StepExecution stepExecutionMock;

    @Mock
    private RuntimeService runTimeServiceMock;

    @Mock
    private ExceptionListener exceptionListenerMock;

    @Mock
    private TaskletExceptionHandler taskletExceptionHandlerMock;

    @Mock
    private ExecutionContext executionContextMock;
    @Mock
    private JobRepository jobRepositoryMock;

    @Mock
    private PlatformTransactionManager platformTransactionManagerMock;

    @Mock
    EnrollmentService enrollmentServiceMock;

    @Mock
    LoginService loginServiceMock;
    @Mock
    CountUpdateListener countUpdateListenerMock;
    @Mock
    JobInstance jobInstanceMock;

    @Mock
    EnrollmentRecordTypeService enrollmentRecordTypeService;

    @Mock
    CommonUtils commonUtilsMock;
    @Mock
    CommonUtil commonUtil;

    @Mock
    RecordIdMainResponse recordIdMainResponseMock;

    @BeforeEach
    public void setUp() {
        TransactionSynchronizationManager.initSynchronization();

    }

    @AfterEach
    public void setDown() {
        TransactionSynchronizationManager.clear();
    }

    void initialise(String stepName) {
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "spEnabled", true);
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "selectiveLoad", "N");
        ReflectionTestUtils.setField(enrollmentRecordTypeService, "enrollmentRecordTypeUrl", "testEnrollmentRecordTypeUrl");
        ReflectionTestUtils.setField(enrollmentRecordTypeService, "recordTypeUrl", "testRecordTypeUrl");

        when(stepExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        // Set the stepName in StepExecution
        when(stepExecutionMock.getStepName()).thenReturn(stepName);
    }


    @Test
    void testReadRuntimeStep() throws Exception {
        log.info("inside testReadRuntimeStep");
        initialise("ReadRunTimeStep");
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        doNothing().when(runTimeServiceMock).readRuntime(any(ExecutionContext.class));
        enrollmentAncillarySteps.readRuntimeStep(jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(runTimeServiceMock).readRuntime(eq(executionContextMock));

    }

    @Test
    void callStoredProcedureStep() throws Exception {
        log.info("inside callStoredProcedureStep");
        String runType = "NORMAL";
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "selectiveLoad", "N");
        initialise("StoredProcedureStep");
        enrollmentAncillarySteps.callStoredProcedureStep(runType,jobRepositoryMock, platformTransactionManagerMock,enrollmentServiceMock)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(enrollmentServiceMock).callStoredProcedureService(stepExecutionMock, runType,"N");
    }

    @Test
    void callStoredProcedureStepSelectiveLoading() throws Exception {
        log.info("inside callStoredProcedureStep");
        String runType = "NORMAL";
        initialise("StoredProcedureStep");
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "selectiveLoad", "Y");

        enrollmentAncillarySteps.callStoredProcedureStep(runType,jobRepositoryMock, platformTransactionManagerMock,enrollmentServiceMock)
                .execute(stepExecutionMock);
        verify(enrollmentServiceMock).callStoredProcedureService(stepExecutionMock, runType,"Y");
    }

    @Test
    void loginTest() throws JobInterruptedException {
        log.info("inside loginTest");
        initialise("CallLoginServiceStep");
        //executing callLoginServiceStep()
        enrollmentAncillarySteps.callLoginServiceStep(jobRepositoryMock, platformTransactionManagerMock,loginServiceMock).execute(stepExecutionMock);
        //verify it is executed
        verify(loginServiceMock).callLoginService(stepExecutionMock);
    }

    @Test
    void testLastRuntimeStep() throws Exception {
        log.info("inside testLastRuntimeStep");
        initialise("UpdateLastRuntimeStep");
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "selectiveLoad", "N");
        when(jobExecutionMock.getJobInstance()).thenReturn(jobInstanceMock);
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        doNothing().when(runTimeServiceMock).updateRuntime(any(ExecutionContext.class));
        enrollmentAncillarySteps.updateLastRuntimeStep(countUpdateListenerMock, jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(runTimeServiceMock).updateRuntime(eq(executionContextMock));

        // verify(runTimeServiceMock).readRuntime(executionContext);
    }

    @Test
    void testLastRuntimeStepSelectiveLoad() throws Exception {
        log.info("inside testLastRuntimeStep");
        initialise("UpdateLastRuntimeStep");
        ReflectionTestUtils.setField(enrollmentAncillarySteps, "selectiveLoad", "Y");
        when(jobExecutionMock.getJobInstance()).thenReturn(jobInstanceMock);
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        enrollmentAncillarySteps.updateLastRuntimeStep(countUpdateListenerMock, jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);
    }

    @Test
    @Transactional
    void testRecordTypeCreationStep() throws JobInterruptedException, InterruptedException {
        log.info("inside testRecordTypeCreationStep");
        initialise("GetRecordTypeCreationStep");

        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        // Mock RecordTypeService
        RecordIdMainResponse responseSet1 =  setRecordIdMainResponse();

        CompletableFuture<RecordIdMainResponse> future1 = CompletableFuture.completedFuture(responseSet1);

        when(enrollmentRecordTypeService.getRecordTypeIdSet(any(ChunkContext.class))).thenReturn(future1);

        enrollmentAncillarySteps.getRecordTypeCreationStep(enrollmentRecordTypeService, jobRepositoryMock, platformTransactionManagerMock).execute(stepExecutionMock);
        verify(enrollmentRecordTypeService, times(1)).getRecordTypeIdSet(any());


        // Capture the argument passed to the method
        ArgumentCaptor<ChunkContext> captor = ArgumentCaptor.forClass(ChunkContext.class);

        // Verify the method invocation with the captured argument
        verify(enrollmentRecordTypeService).getRecordTypeIdSet(captor.capture());

        // Assert on the properties of the captured argument
        ChunkContext capturedChunkContext = captor.getValue();

    }


public static RecordIdMainResponse  setRecordIdMainResponse() {

    // Create ObjectMapper to work with JSON
    ObjectMapper mapper = new ObjectMapper();

    // Example JSON bodies
    String jsonBody1 = "{\"totalSize\":1,\"done\":true,\"records\":[{\"attributes\":{\"type\":\"RecordType\",\"url\":\"/services/data/v56.0/sobjects/RecordType/0125f00000037aCAAQ\"},\"Id\":\"0125f00000037aCAAQ\"}]}";
    String jsonBody2 = "{\"totalSize\":1,\"done\":true,\"records\":[{\"attributes\":{\"type\":\"RecordType\",\"url\":\"/services/data/v56.0/sobjects/RecordType/0125f00000037aEAAQ\"},\"Id\":\"0125f00000037aEAAQ\"}]}";

    // Convert JSON strings to JsonNode objects
    JsonNode body1 = mapper.createObjectNode();
    JsonNode body2 = mapper.createObjectNode();
    try {
        body1 = mapper.readTree(jsonBody1);
        body2 = mapper.readTree(jsonBody2);
    } catch (Exception e) {
        e.printStackTrace();
    }

    // Create RecordIdLoadResponse instances
    RecordIdLoadResponse response1 = new RecordIdLoadResponse();
    response1.setBody(body1);
    response1.setHttpStatusCode(200L);
    response1.setReferenceId("practitionerContactRecordTypeId");

    RecordIdLoadResponse response2 = new RecordIdLoadResponse();
    response2.setBody(body2);
    response2.setHttpStatusCode(200L);
    response2.setReferenceId("supplierHealthCareProviderRecordTypeId");
    RecordIdMainResponse recordIdMainResponse=new RecordIdMainResponse();

    // Add responses to a list
    List<RecordIdLoadResponse> responseList = new ArrayList<>();
    responseList.add(response1);
    responseList.add(response2);
    recordIdMainResponse.setCompositeResponse(responseList);
    return recordIdMainResponse;
}

}