package com.usthealthproof.eplus.batch.enrollment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.batch.enrollment.enums.MemberTestEnum;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.util.MappingUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.junit.jupiter.MockitoExtension;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.spy;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class MappingUtilTest {

    @Test
    void testGetMemberInfo() throws ParseException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MappingUtil mappingUtil = spy(MappingUtil.class);
        MemberEnrollment memberEnrollment = new MemberEnrollment();
        memberEnrollment.setMemberNumber(MemberTestEnum.MEMBER_NUMBER.getValue());
        memberEnrollment.setLisKey(MemberTestEnum.LIS_KEY.getValue());
        memberEnrollment.setLisLevel(MemberTestEnum.LIS_LEVEL.getValue());
        memberEnrollment.setLisStartDate(formatter.parse(MemberTestEnum.LIS_START_DATE.getValue()));
        memberEnrollment.setLisEndDate(formatter.parse(MemberTestEnum.END_DATE.getValue()));
        memberEnrollment.setEndDate(formatter.parse(MemberTestEnum.END_DATE.getValue()));
        LowIncomeSubsidy lis= mappingUtil.getLIS(memberEnrollment);

        String jsonStringLis = objectMapper.writeValueAsString(lis);
        JsonNode jsonNodeLis = objectMapper.readTree(jsonStringLis);

        assertNotNull(lis);
        assertNull(jsonNodeLis.get("UST_EPLUS__Member__r").textValue());
        assertEquals(MemberTestEnum.LIS_LEVEL.getValue(),jsonNodeLis.get("UST_EPLUS__LIS_Level__c").textValue());
        assertEquals(MemberTestEnum.LIS_START_DATE.getValue(),jsonNodeLis.get("UST_EPLUS__Start_Date__c").textValue());
        assertEquals(MemberTestEnum.END_DATE.getValue(),jsonNodeLis.get("UST_EPLUS__End_Date__c").textValue());
    }

    @Test
    void testGetMemberInfoMemberNull() {
        MappingUtil mappingUtil = spy(MappingUtil.class);
        MemberEnrollment memberEnrollment = new MemberEnrollment();
        memberEnrollment.setLisKey(MemberTestEnum.LIS_KEY.getValue());
        memberEnrollment.setLisLevel(MemberTestEnum.LIS_LEVEL.getValue());
        LowIncomeSubsidy lowIncomeSubsidy = mappingUtil.getLIS(memberEnrollment);
        assertNull(lowIncomeSubsidy);
    }

    @Test
    void testGetMemberInfoLisKeyNull() {
        MappingUtil mappingUtil = spy(MappingUtil.class);
        MemberEnrollment memberEnrollment = new MemberEnrollment();
        memberEnrollment.setMemberNumber(MemberTestEnum.MEMBER_NUMBER.getValue());
        memberEnrollment.setLisLevel(MemberTestEnum.LIS_LEVEL.getValue());
        LowIncomeSubsidy lowIncomeSubsidy = mappingUtil.getLIS(memberEnrollment);
        assertNull(lowIncomeSubsidy);

    }
    @Test
    void testGetMemberInfoCaseNull() throws ParseException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MappingUtil mappingUtil = spy(MappingUtil.class);
        MemberEnrollment memberEnrollment = new MemberEnrollment();
        memberEnrollment.setMemberNumber(MemberTestEnum.MEMBER_NUMBER.getValue());
        memberEnrollment.setLisKey(MemberTestEnum.LIS_KEY.getValue());
        memberEnrollment.setLisLevel(null);
        memberEnrollment.setLisStartDate(null);
        memberEnrollment.setLisEndDate(null);
        memberEnrollment.setEndDate(formatter.parse(MemberTestEnum.END_DATE.getValue()));
        LowIncomeSubsidy lis= mappingUtil.getLIS(memberEnrollment);

        String jsonStringLis = objectMapper.writeValueAsString(lis);
        JsonNode jsonNodeLis = objectMapper.readTree(jsonStringLis);

        assertNotNull(lis);
        assertNull(jsonNodeLis.get("UST_EPLUS__Member__r").textValue());
        assertEquals(null,jsonNodeLis.get("UST_EPLUS__LIS_Level__c").textValue());
        assertEquals(null,jsonNodeLis.get("UST_EPLUS__Start_Date__c").textValue());
        assertEquals(null,jsonNodeLis.get("UST_EPLUS__End_Date__c").textValue());
    }



}
