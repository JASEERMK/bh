package com.usthealthproof.eplus.batch.enrollment.constant;

import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnrollmentConstantTest {

    @Test
    public void constantTest() {
        assertEquals("GET_ENROLLMENT_DETAILS_SP", EnrollmentConstant.PARAMETER_GET_ENROLLMENT_DETAILS_SP);
        assertEquals("memberNumberList", EnrollmentConstant.MEMBER_NUMBER_LIST);
        assertEquals("enrollmentRecordTypeId", EnrollmentConstant.ENROLLMENT_RECORD_TYPE_ID);
    }

}