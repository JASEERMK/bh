package com.usthealthproof.eplus.batch.enrollment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.batch.enrollment.enums.MemberTestEnum;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CommonUtilTest {

    @InjectMocks
    CommonUtil commonUtil;
    @InjectMocks
    TestUtil testUtil;

    @Test
    void testGetMemberInfo() throws JsonProcessingException, ParseException {
        ReflectionTestUtils.setField(commonUtil,"showTruncated","true");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MemberEnrollment memberEnrollment = testUtil.setMemberEnrollment();
        MemberInfo memberInfo= commonUtil.getMemberInfo(memberEnrollment, "12345");
        ObjectMapper objectMapper = new ObjectMapper();
        // Convert the MemberInfo object to a JSON string
        String jsonString = objectMapper.writeValueAsString(memberInfo);
        // Parse the JSON string into a JsonNode
        JsonNode jsonNode = objectMapper.readTree(jsonString);
        // testing memberinfo
        assertNotNull(memberInfo);
        testMemberInfo(jsonNode);
    }

    private static void testMemberInfo(JsonNode jsonNode) {
        assertEquals(MemberTestEnum.MEMBER_NUMBER.getValue(),jsonNode.get("UST_EPLUS__Member_ID__c").textValue());
        assertEquals(MemberTestEnum.MEMBER_GENDER.getValue(),jsonNode.get("UST_EPLUS__MemberGender__c").textValue());
        assertEquals(MemberTestEnum.FIRST_NAME.getValue(),jsonNode.get("FirstName").textValue());
        assertEquals(MemberTestEnum.LAST_NAME.getValue(),jsonNode.get("Lastname").textValue());
        assertEquals(MemberTestEnum.PHONE.getValue(),jsonNode.get("Phone").textValue());
        assertEquals(MemberTestEnum.EMAIL.getValue(),jsonNode.get("PersonEmail").textValue());
        assertEquals(MemberTestEnum.BIRTH_DATE.getValue(),jsonNode.get("PersonBirthDate").textValue());
        assertEquals(MemberTestEnum.UDT_ONE.getValue(),jsonNode.get("UST_EPLUS__UDT1__c").textValue());
        assertEquals(MemberTestEnum.UDT_TWO.getValue(),jsonNode.get("UST_EPLUS__UDT2__c").textValue());
        assertEquals(MemberTestEnum.UDT_THREE.getValue(),jsonNode.get("UST_EPLUS__UDT3__c").textValue());
        assertEquals(MemberTestEnum.MEMBER_LOB.getValue(),jsonNode.get("UST_EPLUS__Line_of_Business__c").textValue());
        assertEquals(MemberTestEnum.PRODUCT.getValue(),jsonNode.get("UST_EPLUS__Product__c").textValue());
        assertEquals(MemberTestEnum.STATE.getValue(),jsonNode.get("UST_EPLUS__State__c").textValue());
        assertEquals(MemberTestEnum.IS_EMPLOYEE.getValue(),jsonNode.get("UST_EPLUS__VIP__c").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue(),jsonNode.get("PersonMailingLatitude").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue(),jsonNode.get("PersonMailingLongitude").textValue());
        assertEquals(MemberTestEnum.MEDICARE_ENROLEE.getValue(),jsonNode.get("UST_EPLUS__Medicare_Enrollee__c").textValue());
        assertEquals(MemberTestEnum.ELIGIBILITY_STATUS.getValue(),jsonNode.get("UST_EPLUS__Medicaid_Eligibility_Status__c").textValue());
        assertEquals(MemberTestEnum.LANGUAGE.getValue(),jsonNode.get("UST_EPLUS__Preferred_Language__c").textValue());
        assertEquals("",jsonNode.get("UST_EPLUS__Subscriber__c").textValue());
        assertEquals(MemberTestEnum.PARENT_MEMBER.getValue(),jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());
        assertEquals(MemberTestEnum.RLTP_TO_MEMBER.getValue(),jsonNode.get("UST_EPLUS__Relationship_to_Subscriber__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET.getValue(),jsonNode.get("PersonMailingStreet").textValue());
       assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS1.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_1__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS2.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_2__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET_ADDRESS3.getValue(), jsonNode.get("UST_EPLUS__Mailing_Address_Line_3__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_CITY.getValue(), jsonNode.get("PersonMailingCity").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STATE.getValue(), jsonNode.get("PersonMailingState").textValue());
        assertEquals(MemberTestEnum.SHIPPING_COUNTY.getValue(), jsonNode.get("UST_EPLUS__County_Mailing_Address__C").textValue());
        assertEquals(MemberTestEnum.SHIPPING_COUNTRY.getValue(), jsonNode.get("PersonMailingCountry").textValue());
        assertEquals(MemberTestEnum.SHIPPING_POSTAL_CODE.getValue(), jsonNode.get("PersonMailingPostalCode").textValue());
        assertEquals(MemberTestEnum.BILLING_CITY.getValue(), jsonNode.get("personOtherCity").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET.getValue(), jsonNode.get("personOtherStreet").textValue());
        assertEquals(MemberTestEnum.BILLING_STATE.getValue(), jsonNode.get("personOtherState").textValue());
        assertEquals(MemberTestEnum.BILLING_COUNTY.getValue(), jsonNode.get("UST_EPLUS__County_Permanent_Address__C").textValue());
        assertEquals(MemberTestEnum.BILLING_COUNTRY.getValue(), jsonNode.get("personOtherCountry").textValue());
        assertEquals(MemberTestEnum.BILLING_POSTAL_CODE.getValue(), jsonNode.get("personOtherPostalCode").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS1.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_1__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS2.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_2__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET_ADDRESS3.getValue(), jsonNode.get("UST_EPLUS__Permanent_Address_Line_3__c").textValue());
        assertEquals(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue(), jsonNode.get("PersonOtherLatitude").toString());
        assertEquals(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue(), jsonNode.get("PersonOtherLongitude").toString());
        assertNotEquals(MemberTestEnum.SSN.getValue(), jsonNode.get("UST_EPLUS__SSN_Digest__c").textValue());
        assertNotEquals(MemberTestEnum.SSN.getValue(), jsonNode.get("UST_EPLUS__SSN_Masked__c").textValue());
        assertEquals(MemberTestEnum.MBI_ID.getValue(), jsonNode.get("UST_EPLUS__MBI_ID__c").textValue());
        assertEquals(MemberTestEnum.HOH_NAME.getValue(), jsonNode.get("UST_EPLUS__Head_of_Household_Name__c").textValue());
        assertEquals(MemberTestEnum.HOH_SSNID.getValue(), jsonNode.get("UST_EPLUS__HOH_ID__c").textValue());
        assertEquals(MemberTestEnum.INSULIN_IND.getValue(), jsonNode.get("UST_EPLUS__DIABETES__pc").textValue());
        assertEquals(MemberTestEnum.DISABLED.getValue(), jsonNode.get("UST_EPLUS__Disabled__c").textValue());
        assertEquals(MemberTestEnum.IN_HOSPICE.getValue(), jsonNode.get("UST_EPLUS__In_Hospice__c").textValue());
        assertEquals(MemberTestEnum.IN_HOSPICE_DATE.getValue(), jsonNode.get("UST_EPLUS__Hospice_Date__c").textValue());
        assertEquals(MemberTestEnum.LAST_HRA_DATE.getValue(), jsonNode.get("UST_EPLUS__Last_HRA_Date__pc").textValue());
        assertEquals(MemberTestEnum.RE_DETERMINATION_DATE.getValue(), jsonNode.get("UST_EPLUS__Redetermination_Date__pc").textValue());
        assertEquals(MemberTestEnum.MEDICAID_CASE.getValue(), jsonNode.get("UST_EPLUS__Medicaid_Case__pc").textValue());
        assertEquals(MemberTestEnum.HOH_ADDRESS.getValue(), jsonNode.get("UST_EPLUS__HOH_Address__c").textValue());
        assertEquals(MemberTestEnum.IS_HRA_NEEDED.getValue(), jsonNode.get("UST_EPLUS__HRA_Needed__pc").textValue());
        assertEquals(MemberTestEnum.IS_ESRDC.getValue(), jsonNode.get("UST_EPLUS__ESRD__pc").textValue());
        assertEquals(MemberTestEnum.IS_COPD.getValue(), jsonNode.get("UST_EPLUS__COPD__pc").textValue());
        assertEquals(MemberTestEnum.ASSIGNED_LAB.getValue(), jsonNode.get("UST_EPLUS__Assigned_Lab__pc").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_ONE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_1__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_TWO.getValue(), jsonNode.get("UST_EPLUS__Other_ID_2__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_THREE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_3__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_FOUR.getValue(), jsonNode.get("UST_EPLUS__Other_ID_4__c").textValue());
        assertEquals(MemberTestEnum.OTHER_ID_FIVE.getValue(), jsonNode.get("UST_EPLUS__Other_ID_5__c").textValue());
        assertEquals(MemberTestEnum.RECORD_TYPE_ID.getValue(), jsonNode.get("RecordTypeId").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STREET.getValue(), jsonNode.get("UST_EPLUS__Mailing_street_without_space__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_CITY.getValue(), jsonNode.get("UST_EPLUS__Mailing_city_without_space__c").textValue());
        assertEquals(MemberTestEnum.SHIPPING_STATE.getValue(), jsonNode.get("UST_EPLUS__Mailing_state_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STREET.getValue(), jsonNode.get("UST_EPLUS__Permanent_street_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_CITY.getValue(), jsonNode.get("UST_EPLUS__Permanent_city_without_space__c").textValue());
        assertEquals(MemberTestEnum.BILLING_STATE.getValue(), jsonNode.get("UST_EPLUS__Permanent_state_without_space__c").textValue());
        assertEquals(MemberTestEnum.PARENT_MEMBER.getValue(), jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());
        assertNull(jsonNode.get("UST_EPLUS__Subscriber__r"));
        assertEquals(MemberTestEnum.MEMBER_PRONOUNS.getValue(),jsonNode.get("UST_EPLUS__Pronoun__c").textValue());
        assertEquals(MemberTestEnum.GENDER_IDENTITY.getValue(),jsonNode.get("UST_EPLUS__Gender_Identity__c").textValue());
        assertEquals(MemberTestEnum.SEXUAL_ORIENTATION.getValue(),jsonNode.get("UST_EPLUS__Sexual_Orientation__c").textValue());

    }

    @Test
    void testGetMemberInfoCaseNull() throws JsonProcessingException, ParseException {
        ReflectionTestUtils.setField(commonUtil,"showTruncated","true");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MemberEnrollment memberEnrollment = testUtil.setMemberEnrollment();
        setNullValue(memberEnrollment);
        MemberInfo memberInfo= commonUtil.getMemberInfo(memberEnrollment, "12345");
        ObjectMapper objectMapper = new ObjectMapper();
        // Convert the MemberInfo object to a JSON string
        String jsonString = objectMapper.writeValueAsString(memberInfo);
        // Parse the JSON string into a JsonNode
        JsonNode jsonNode = objectMapper.readTree(jsonString);
        // testing memberinfo
        assertNotNull(memberInfo);
        testMemberInfoNull(jsonNode);
    }

    private static void setNullValue(MemberEnrollment memberEnrollment) {
        memberEnrollment.setLanguage("ENGLISH-");
        memberEnrollment.setDob(null);
        memberEnrollment.setPersonMailingLatitude(null);
        memberEnrollment.setPersonMailingLongitude(null);
        memberEnrollment.setMedicaidCaseId(null);
        memberEnrollment.setDateHospice(null);
        memberEnrollment.setLastHraDate(null);
        memberEnrollment.setRedeterminationDate(null);
        memberEnrollment.setRltpToMember(null);
        memberEnrollment.setLob(null);
        memberEnrollment.setSsn("");
        memberEnrollment.setUdtValue2(null);
        memberEnrollment.setUdtValue3(null);
        memberEnrollment.setShippingCity(null);
    }

    private static void testMemberInfoNull(JsonNode jsonNode) {
        assertEquals(null,jsonNode.get("PersonBirthDate").textValue());
        assertEquals(null,jsonNode.get("UST_EPLUS__UDT2__c").textValue());
        assertEquals(null,jsonNode.get("UST_EPLUS__UDT3__c").textValue());
        assertEquals("lob1",jsonNode.get("UST_EPLUS__Line_of_Business__c").textValue());
        assertEquals(null,jsonNode.get("PersonMailingLatitude").textValue());
        assertEquals(null,jsonNode.get("PersonMailingLongitude").textValue());
        assertEquals("",jsonNode.get("UST_EPLUS__Subscriber__c").textValue());
        assertEquals(null,jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());
        assertEquals(null,jsonNode.get("UST_EPLUS__Relationship_to_Subscriber__c").textValue());
        assertEquals(null, jsonNode.get("PersonMailingCity").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Hospice_Date__c").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Last_HRA_Date__pc").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Redetermination_Date__pc").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Medicaid_Case__pc").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Mailing_city_without_space__c").textValue());
        assertEquals(null, jsonNode.get("UST_EPLUS__Subscriber_ID__c").textValue());

    }

}