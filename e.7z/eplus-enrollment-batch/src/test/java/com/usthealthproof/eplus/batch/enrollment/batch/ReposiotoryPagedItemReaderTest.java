package com.usthealthproof.eplus.batch.enrollment.batch;

import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.RepositoryPagedItemReader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.item.adapter.DynamicMethodInvocationException;
import org.springframework.data.domain.Sort;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ReposiotoryPagedItemReaderTest {

    @Mock
    private AccountDetailsRepository repository;

    @InjectMocks
    private RepositoryPagedItemReader repositoryPagedItemReader;

    @BeforeEach
    void setUp() {
        repositoryPagedItemReader.setRepository(repository);
        repositoryPagedItemReader.setPageSize(10);
        Map<String, Sort.Direction> sortMap = new HashMap<>();
        sortMap.put("propertyName1", Sort.Direction.ASC);
        sortMap.put("propertyName2", Sort.Direction.DESC);
        repositoryPagedItemReader.setSort(sortMap);

    }

    @Test
    void testAfterPropertiesShouldPass() {
        repositoryPagedItemReader.afterPropertiesSet();
    }

    @Test
    void testAfterPropertiesShouldThrowException() {
        repositoryPagedItemReader.setRepository(null);

        assertThrows(IllegalStateException.class, () -> {
            repositoryPagedItemReader.afterPropertiesSet();
        });
    }

    @Test
    void testAfterPropertiesSetPageSizeIsZero() {
        repositoryPagedItemReader.setPageSize(0);

        assertThrows(IllegalStateException.class, () -> {
            repositoryPagedItemReader.afterPropertiesSet();
        });
    }

    @Test
    void testSortIsNullShouldThrowException() {

        assertThrows(NullPointerException.class, () -> {
            repositoryPagedItemReader.setSort(null);;
        });
    }

    @Test
    void testDoReadShouldThrowNoSuchMethod() throws IllegalAccessException, NoSuchFieldException {
        Field methodNameField = repositoryPagedItemReader.getClass().getDeclaredField("methodName");
        methodNameField.setAccessible(true);
        methodNameField.set(repositoryPagedItemReader, "testMethod");

        assertThrows(DynamicMethodInvocationException.class, () -> {
            repositoryPagedItemReader.read();
        });
    }

    @Test
    void testDoOpenShouldInitializeState() throws IllegalAccessException, NoSuchFieldException {
        //repositoryPagedItemReader.open();
        Field pageField = repositoryPagedItemReader.getClass().getDeclaredField("page");
        pageField.setAccessible(true);
        int page = (int) pageField.get(repositoryPagedItemReader);
        assertEquals(0, page);
        Field resultsField = repositoryPagedItemReader.getClass().getDeclaredField("results");
        resultsField.setAccessible(true);
        Object results = resultsField.get(repositoryPagedItemReader);
        assertNull(results);
    }


    @Test
    void testDoCloseShouldResetState() throws NoSuchFieldException, IllegalAccessException {
        repositoryPagedItemReader.close();

        Field pageField = repositoryPagedItemReader.getClass().getDeclaredField("page");
        pageField.setAccessible(true);
        int page = (int) pageField.get(repositoryPagedItemReader);
        assertEquals(0, page);
        Field resultsField = repositoryPagedItemReader.getClass().getDeclaredField("results");
        resultsField.setAccessible(true);
        Object results = resultsField.get(repositoryPagedItemReader);
        assertNull(results);
    }

}

