package com.usthealthproof.eplus.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.batch.enrollment.enums.MemberTestEnum;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Slf4j
public class TestUtil {
    // setting test values
    public static MemberEnrollment setMemberEnrollment() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MemberEnrollment memberEnrollment = new MemberEnrollment();
        memberEnrollment.setMemberNumber(MemberTestEnum.MEMBER_NUMBER.getValue());
        memberEnrollment.setMemberId(MemberTestEnum.MEMBER_NUMBER.getValue());
        memberEnrollment.setMemberGender(MemberTestEnum.MEMBER_GENDER.getValue());
        memberEnrollment.setMemberFirstName(MemberTestEnum.FIRST_NAME.getValue());
        memberEnrollment.setMemberLastName(MemberTestEnum.LAST_NAME.getValue());
        memberEnrollment.setPhone(MemberTestEnum.PHONE.getValue());
        memberEnrollment.setEmail(MemberTestEnum.EMAIL.getValue());
        memberEnrollment.setDob(formatter.parse(MemberTestEnum.BIRTH_DATE.getValue()));
        memberEnrollment.setIsValidPlan(MemberTestEnum.IS_VALID_PLAN.getValue());
        memberEnrollment.setIsVoidPlan(MemberTestEnum.IS_VOID_PLAN.getValue());
        memberEnrollment.setAccountName(MemberTestEnum.ACCOUNT_NAME.getValue());
        memberEnrollment.setUdtValue1(MemberTestEnum.UDT_ONE.getValue());
        memberEnrollment.setUdtValue2(MemberTestEnum.UDT_TWO.getValue());
        memberEnrollment.setUdtValue3(MemberTestEnum.UDT_THREE.getValue());
        memberEnrollment.setMemberLob(MemberTestEnum.MEMBER_LOB.getValue());
        memberEnrollment.setMemberProduct(MemberTestEnum.PRODUCT.getValue());
        memberEnrollment.setMemberState(MemberTestEnum.STATE.getValue());
        memberEnrollment.setLisLevel(MemberTestEnum.LIS_LEVEL.getValue());
        memberEnrollment.setPlanId(MemberTestEnum.PLAN_ID.getValue());
        memberEnrollment.setPlanYear(MemberTestEnum.PLAN_YEAR.getValue());
        memberEnrollment.setIsEmployee(MemberTestEnum.IS_EMPLOYEE.getValue());
        memberEnrollment.setBenefitNetworkName(MemberTestEnum.BENEFIT_NETWORK.getValue());
        memberEnrollment.setPersonMailingLatitude(new BigDecimal(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue()));
        memberEnrollment.setPersonMailingLongitude(new BigDecimal(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue()));
        memberEnrollment.setMedicareEnrollee(MemberTestEnum.MEDICARE_ENROLEE.getValue());
        memberEnrollment.setMedicaidEligibilityStatus(MemberTestEnum.ELIGIBILITY_STATUS.getValue());
        memberEnrollment.setLanguage(MemberTestEnum.LANGUAGE.getValue());
        memberEnrollment.setParentMember(MemberTestEnum.PARENT_MEMBER.getValue());
        memberEnrollment.setRltpToMember(MemberTestEnum.RLTP_TO_MEMBER.getValue());
        memberEnrollment.setShippingStreet(MemberTestEnum.SHIPPING_STREET.getValue());
        memberEnrollment.setMailingAddress1(MemberTestEnum.SHIPPING_STREET_ADDRESS1.getValue());
        memberEnrollment.setMailingAddress2(MemberTestEnum.SHIPPING_STREET_ADDRESS2.getValue());
        memberEnrollment.setMailingAddress3(MemberTestEnum.SHIPPING_STREET_ADDRESS3.getValue());
        memberEnrollment.setShippingCity(MemberTestEnum.SHIPPING_CITY.getValue());
        memberEnrollment.setShippingState(MemberTestEnum.SHIPPING_STATE.getValue());
        memberEnrollment.setShippingCounty(MemberTestEnum.SHIPPING_COUNTY.getValue());
        memberEnrollment.setShippingCountry(MemberTestEnum.SHIPPING_COUNTRY.getValue());
        memberEnrollment.setShippingPostalCode(MemberTestEnum.SHIPPING_POSTAL_CODE.getValue());
        memberEnrollment.setBillingCity(MemberTestEnum.BILLING_CITY.getValue());
        memberEnrollment.setBillingStreet(MemberTestEnum.BILLING_STREET.getValue());
        memberEnrollment.setBillingState(MemberTestEnum.BILLING_STATE.getValue());
        memberEnrollment.setBillingCounty(MemberTestEnum.BILLING_COUNTY.getValue());
        memberEnrollment.setBillingCountry(MemberTestEnum.BILLING_COUNTRY.getValue());
        memberEnrollment.setBillingPostalCode(MemberTestEnum.BILLING_POSTAL_CODE.getValue());
        memberEnrollment.setPersonOtherLatitude(new BigDecimal(MemberTestEnum.PERSON_MAILING_LATITUDE.getValue()));
        memberEnrollment.setPersonOtherLongitude(new BigDecimal(MemberTestEnum.PERSON_MAILING_LONGITUDE.getValue()));
        memberEnrollment.setPermanentAddress1(MemberTestEnum.BILLING_STREET_ADDRESS1.getValue());
        memberEnrollment.setPermanentAddress2(MemberTestEnum.BILLING_STREET_ADDRESS2.getValue());
        memberEnrollment.setPermanentAddress3(MemberTestEnum.BILLING_STREET_ADDRESS3.getValue());
        memberEnrollment.setSsn(MemberTestEnum.SSN.getValue());
        memberEnrollment.setMbi(MemberTestEnum.MBI_ID.getValue());
        memberEnrollment.setHohName(MemberTestEnum.HOH_NAME.getValue());
        memberEnrollment.setHohSsn(MemberTestEnum.HOH_SSNID.getValue());
        memberEnrollment.setIsEmployee(MemberTestEnum.IS_EMPLOYEE.getValue());
        memberEnrollment.setInsulinDepDiabeticInd(MemberTestEnum.INSULIN_IND.getValue());
        memberEnrollment.setDisabled(MemberTestEnum.DISABLED.getValue());
        memberEnrollment.setIsHospice(MemberTestEnum.IN_HOSPICE.getValue());
        memberEnrollment.setDateHospice(formatter.parse(MemberTestEnum.IN_HOSPICE_DATE.getValue()));
        memberEnrollment.setLastHraDate(formatter.parse(MemberTestEnum.LAST_HRA_DATE.getValue()));
        memberEnrollment.setRedeterminationDate(formatter.parse(MemberTestEnum.RE_DETERMINATION_DATE.getValue()));
        memberEnrollment.setMedicaidCaseId(MemberTestEnum.MEDICAID_CASE.getValue());
        memberEnrollment.setHohAddress(MemberTestEnum.HOH_ADDRESS.getValue());
        memberEnrollment.setIsHraNeeded(MemberTestEnum.IS_HRA_NEEDED.getValue());
        memberEnrollment.setEsrdInd(MemberTestEnum.IS_ESRDC.getValue());
        memberEnrollment.setCopdInd(MemberTestEnum.IS_COPD.getValue());
        memberEnrollment.setLabId(MemberTestEnum.ASSIGNED_LAB.getValue());
        memberEnrollment.setOtherID1(MemberTestEnum.OTHER_ID_ONE.getValue());
        memberEnrollment.setOtherID2(MemberTestEnum.OTHER_ID_TWO.getValue());
        memberEnrollment.setOtherID3(MemberTestEnum.OTHER_ID_THREE.getValue());
        memberEnrollment.setOtherID4(MemberTestEnum.OTHER_ID_FOUR.getValue());
        memberEnrollment.setOtherID5(MemberTestEnum.OTHER_ID_FIVE.getValue());

        memberEnrollment.setLisKey(MemberTestEnum.LIS_KEY.getValue());
        memberEnrollment.setLisLevel(MemberTestEnum.LIS_LEVEL.getValue());
        memberEnrollment.setLisStartDate(formatter.parse(MemberTestEnum.LIS_START_DATE.getValue()));
        memberEnrollment.setLisEndDate(formatter.parse(MemberTestEnum.END_DATE.getValue()));
        memberEnrollment.setEndDate(formatter.parse(MemberTestEnum.END_DATE.getValue()));


        memberEnrollment.setPlanStartDate(formatter.parse(MemberTestEnum.PLAN_START_DATE.getValue()));
        memberEnrollment.setPlanEndDate(formatter.parse(MemberTestEnum.PLAN_END_DATE.getValue()));
        memberEnrollment.setPlanId(MemberTestEnum.PLAN_ID.getValue());
        memberEnrollment.setMemberPlanName(MemberTestEnum.PLAN_NAME.getValue());
        memberEnrollment.setAccountId(MemberTestEnum.ACCOUNT_ID.getValue());
        memberEnrollment.setLob(MemberTestEnum.LOB.getValue());
        memberEnrollment.setPrimarySecondary(MemberTestEnum.PRIMARY_SECONDARY.getValue());
        memberEnrollment.setCurrentPlan(MemberTestEnum.CURRENT_PLAN.getValue());
        memberEnrollment.setBenefitNetworkName(MemberTestEnum.BENEFIT_NETWORK.getValue());
        memberEnrollment.setIsValidPlan(MemberTestEnum.IS_VALID_PLAN.getValue());
        memberEnrollment.setIsVoidPlan(MemberTestEnum.IS_VOID_PLAN.getValue());
        memberEnrollment.setAccountName(MemberTestEnum.ACCOUNT_NAME.getValue());
        memberEnrollment.setPlanId(MemberTestEnum.PLAN_ID.getValue());
        memberEnrollment.setPlanYear(MemberTestEnum.PLAN_YEAR.getValue());
        memberEnrollment.setMemberPlanProduct(MemberTestEnum.PRODUCT.getValue());
        memberEnrollment.setMemberPlanState(MemberTestEnum.STATE.getValue());
        memberEnrollment.setMemberPlanKey(MemberTestEnum.PLAN_KEY.getValue());
        memberEnrollment.setMemberPlanDesc(MemberTestEnum.PLAN_DESC.getValue());
        memberEnrollment.setMemberPronouns(MemberTestEnum.MEMBER_PRONOUNS.getValue());
        memberEnrollment.setGenderIdentity(MemberTestEnum.GENDER_IDENTITY.getValue());
        memberEnrollment.setSexualOrientation(MemberTestEnum.SEXUAL_ORIENTATION.getValue());
        return memberEnrollment;
    }

}
