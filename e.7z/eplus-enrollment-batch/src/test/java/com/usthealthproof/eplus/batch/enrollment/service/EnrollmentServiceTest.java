package com.usthealthproof.eplus.batch.enrollment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchProcessingException;
import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import com.usthealthproof.eplus.commons.batch.common.model.response.GraphResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.common.service.SpErrorLogService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.batch.EnrollmentDataProcessingSteps;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import com.usthealthproof.eplus.commons.batch.enrollment.model.response.EnrollBatchLoadResponse;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentAdapterService;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_ERROR_VALUE;
import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EnrollmentServiceTest {

    @InjectMocks
    static EnrollmentService enrollmentServiceMock;

    @Mock
    private RestCallService<EnrollBatchLoadResponse> restCallServiceMock;

    @Mock
    AuditService auditService;
    @Mock
    private AdhocService adhocService;
    @Mock
    private AccountDetailsRepository accountDetailsRepository;

    @Mock
    private EnrollmentAdapterService enrollmentAdapterService;
    @Mock
    private FileWriter fileWriterMock;

    @Mock
    private BufferedWriter bufferedWriterMock;
    @Spy
    AtomicInteger atomicInteger;
    @Mock
    private StepExecution stepExecutionMock;
    @Mock
    private JobExecution jobExecutionMock;
    @Mock
    private ExecutionContext executionContextMock;
    @Mock
    AccountDetailsRepository accountDetailsRepositoryMock;
    @Mock
    private SpErrorLogService spErrorLogService;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;

    private AtomicInteger successCount;
    private AtomicInteger failureCount;
    private AtomicInteger planSuccessCount;
    private AtomicInteger planFailureCount;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        successCount = new AtomicInteger(0);
        failureCount = new AtomicInteger(0);
        planSuccessCount = new AtomicInteger(0);
        planFailureCount = new AtomicInteger(0);
        enrollmentServiceMock = new EnrollmentService(accountDetailsRepositoryMock,auditService,adhocService,enrollmentAdapterService,restCallServiceMock,spErrorLogService,auditErrorMessageUtil);
        ReflectionTestUtils.setField(enrollmentServiceMock, "otherId", "Medicaid ID");
    }

    @Test
    void testAddEnrollmentService() {
        // Create a mock Graphs object
        Graphs graphsMock = mock(Graphs.class);
        // Create a mock StepExecution object
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        ReflectionTestUtils.setField(enrollmentServiceMock, "writeEnrollmentDetails", false);
        enrollmentServiceMock.addEnrollmentService(graphsMock, stepExecutionMock);
    }

    @Test
    public void testCallStoredProcedureService_Success() {
        // Mock data
        String lastRuntime = "2023-04-24";
        Date newRuntime = new Date();
        String spRunTypeParam = "someParam";
        int storedProcedureResult = 0;
        // Mock behavior
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RUNTIME)).thenReturn(lastRuntime);
        when(executionContextMock.get(Constant.NEW_RUNTIME)).thenReturn(newRuntime);
        // Call the method
        enrollmentServiceMock.callStoredProcedureService(stepExecutionMock, spRunTypeParam,"Y");

        // Verify interactions
        verify(auditService).auditStepStatus(anyString(), eq(Constant.PROCESS_STEP_SP), eq(PROCESS_STATUS_SUCCESS_VALUE),
                isNull(), isNull());
    }

    @Test
    public void testCallStoredProcedureService_Error() {
        // Mock data
        String lastRuntime = "2023-04-24";
        Date newRuntime = new Date();
        String spRunTypeParam = "someParam";
        String isSelectiveLoad = "Y";
        int storedProcedureResult = 1;

        // Mock behavior
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RUNTIME)).thenReturn(lastRuntime);
        when(executionContextMock.get(Constant.NEW_RUNTIME)).thenReturn(newRuntime);
        //when(accountDetailsRepository.getEnrollmentDetailsSP(any(),eq(lastRuntime), eq(spRunTypeParam), eq("Medicaid ID"),anyString())).thenReturn(storedProcedureResult);

        // Call the method
        enrollmentServiceMock.callStoredProcedureService(stepExecutionMock, spRunTypeParam,isSelectiveLoad);

    }

    @Test
    public void testAuditEnrollmentDataLoadStatus_WhenProviderBatchLoadResponseIsNull() {
        List<Map<String, String>> errorList = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("referenceId", "");
        errorMap.put("responseText", "Service Response is empty");
        errorList.add(errorMap);
        assertTrue(enrollmentServiceMock.auditEnrollmentDataLoadStatus(null, errorList));
        assertEquals(2, errorList.size());
        assertEquals("Service Response is empty", errorList.get(0).get("responseText"));
    }

    @Test
    public void testAuditEnrollmentDataLoadStatus_WhenEnrollmentBatchLoadResponseIs() throws JsonProcessingException {
        List<Map<String, String>> errorList = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("referenceId", "");
        errorMap.put("RESPONSE_TEXT", "Service Response is empty");
        errorList.add(errorMap);
        assertTrue(enrollmentServiceMock.auditEnrollmentDataLoadStatus(mockEnrollmentBatchLoadResponse(), errorList));
        assertEquals(6, errorList.size());

    }

// Test other scenarios similarly for remaining conditions...

    @Test
    public void testAuditEnrollmentDataLoadStatus_WhenErrorListIsNullOrEmpty() throws JsonProcessingException {
        assertTrue(enrollmentServiceMock.auditEnrollmentDataLoadStatus(null, new ArrayList<>()));
        assertTrue(enrollmentServiceMock.auditEnrollmentDataLoadStatus(mockEnrollmentBatchLoadResponse(), new ArrayList<>()));
    }

    @Test
    public void testAuditEnrollmentDataLoadStatus_WhenErrorListIsNotEmpty() throws JsonProcessingException {
        List<Map<String, String>> errorList = new ArrayList<>();
        errorList.add(new HashMap<>());
        assertTrue(enrollmentServiceMock.auditEnrollmentDataLoadStatus(mockEnrollmentBatchLoadResponse(), errorList));
    }

    // Helper method to mock ProviderBatchLoadResponse
    private EnrollBatchLoadResponse mockEnrollmentBatchLoadResponse() throws JsonProcessingException {
        // Mocking necessary methods of ProviderBatchLoadResponse
        EnrollBatchLoadResponse mockResponse = mock(EnrollBatchLoadResponse.class);
        List<Graph> graphs=createDummyGraphs(5);
        mockResponse.setGraphs(graphs);
        when(mockResponse.getGraphs()).thenReturn(graphs);
        List<EnrollBatchLoadResponse> memberGraphs = new ArrayList<>();
        memberGraphs.add(mockResponse);
        return mockResponse;
    }

    public static List<Graph> createDummyGraphs(int count) throws JsonProcessingException {
        ReflectionTestUtils.setField(enrollmentServiceMock, "successCount", new AtomicInteger());
        ReflectionTestUtils.setField(enrollmentServiceMock, "failureCount", new AtomicInteger());
        ReflectionTestUtils.setField(enrollmentServiceMock, "planSuccessCount", new AtomicInteger());
        ReflectionTestUtils.setField(enrollmentServiceMock, "planFailureCount", new AtomicInteger());

        // Create a mock AtomicInteger
        AtomicInteger successCount = mock(AtomicInteger.class);

        List<Graph> dummyGraphs = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Graph graph = new Graph();
            graph.setGraphId("GraphId" + i);
            GraphResponse graphResponse=new GraphResponse();
            CompositeResponse compositeResponse1=new CompositeResponse();
            compositeResponse1.setReferenceId("123");
            compositeResponse1.setHttpStatusCode(200);
            CompositeResponse compositeResponse2=new CompositeResponse();
            compositeResponse2.setReferenceId("345");
            compositeResponse2.setHttpStatusCode(400);
            // Create ObjectMapper instance (part of Jackson library)
            ObjectMapper objectMapper = new ObjectMapper();

            // JSON string
            String jsonString = "[{\"message\":\"Transaction declined due to insufficient funds\",\"age\":30,\"city\":\"New York\"}]";
            // Parse JSON string to JsonNode
            JsonNode jsonNode = objectMapper.readTree(jsonString);
            compositeResponse2.setBody(jsonNode);
            List<CompositeResponse> compositeResponseList=new ArrayList<>();
            compositeResponseList.add(compositeResponse1);
            compositeResponseList.add(compositeResponse2);
            graphResponse.setCompositeResponse(compositeResponseList);
            graph.setGraphResponse(graphResponse); // You need to create a dummy GraphResponse object as well
            graph.setIsSuccessful(true); // or false based on your requirement
            dummyGraphs.add(graph);
        }
        return dummyGraphs;
    }

    @Test
    public void testUpdateSFDataLoadSuccessAndErrorCountAudit_NoCounts() {
        // Arrange
        enrollmentServiceMock.resetCounter();
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        enrollmentServiceMock.updateSFDataLoadSuccessAndErrorCountAudit(stepExecutionMock);

        verify(auditService, times(2)).auditExecuteQueryCountStatus(anyString(),anyLong(), anyLong(),anyString(), anyString());
    }


    @Test
    public void testUpdateSFDataLoadSuccessAndErrorCountAudit_WithCounts() {
        ReflectionTestUtils.setField(enrollmentServiceMock, "successCount", new AtomicInteger(5));
        ReflectionTestUtils.setField(enrollmentServiceMock, "failureCount", new AtomicInteger(10));
        ReflectionTestUtils.setField(enrollmentServiceMock, "planSuccessCount", new AtomicInteger(5));
        ReflectionTestUtils.setField(enrollmentServiceMock, "planFailureCount", new AtomicInteger(10));
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        enrollmentServiceMock.updateSFDataLoadSuccessAndErrorCountAudit(stepExecutionMock);

        verify(auditService, times(6)).auditExecuteQueryCountStatus(anyString(),anyLong(), anyLong(),anyString(), anyString());
    }


    @Test
    void testAddEnrollmentServiceThrowsException() {
        // Create a mock Graphs object
        Graphs graphsMock = mock(Graphs.class);
        // Create a mock StepExecution object
        StepExecution stepExecutionMock = mock(StepExecution.class);
        ReflectionTestUtils.setField(enrollmentServiceMock, "writeEnrollmentDetails", true);
        ReflectionTestUtils.setField(enrollmentServiceMock, "logFilePath", "C:\\Users\\Documents\\workspace\\logs");
        assertThrows(BatchProcessingException.class, ()->
        {
            enrollmentServiceMock.addEnrollmentService(graphsMock, stepExecutionMock);
        });
    }
    @Test
    void testWriteEnrollmentResponseLogThrowsException() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, NoSuchFieldException {
        // Create a mock Graphs object
        EnrollBatchLoadResponse enrollBatchLoadResponse = mock(EnrollBatchLoadResponse.class);
        Field writeEnrollmentDetails= EnrollmentService.class.getDeclaredField("writeEnrollmentDetails");
        writeEnrollmentDetails.setAccessible(true);
        writeEnrollmentDetails.set(enrollmentServiceMock, true);

        Field filePath = EnrollmentService.class.getDeclaredField("logFilePath");
        filePath.setAccessible(true);
        filePath.set(enrollmentServiceMock, "C:\\Users\\Documents\\workspace\\logs");

        Method method = EnrollmentService.class.getDeclaredMethod("writeEnrollmentResponseLog", EnrollBatchLoadResponse.class);
        method.setAccessible(true);
        assertThrows(InvocationTargetException.class, ()->
        {
            method.invoke(enrollmentServiceMock,enrollBatchLoadResponse);
        });

        writeEnrollmentDetails.setAccessible(false);
        filePath.setAccessible(false);
        method.setAccessible(false);
    }
}
