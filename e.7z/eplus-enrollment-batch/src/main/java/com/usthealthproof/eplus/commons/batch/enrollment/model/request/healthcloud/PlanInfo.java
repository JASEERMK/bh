package com.usthealthproof.eplus.commons.batch.enrollment.model.request.healthcloud;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.BasePlanRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * @author U55312
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PlanInfo extends BasePlanRequest {

	/**
	 * member
	 */
	@JsonProperty("Member")
	private Map<String, String> member = new HashMap<>();

	/**
	 * member_id
	 */
	@JsonProperty("MemberId")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String memberId;
	
	/**
	 * plan_start_date
	 */
	@JsonProperty("EffectiveFrom")
	private String planStartDate;

	/**
	 * plan_end_date
	 */
	@JsonProperty("EffectiveTo")
	private String planEndDate;

	
	/**
	 * lob
	 */
	@JsonProperty("UST_EPLUS__Line_of_Business__c")
	private String lob;

	
	/**
	 * current Member plan flag
	 * Checkbox field
	 */
	@JsonProperty("UST_EPLUS__Is_Current_Plan__c")
	private String currentMemberPlan;

	@JsonProperty("UST_EPLUS__BenefitNetwork__c")
	private String benefitNetwork;

	@JsonProperty("UST_EPLUS__Is_Valid_Plan__c")
	private String isValidPlan;

	@JsonProperty("UST_EPLUS__Is_Void_Plan__c")
	private String isVoidPlan;



	@JsonProperty("UST_EPLUS__Member_Plan_ID__c")
	private String memberPlanId;
	
}
