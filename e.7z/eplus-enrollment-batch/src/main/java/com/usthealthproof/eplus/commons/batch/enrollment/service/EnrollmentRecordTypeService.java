package com.usthealthproof.eplus.commons.batch.enrollment.service;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.constant.ErrorCodeConstant;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchRestServiceException;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequestRecordId;
import com.usthealthproof.eplus.commons.batch.common.model.request.RecordIdRequest;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_ERROR_VALUE;

/**
 * @author 210409
 */
@Slf4j
@Service
public class EnrollmentRecordTypeService {

    @Autowired
    RestCallService<RecordIdMainResponse> restCallService;

    @Autowired
    AuditService auditService;

    @Autowired
    private WebClient webClient;

    /**
     * enrollmentRecordTypeUrl
     */
    @Value("${enrollment.url.common.record-type-account}")
    private String enrollmentRecordTypeUrl;

    @Value("${salesforce.record.type.url}")
    private String recordTypeUrl;

    @Async("asyncExecutor")
    public CompletableFuture<RecordIdMainResponse> getRecordTypeIdSet(ChunkContext chunkContext)
    {
        log.info("Inside getRecordTypeIdSet() in EnrollmentRecordTypeService class");
        List<CompositeRequestRecordId> composite = new ArrayList<>();
        composite.add(createCompositeRequest(EnrollmentConstant.ENROLLMENT_RECORD_TYPE_ID, enrollmentRecordTypeUrl));
        RecordIdRequest request = new RecordIdRequest();
        request.setCompositeRequest(composite);
        RecordIdMainResponse responseEntity = callService(request, chunkContext);
        log.debug("getRecordTypeId1, {}", responseEntity);
        log.info("getRecordTypeId1 completed");
        return CompletableFuture.completedFuture(responseEntity);
    }

    public  RecordIdMainResponse callService(RecordIdRequest request, ChunkContext chunkContext) {
        log.info("Inside callService() in EnrollmentRecordTypeService class");
        RecordIdMainResponse response = null;
        try {
            response = restCallService
                    .callPostRequest(recordTypeUrl, RecordIdMainResponse.class, request,
                            chunkContext.getStepContext().getStepExecution());
        } catch (WebClientException e) {
            log.error("WebClientException on Enrollment RecordTypeService");
            String jobId= String.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId());
            auditService.auditStepStatus(jobId, Constant.PROCESS_STEP_RECORD_TYPE,PROCESS_STATUS_ERROR_VALUE, String.valueOf(ErrorCodeConstant.REST_SERVICE_ERROR),e.getMessage());
            throw new BatchRestServiceException(ErrorCodeConstant.REST_SERVICE_ERROR, e);
        }

        return response;
    }

    /**
     * Create composite request for record ID
     * @param refId reference Id
     * @param url url
     * @return composite request id for the reference id and url
     */
    private CompositeRequestRecordId createCompositeRequest(String refId, String url) {
        CompositeRequestRecordId recordId = new CompositeRequestRecordId();
        recordId.setReferenceId(refId);
        recordId.setUrl(url);
        return recordId;
    }

}
