package com.usthealthproof.eplus.commons.batch.enrollment.service;

import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.enrollment.model.response.EnrollBatchLoadResponse;

public interface EnrollmentAdapterService
{
        public void updateRequest(Graphs graphs);

        public void updateResponse(EnrollBatchLoadResponse response);

}
