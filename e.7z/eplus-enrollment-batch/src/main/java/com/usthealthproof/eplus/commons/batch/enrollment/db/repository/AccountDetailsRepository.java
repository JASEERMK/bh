package com.usthealthproof.eplus.commons.batch.enrollment.db.repository;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 210409
 */
public interface AccountDetailsRepository<T extends MemberEnrollment> extends JpaRepository<T, Long> {

    String FIND_DISTINCT_MEMBERS= "SELECT COUNT(DISTINCT MEMBER_NUMBER) FROM EPLUS_MEMBER_ENROLLMENT";
    @Query(value = FIND_DISTINCT_MEMBERS, nativeQuery = true)
    long distinctCount();
    @Query(value = "select DISTINCT MEMBER_NUMBER from EPLUS_MEMBER_ENROLLMENT", nativeQuery = true)
    List<String> findKeys(Pageable pageable);


    List<T> findByMemberNumberInOrderByMemberNumberAsc(List<String> accountKeys);

    @Transactional
    @Procedure(value = "sp_eplus_GetEnrollmentDtl", outputParameterName = "returnstatus")
    Integer  getEnrollmentDetailsSP(@Param("InterfaceId") String interfaceId,@Param("processdate") String lastRuntime, @Param("runtype") String runType, @Param("otherIDname") String otherId, @Param("recipientIDType") String recipientID, @Param("SelectiveLoad") String isSelectiveLoad);

    String FIND_DISTINCT_MEMBER_PLAN= "SELECT COUNT(DISTINCT MEMBER_PLAN_KEY) FROM EPLUS_MEMBER_ENROLLMENT";
    @Query(value = FIND_DISTINCT_MEMBER_PLAN, nativeQuery = true)
    long planCount();
}
