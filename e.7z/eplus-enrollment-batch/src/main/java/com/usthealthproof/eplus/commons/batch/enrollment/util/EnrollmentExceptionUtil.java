package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.ExceptionUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.*;

@Component
public class EnrollmentExceptionUtil implements ExceptionUtil {

    @Autowired
    @Qualifier(value = "enrollmentMappingUtil")
    MappingUtil mappingUtil;

    @Override
    public List<Map<String, String>> getProcessErrorDetails(Object object, boolean enableAuditRequest) {
        List<Map<String,String>> processErrors;
        if(object instanceof List) {
            processErrors = new ArrayList<>();
            List<MemberEnrollment> result = (List<MemberEnrollment>) object;
            result.forEach(memberEnrollment -> {
                Map<String,String> processError = new HashMap<>();
                String memberId = memberEnrollment.getMemberNumber();
                processError.put(GRAPH_ID, memberId);
                processError.put(REFERENCE_ID, memberId);
                if(enableAuditRequest) {
                    processError.put(REQUEST_MESSAGE, CommonUtils.getObjectAsString(memberEnrollment));
                }
                processErrors.add(processError);
            });
        } else {
            processErrors = null;
        }
        return processErrors;
    }

    @Override
    public List<Map<String, String>> getWriteErrorDetails(Object object, boolean enableAuditRequest) {
        List<Map<String,String>> processErrors;
        if(object instanceof List) {
            processErrors = new ArrayList<>();
            List<AccountRequest> result = (List<AccountRequest>) object;
            result.forEach(accountRequest -> {
                Map<String,String> processError = new HashMap<>();
                String providerId = accountRequest.getGraphId();
                processError.put(GRAPH_ID, providerId);
                processError.put(REFERENCE_ID, providerId);
                if(enableAuditRequest) {
                    processError.put(REQUEST_MESSAGE, CommonUtils.getObjectAsString(accountRequest));
                }
                processErrors.add(processError);
            });
        } else {
            processErrors = null;
        }
        return processErrors;
    }
}
