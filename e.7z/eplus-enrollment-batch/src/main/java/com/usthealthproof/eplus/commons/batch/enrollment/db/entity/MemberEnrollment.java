package com.usthealthproof.eplus.commons.batch.enrollment.db.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 210409
 */
@Data
@MappedSuperclass
public class MemberEnrollment {

    @Id
    @Column(name = "ACCOUNT_DETAILS_KEY")
    private BigDecimal accountDetailsKey;

    @Column(name = "MEMBER_NUMBER")
    private String memberNumber;

    @Column(name = "MEMBER_ID")
    private String memberId;

    @Column(name = "MEMBER_GENDER")
    private String memberGender;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "PHONE")
    private String phone;

    @Column(name = "DOB")
    private Date dob;

    @Column(name = "DISABLED")
    private String disabled;

    @Column(name = "MEDICARE_ENROLLEE")
    private String medicareEnrollee;

    @Column(name = "LANGUAGE")
    private String language;

    @Column(name = "MEDICAID_ELIGIBILITY_STATUS")
    private String medicaidEligibilityStatus;

    @Column(name = "BILLING_STREET")
    private String billingStreet;

    @Column(name = "PERMANENT_ADDRESS_2")
    private String permanentAddress2;

    @Column(name = "PERMANENT_ADDRESS_3")
    private String permanentAddress3;

    @Column(name = "BILLING_COUNTY")
    private String billingCounty;

    @Column(name = "BILLING_STATE")
    private String billingState;

    @Column(name = "BILLING_CITY")
    private String billingCity;

    @Column(name = "BILLING_POSTAL_CODE")
    private String billingPostalCode;

    @Column(name = "BILLING_COUNTRY")
    private String billingCountry;

    @Column(name = "SHIPPING_STREET")
    private String shippingStreet;

    @Column(name = "MAILING_ADDRESS_2")
    private String mailingAddress2;

    @Column(name = "MAILING_ADDRESS_3")
    private String mailingAddress3;

    @Column(name = "SHIPPING_STATE")
    private String shippingState;

    @Column(name = "SHIPPING_CITY")
    private String shippingCity;

    @Column(name = "SHIPPING_POSTAL_CODE")
    private String shippingPostalCode;

    @Column(name = "SHIPPING_COUNTY")
    private String shippingCounty;

    @Column(name = "SHIPPING_COUNTRY")
    private String shippingCountry;

    @Column(name = "END_DATE")
    private Date endDate;

    @Column(name = "MEMBER_PLAN_NAME")
    private String memberPlanName;

    @Column(name = "ACCOUNT_ID")
    private String accountId;

    @Column(name = "ACCOUNT_NAME")
    private String accountName;

    @Column(name = "PLAN_START_DATE")
    private Date planStartDate;

    @Column(name = "PLAN_END_DATE")
    private Date planEndDate;

    @Column(name = "MEMBER_FIRST_NAME")
    private String memberFirstName;

    @Column(name = "MEMBER_LAST_NAME")
    private String memberLastName;

    @Column(name = "PARENT_MEMBER")
    private String parentMember;

    @Column(name = "RLTP_TO_MEMBER")
    private String rltpToMember;

    @Column(name = "MEMBER_PLAN_KEY")
    private String memberPlanKey;

    @Column(name = "PLAN_ID")
    private String planId;

    @Column(name = "PLAN_YEAR")
    private String planYear;

    @Column(name = "LOB")
    private String lob;

    @Column(name = "PRIMARYSECONDARY")
    private String primarySecondary;

    @Column(name = "PERSONMAILINGLONGITUDE")
    private BigDecimal personMailingLongitude;

    @Column(name = "PERSONMAILINGLATITUDE")
    private BigDecimal personMailingLatitude;

    @Column(name = "PERSONOTHERLONGITUDE", columnDefinition = "NUMERIC(12,6)")
    private BigDecimal personOtherLongitude;

    @Column(name = "PERSONOTHERLATITUDE", columnDefinition = "NUMERIC(12,6)")
    private BigDecimal personOtherLatitude;

    @Column(name = "LAB_ID")
    private String labId;

    @Column(name = "MBI")
    private String mbi;

    @Column(name = "SSN")
    private String ssn;

    @Column(name = "MEDICAID_CASE_ID")
    private String medicaidCaseId;

    @Column(name = "LIS_LEVEL")
    private String lisLevel;

    @Column(name = "LIS_START_DATE")
    private Date lisStartDate;

    @Column(name = "LIS_END_DATE")
    private Date lisEndDate;

    @Column(name = "LIS_KEY")
    private String lisKey;

    @Column(name = "PERMANENT_ADDRESS_1")
    private String permanentAddress1;

    @Column(name = "MAILING_ADDRESS_1")
    private String mailingAddress1;

    @Column(name = "HOH_NAME")
    private String hohName;

    @Column(name = "HOH_SSN")
    private String hohSsn;

    @Column(name = "HOH_ADDRESS")
    private String hohAddress;

    @Column(name = "COPD_IND")
    private String copdInd;

    @Column(name = "ESRD_IND")
    private String esrdInd;

    @Column(name = "INSULIN_DEP_DIABETIC_IND")
    private String insulinDepDiabeticInd;

    @Column(name = "CURRENT_PLAN")
    private String currentPlan;

    @Column(name = "BENEFIT_NETWORK_NAME")
    private String benefitNetworkName;

    @Column(name = "IS_VALID_PLAN")
    private String isValidPlan;

    @Column(name = "IS_VOID_PLAN")
    private String isVoidPlan;

    @Column(name = "IS_EMPLOYEE")
    private String isEmployee;

    @Column(name = "UDT_VALUE_1")
    private String udtValue1;

    @Column(name = "UDT_VALUE_2")
    private String udtValue2;

    @Column(name = "UDT_VALUE_3")
    private String udtValue3;

    @Column(name = "MEMBER_STATE")
    private String memberState;

    @Column(name = "MEMBER_PRODUCT")
    private String memberProduct;

    @Column(name = "MEMBER_LOB")
    private String memberLob;

    @Column(name = "MEMBER_PLAN_STATE")
    private String memberPlanState;

    @Column(name = "MEMBER_PLAN_PRODUCT")
    private String memberPlanProduct;

    @Column(name = "IS_MEMBER_IN_HOSPICE")
    private String isHospice;

    @Column(name = "EFF_DATE_HOSPICE")
    private Date dateHospice;

    @Column(name = "HRA_NEEDED_FLG")
    private String isHraNeeded;

    @Column(name = "LAST_HRA_DT")
    private Date lastHraDate;

    @Column(name = "REDETERMINATION_DATE")
    private Date redeterminationDate;

    @Column(name = "OTHER_ID_VALUE_1")
    private String otherID1;

    @Column(name = "OTHER_ID_VALUE_2")
    private String otherID2;

    @Column(name = "OTHER_ID_VALUE_3")
    private String otherID3;

    @Column(name = "OTHER_ID_VALUE_4")
    private String otherID4;

    @Column(name = "OTHER_ID_VALUE_5")
    private String otherID5;

    @Column(name = "MEMBER_PLAN_DESC")
    private String memberPlanDesc;

    @Column(name = "MEDICAID_ID")
    private String recipientID;

    @Column(name = "GENDER_IDENTITY")
    private String genderIdentity;

    @Column(name = "MEMBER_PRONOUNS")
    private String memberPronouns;

    @Column(name = "SEXUAL_ORIENTATION")
    private String sexualOrientation;
}
