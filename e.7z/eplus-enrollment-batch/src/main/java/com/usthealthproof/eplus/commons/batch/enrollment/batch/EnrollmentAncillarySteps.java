package com.usthealthproof.eplus.commons.batch.enrollment.batch;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.commons.batch.common.service.RuntimeService;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentRecordTypeService;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class EnrollmentAncillarySteps {

    @Autowired
    private AuditService auditService;

    @Autowired
    private RuntimeService runTimeService;

    @Autowired
    private WebClient webClient;

    @Autowired
    private TaskletExceptionHandler taskletExceptionHandler;

    @Autowired
    private ExceptionListener exceptionListener;

    
    @Value("${batch.sp.enabled}")
    private boolean spEnabled;

    @Value("${batch.sp.is-selective-load}")
    private String selectiveLoad;


    /**
     * @return Step for reading current runtime
     */
    @Bean
    @Qualifier("readRuntimeStep")
    public Step readRuntimeStep(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        log.info("Inside readRuntimeStep() in EnrollmentAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_READ_RUNTIME,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    ExecutionContext executionContext = chunkContext.getStepContext()
                            .getStepExecution().getJobExecution().getExecutionContext();
                    executionContext.put("jobId", chunkContext
                            .getStepContext().getStepExecution().getJobExecution().getJobId());
                    runTimeService.readRuntime(executionContext);
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .build();
    }

    /**
     * @return Step for calling stored procedure
     */
    @Bean
    @Qualifier("callStoredProcedureStep")
    public Step callStoredProcedureStep(@Value("${sp.parameter.run-type}") String spRunTypeParam, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, EnrollmentService enrollmentService) {
        log.info("Inside callStoredProcedureStep() in EnrollmentAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_SP,jobRepository).tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
                    log.info("Calling StoredProcedure Enabled  : {}", spEnabled);
                    String isSelectiveLoad = ( selectiveLoad.equals("Y")) ? "Y" : "N";
                    log.info("Is Selective Load : {}", isSelectiveLoad);
                    if(spEnabled) { // check if calling stored procedure enabled
                    enrollmentService.callStoredProcedureService(stepExecution, spRunTypeParam, isSelectiveLoad);
                    }
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .build();
    }

    /**
     * @return Step for calling login service for getting token
     */
    @Bean
    @Qualifier("callLoginServiceStep")
    public Step callLoginServiceStep(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, LoginService loginService) {
        log.info("Inside callLoginServiceStep() in EnrollmentAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_SF_LOGIN,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    log.info("Step : callLoginService");
                    loginService.callLoginService(chunkContext.getStepContext().getStepExecution());
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager).listener(exceptionListener).exceptionHandler(taskletExceptionHandler).build();
    }

    /**
     * @return Step for calling stored procedure
     */
    @Bean
    @Qualifier("getRecordTypeCreationStep")
    public Step getRecordTypeCreationStep(EnrollmentRecordTypeService recordTypeService,JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        log.info("Inside getRecordTypeCreationStep() in EnrollmentAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_RECORD_TYPE,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    log.info("Step : getRecordTypeCreation");
                    ExecutionContext context = chunkContext.getStepContext()
                            .getStepExecution().getJobExecution().getExecutionContext();
                    String jobId = String.valueOf(chunkContext.getStepContext()
                            .getStepExecution().getJobExecution().getJobId());
                    CompletableFuture<RecordIdMainResponse> typeCompletableSet = recordTypeService.getRecordTypeIdSet(chunkContext);
                    CompletableFuture.allOf(typeCompletableSet).join();
                    Map<String, String> recordTypeIdMap = new HashMap<>();
                    updateRecordTypeId(typeCompletableSet.get(), recordTypeIdMap);
                    context.put(Constant.RECORD_TYPE_MAP, recordTypeIdMap);
                    auditService.auditStepStatus(jobId, Constant.PROCESS_STEP_RECORD_TYPE,PROCESS_STATUS_SUCCESS_VALUE, null,null);
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager).listener(exceptionListener).exceptionHandler(taskletExceptionHandler).build();
    }


    @Bean
    @Qualifier("updateLastRuntimeStep")
    public Step updateLastRuntimeStep(CountUpdateListener  countUpdateListener,JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        log.info("Inside updateLastRuntimeStep() in EnrollmentAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_UPDATE_RUNTIME,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    if(!selectiveLoad.equals("Y")) {
                        ExecutionContext executionContext = chunkContext
                                .getStepContext().getStepExecution().getJobExecution().getExecutionContext();
                        executionContext.put("jobId", chunkContext
                                .getStepContext().getStepExecution().getJobExecution().getJobId());
                        runTimeService.updateRuntime(executionContext);
                    }
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(countUpdateListener)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .build();
    }

    private void updateRecordTypeId(RecordIdMainResponse recordResponse, Map<String, String> recordTypeIdMap) {
        CommonUtils.validateRecordTypeResponse(recordResponse);
        recordResponse.getCompositeResponse().forEach(compositeResponse -> {
            String recordId = String.valueOf(compositeResponse.getBody().get("records").get(0).get("Id"));
            log.debug("Record Type Id : " + compositeResponse.getReferenceId() + " - " + recordId);
            recordTypeIdMap.put(compositeResponse.getReferenceId(), CommonUtils.cleanRecordTypeId(recordId));
        });
    }

}
