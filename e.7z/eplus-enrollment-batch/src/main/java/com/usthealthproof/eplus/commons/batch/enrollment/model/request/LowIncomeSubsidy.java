package com.usthealthproof.eplus.commons.batch.enrollment.model.request;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.common.model.request.Body;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;


@Data
@EqualsAndHashCode(callSuper = false)
public class LowIncomeSubsidy extends Body {
	
	@JsonProperty("UST_EPLUS__LIS_Level__c")  //   OLD VALUE USTHPS__LIS_Level__c
	private String lisLevel;
	
	@JsonProperty("UST_EPLUS__Member__r")
	private Map<String, String> memberKey = new HashMap<>();
	
	@JsonProperty("UST_EPLUS__Start_Date__c")
	private String lisStartDate;
	
	@JsonProperty("UST_EPLUS__End_Date__c")
	private String lisEndDate;

}
