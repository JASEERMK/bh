package com.usthealthproof.eplus.commons.batch.enrollment.config;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = "classpath:enrollment-application.yml", factory = YamlPropertySourceFactory.class)
public class EnrollmenntPropertyConfig {
}