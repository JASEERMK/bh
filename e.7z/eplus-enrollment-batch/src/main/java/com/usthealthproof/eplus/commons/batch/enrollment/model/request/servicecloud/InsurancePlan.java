package com.usthealthproof.eplus.commons.batch.enrollment.model.request.servicecloud;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.BasePlanRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper = false)
public class InsurancePlan extends BasePlanRequest {
    /**
     * member
     */
    @JsonProperty("UST_EPLUS__Member__r")
    private Map<String, String> memberSc = new HashMap<>();

    /**
     * member_id
     */
    @JsonProperty("UST_EPLUS__Member__c")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String memberIdSc;

    /**
     * plan_start_date
     */
    @JsonProperty("UST_EPLUS__Plan_Effective_From__c")
    private String planStartDateSc;

    /**
     * plan_end_date
     */
    @JsonProperty("UST_EPLUS__Plan_Effective_To__c")
    private String planEndDateSc;

    /**
     * member_plan_name_full
     */
    @JsonProperty("UST_EPLUS__Plan_Name_Full__c")
    private String memberPlanNameFull;
    /**
     * lob
     */
    @JsonProperty("UST_EPLUS__LineofBusiness__c")
    private String lobSc;

    /**
     * current Member plan flag
     * Checkbox field
     */
    @JsonProperty("UST_EPLUS__Current_Plan__c")
    private String currentMemberPlanSc;

    @JsonProperty("UST_EPLUS__Benefit_Network__c")
    private String benefitNetworkSc;

    @JsonProperty("UST_EPLUS__Valid_Plan__c")
    private String isValidPlanSc;

    @JsonProperty("UST_EPLUS__Void_Plan__c")
    private String isVoidPlanSc;

    @JsonProperty("UST_EPLUS__Insurance_Plan_ID__c")
    private String insurancePlanId;

}
