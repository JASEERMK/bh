package com.usthealthproof.eplus.commons.batch.enrollment.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import lombok.Data;

import java.util.List;

/**
 * @author U90305
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EnrollBatchLoadResponse {

	private List<Graph> graphs;
}
