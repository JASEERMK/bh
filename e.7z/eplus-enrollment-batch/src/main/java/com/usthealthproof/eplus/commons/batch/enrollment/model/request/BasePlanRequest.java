package com.usthealthproof.eplus.commons.batch.enrollment.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.commons.batch.common.model.request.Body;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public abstract class BasePlanRequest extends Body {

    /**
     * member_plan_name
     */
    @JsonProperty("Name")
    private String memberPlanName;

    /**
     * group_number
     */
    @JsonProperty("UST_EPLUS__Account_ID__c")
    private String groupNumber;

    /**
     * primarySecondary
     */
    @JsonProperty("UST_EPLUS__COB__c")
    private String eplusCOB;

    @JsonProperty("UST_EPLUS__Account_Name__c")
    private String accountName;

    @JsonProperty("UST_EPLUS__Plan_Year_Start_Date__c")
    private String planYear;

    @JsonProperty("UST_EPLUS__State__c")
    private String memberPlanState;

    @JsonProperty("UST_EPLUS__Product__c")
    private String memberPlanProduct;

    @JsonProperty("UST_EPLUS__Plan_Description__c")
    private String memberPlanDescription;

}
