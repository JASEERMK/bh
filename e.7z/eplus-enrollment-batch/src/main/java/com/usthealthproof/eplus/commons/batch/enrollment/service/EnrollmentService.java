package com.usthealthproof.eplus.commons.batch.enrollment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchProcessingException;

import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.common.service.SpErrorLogService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.DateUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import com.usthealthproof.eplus.commons.batch.enrollment.model.response.EnrollBatchLoadResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.*;
import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.writeDebugMessage;

/**
 * @author 210409
 */
@Slf4j
@Service
public class EnrollmentService {

    private final AccountDetailsRepository accountDetailsRepository;

    private AuditService auditService;

    private AdhocService adhocService;

    private EnrollmentAdapterService enrollmentAdapterService;

    private final RestCallService<EnrollBatchLoadResponse> restCallService;

    private SpErrorLogService spErrorLogService;

    private AuditErrorMessageUtil auditErrorMessageUtil;

    @Value("${sp.parameter.otherId}")
    private String otherId;

    @Value("${sp.parameter.recipientID}")
    private String recipientID;

    @Value("${salesforce.url.loadUrl}")
    private String enrollmentLoadURL;

    @Value("${batch.log.path}")
    private String logFilePath;

    @Value("${batch.log.write}")
    private boolean writeEnrollmentDetails;

    @Value("${batch.audit.request}")
    private boolean auditRequest;

    @Value("${batch.interface-id}")
    private String interfaceId;

    private AtomicInteger successCount;

    private AtomicInteger failureCount;

    private AtomicInteger planSuccessCount;

    private AtomicInteger planFailureCount;

    private List<String> graphList = new ArrayList<>();

    @Autowired
    WebClient webClient;

    public EnrollmentService(@Qualifier(value = "EnrollmentAdapterRepository") AccountDetailsRepository accountDetailsRepository, AuditService auditService, AdhocService adhocService, EnrollmentAdapterService enrollmentAdapterService, RestCallService<EnrollBatchLoadResponse> restCallService,SpErrorLogService spErrorLogService, AuditErrorMessageUtil auditErrorMessageUtil) {
        this.accountDetailsRepository = accountDetailsRepository;
        this.auditService = auditService;
        this.adhocService = adhocService;
        this.enrollmentAdapterService = enrollmentAdapterService;
        this.restCallService = restCallService;
        this.spErrorLogService = spErrorLogService;
        this.auditErrorMessageUtil = auditErrorMessageUtil;


    }

    public void callStoredProcedureService(StepExecution stepExecution, String spRunTypeParam, String isSelectiveLoad) {
        ExecutionContext context = stepExecution.getJobExecution().getExecutionContext();
        String lastRuntime = (String) context.get(Constant.RUNTIME);
        Date newRuntime = (Date) context.get(Constant.NEW_RUNTIME);
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        int storedProcedureResult = accountDetailsRepository.getEnrollmentDetailsSP(interfaceId,lastRuntime, spRunTypeParam, otherId, recipientID, isSelectiveLoad);
        if (storedProcedureResult == 1) {
            log.info("Stored Procedure not executed Successfully : {}", storedProcedureResult);
            AuditBatch auditBatch= spErrorLogService.addSPErrorLog(newRuntime,
                    EnrollmentConstant.PARAMETER_GET_ENROLLMENT_DETAILS_SP);
            if(auditBatch != null) {
                auditService.auditStepStatus(jobId, Constant.PROCESS_STEP_SP, PROCESS_STATUS_ERROR_VALUE, auditBatch.getErrorMessage(), auditBatch.getErrorDetails());
            }
            stepExecution.setTerminateOnly();
        } else {
            log.info("Stored Procedure executed Successfully : {}", storedProcedureResult);
            auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SP,PROCESS_STATUS_SUCCESS_VALUE,null,null);
        }
    }

    public void addEnrollmentService(Graphs graphs, StepExecution stepExecution) {
        log.debug("Inside addEnrollmentService() in EnrollmentService class");
        log.debug("Account List Included {} ", graphs.getAccountRequestList().size());
        enrollmentAdapterService.updateRequest(graphs);
        writeEnrollmentRequestLog(graphs);
        writeDebugMessage("addEnrollmentService Request {} ", graphs);
        EnrollBatchLoadResponse enrollmentResponse = restCallService.callPostRequest(enrollmentLoadURL,
                EnrollBatchLoadResponse.class, graphs, stepExecution);
        writeDebugMessage("addEnrollmentService Response {} ", enrollmentResponse);
        enrollmentAdapterService.updateResponse(enrollmentResponse);
        writeEnrollmentResponseLog(enrollmentResponse);
        List<Map<String, String>> errorList = new ArrayList<>();
        boolean isAuditRequired = auditEnrollmentDataLoadStatus(enrollmentResponse, errorList);
        if (isAuditRequired) {
            String request=null;
            if(auditRequest) {
                request=CommonUtils.getObjectAsString(graphs);
            }
            String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditSFDataLoadWriteError(jobId,errorList, stepExecution.getStepName(),request);
            if(!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }
            adhocService.setAdhocTableEntries(errorList, interfaceId);
        }
        log.debug("addEnrollmentService response {}", enrollmentResponse);
        log.debug("addEnrollmentService completed");
    }

    private void writeEnrollmentRequestLog(Graphs graphs) {
        log.debug("Request Graph {} ", CommonUtils.getObjectAsString(graphs));
        if (!Boolean.TRUE.equals(writeEnrollmentDetails)) {
            return;
        }
        try {
            String str = CommonUtils.getObjectAsString(graphs);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(logFilePath + "/ENROLLMENT/REQUEST/" + DateUtil.dateForFileCreation(new Date())));
            writer.write(str);
            writer.close();
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException writing request to log", e);
            throw new BatchProcessingException("JsonProcessingException", e);
        } catch (IOException e) {
            log.error("IOException writing request to log", e);
            throw new BatchProcessingException("IOException", e);
        }
    }

    private void writeEnrollmentResponseLog(EnrollBatchLoadResponse enrollBatchLoadResponse) {
        log.debug("Inside writeEnrollmentResponseLog() in EnrollmentService class");
        if (!Boolean.TRUE.equals(writeEnrollmentDetails)) {
            return;
        }
        String str = null;
        try {
            str = CommonUtils.getObjectAsString(enrollBatchLoadResponse);
            BufferedWriter writer = null;
            writer = new BufferedWriter(
                    new FileWriter(logFilePath + "/ENROLLMENT/RESPONSE/" + DateUtil.dateForFileCreation(new Date())));
            writer.write(str);
            writer.close();
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException writing response to log", e);
            throw new BatchProcessingException("JsonProcessingException", e);
        } catch (IOException e) {
            log.error("IOException writing response to log", e);
            throw new BatchProcessingException("IOException", e);
        }
    }

    /**
     * Method which store errors in an error list, if there is any fallouts getting
     * from salesforce while inserting or upserting enrollment records. Later this
     * error list used in router class to insert those fall outs in Audit table.
     */
    public boolean auditEnrollmentDataLoadStatus(EnrollBatchLoadResponse enrollmentBatchLoadResponse, List<Map<String, String>> errorList) {
        log.debug("Inside auditEnrollmentDataLoadStatus() in EnrollmentService class");
        if (enrollmentBatchLoadResponse == null || CollectionUtils.isEmpty(enrollmentBatchLoadResponse.getGraphs())
                || enrollmentBatchLoadResponse.getGraphs().get(0) == null
                || enrollmentBatchLoadResponse.getGraphs().get(0).getGraphResponse() == null || CollectionUtils
                .isEmpty(enrollmentBatchLoadResponse.getGraphs().get(0).getGraphResponse().getCompositeResponse())) {
            log.error("Service Response body is empty or null");
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put(REFERENCE_ID, StringUtils.EMPTY);
            errorMap.put("responseText", "Service Response is empty");
            errorList.add(errorMap);
            return true;
        }
        setEnrollmentDataLoadErrorStatus(enrollmentBatchLoadResponse, errorList);
        return !CollectionUtils.isEmpty(errorList);
    }

    /**
     * @param enrollBatchLoadResponse enrollment batch load response
     */
    private void setEnrollmentDataLoadErrorStatus(EnrollBatchLoadResponse enrollBatchLoadResponse, List<Map<String, String>> errorList) {
        log.debug("Inside setEnrollmentDataLoadErrorStatus() in EnrollmentService class");
        for (Graph graph : enrollBatchLoadResponse.getGraphs()) {
            if (Boolean.TRUE.equals(graph.getIsSuccessful())) {
                if(graphList.contains(graph.getGraphId())) {
                    log.info("graph  id already exist {}",graph.getGraphId());
                }
                else {
                    successCount.incrementAndGet();
                    graph.getGraphResponse().getCompositeResponse().stream()
                            .filter(compositeResponse -> compositeResponse.getReferenceId().startsWith("PLAN_"))
                            .forEach(compositeResponse -> planSuccessCount.incrementAndGet());
                }
                log.debug("Service call is success for GraphID:{} and Success Count {}",
                        graph.getGraphId(), successCount.toString());
                graphList.add(graph.getGraphId());
            }
            for (CompositeResponse compositeResponse : graph.getGraphResponse().getCompositeResponse()) {
                processCompositeResponse(graph, compositeResponse, errorList);
            }
        }
    }

    private boolean processCompositeResponse(Graph graph, CompositeResponse compositeResponse, List<Map<String, String>> errorList) {
        if (compositeResponse.getHttpStatusCode().toString().startsWith("2")) {
            log.debug("Service call is success for:{} ", compositeResponse.getReferenceId());
            return true;
        }
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("graphId", graph.getGraphId());
        errorMap.put("referenceId", compositeResponse.getReferenceId());
        errorMap.put("responseText", CommonUtils.getObjectAsString(graph));
        if (compositeResponse.getBody() instanceof ArrayNode node && node != null && !node.isEmpty()) {
            JsonNode jsonNode = node.get(0).get("message");
            if (jsonNode != null && !jsonNode.asText().contains("rolled back")) {
                String message = jsonNode.asText();
                errorMap.put("message", message);
                errorList.add(errorMap);
                String referenceId = errorMap.get("referenceId");
                log.error("Error for Member: {}, error: {}", referenceId, message);
                failureCount.incrementAndGet();
            }
            if (jsonNode != null && compositeResponse.getReferenceId().startsWith("PLAN_")){
                String errorMessage = jsonNode.asText();
                log.error("Error for Member Plan: {}, statusCode: {}, error: {}", compositeResponse.getReferenceId(), compositeResponse.getHttpStatusCode(), errorMessage);
                planFailureCount.incrementAndGet();
            }
            return false;
        }
        return true;
    }

    public void updateSFDataLoadSuccessAndErrorCountAudit(StepExecution stepExecution) {
        log.debug("Inside updateSFDataLoadSuccessAndErrorCountAudit() in EnrollmentService class");
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        long totalCount= accountDetailsRepository.distinctCount();
        auditService.auditExecuteQueryCountStatus(jobId,totalCount, 0,PROCESS_STATUS_SUCCESS_VALUE,EnrollmentConstant.MEMBER_COUNT);
        Integer sCount = successCount.get();
        Integer fCount = failureCount.get();
        if ((sCount > 0) || (fCount > 0)) {
            auditService.auditExecuteQueryCountStatus(jobId,0,successCount.get(),PROCESS_STATUS_SUCCESS_VALUE,EnrollmentConstant.MEMBER_SUCCESS_COUNT);
            auditService.auditExecuteQueryCountStatus(jobId,0, failureCount.get(),PROCESS_STATUS_ERROR_VALUE,EnrollmentConstant.MEMBER_FAILURE_COUNT);
        }
        long totalPlanCount = accountDetailsRepository.planCount();
        auditService.auditExecuteQueryCountStatus(jobId,totalPlanCount, 0,PROCESS_STATUS_SUCCESS_VALUE,EnrollmentConstant.MEMBER_PLAN_COUNT);
        Integer planSCount = planSuccessCount.get();
        Integer planFCount = planFailureCount.get();
        if ((planSCount > 0) || (planFCount > 0)) {
            auditService.auditExecuteQueryCountStatus(jobId,0,planSuccessCount.get(),PROCESS_STATUS_SUCCESS_VALUE,EnrollmentConstant.MEMBER_PLAN_SUCCESS_COUNT);
            auditService.auditExecuteQueryCountStatus(jobId,0, planFailureCount.get(),PROCESS_STATUS_ERROR_VALUE,EnrollmentConstant.MEMBER_PLAN_FAILURE_COUNT);

        }
    }

    public void resetCounter() {
        successCount = new AtomicInteger();
        failureCount = new AtomicInteger();
        planSuccessCount = new AtomicInteger();
        planFailureCount = new AtomicInteger();
        graphList.clear();
    }


}
