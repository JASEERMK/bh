package com.usthealthproof.eplus.commons.batch.enrollment.model.request;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.common.model.request.Body;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Data
@EqualsAndHashCode(callSuper = false)
public class MemberInfo extends Body {

	/**
	 * member_first_name
	 */
	@JsonProperty("FirstName")
	private String firstName;

	/**
	 * member_last_name
	 */
	@JsonProperty("Lastname")
	private String lastName;
	
	/**
	 * dob
	 */
	@JsonProperty("PersonBirthDate")
	private String dob;
	
	/**
	 * member_gender
	 */
	@JsonProperty("UST_EPLUS__MemberGender__c")
	private String gender;
	
	/**
	 * phone
	 */
	@JsonProperty("Phone")
	private String phone;
	
	/**
	 * email
	 */
	@JsonProperty("PersonEmail")
	private String email;

	/**
	 * memberId
	 */
	@JsonProperty("UST_EPLUS__Member_ID__c")
	private String memberId;
	
	/**
	 * medicareEnrollee
	 */
	@JsonProperty("UST_EPLUS__Medicare_Enrollee__c")
	private String medicareEnrollee;
	
	/**
	 * MedicaidEligibilityStatus
	 * Checkbox field
	 */
	@JsonProperty("UST_EPLUS__Medicaid_Eligibility_Status__c")
	private String medicaidEligibilityStatus;
	
	/**
	 * language
	 */
	@JsonProperty("UST_EPLUS__Preferred_Language__c")
	private String language;
		
	/**
	 * parent_members
	 */
	@JsonProperty("UST_EPLUS__Subscriber__r")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Map<String, String> parentMembers;

	/**
	 * parentMemberRef
	 */
	@JsonProperty("UST_EPLUS__Subscriber__c")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String parentMemberRef;
	
	/**
	 * rltp_to_member
	 */
	@JsonProperty("UST_EPLUS__Relationship_to_Subscriber__c")
	private String rltpToMember;
	
	/**
	 * shipping_street
	 */
	@JsonProperty("PersonMailingStreet")
	private String shippingStreet;
	
	/**
	 * shipping_street
	 */
	@JsonProperty("UST_EPLUS__Mailing_Address_Line_1__c")
	private String shippingStreetAddress1;
	
	/**
	 * shipping_street
	 */
	@JsonProperty("UST_EPLUS__Mailing_Address_Line_2__c")
	private String shippingStreetAddress2;
	
	/**
	 * shipping_street
	 */
	@JsonProperty("UST_EPLUS__Mailing_Address_Line_3__c")
	private String shippingStreetAddress3;

	/**
	 * shipping_state
	 */
	@JsonProperty("PersonMailingState")
	private String shippingState;

	/**
	 * shipping_city
	 */
	@JsonProperty("PersonMailingCity")
	private String shippingCity;

	/**
	 * shipping_postal_code
	 */
	@JsonProperty("PersonMailingPostalCode")
	private String shippingPostalCode;

	/**
	 * shipping_country
	 */
	@JsonProperty("UST_EPLUS__County_Mailing_Address__C")
	private String shippingCounty;

	/**
	 * shipping_country
	 */
	@JsonProperty("PersonMailingCountry")
	private String shippingCountry;
		
	/**
	 * PersonOtherStreet
	 */
	@JsonProperty("personOtherStreet")
	private String billingStreet;

	/**
	 * billing_state
	 */
	@JsonProperty("UST_EPLUS__Permanent_Address_Line_1__c")
	private String billingStreetAddress1;
	
	/**
	 * billing_state
	 */
	@JsonProperty("UST_EPLUS__Permanent_Address_Line_2__c")
	private String billingStreetAddress2;
	
	/**
	 * billing_state
	 */
	@JsonProperty("UST_EPLUS__Permanent_Address_Line_3__c")
	private String billingStreetAddress3;

	/**
	 * billing county
	 */
	@JsonProperty("UST_EPLUS__County_Permanent_Address__C")
	private String billingCounty;


	/**
	 * billing_state
	 */
	@JsonProperty("personOtherState")
	private String billingState;
	
	/**
	 * billing_city
	 */
	@JsonProperty("personOtherCity")
	private String billingCity;

	/**
	 * billing_postal_code
	 */
	@JsonProperty("personOtherPostalCode")
	private String billingPostalCode;

	/**
	 * billing_country
	 */
	@JsonProperty("personOtherCountry")
	private String billingCountry;
	
	/**
	 * SSN_ID Digest
	 */
	@JsonProperty("UST_EPLUS__SSN_Digest__c")
	private String ssnDigest;

	/**
	 * SSN_ID Masked
	 */
	@JsonProperty("UST_EPLUS__SSN_Masked__c")
	private String ssnMasked;

	/**
	 * HRA_STATUS
	 */
	@JsonProperty("UST_EPLUS__MBI_ID__c")
	private String mbiId;
	
	@JsonProperty("UST_EPLUS__Head_of_Household_Name__c")
	private String headOfHouseHoldName;

	
	/**
	 * memberLock
	 */
	@JsonProperty("UST_EPLUS__HOH_ID__c")
	private String hohSsnId;
	
	
	/**
	 * recordTypeId
	 */
	@JsonProperty("RecordTypeId")
	private String recordTypeId;
	
	/**
	 * PersonMailingLatitude
	 */
	@JsonProperty("PersonMailingLatitude")
	private String personMailingLatitude;
	
	/**
	 * PersonMailingLatitude
	 */
	@JsonProperty("PersonMailingLongitude")
	private String personMailingLongitude;
	
	
	@JsonProperty("UST_EPLUS__Subscriber_ID__c")
    private String subscriberId;
	
	
    @JsonProperty("UST_EPLUS__Medicaid_Case__pc")
    private String medicaidCase;
    
	
    @JsonProperty("UST_EPLUS__HOH_Address__c")
    private String hohAddress;

	@JsonProperty("UST_EPLUS__UDT1__c")
	private String udt1;

	@JsonProperty("UST_EPLUS__UDT2__c")
	private String udt2;

	@JsonProperty("UST_EPLUS__UDT3__c")
	private String udt3;

	@JsonProperty("UST_EPLUS__VIP__c")
	private String isVIPAccount;

	@JsonProperty("PersonOtherLatitude")
	private BigDecimal billingLatitude;

	@JsonProperty("PersonOtherLongitude")
	private BigDecimal billingLongitude;

	@JsonProperty("UST_EPLUS__State__c")
	private String memberState;

	@JsonProperty("UST_EPLUS__Product__c")
	private String memberProduct;

	@JsonProperty("UST_EPLUS__Line_of_Business__c")
	private String memberLob;

	@JsonProperty("UST_EPLUS__Disabled__c")
	private String disabled;

	@JsonProperty("UST_EPLUS__In_Hospice__c")
	private String inHospice;

	@JsonProperty("UST_EPLUS__Hospice_Date__c")
	private String inHospiceDate;

	@JsonProperty("UST_EPLUS__HRA_Needed__pc")
	private String isHraNeeded;

	@JsonProperty("UST_EPLUS__Last_HRA_Date__pc")
	private String lastHraDate;

	@JsonProperty("UST_EPLUS__ESRD__pc")
	private String isEsrdc;

	@JsonProperty("UST_EPLUS__DIABETES__pc")
	private String isDiabetic;

	@JsonProperty("UST_EPLUS__COPD__pc")
	private String isCopd;

	@JsonProperty("UST_EPLUS__Assigned_Lab__pc")
	private String assignedLab;

	@JsonProperty("UST_EPLUS__Redetermination_Date__pc")
	private String redeterminationDate;

	@JsonProperty("UST_EPLUS__Other_ID_1__c")
	private String otherID1;

	@JsonProperty("UST_EPLUS__Other_ID_2__c")
	private String otherID2;

	@JsonProperty("UST_EPLUS__Other_ID_3__c")
	private String otherID3;

	@JsonProperty("UST_EPLUS__Other_ID_4__c")
	private String otherID4;

	@JsonProperty("UST_EPLUS__Other_ID_5__c")
	private String otherID5;

	@JsonProperty("UST_EPLUS__Mailing_street_without_space__c")
	private String shippingStreetWithOutSpace;

	@JsonProperty("UST_EPLUS__Mailing_city_without_space__c")
	private String shippingCityWithOutSpace;

	@JsonProperty("UST_EPLUS__Mailing_state_without_space__c")
	private String shippingStateWithOutSpace;

	@JsonProperty("UST_EPLUS__Permanent_street_without_space__c")
	private String billingStreetWithOutSpace;

	@JsonProperty("UST_EPLUS__Permanent_city_without_space__c")
	private String billingCityWithOutSpace;

	@JsonProperty("UST_EPLUS__Permanent_state_without_space__c")
	private String billingStateWithOutSpace;

	@JsonProperty("UST_EPLUS__PersonBirthDate__c")
	private String birthDate;

	@JsonProperty("UST_EPLUS__Recipient_ID__c")
	private String recipientID;

	@JsonProperty("UST_EPLUS__Pronoun__c")
	private String memberPronouns;

	@JsonProperty("UST_EPLUS__Gender_Identity__c")
	private String genderIdentity;

	@JsonProperty("UST_EPLUS__Sexual_Orientation__c")
	private String sexualOrientation;

}
