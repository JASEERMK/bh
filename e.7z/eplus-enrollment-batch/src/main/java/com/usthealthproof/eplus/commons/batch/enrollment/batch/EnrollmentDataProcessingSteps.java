package com.usthealthproof.eplus.commons.batch.enrollment.batch;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.SkippedItemsExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import com.usthealthproof.eplus.commons.batch.enrollment.util.MappingUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudMappingUtil.distinctByKey;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class EnrollmentDataProcessingSteps {

    protected static final String OVERRIDDEN_BY_EXPRESSION = null;

    private static final String FIND_ALL_ENROLLMENT = "findKeys";
    private static final String STEP_EXECUTION_CONTEXT_START = "#{stepExecutionContext['";
    private static final String STEP_EXECUTION_CONTEXT_END = "']}";
    private static final String STEP_CONTEXT_CURRENT_PAGE = "CURRENT_PAGE";

    private static int pageSize = 0;

    private final AccountDetailsRepository<MemberEnrollment> accountDetailsRepository;

    private EnrollmentService enrollmentService;

    private Environment env;

    private SkippedItemsExceptionListener skippedItemsExceptionListener;

    @Autowired
    public EnrollmentDataProcessingSteps(AccountDetailsRepository accountDetailsRepository,
                                         EnrollmentService enrollmentService, Environment env,
                                         SkippedItemsExceptionListener skippedItemsExceptionListener) {
        this.accountDetailsRepository = accountDetailsRepository;
        this.enrollmentService = enrollmentService;
        this.env = env;
        this.skippedItemsExceptionListener = skippedItemsExceptionListener;

    }

    private static void accept(AccountRequest accountRequest) {
        List<CompositeRequest> resultList = accountRequest.getCompositeRequest().stream().filter(distinctByKey(compositeRequest -> compositeRequest.getReferenceId())).collect(Collectors.toList());
        accountRequest.setCompositeRequest(resultList);
    }

    @Bean
    @Qualifier("enrollmentLoadStep")
    public Step supplierLoadStep(ItemWriter<List<AccountRequest>> itemWriter, @Qualifier("asyncExecutor") TaskExecutor executor, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, @Qualifier("enrollmentMappingUtil") MappingUtil mappingUtil)   {
        log.debug("Inside supplierLoadStep() in EnrollmentDataProcessingSteps class");
        return getEnrollmentProcessingStep(itemWriter, executor,jobRepository,platformTransactionManager, mappingUtil);
    }

    @Bean
    @StepScope
    public RepositoryPagedItemReader reader(
            @Value(STEP_EXECUTION_CONTEXT_START + STEP_CONTEXT_CURRENT_PAGE + STEP_EXECUTION_CONTEXT_END) String currentPage) {
        log.debug("Inside reader() in EnrollmentDataProcessingSteps class");
        log.info("Repo Reader Initialization Current Page {} ", currentPage);

        RepositoryPagedItemReader reader = new RepositoryPagedItemReader();
        reader.setRepository(accountDetailsRepository);
        reader.setMethodName(FIND_ALL_ENROLLMENT);
        reader.setPage(Integer.parseInt(currentPage));
        reader.setPageSize(pageSize);
        /* Arguments */

        /* Sorting */
        Map<String, Sort.Direction> sorts = new HashMap<>();
        sorts.put("MEMBER_NUMBER", Sort.Direction.ASC);
        reader.setSort(sorts);
        return reader;
    }

    @Bean
    public ItemProcessor<List<MemberEnrollment>, List<AccountRequest>> processor(@Qualifier("enrollmentMappingUtil") MappingUtil mappingUtil) {
        log.debug("Inside processor() in EnrollmentDataProcessingSteps class");
        return new ItemProcessor<List<MemberEnrollment>, List<AccountRequest>>() {

            private AccountRequest apply(MemberEnrollment accountReq) {
                return mappingUtil.createMemberBatchRequest(accountReq, jobExecution);
            }

            private JobExecution jobExecution;

            @BeforeStep
            public void beforeStep(StepExecution stepExecution) {
                jobExecution = stepExecution.getJobExecution();
            }

            @Override
            public List<AccountRequest> process(List<MemberEnrollment> enrollmentBatchList)   {
                return enrollmentBatchList.stream().map(this::apply).collect(Collectors.toList());
            }
        };
    }

    @Bean
    public ItemWriter<List<AccountRequest>> write() {
        log.debug("Inside write() in EnrollmentDataProcessingSteps class");

        return new ItemWriter<List<AccountRequest>>() {
            private StepExecution stepExecution;

            @BeforeStep
            public void beforeStep(StepExecution stepExecution) {
                this.stepExecution = stepExecution;
            }
            public void write(Chunk<? extends List<AccountRequest>> chunk)   {
                log.debug("Inside item writer ");
                writeMembers(chunk.getItems(), stepExecution);
            }
        };
    }

    private void writeMembers(List<? extends List<AccountRequest>> accountRequestList, StepExecution stepExecution)  {
        List<AccountRequest> accountRequests = filterAccountList(accountRequestList);
        removeDuplicateCompositeRequest(accountRequests);
        List<Graphs> graphRequests = splitAccountRequestList(accountRequests);
        graphRequests.forEach(graphs ->{
            if(log.isDebugEnabled()) {
                log.info("Graph Requests {} ", CommonUtils.getObjectAsString(graphs));
            }
            enrollmentService.addEnrollmentService(graphs, stepExecution);
        }
        );
    }

    private void removeDuplicateCompositeRequest(List<AccountRequest> accountRequests) {
        accountRequests.stream().forEach(EnrollmentDataProcessingSteps::accept);
    }

    private List<AccountRequest> filterAccountList(List<? extends List<AccountRequest>> accountRequestList) {
        Map<String,AccountRequest> accountRequestMap = new HashMap<>();
        accountRequestList.stream().forEach(accountRequests -> accountRequests.forEach(accountRequest -> {
            AccountRequest req = accountRequestMap.get(accountRequest.getGraphId());
            if(req == null) {
                accountRequestMap.put(accountRequest.getGraphId(), accountRequest);
            } else {
                req.getCompositeRequest().addAll(accountRequest.getCompositeRequest());
            }
        }));
        return new ArrayList<>(accountRequestMap.values());
    }


    /**
     * If a Graph request exceeding 500 limit, splitting the request and creating a
     * new graph request to limit graph objects below 500
     *
     * @param graphRequestMain main graph request
     * @return List<Graphs> converted graph request
     */
    private List<Graphs> splitAccountRequestList(List<AccountRequest> graphRequestMain) {
        int size = 0;
        log.debug("Size of AccountRequest Received {} ", graphRequestMain.size());
        List<Graphs> listOfGraphRequest = new ArrayList<>();
        List<AccountRequest> accountReqListForGraphReq = new ArrayList<>();
        listOfGraphRequest.add(Graphs.builder().accountRequestList(accountReqListForGraphReq).build());
        for (AccountRequest request : graphRequestMain) {
            size += request.getCompositeRequest().size();
            /**Logic to limit maximum composite request to 500
             * or maximum account requests to 30 which ever comes first **/
            if (size > 500 || accountReqListForGraphReq.size() == 30 ) {
                size = request.getCompositeRequest().size();
                accountReqListForGraphReq = new ArrayList<>();
                listOfGraphRequest.add(Graphs.builder().accountRequestList(accountReqListForGraphReq).build());
            }
            accountReqListForGraphReq.add(request);
        }

        return listOfGraphRequest;
    }

    private Step getEnrollmentProcessingStep(ItemWriter<List<AccountRequest>> itemWriter, TaskExecutor executor, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, MappingUtil mappingUtil) {
        Step step = getChunkStep(itemWriter,jobRepository,platformTransactionManager, mappingUtil);
        return getPartitionerStep(step, executor,jobRepository);
    }

    private Step getChunkStep(ItemWriter<List<AccountRequest>> itemWriter, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, MappingUtil mappingUtil) {
        return new StepBuilder(Constant.PROCESS_STEP_SF_DATA_LOAD,jobRepository)
                .<List<MemberEnrollment>, List<AccountRequest>>chunk(Integer.parseInt(env.getProperty("batch.execution.chunk-size")),platformTransactionManager)
                .reader(reader(OVERRIDDEN_BY_EXPRESSION))
                .processor(processor(mappingUtil))
                .writer(itemWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(1000)
                .processorNonTransactional()
                .listener((StepExecutionListener) skippedItemsExceptionListener)
                .build();
    }

    private Step getPartitionerStep(Step step, TaskExecutor executor,JobRepository jobRepository ) {
        return new StepBuilder("stepPartition_enrollment",jobRepository)
                .partitioner(step)
                .partitioner("stepPartition", getPartitioner())
                .taskExecutor(executor)
                .build();
    }

    private Partitioner getPartitioner() {

        return new Partitioner() {

            @Override
            public Map<String, ExecutionContext> partition(int gridSize) {
                log.info("Inside Partitioner Bean");
                Map<String, ExecutionContext> result = new HashMap<>();
                // Fetch distinct count instead of total count
                Long distinctRecords = accountDetailsRepository.distinctCount();
                log.info("The distinct Records available in database: {}", distinctRecords);
                Long preferredPartitionSize = Long.valueOf(env.getProperty("batch.execution.partition-count"));
                double partitionSize = distinctRecords.doubleValue() / preferredPartitionSize.doubleValue();
                calculatePageSize(partitionSize);
                Long numberOfThreads = preferredPartitionSize;
                if (partitionSize < 1) {
                    numberOfThreads = distinctRecords;
                }
                log.info("The Number of threads that will be spawned : {}", numberOfThreads);
                int index;
                for (index = 0; index < numberOfThreads; index++) {
                    ExecutionContext value = new ExecutionContext();
                    value.putInt(STEP_CONTEXT_CURRENT_PAGE, index);
                    result.put("partition" + index, value);
                }
                return result;
            }
        };
    }
    // static method to set
    private static void calculatePageSize(double partitionSize) {
        pageSize = (int) Math.ceil(partitionSize);
    }
}
