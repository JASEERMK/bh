package com.usthealthproof.eplus.commons.batch.enrollment.config;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.CollectionUtils;

import java.util.List;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class JobConfiguration {


    @Autowired
    private EnrollmentService enrollmentService;

    @Autowired
    private JobAuditListener jobAuditListener;

    @Autowired
    private AuditService auditService;

    @Autowired
    private AuditErrorMessageUtil auditErrorMessageUtil;

    protected static final Step OVERRIDDEN_STEP_BY_EXPRESSION = null;

    @Bean
    public Job profileUpdateJob(@Qualifier("readRuntimeStep") Step readRuntimeStep,
                                @Qualifier("callStoredProcedureStep") Step callStoredProcedure,
                                @Qualifier("callLoginServiceStep") Step callLoginService,
                                @Qualifier("getRecordTypeCreationStep") Step getRecordTypeCreation,
                                @Qualifier("enrollmentLoadStep") Step enrollmentLoadStep,
                                @Qualifier("updateLastRuntimeStep") Step updateLastRuntimeStep, JobRepository jobRepository, PlatformTransactionManager transactionManager,AuditService auditService)   {

        Job job = null;
        try {
            job = new JobBuilder("enrollmentBatchJob",jobRepository)
                    .incrementer(new RunIdIncrementer())
                    .listener(getJobListenerCount())
                    .listener(jobAuditListener)
                    .start(readRuntimeStep)
                    .next(callStoredProcedure)
                    .next(callLoginService)
                    .next(getRecordTypeCreation)
                    .next(enrollmentLoadStep)
                    .next(updateLastRuntimeStep)
                    .build();
        } catch (Exception e) {
            log.error("Exception while running the job ", e);
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditException(" ",e, Constant.PROCESS_JOB);
            if(!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }
        }
        return job;
    }

    public JobExecutionListener getJobListenerCount() {
        return new JobExecutionListener() {
            @Override
            public void beforeJob(JobExecution jobExecution) {
                enrollmentService.resetCounter();
                log.info("Enrollment Batch Job Started");
                String jobId= String.valueOf(jobExecution.getJobId());
                auditService.auditStepStatus(jobId, EnrollmentConstant.ENROLLMENT_BATCH_START,PROCESS_STATUS_SUCCESS_VALUE,null,null);
            }

            @Override
            public void afterJob(JobExecution jobExecution) {
                enrollmentService.resetCounter();
                log.info("Enrollment Batch Job Ended");
                String jobId= String.valueOf(jobExecution.getJobId());
                auditService.auditStepStatus(jobId, EnrollmentConstant.ENROLLMENT_BATCH_END,PROCESS_STATUS_SUCCESS_VALUE,null,null);
            }
        };
    }

    @Scheduled(cron = "${batch.schedule}")
    public void launchJob() throws Exception {
        JobParameters param = new JobParametersBuilder().addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        taskExecutorJobLauncher(null)
                .run(profileUpdateJob(OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        null, null, null), param);
    }

    @Bean
    public TaskExecutorJobLauncher taskExecutorJobLauncher(JobRepository jobRepository) {
        TaskExecutorJobLauncher launcher = new TaskExecutorJobLauncher();
        launcher.setJobRepository(jobRepository);
        return launcher;
    }


}
