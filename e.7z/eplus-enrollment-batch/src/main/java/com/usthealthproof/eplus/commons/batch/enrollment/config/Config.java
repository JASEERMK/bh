package com.usthealthproof.eplus.commons.batch.enrollment.config;

import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudMappingUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.util.MappingUtil;
import com.usthealthproof.eplus.commons.batch.enrollment.util.ServiceCloudMappingUtil;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import java.time.Duration;
import java.util.TimeZone;

import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.THREAD_PREFIX;

/**
 * @author 210409
 */
@Configuration
@EnableAsync
@Slf4j
public class Config {

    @Value("${batch.timeout}")
    private Integer connectionTimeout;
    @Value("${batch.time-zone}")
    String batchTimezone;

    @Bean(name = "asyncExecutor")
    public TaskExecutor asyncExecutor(@Value("${batch.execution.thread-pool-size}") String poolSize,@Value("${batch.interface-id}") String interfaceId) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(Integer.parseInt(poolSize));
        executor.setMaxPoolSize(Integer.MAX_VALUE);
        executor.setQueueCapacity(Integer.MAX_VALUE);
        executor.setThreadNamePrefix(interfaceId + THREAD_PREFIX);
        executor.initialize();
        return executor;
    }

    @Bean
    public WebClient webClient() {
        final ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();
        return WebClient.builder().clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies).build();
    }

    private HttpClient getHttpClient() {
        ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(1000).maxIdleTime(Duration.ofSeconds(20))
                .maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
                .evictInBackground(Duration.ofSeconds(120)).build();
        return HttpClient.create(provider).option(ChannelOption.CONNECT_TIMEOUT_MILLIS,  connectionTimeout * 1000).doOnConnected(
                conn -> conn.addHandlerLast(new ReadTimeoutHandler(connectionTimeout)).addHandlerLast(new WriteTimeoutHandler(connectionTimeout)));
    }

    @Bean(name = "enrollmentMappingUtil")
    public MappingUtil cloudEnviornmentSelection(@Value("${batch.is-service-cloud}")  Boolean isServiceCloud) {
        log.debug("Inside cloudEnviornmentSelection...isServiceCloud {} ",isServiceCloud);
        if(Boolean.TRUE.equals(isServiceCloud)){
            return new ServiceCloudMappingUtil();
        } else
            return new HealthCloudMappingUtil();

    }
    @PostConstruct
    public void setTimeZone() {
        TimeZone.setDefault(TimeZone.getTimeZone(batchTimezone));
    }


}
