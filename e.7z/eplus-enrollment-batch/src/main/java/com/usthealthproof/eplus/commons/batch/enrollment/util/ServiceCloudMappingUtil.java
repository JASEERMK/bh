package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.servicecloud.InsurancePlan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.util.*;

import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.extractDate;

@Slf4j
@Component
public class ServiceCloudMappingUtil implements MappingUtil {

    /**
     * USTHPS_CIL_MEMBER_KEY_C
     */
    private static final String UST_EPLUS_CIL_MEMBER_KEY_C = "UST_EPLUS__CIL_Member_Key__c";

    /**
     * accountEnrollmentUrl
     */
    @Value("${enrollment.url.common.account}")
    private String accountEnrollmentUrl;

    /**
     * planEnrollmentUrl
     */
    @Value("${enrollment.url.service-cloud.plan}")
    private String planEnrollmentUrl;

    /**
     * lisEnrollmentUrl
     */
    @Value("${enrollment.url.service-cloud.lis}")
    private String lisEnrollmentUrl;

    @Value("${batch.ssn.show-truncated}")
    private String showTruncated;

    @Value("${batch.ssn.masking-char}")
    private String maskingChar;
    @Autowired
    ServiceCloudEnrollmentAdapterMapping serviceCloudClientMapping;

    @Autowired
    CommonUtil commonUtilSc;


    /**
     * This is the main bean method which creates enrollment batch request for SC
     *
     * @param memberEnrollment enrollment batch data from db
     * @param jobExecution job execution context
     * @throws JsonProcessingException
     * @throws ParseException
     * @return converted account request for SC
     */
    @SuppressWarnings("unchecked")
    public AccountRequest createMemberBatchRequest(MemberEnrollment memberEnrollment, JobExecution jobExecution)   {
        Map<String, String> recordTypeMap = (Map<String, String>) jobExecution.getExecutionContext().get(Constant.RECORD_TYPE_MAP);

        String memberNumber = memberEnrollment.getMemberNumber();

        if(memberNumber == null) {
            return null;
        }

        Set<CompositeRequest> compositeRequests = new LinkedHashSet<>();
        CompositeRequest memberInfo = createMemberInfo(memberEnrollment,recordTypeMap) ;
        compositeRequests.add(memberInfo);

        String externalId = memberEnrollment.getMemberPlanKey();
        if (StringUtils.hasLength(externalId)) {
            InsurancePlan insurancePlan = getInsurancePlan(memberEnrollment);
            serviceCloudClientMapping.updateInsurancePlan(memberEnrollment, insurancePlan);
            CompositeRequest planRequest = new CompositeRequest();
            planRequest.setUrl(planEnrollmentUrl + externalId);
            planRequest.setReferenceId("PLAN_"+formatRefId(externalId));
            planRequest.setBody(insurancePlan);
            compositeRequests.add(planRequest);
        }
        String newLIS = memberEnrollment.getLisKey();
        if (StringUtils.hasLength(newLIS)) {
            LowIncomeSubsidy lis = getLIS(memberEnrollment);
            serviceCloudClientMapping.updateLowIncomeSubsidy(memberEnrollment, lis);
            CompositeRequest lisRequest = new CompositeRequest();
            externalId = (memberEnrollment.getLisKey());
            lisRequest.setUrl(lisEnrollmentUrl + externalId);
            lisRequest.setReferenceId(formatRefId(externalId));
            lisRequest.setBody(lis);
            compositeRequests.add(lisRequest);
        }
        AccountRequest accountRequest = new AccountRequest();
        accountRequest.setGraphId(memberNumber);
        accountRequest.setCompositeRequest(new ArrayList<>(compositeRequests));
        return accountRequest;
    }

    private CompositeRequest createMemberInfo(MemberEnrollment data, Map<String, String> recordTypeMap) {
        String recordTypeId = recordTypeMap.get(EnrollmentConstant.ENROLLMENT_RECORD_TYPE_ID);
        MemberInfo memberInfo = commonUtilSc.getMemberInfo(data, recordTypeId);
        String externalId = data.getMemberNumber();
        serviceCloudClientMapping.updateMemberInfo(data, memberInfo);
        CompositeRequest memberRequest = new CompositeRequest();
        memberRequest.setUrl(accountEnrollmentUrl + externalId);
        memberRequest.setReferenceId(formatRefId(externalId));
        memberRequest.setBody(memberInfo);
        return memberRequest;
    }


    private InsurancePlan getInsurancePlan(MemberEnrollment data) {
        InsurancePlan body = new InsurancePlan();
        Map<String, String> member = body.getMemberSc();
        String cilMemberKey = data.getMemberNumber();
        member.put(UST_EPLUS_CIL_MEMBER_KEY_C, cilMemberKey);
        body.setMemberSc(member);
        Date dateStart = data.getPlanStartDate();
        body.setPlanStartDateSc(extractDate(dateStart));
        Date dateEnd = data.getPlanEndDate();
        body.setPlanEndDateSc(extractDate(dateEnd));
        body.setMemberPlanName(trimString(data.getMemberPlanName()));
        body.setMemberPlanNameFull(data.getMemberPlanName());
        body.setLobSc(data.getLob());
        body.setCurrentMemberPlanSc(CommonUtils.validateBooleanValueYorN(data.getCurrentPlan()));
        if(null != data.getBenefitNetworkName()) {
            body.setBenefitNetworkSc(data.getBenefitNetworkName());
        }
        body.setIsValidPlanSc(CommonUtils.validateBooleanValue(data.getIsValidPlan()));
        body.setIsVoidPlanSc(CommonUtils.validateBooleanValue(data.getIsVoidPlan()));
        if (null != data.getPlanId()) {
            body.setInsurancePlanId(data.getPlanId());
        }
        commonUtilSc.setCommoPlan(body,data);
        return body;
    }

    /***
     *
     * @return
     */


    private String formatRefId(String referenceId) {
        return CommonUtils.removeSpecialCharacter(referenceId.replace("-", "_"));
    }

    private String trimString(String input) {
        if (input == null) {
            return null;
        }
        return input.length() > 80 ? input.substring(0, 80) : input;
    }
}
