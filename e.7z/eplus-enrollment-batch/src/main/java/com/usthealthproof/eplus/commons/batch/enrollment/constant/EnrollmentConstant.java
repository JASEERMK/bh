package com.usthealthproof.eplus.commons.batch.enrollment.constant;

/**
 * @author 210409
 */
public class EnrollmentConstant {

    private EnrollmentConstant() { }

    /*DB Params*/
    public static final String PARAMETER_GET_ENROLLMENT_DETAILS_SP = "GET_ENROLLMENT_DETAILS_SP";

    public static final String MEMBER_NUMBER_LIST = "memberNumberList";

    /*Record Type Id*/
    public static final String ENROLLMENT_RECORD_TYPE_ID = "enrollmentRecordTypeId";

    public static final String MEMBER_PLAN_FAILURE_COUNT = "MemberPlanFailureCount";
    public static final String MEMBER_PLAN_SUCCESS_COUNT = "MemberPlanSuccessCount";
    public static final String MEMBER_PLAN_COUNT = "MemberPlanCount";
    public static final String MEMBER_FAILURE_COUNT = "MemberFailureCount";
    public static final String MEMBER_SUCCESS_COUNT = "MemberSuccessCount";
    public static final String MEMBER_COUNT = "MemberCount";
    public static final String SUCCESS = "SUCCESS";
    public static final String ERROR = "ERROR";
    public static final String ENROLLMENT_BATCH_START = "EnrollmentBatchStart";
    public static final String ENROLLMENT_BATCH_END = "EnrollmentBatchEnd";


}
