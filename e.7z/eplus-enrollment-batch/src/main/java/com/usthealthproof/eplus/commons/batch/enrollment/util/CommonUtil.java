package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.BasePlanRequest;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.BLANK_STRING;
import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.extractDate;

@Component
public class CommonUtil {

    /**
     * USTHPS_CIL_MEMBER_KEY_C
     */
    private static final String UST_EPLUS_CIL_MEMBER_KEY_C = "UST_EPLUS__CIL_Member_Key__c";

    @Value("${batch.ssn.masking-char}")
    private String maskingChar;

    @Value("${batch.ssn.show-truncated}")
    private String showTruncated;


    public MemberInfo getMemberInfo(MemberEnrollment data, String recordTypeId) {
        MemberInfo memberInfo = new MemberInfo();
        memberInfo.setFirstName(StringUtils.capitalize(data.getMemberFirstName()));
        memberInfo.setLastName(StringUtils.capitalize(data.getMemberLastName()));
        memberInfo.setMemberId(data.getMemberId());
        memberInfo.setGender(data.getMemberGender());
        memberInfo.setEmail(data.getEmail());
        memberInfo.setPhone(data.getPhone());
        Date dob = data.getDob();
        if (dob != null) {
            memberInfo.setDob(extractDate(dob));
            memberInfo.setBirthDate(extractDate(dob));
        }

        memberInfo.setMedicareEnrollee(data.getMedicareEnrollee());

        memberInfo.setMedicaidEligibilityStatus(CommonUtils.validateBooleanValue(data.getMedicaidEligibilityStatus()));
        String language = data.getLanguage();
        if (StringUtils.hasLength(language) && language.contains("-")) {
            language = language.substring(0, language.lastIndexOf('-'));
        }
        memberInfo.setLanguage(language);
        memberInfo.setRltpToMember(data.getRltpToMember());
        // Permanent Address Mapping
        memberInfo.setBillingStreet(data.getBillingStreet());
        memberInfo.setBillingStreetAddress1(data.getPermanentAddress1());
        memberInfo.setBillingStreetAddress2(data.getPermanentAddress2());
        memberInfo.setBillingStreetAddress3(data.getPermanentAddress3());
        memberInfo.setBillingCounty(data.getBillingCounty());
        memberInfo.setBillingState(data.getBillingState());
        memberInfo.setBillingCity(data.getBillingCity());
        memberInfo.setBillingPostalCode(data.getBillingPostalCode());
        memberInfo.setBillingCountry(data.getBillingCountry());
        memberInfo.setBillingLatitude(data.getPersonOtherLatitude());
        memberInfo.setBillingLongitude(data.getPersonOtherLongitude());
        // Mailing Address Mapping
        memberInfo.setShippingStreet(data.getShippingStreet());
        memberInfo.setShippingStreetAddress1(data.getMailingAddress1());
        memberInfo.setShippingStreetAddress2(data.getMailingAddress2());
        memberInfo.setShippingStreetAddress3(data.getMailingAddress3());
        memberInfo.setShippingState(data.getShippingState());
        memberInfo.setShippingCity(data.getShippingCity());
        memberInfo.setShippingPostalCode(data.getShippingPostalCode());
        memberInfo.setShippingCounty(data.getShippingCounty());
        memberInfo.setShippingCountry(data.getShippingCountry());

        memberInfo.setRecordTypeId(recordTypeId);

        setSubscriber(data, memberInfo);
        setDataForCommercial(data, memberInfo);

        setSSNValues(data.getSsn(), memberInfo);
        memberInfo.setMbiId(data.getMbi());
        memberInfo.setHeadOfHouseHoldName(data.getHohName());
        memberInfo.setHohAddress(data.getHohAddress());
        memberInfo.setHohSsnId(data.getHohSsn());
        BigDecimal latitude = data.getPersonMailingLatitude();
        if (latitude != null) {
            memberInfo.setPersonMailingLatitude((latitude).toString());
        }

        BigDecimal longitude = data.getPersonMailingLongitude();
        if (longitude != null) {
            memberInfo.setPersonMailingLongitude((longitude).toString());
        }
        setUDTValues(data, memberInfo);

        if (data.getMedicaidCaseId() != null) {
            memberInfo.setMedicaidCase(data.getMedicaidCaseId());
        }
        memberInfo.setIsVIPAccount(CommonUtils.validateBooleanValue(data.getIsEmployee()));
        memberInfo.setMemberState(data.getMemberState());
        memberInfo.setMemberProduct(data.getMemberProduct());
        memberInfo.setMemberLob(data.getMemberLob());

        memberInfo.setDisabled(CommonUtils.validateBooleanValue(data.getDisabled()));
        memberInfo.setInHospice(CommonUtils.validateBooleanValueYorN(data.getIsHospice()));
        if (data.getDateHospice() != null) {
            Date date = data.getDateHospice();
            memberInfo.setInHospiceDate(extractDate(date));
        }
        memberInfo.setIsHraNeeded(data.getIsHraNeeded());
        if (data.getLastHraDate() != null) {
            Date date = data.getLastHraDate();
            memberInfo.setLastHraDate(extractDate(date));
        }
        memberInfo.setIsEsrdc(data.getEsrdInd());
        memberInfo.setIsDiabetic(data.getInsulinDepDiabeticInd());
        memberInfo.setIsCopd(data.getCopdInd());
        memberInfo.setAssignedLab(data.getLabId());
        if (data.getRedeterminationDate() != null) {
            Date date = data.getRedeterminationDate();
            memberInfo.setRedeterminationDate(extractDate(date));
        }
        memberInfo.setOtherID1(data.getOtherID1());
        memberInfo.setOtherID2(data.getOtherID2());
        memberInfo.setOtherID3(data.getOtherID3());
        memberInfo.setOtherID4(data.getOtherID4());
        memberInfo.setOtherID5(data.getOtherID5());
        memberInfo.setShippingStreetWithOutSpace(removeWhiteSpace(data.getShippingStreet()));
        memberInfo.setShippingCityWithOutSpace(removeWhiteSpace(data.getShippingCity()));
        memberInfo.setShippingStateWithOutSpace(removeWhiteSpace(data.getShippingState()));
        memberInfo.setBillingStreetWithOutSpace(removeWhiteSpace(data.getBillingStreet()));
        memberInfo.setBillingCityWithOutSpace(removeWhiteSpace(data.getBillingCity()));
        memberInfo.setBillingStateWithOutSpace(removeWhiteSpace(data.getBillingState()));
        memberInfo.setRecipientID(data.getRecipientID());
        memberInfo.setMemberPronouns(data.getMemberPronouns());
        memberInfo.setGenderIdentity(data.getGenderIdentity());
        memberInfo.setSexualOrientation(data.getSexualOrientation());
        return memberInfo;
    }
    public <T extends BasePlanRequest> T setCommoPlan(T body, MemberEnrollment data) {
        body.setGroupNumber(data.getAccountId());
        body.setEplusCOB(data.getPrimarySecondary());
        if (null != data.getAccountName()) {
            body.setAccountName(data.getAccountName());
        }
        if (null != data.getPlanYear()) {
            body.setPlanYear(data.getPlanYear());
        }
        body.setMemberPlanState(data.getMemberPlanState());
        body.setMemberPlanProduct(data.getMemberPlanProduct());
        body.setMemberPlanDescription(data.getMemberPlanDesc());
        return body;
    }

    private void setSubscriber(MemberEnrollment data, MemberInfo memberInfo) {
        String subscriber = data.getParentMember();
        String relationToSubscriber = data.getRltpToMember();
        if(relationToSubscriber != null && !relationToSubscriber.equalsIgnoreCase("self")) {
            memberInfo.setParentMembers(Map.of(UST_EPLUS_CIL_MEMBER_KEY_C, subscriber));
        }
        else {
            memberInfo.setParentMemberRef(BLANK_STRING);
        }
    }

    private void setDataForCommercial(MemberEnrollment data, MemberInfo memberInfo) {
        String subscriber = data.getParentMember();
        String lob = data.getLob();
        if(lob!= null && !lob.equalsIgnoreCase("Medicaid")
                && !lob.equalsIgnoreCase("Medicare")) {
            memberInfo.setSubscriberId(subscriber);
        }
    }

    private void setSSNValues(String ssn, MemberInfo memberInfo) {
        if(!StringUtils.hasLength(ssn)) {
            return;
        }
        memberInfo.setSsnDigest(HashingUtil.hash(ssn));
        memberInfo.setSsnMasked(HashingUtil.mask(ssn, maskingChar, showTruncated));
    }

    private static void setUDTValues(MemberEnrollment data, MemberInfo memberInfo) {
        String udt1 = data.getUdtValue1();
        String udt2 = data.getUdtValue2();
        String udt3 = data.getUdtValue3();
        memberInfo.setUdt1(CommonUtils.validateBooleanValue((udt1)));
        if (udt2 != null ) {
            memberInfo.setUdt2(udt2);
        }
        if (udt3 != null) {
            Date date = (extractDate(udt3));
            memberInfo.setUdt3(extractDate(date));
        }

    }

    private static String removeWhiteSpace(String data) {
        if (data == null) {
            return null;
        }
        // replace all white spaces with an empty string
        return data.replaceAll("\\s", "");
    }
}
