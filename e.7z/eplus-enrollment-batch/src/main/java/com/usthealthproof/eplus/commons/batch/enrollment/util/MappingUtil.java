package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import org.springframework.batch.core.JobExecution;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.Map;

import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.extractDate;

public interface MappingUtil {

    /**
     * USTHPS_CIL_MEMBER_KEY_C
     */
    public static final String UST_EPLUS_CIL_MEMBER_KEY_C = "UST_EPLUS__CIL_Member_Key__c";

    public AccountRequest createMemberBatchRequest(MemberEnrollment memberEnrollment, JobExecution jobExecution);

     default LowIncomeSubsidy getLIS(MemberEnrollment data) {

        if (data.getMemberNumber() == null) {
            return null;
        }
        if (!StringUtils.hasLength(data.getLisKey())) {
            return null;
        }
        LowIncomeSubsidy lowIncomeSubsidy = new LowIncomeSubsidy();
        if (data.getLisLevel() != null) {
            lowIncomeSubsidy.setLisLevel(data.getLisLevel());
        }
        Map<String, String> memberKey = lowIncomeSubsidy.getMemberKey();
        memberKey.put(UST_EPLUS_CIL_MEMBER_KEY_C, data.getMemberNumber());

        if (data.getLisStartDate() != null) {
            Date date = data.getLisStartDate();
            lowIncomeSubsidy.setLisStartDate(extractDate(date));
        }
        if (data.getLisEndDate() != null) {
            Date date = data.getEndDate();
            lowIncomeSubsidy.setLisEndDate(extractDate(date));
        }

        return lowIncomeSubsidy;
    }
}
