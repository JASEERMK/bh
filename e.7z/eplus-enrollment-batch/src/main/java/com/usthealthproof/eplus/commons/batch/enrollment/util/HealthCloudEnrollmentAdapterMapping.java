package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.healthcloud.PlanInfo;

public interface HealthCloudEnrollmentAdapterMapping {

    public void updateLowIncomeSubsidy(MemberEnrollment entity, LowIncomeSubsidy lis);

    public void updateMemberInfo(MemberEnrollment entity, MemberInfo memberInfo);

    public void updatePlanInfo(MemberEnrollment entity, PlanInfo planInfo);


}
