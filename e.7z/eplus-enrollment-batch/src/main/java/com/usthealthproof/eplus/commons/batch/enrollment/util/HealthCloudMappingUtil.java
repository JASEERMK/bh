package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.model.request.AccountRequest;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.enrollment.constant.EnrollmentConstant;
import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.healthcloud.PlanInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.extractDate;

/**
 * @author 210409
 */
@Slf4j
@Component
public class HealthCloudMappingUtil implements MappingUtil {

    /**
     * USTHPS_CIL_MEMBER_KEY_C
     */
    private static final String UST_EPLUS_CIL_MEMBER_KEY_C = "UST_EPLUS__CIL_Member_Key__c";

    /**
     * accountEnrollmentUrl
     */
    @Value("${enrollment.url.common.account}")
    private String accountEnrollmentUrl;

    /**
     * planEnrollmentUrl
     */
    @Value("${enrollment.url.health-cloud.plan}")
    private String planEnrollmentUrl;

    /**
     * lisEnrollmentUrl
     */
    @Value("${enrollment.url.health-cloud.lis}")
    private String lisEnrollmentUrl;


    @Autowired
    HealthCloudEnrollmentAdapterMapping healthcloudClientMapping;

    @Autowired
    CommonUtil commonUtil;


    /**
     * This is the main bean method which creates enrollment batch request
     *
     * @param memberEnrollment enrollment batch data from db
     * @param jobExecution job execution context
     * @throws JsonProcessingException
     * @throws ParseException
     * @return converted account request
     */
    @SuppressWarnings("unchecked")
    public AccountRequest createMemberBatchRequest(MemberEnrollment memberEnrollment, JobExecution jobExecution)   {
        Map<String, String> recordTypeMap = (Map<String, String>) jobExecution.getExecutionContext().get(Constant.RECORD_TYPE_MAP);

        String memberNumber = memberEnrollment.getMemberNumber();

        if(memberNumber == null) {
            return null;
        }

        Set<CompositeRequest> compositeRequests = new LinkedHashSet<>();
        CompositeRequest memberInfo = createMemberInfo(memberEnrollment,recordTypeMap) ;
        compositeRequests.add(memberInfo);

        String externalId = memberEnrollment.getMemberPlanKey();
        if (StringUtils.hasLength(externalId)) {
            PlanInfo planInfo = getPlanInfo(memberEnrollment);
            healthcloudClientMapping.updatePlanInfo(memberEnrollment, planInfo);
            CompositeRequest planRequest = new CompositeRequest();
            planRequest.setUrl(planEnrollmentUrl + externalId);
            planRequest.setReferenceId("PLAN_"+formatRefId(externalId));
            planRequest.setBody(planInfo);
            compositeRequests.add(planRequest);
        }
        String newLIS = memberEnrollment.getLisKey();
        if (StringUtils.hasLength(newLIS)) {
            LowIncomeSubsidy lis = getLIS(memberEnrollment);
            healthcloudClientMapping.updateLowIncomeSubsidy(memberEnrollment, lis);
            CompositeRequest lisRequest = new CompositeRequest();
            externalId = (memberEnrollment.getLisKey());
            lisRequest.setUrl(lisEnrollmentUrl + externalId);
            lisRequest.setReferenceId(formatRefId(externalId));
            lisRequest.setBody(lis);
            compositeRequests.add(lisRequest);
        }
        AccountRequest accountRequest = new AccountRequest();
        accountRequest.setGraphId(memberNumber);
        accountRequest.setCompositeRequest(new ArrayList<>(compositeRequests));
        return accountRequest;
    }

    private CompositeRequest createMemberInfo(MemberEnrollment data, Map<String, String> recordTypeMap) {
        String recordTypeId = recordTypeMap.get(EnrollmentConstant.ENROLLMENT_RECORD_TYPE_ID);
        MemberInfo memberInfo = commonUtil.getMemberInfo(data, recordTypeId);
        String externalId = data.getMemberNumber();
        healthcloudClientMapping.updateMemberInfo(data, memberInfo);
        CompositeRequest memberRequest = new CompositeRequest();
        memberRequest.setUrl(accountEnrollmentUrl + externalId);
        memberRequest.setReferenceId(formatRefId(externalId));
        memberRequest.setBody(memberInfo);
        return memberRequest;
    }

    private PlanInfo getPlanInfo(MemberEnrollment data) {
        PlanInfo body = new PlanInfo();
        Map<String, String> member = body.getMember();
        String cilMemberKey = data.getMemberNumber();
        member.put(UST_EPLUS_CIL_MEMBER_KEY_C, cilMemberKey);
        body.setMember(member);
        Date dateStart = data.getPlanStartDate();
        body.setPlanStartDate(extractDate(dateStart));
        Date dateEnd = data.getPlanEndDate();
        body.setPlanEndDate(extractDate(dateEnd));
        body.setMemberPlanName(data.getMemberPlanName());
        body.setLob(data.getLob());
        body.setCurrentMemberPlan(CommonUtils.validateBooleanValueYorN(data.getCurrentPlan()));
        if(null != data.getBenefitNetworkName()) {
            body.setBenefitNetwork(data.getBenefitNetworkName());
        }
        body.setIsValidPlan(CommonUtils.validateBooleanValue(data.getIsValidPlan()));
        body.setIsVoidPlan(CommonUtils.validateBooleanValue(data.getIsVoidPlan()));
        if (null != data.getPlanId()) {
            body.setMemberPlanId(data.getPlanId());
        }
        commonUtil.setCommoPlan(body,data);
        return body;
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
    private String formatRefId(String referenceId) {
        return CommonUtils.removeSpecialCharacter(referenceId.replace("-", "_"));
    }

}
