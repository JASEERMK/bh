package com.usthealthproof.eplus.commons.batch.enrollment.util;

import com.usthealthproof.eplus.commons.batch.common.exception.BatchProcessingException;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Slf4j
public class HashingUtil {

    private HashingUtil() {
    }

    public static String hash(String val) {
        String input = val.replace("-", "");
        try {
            // Create SHA-3 512 MessageDigest instance
            MessageDigest sha3Digest = MessageDigest.getInstance("SHA3-512");

            // Convert the input string to bytes
            byte[] inputBytes = input.getBytes(StandardCharsets.UTF_8);

            // Compute the hash
            byte[] hashBytes = sha3Digest.digest(inputBytes);

            // Convert the hash bytes to hexadecimal representation
            StringBuilder hexBuilder = new StringBuilder();
            for (byte b : hashBytes) {
                hexBuilder.append(String.format("%02x", b));
            }
            return hexBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            log.error("Encryption Algorithm not available.");
            throw new BatchProcessingException("Encryption Algorithm not available.", e);
        }
    }

    public static String mask(String currValue, String mask, String showTruncated) {
        String part2 = currValue.substring(currValue.length() - 4);
        if (showTruncated.equals("true")) {
            return part2;
        }
        String regex = "\\d";
        String part1 = currValue.substring(0, currValue.length() - 4).replaceAll(regex,
                String.valueOf(mask));
        return part1 + part2;
    }

}
