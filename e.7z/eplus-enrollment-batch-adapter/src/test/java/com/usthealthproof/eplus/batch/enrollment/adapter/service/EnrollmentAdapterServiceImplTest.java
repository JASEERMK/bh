package com.usthealthproof.eplus.batch.enrollment.adapter.service;

import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.enrollment.model.response.EnrollBatchLoadResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
class EnrollmentAdapterServiceImplTest {

    @InjectMocks
    EnrollmentAdapterServiceImpl enrollmentAdapterService;

    @Mock
    Graphs graphMock;

    @Mock
    EnrollBatchLoadResponse enrollBatchLoadResponseMock;

    @Test
    public void testUpdateRequest() {
        log.info("inside testUpdateRequest");
        enrollmentAdapterService.updateRequest(graphMock);
    }
    @Test
    public void testUpdateResponse() {
        log.info("inside testUpdateResponse");
        enrollmentAdapterService.updateResponse(enrollBatchLoadResponseMock);
    }

}