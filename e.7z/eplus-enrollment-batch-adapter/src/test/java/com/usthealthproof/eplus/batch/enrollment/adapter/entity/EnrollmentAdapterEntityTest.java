package com.usthealthproof.eplus.batch.enrollment.adapter.entity;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
class EnrollmentAdapterEntityTest {
    @InjectMocks
    EnrollmentAdapterEntity enrollmentAdapterEntity;

    @Test
    public void testEnrollmentAdapterEntity() {
        log.info("inside testEnrollmentAdapterEntity");
        enrollmentAdapterEntity.hashCode();
    }

}