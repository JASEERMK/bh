package com.usthealthproof.eplus.batch.enrollment.adapter.util;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.servicecloud.InsurancePlan;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ServiceCloudEnrollmentAdapterMappingImplTest {

    @InjectMocks
    ServiceCloudEnrollmentAdapterMappingImpl serviceCloudEnrollmentAdapterMapping;

    @Mock
    MemberEnrollment memberEnrollmentMock;

    @Mock
    LowIncomeSubsidy lowIncomeSubsidyMock;

    @Mock
    MemberInfo memberInfoMock;

    @Mock
    InsurancePlan insurancePlanMock;


    @Test
    void testUpdateLowIncomeSubsidy()
    {
        log.info("inside testUpdateLowIncomeSubsidy");
        serviceCloudEnrollmentAdapterMapping.updateLowIncomeSubsidy(memberEnrollmentMock,lowIncomeSubsidyMock);
    }

    @Test
    void testupdateMemberInfo()
    {
        log.info("inside testupdateMemberInfo");
        serviceCloudEnrollmentAdapterMapping.updateMemberInfo(memberEnrollmentMock,memberInfoMock);
    }

    @Test
    void testUpdateInsurancePlan()
    {
        log.info("inside updateInsurancePlan");
        serviceCloudEnrollmentAdapterMapping.updateInsurancePlan(memberEnrollmentMock,insurancePlanMock);
    }

}