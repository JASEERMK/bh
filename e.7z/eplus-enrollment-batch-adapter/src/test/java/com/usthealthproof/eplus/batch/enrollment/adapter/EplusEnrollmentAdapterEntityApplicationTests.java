package com.usthealthproof.eplus.batch.enrollment.adapter;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@Slf4j
@ExtendWith(MockitoExtension.class)
class EplusEnrollmentAdapterEntityApplicationTests {

    @InjectMocks
    EplusEnrollmentAdapterApplication eplusEnrollmentAdapterApplication;

    @Test
    void applicationContextLoads() {
        log.info("inside applicationContextLoads");
        try (MockedStatic<SpringApplication> mockedStatic = Mockito.mockStatic(SpringApplication.class)) {
            // Call the main method of DemoApplication
            EplusEnrollmentAdapterApplication.main(new String[]{});

            // Verify that SpringApplication.run() was called exactly once with DemoApplication.class as an argument
            mockedStatic.verify(() -> SpringApplication.run(EplusEnrollmentAdapterApplication.class, new String[]{}));
        }
    }

}
