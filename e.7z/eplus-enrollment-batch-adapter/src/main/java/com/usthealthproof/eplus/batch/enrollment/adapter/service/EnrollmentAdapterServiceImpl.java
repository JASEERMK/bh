package com.usthealthproof.eplus.batch.enrollment.adapter.service;

import com.usthealthproof.eplus.commons.batch.common.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.enrollment.model.response.EnrollBatchLoadResponse;
import com.usthealthproof.eplus.commons.batch.enrollment.service.EnrollmentAdapterService;
import org.springframework.stereotype.Service;

@Service
public class EnrollmentAdapterServiceImpl implements EnrollmentAdapterService {

    /*
     * Update the request graph object if require
     *
     * @param graphs This will be the request sending to SF
     */
    @Override
    public void updateRequest(Graphs graphs) {
        // Update request object here
    }
    /*
     * Update the response object if require
     * @param response Response object received from SF
     */
    @Override
    public void updateResponse(EnrollBatchLoadResponse response) {
        // Update request object here
    }
}
