package com.usthealthproof.eplus.batch.enrollment.adapter.entity;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name ="EPLUS_MEMBER_ENROLLMENT")
public class EnrollmentAdapterEntity extends MemberEnrollment {
    /*
     * Customer specific columns can be added in the class
     */

    // * @Column(name = "PCP_INDICATOR")
    // * private String pcpIndicator;
}
