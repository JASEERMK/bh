package com.usthealthproof.eplus.batch.enrollment.adapter.repo;

import com.usthealthproof.eplus.batch.enrollment.adapter.entity.EnrollmentAdapterEntity;
import com.usthealthproof.eplus.commons.batch.enrollment.db.repository.AccountDetailsRepository;
import org.springframework.stereotype.Repository;

@Repository(value = "EnrollmentAdapterRepository")
public interface EnrollmentAdapterRepository extends AccountDetailsRepository<EnrollmentAdapterEntity> {
    /*
     * Please make sure the annotation repository have value EnrollmentAdapterRepository
     */

}
