package com.usthealthproof.eplus.batch.enrollment.adapter.util;

import com.usthealthproof.eplus.commons.batch.enrollment.db.entity.MemberEnrollment;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.LowIncomeSubsidy;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.MemberInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.model.request.healthcloud.PlanInfo;
import com.usthealthproof.eplus.commons.batch.enrollment.util.HealthCloudEnrollmentAdapterMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class HealthCloudEnrollmentAdapterMappingImpl implements HealthCloudEnrollmentAdapterMapping {

    /*
     * Update the @lis object with values from database entity if needed
     * @param entity This can be mapped to adapter
     *               entity object created in this adapter project
     * @param lis Sale force account object in request
     */

    @Override
    public void updateLowIncomeSubsidy(MemberEnrollment entity, LowIncomeSubsidy lis) {
        // Update LowIncomeSubsidy object here
    }

    /*
     * Update the @memberInfo object with values from database entity if needed
     * @param entity This can be mapped to adapter
     *               entity object created in this adapter project
     * @param memberInfo Sale force account object in request
     */

    @Override
    public void updateMemberInfo(MemberEnrollment entity, MemberInfo memberInfo) {
        // Update MemberInfo object here
    }

    /*
     * Update the @planInfo object with values from database entity if needed
     * @param entity This can be mapped to adapter
     *               entity object created in this adapter project
     * @param planInfo Sale force account object in request
     */

    @Override
    public void updatePlanInfo(MemberEnrollment entity, PlanInfo planInfo) {
        // Update PlanInfo object here
    }
}
