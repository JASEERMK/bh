package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Hidden
@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Claims Data Check Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class ClaimDataCheckController {

    @Autowired
    private ClaimHeaderSearchService claimHeaderSearchService;
    @Autowired
    private Validator validator;

    /**
     * API to check Provider Claim Search Data Information
     *
     * @param providerId
     * @param providerType
     * @param claimTypes
     * @param claimNumber
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimStatus
     * @param serviceCode
     * @param diagnosisCode
     * @param memberNumber
     * @param state
     * @param lob
     * @param product
     * @return
     * @throws Exception
     */
    @Operation(summary = "Claim Data Check", method = "GET", description = "Provider claims data check", responses = {
            @ApiResponse(responseCode = "200", description = "Claim Data Check Details", content = {
                    @Content(schema = @Schema(implementation = ClaimHeaderSearchResponse.class)) }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
    @GetMapping(value = "/provider/claimSearch/isAvailable")
    @ResponseBody
        public ResponseEntity<ClaimHeaderSearchResponse> providerClaimDataAvailabilityCheck(
            @Parameter(description = "Provider Id", required = false) @RequestParam(value = "providerId", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: providerId is not in valid format") String providerId,
            @Parameter(description = "Provider Type", required = false) @RequestParam(value = "providerType", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: providerType is not in valid format") String providerType,
            @Parameter(description = "Claim Types", required = true) @RequestParam(value = "claimTypes") @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimTypes is not in valid format") String claimTypes,
            @Parameter(description = "Claim Number", required = false) @RequestParam(value = "claimNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimNumber is not in valid format") String claimNumber,
            @Parameter(description = "Service From Date", required = false) @RequestParam(value = "serviceFromDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceFromDate is not in valid format") String serviceFromDate,
            @Parameter(description = "Service To Date", required = false) @RequestParam(value = "serviceToDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceToDate is not in valid format") String serviceToDate,
            @Parameter(description = "Claim Status", required = false) @RequestParam(value = "claimStatus", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|;!]*$", message = "Invalid Request: claimStatus is not in valid format") String claimStatus,
            @Parameter(description = "Service Code", hidden = false) @RequestParam(value = "serviceCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: serviceCode is not in valid format") String serviceCode,
            @Parameter(description = "Diagnosis Code", hidden = false) @RequestParam(value = "diagnosisCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: diagnosisCode is not in valid format") String diagnosisCode,
            @Parameter(description = "Member Number", required = false) @RequestParam(value = "memberNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: memberNumber is not in valid format") String memberNumber,
            @Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
            @Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String lob,
            @Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String product
    )
            throws Exception {
        log.info("Inside providerClaimDataAvailabilityCheck() in ClaimDataCheckController class");
        log.debug("Provider claim data availability check request:- ClaimTypes: {}, claimNumber: {}, serviceFromDate: {}, serviceToDate: {}, claimStatus: {}, memberNumber: {}, providerId: {}, providerType: {}, serviceCode: {}, diagnosisCode: {}, state: {}, lob: {}, product: {}",
                claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, providerId, providerType,
                serviceCode, diagnosisCode, state, lob, product);

        ClaimHeaderSearchResponse claimHeaderSearchResponse;
        validator.validateProviderSearchRequest(claimTypes, serviceFromDate, serviceToDate, claimNumber, providerId, providerType);

        ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();
        claimHeaderSearchRequest.setMemberNumber(memberNumber);
        claimHeaderSearchRequest.setServiceFromDate(serviceFromDate);
        claimHeaderSearchRequest.setServiceToDate(serviceToDate);
        claimHeaderSearchRequest.setClaimTypes(claimTypes);
        claimHeaderSearchRequest.setClaimStatus(claimStatus);
        claimHeaderSearchRequest.setClaimNumber(claimNumber);
        claimHeaderSearchRequest.setProviderId(providerId);
        claimHeaderSearchRequest.setProviderIdType(providerType);
        claimHeaderSearchRequest.setServiceCode(serviceCode);
        claimHeaderSearchRequest.setDiagnosisCode(diagnosisCode);
        claimHeaderSearchRequest.setState(state);
        claimHeaderSearchRequest.setLob(lob);
        claimHeaderSearchRequest.setProduct(product);
        claimHeaderSearchResponse = claimHeaderSearchService.providerClaimDataAvailabilityCheck(claimHeaderSearchRequest);
        return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
    }
}
