package com.usthealthproof.eplus.ods.claim.mapper.portal;


import com.usthealthproof.eplus.ods.claim.model.portal.Diagnoses;
import com.usthealthproof.eplus.ods.claim.model.portal.Name;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.PaymentInformation;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimLineProcedure;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isAllBlank;
@Slf4j
@Component
public class ClaimDetailsMapper implements RowMapper<ClaimDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Value("#{${claims.claimStatus}}")
	private Map<String, String> claimDetailsStatusMap;
	@Value("#{${claims.claimLineStatus}}")
	private Map<String, String> claimLineStatusMap;
	private static final String CLAIM_STATUS = "claim_status";
	private static final String CLAIM_LINE_STATUS = "claim_line_status";

	@Override
	public ClaimDetails mapRow(ResultSet rs, int i) throws SQLException {
		ClaimDetails claimDetails = new ClaimDetails();
		claimDetails.setClaimNumber(rs.getString("claim_number"));
		if (StringUtils.isNotBlank(rs.getString(CLAIM_STATUS))) {
			if (StringUtils.isNotBlank(claimDetailsStatusMap.get(rs.getString(CLAIM_STATUS)))) {
				claimDetails.setClaimStatus(claimDetailsStatusMap.get(rs.getString(CLAIM_STATUS)));
			} else {
				claimDetails.setClaimStatus(claimDetailsStatusMap.get("Others"));
			}
		}
		claimDetails.setClaimType(rs.getString("claim_category"));
		claimDetails.setServiceDate(dateUtils.getFormattedClientDate(rs.getString("service_date")));
		claimDetails.setTotalSubmittedAmount(rs.getString("total_submitted_amount"));
		claimDetails.setTotalPatientResponsibilityAmount(rs.getString("total_patient_responsibility_amount"));
		claimDetails.setTotalPaidAmount(rs.getString("total_paid_amount"));
		claimDetails.setTotalCopayAmount(rs.getString("total_copay_amount"));
		claimDetails.setTotalCoinsuranceAmount(rs.getString("total_coinsurance_amount"));
		claimDetails.setTotalDeductibleAmount(rs.getString("total_deductible_amount"));
		claimDetails.setTotalBilledAmount(rs.getString("total_billed_amount"));
		claimDetails.setPaymentStatus(rs.getString("payment_status"));
		claimDetails.setPaymentDate(dateUtils.getFormattedClientDate(rs.getString("payment_date")));
		claimDetails.setPaymentInformationList(getPaymentInformationList(rs));
		claimDetails.setPatient(getPatient(rs));
		claimDetails.setModifiedBy(rs.getString("modifiers_Value"));
		String claimLineNumber = rs.getString("line_number");
		if (null != claimLineNumber) {
			claimDetails.setClaimLineDetailsList(getClaimLineDetailsList(rs, claimLineNumber));
		}
		claimDetails.setProvider(getSupplier(rs));
		String diagnosisCode = rs.getString("diagnosis_code");
		if (!StringUtils.isEmpty(diagnosisCode)) {
			claimDetails.setDiagnosesList(getDiagnosesList(rs, diagnosisCode));
		}
		return claimDetails;
	}

	/**
	 * get diagnosis list
	 *
	 * @param rs
	 * @param diagnosisCode
	 * @return
	 * @throws SQLException
	 */
	private List<Diagnoses> getDiagnosesList(ResultSet rs, String diagnosisCode) throws SQLException {

		List<Diagnoses> diagnosesList = null;
		String diagnosisDescription = rs.getString("diagnosis_description");
		if (!StringUtils.isEmpty(diagnosisCode) || !StringUtils.isEmpty(diagnosisDescription)) {
			Diagnoses diagnoses = new Diagnoses();
			diagnosesList = new ArrayList<>();
			diagnoses.setDiagnosisCode(diagnosisCode);
			diagnoses.setDiagnosisDescription(diagnosisDescription);
			diagnosesList.add(diagnoses);
		}
		return diagnosesList;
	}

	/**
	 * get claim line details
	 *
	 * @param rs
	 * @param claimLineNumber
	 * @return
	 * @throws SQLException
	 */
	private List<ClaimLineDetails> getClaimLineDetailsList(ResultSet rs, String claimLineNumber) throws SQLException {
		ClaimLineDetails claimLineDetails = new ClaimLineDetails();
		List<ClaimLineDetails> claimLineDetailsList = new ArrayList<>(1);
		claimLineDetails.setClaimLineNumber(claimLineNumber);
		claimLineDetails.setServiceStartDate(dateUtils.getFormattedClientDate(rs.getString("service_from_date")));
		claimLineDetails.setServiceEndDate(dateUtils.getFormattedClientDate(rs.getString("service_to_date")));
		claimLineDetails.setBilledAmount(rs.getString("billed_amount"));
		claimLineDetails.setServiceUnits(rs.getString("service_units"));
		claimLineDetails.setDeductibleAmount(rs.getString("deductible_amount"));
		claimLineDetails.setAmountNotCovered(rs.getString("amount_not_covered"));
		claimLineDetails.setPaidAmount(rs.getString("paid_amount"));
		claimLineDetails.setCoinsuranceAmount(rs.getString("coinsurance_amount"));
		claimLineDetails.setCopayAmount(rs.getString("copay_amount"));
		claimLineDetails.setPatientResponsibilityAmount(rs.getString("patient_responsibility_amount"));
		if (StringUtils.isNotBlank(rs.getString(CLAIM_LINE_STATUS))) {
			if (StringUtils.isNotBlank(claimLineStatusMap.get(rs.getString(CLAIM_LINE_STATUS)))) {
				claimLineDetails.setStatus(claimLineStatusMap.get(rs.getString(CLAIM_LINE_STATUS)));
			} else {
				claimLineDetails.setStatus(rs.getString(CLAIM_LINE_STATUS));
			}
		}
		claimLineDetails.setClaimLineProcedureList(getClaimLineProcedureList(rs));
		claimLineDetailsList.add(claimLineDetails);
		return claimLineDetailsList;
	}

	/**
	 * get supplier
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Provider getSupplier(ResultSet rs) throws SQLException {
		Provider supplier = new Provider();
		supplier.setProviderId(rs.getString("supplier_id"));
		supplier.setName(getSupplierName(rs));
		supplier.setProviderNpi(rs.getString("supplier_npi"));
		return supplier;
	}

	/**
	 * get supplier name
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Name getSupplierName(ResultSet rs) throws SQLException {
		Name supplierName = new Name();
		supplierName.setFirstName(rs.getString("supplier_first_name"));
		supplierName.setLastName(rs.getString("supplier_last_name"));
		supplierName.setMiddleName(rs.getString("supplier_middle_name"));
		supplierName.setSuffix(rs.getString("supplier_prefix"));
		supplierName.setPrefix(rs.getString("supplier_suffix"));
		return supplierName;
	}

	/**
	 * get Claim line procedure list
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private List<ClaimLineProcedure> getClaimLineProcedureList(ResultSet rs) throws SQLException {

		List<ClaimLineProcedure> claimLineProcedureList = null;

		String procedureCode = rs.getString("claimlineProcedures_procedure_code");
		String procedureDescription = rs.getString("claimlineProcedures_procedure_description");

		if (!isAllBlank(procedureCode, procedureDescription)) {
			ClaimLineProcedure claimLineProcedure = new ClaimLineProcedure();
			claimLineProcedureList = new ArrayList<>();
			claimLineProcedure.setProcedureCode(procedureCode);
			claimLineProcedure.setProcedureDescription(procedureDescription);
			claimLineProcedureList.add(claimLineProcedure);
		}

		return claimLineProcedureList;
	}

	/**
	 * get Patient
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Patient getPatient(ResultSet rs) throws SQLException {
		Patient patient = new Patient();
		patient.setMemberNumber(rs.getString("member_number"));
		patient.setName(getPatientName(rs));
		return patient;
	}

	/**
	 * get Patient Name
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private Name getPatientName(ResultSet rs) throws SQLException {
		Name patientName = new Name();
		patientName.setFirstName(rs.getString("first_name"));
		patientName.setLastName(rs.getString("last_name"));
		patientName.setMiddleName(rs.getString("middle_name"));
		patientName.setPrefix(rs.getString("prefix"));
		patientName.setSuffix(rs.getString("suffix"));
		return patientName;
	}

	/**
	 * get Payment Information
	 *
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	private List<PaymentInformation> getPaymentInformationList(ResultSet rs) throws SQLException {
		List<PaymentInformation> paymentInformationList = new ArrayList<>();
		PaymentInformation paymentInformation = new PaymentInformation();
		paymentInformation.setPaymentType(rs.getString("payment_type"));
		paymentInformation.setPaymentDate(dateUtils.getFormattedClientDate(rs.getString("payment_date")));
		paymentInformation.setPaymentAmount(rs.getString("payment_amount"));
		paymentInformation.setPaymentNumber(rs.getString("payment_check_number"));
		paymentInformation.setPaymentIssuedTo(rs.getString("payment_check_issued_to"));
		paymentInformationList.add(paymentInformation);
		return paymentInformationList;
	}
}
