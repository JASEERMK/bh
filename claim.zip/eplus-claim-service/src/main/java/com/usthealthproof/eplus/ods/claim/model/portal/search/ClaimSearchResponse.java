package com.usthealthproof.eplus.ods.claim.model.portal.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonPropertyOrder({ "count","results", "status"})
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response class containing claim search details")
public class ClaimSearchResponse {

	@Schema(description = "Count")
	private int count;
	@Schema(description = "Results")
	private List<ClaimSearchModel> results;
	@Schema(description = "Response Status: SUCCESS or FAILURE")
	private String status;

}
