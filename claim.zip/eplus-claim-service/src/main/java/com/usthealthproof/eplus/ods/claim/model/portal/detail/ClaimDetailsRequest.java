package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim details request")
public class ClaimDetailsRequest implements Serializable {

	private static final long serialVersionUID = -394998641295151056L;

	@Schema(description = "Claim types")
	@JsonProperty("claimTypes")
	@Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Claim types is not in valid format")
	private String claimTypes;

	@Schema(description = "member Number")
	@JsonProperty("memberNumber")
	@Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Member number is not in valid format")
	private String memberNumber;

	@Schema(description = "Claim number")
	@JsonProperty("claimHccId")
	@Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Claim number is not in valid format")
	private String claimNumber;

	@Schema(description = "Header details")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: userIdentities is not in valid format")
	private String userIdentities;

}
