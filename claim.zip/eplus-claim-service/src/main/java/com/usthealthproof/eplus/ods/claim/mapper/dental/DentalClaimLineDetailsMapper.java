package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class DentalClaimLineDetailsMapper implements RowMapper<DentalClaimLineDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public DentalClaimLineDetails mapRow(ResultSet rs, int i) throws SQLException {

		var dentalClaimLineDetails = new DentalClaimLineDetails();

		dentalClaimLineDetails.setClaimHccId(rs.getString("claimhccid"));
		dentalClaimLineDetails.setCodeDescription(rs.getString("Codedescription"));
		dentalClaimLineDetails.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		dentalClaimLineDetails.setSurface(rs.getString("surface"));
		dentalClaimLineDetails.setTooth(rs.getString("tooth"));
		dentalClaimLineDetails.setAllowedAmount(rs.getString("allowedamount"));
		dentalClaimLineDetails.setPaidAmount(rs.getString("paidAmount"));
		dentalClaimLineDetails.setDeductible(rs.getString("deductible"));
		dentalClaimLineDetails.setCoPay(rs.getString("co_pay"));
		dentalClaimLineDetails.setCoInsurance(rs.getString("co_insurance"));
		dentalClaimLineDetails.setOverMax(rs.getString("overmax"));
		dentalClaimLineDetails.setCobAmount(rs.getString("cob_amount"));
		dentalClaimLineDetails.setPaymentNotes(rs.getString("payment_notes"));
		dentalClaimLineDetails.setAreaOfOralCavity(rs.getString("area_of_oral_cavity"));
		dentalClaimLineDetails.setAuthorizationNumber(rs.getString("authorization_id"));
		dentalClaimLineDetails.setServiceException(rs.getString("service_exception"));
		dentalClaimLineDetails.setBilledAmount(rs.getString("billed_amount"));

		return dentalClaimLineDetails;
	}

}
