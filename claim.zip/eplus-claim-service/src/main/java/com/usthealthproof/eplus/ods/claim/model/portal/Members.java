package com.usthealthproof.eplus.ods.claim.model.portal;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class Members {

	private String member_id;

	private String relation;

}
