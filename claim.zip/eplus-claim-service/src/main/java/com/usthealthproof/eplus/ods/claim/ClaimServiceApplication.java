package com.usthealthproof.eplus.ods.claim;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

import java.time.ZonedDateTime;
import java.util.TimeZone;

@SpringBootApplication
@Slf4j
@SecurityScheme(name = "ClaimService", scheme = "bearer", type = SecuritySchemeType.HTTP , in = SecuritySchemeIn.HEADER)
public class ClaimServiceApplication {

	public static void main(String[] args) {
		log.info("Claim Service started and running !!!");
		SpringApplication.run(ClaimServiceApplication.class, args);
	}
	@Value("${application.timeZone}")
	private String timeZone;
	@PostConstruct
	public void init(){
	// Setting Spring Boot SetTimeZone
	TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
	log.info("Application timezone is {}. Today = {} ", TimeZone.getDefault().toZoneId(), ZonedDateTime.now());
	}

}