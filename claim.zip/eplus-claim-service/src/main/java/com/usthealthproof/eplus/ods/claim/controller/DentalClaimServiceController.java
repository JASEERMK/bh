package com.usthealthproof.eplus.ods.claim.controller;

import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLinesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Dental Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class DentalClaimServiceController {

	@Autowired
	private ClaimServices claimServices;
	@Autowired
	private Validator validator;

	/***
	 * get the dental claim details
	 *
	 * @param claimHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "Dental Claim Details", description = "Details regarding dental claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Dental Claim Details", content = {
					@Content(schema = @Schema(implementation = DentalClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimDetails> getDentalClaimDetails(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){
		log.info("Inside getDentalClaimDetails() in DentalClaimServiceController");
		log.debug("Dental claim details request:- claimHccId: {}, state: {}, lob: {}, product: {}", claimHccId, state, lob, product);
		validator.validateRequestField(claimHccId);
		return new ResponseEntity<>(claimServices.findDentalClaimId(claimHccId, state, lob, product), HttpStatus.OK);
	}

	/***
	 * get all Dental claim lines of the particular claim
	 *
	 * @param claimHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "Dental Claim Lines", description = "Service Lines information’s regarding dental claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of all claim lines of the claim", content = {
					@Content(schema = @Schema(implementation = DentalClaimLinesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental/claimlines", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimLinesResponse> getDentalClaimLines(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){

		log.info("Inside getDentalClaimLines() in DentalClaimServiceController");
		log.debug("Dental claim lines request received with claimHccId= {}, state: {}, lob: {}, product: {}", claimHccId, state, lob, product);
		validator.validateRequestField(claimHccId);
		var dentalClaimLinesResponse = new DentalClaimLinesResponse();
		List<DentalClaimLines> dentalClaimLineDetailsList = claimServices.getDentalClaimLines(claimHccId, state, lob, product);
		dentalClaimLinesResponse.setDentalClaimLines(dentalClaimLineDetailsList);
		return new ResponseEntity<>(dentalClaimLinesResponse, HttpStatus.OK);
	}

	/**
	 * get specific Dental claim line details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "Dental Claim Line Details", description = "Service Line details regarding dental claims, can be accessed through the specified service. Claim HCC ID and Claim Line HCC ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Dental claim line detail of the particular claim", content = {
					@Content(schema = @Schema(implementation = DentalClaimLineDetailResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/dental/claimline", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<DentalClaimLineDetailResponse> getDentalClaimLineDetails(
			@Parameter(description = "Dental Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "Dental Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") @Pattern(regexp = "^(?!.*--)[a-zA-Z0-9._-]*$", message = "Invalid Request: claimLineHccId is not in valid format") String claimLineHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){

		log.info("Inside getDentalClaimLineDetails() in DentalClaimServiceController");
		log.debug("Dental claim line details request received with claimHccID= {}, claimLineHccId= {}, state: {}, lob: {}, product: {}", claimHccId,
				claimLineHccId, state, lob, product);
		validator.validateRequestField(claimHccId, claimLineHccId);
		var dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
		var dentalClaimLineDetails = claimServices.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
		List<DentalClaimLineDetails> dentalClaimLineDetailsList = new ArrayList<>();
		dentalClaimLineDetailsList.add(dentalClaimLineDetails);
		dentalClaimLineDetailResponse.setDentalClaimLineDetailsList(dentalClaimLineDetailsList);
		return new ResponseEntity<>(dentalClaimLineDetailResponse, HttpStatus.OK);
	}

}
