package com.usthealthproof.eplus.ods.claim.repository.utilis;

import com.usthealthproof.eplus.ods.claim.mapper.medical.*;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Repository
@Slf4j
@Async("asyncExecutor")
public class AsyncExecutorUtils {

    @Value("${claims.spClaimFactKey}")
    private String spClaimFactKey;
    @Value("${claims.spMedicalClaimLineVersionDtl}")
    private String spMedicalClaimLineVersionDtl;
    @Value("${claims.spMedicalClaimLineDtl}")
    private String spMedicalClaimLineDtl;
    @Value("${claims.claimNotesDelimiter}")
    private String claimNotesDelimiter;
    @Value("${claims.claimNotesPrioritySeparator}")
    private String claimNotesPrioritySeparator;
    @Value("${claims.spClaimRejectionReason}")
    private String spClaimRejectionReason;
    @Value("${claims.spMedicalClaimLinesVersion}")
    private String spMedicalClaimLinesVersion;
    @Value("${claims.spMedicalClaimLines}")
    private String spMedicalClaimLines;
    @Value("${claims.spMedicalClaimVersionDtl}")
    private String spMedicalClaimVersionDtl;
    @Value("${claims.spMedicalClaimDtl}")
    private String spMedicalClaimDtl;
    @Autowired
    private MedicalClaimLinesMapper medicalClaimLinesMapper;
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private ClaimRejectionCodeMapper claimRejectionCodeMapper;
    @Autowired
    private MedicalClaimLineDetailsMapper medicalClaimLineDetailsMapper;
    @Autowired
    private ClaimFactKeysMapper claimFactKeysMapper;
    @Autowired
    private MedicalClaimDetailsMapper medicalClaimDetailsMapper;

    private static final String SP_CALL_PREFIX = "{CALL ";
    private static final String CLAIM_HCC_ID = "claimHccId";
    private static final String RETURN_STATUS = "returnStatus";
    private static final String CLAIM_LINE_HCC_ID = "claimLineHccId";
    private static final String CLAIM_FACT_KEY = "claimFactKey";
    private static final String STATE = "state";
    private static final String PRODUCT = "product";
    private static final String LOB = "lob";
    private static final String DB_SP_EXECUTION_LOG = "Completed the DB call, Query execution time for {} is {}";
    private static final String CLAIM_NOTES_SEPARATOR = "claimNotesSeparator";
    private static final String CLAIM_NOTES_DELIMITTER = "claimNotesDelimiter";

    /**
     * Class specifically created for generating AsyncCalls. It includes
     * 1.Method for retrieving the ClaimFactKeys based on the claimHccId
     * 2.Method for retrieving the Claim Rejection details based on the claimHccId,claimLineHccId,claimFactKey
     * 3.Method for retrieving the Claim Lines response based on the claimHccId,claimFactKey
     * 4.Method for retrieving the Claim Line Details response based on the claimHccId,claimLineHccId,claimFactKey
     *
     */

    public CompletableFuture<List<String>> getClaimFactKeys(String claimHccId) {
        log.info("Inside getClaimFactKeys() in AsyncExecutorUtils class");

        List<String> claimFactKeys = null;
        String claimFactKeySql = SP_CALL_PREFIX + spClaimFactKey + "(:claimHccId, :returnStatus)}";
        MapSqlParameterSource claimFactKeyParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId, Types.VARCHAR)
                .addValue(RETURN_STATUS, 0, Types.NUMERIC);
        log.info("Going for ClaimFactKeys SP DB call");
        long startServiceRequestTime = System.currentTimeMillis();
        claimFactKeys = namedParameterJdbcTemplate.query(claimFactKeySql, claimFactKeyParams, claimFactKeysMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spClaimFactKey, endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(claimFactKeys);
    }

    /**
     * Method for retrieving the Rejection code description based on the claimHccId
     *
     * @param claimHccId
     * @return
     */
    public CompletableFuture<List<ClaimRejectionDetails>> getRejectionCodeDesc(String claimHccId, String claimLineHccId, String claimFactKey, String state, String lob, String product) {
        log.info("Inside getRejectionCodeDesc() in AsyncExecutorUtils class");

        List<ClaimRejectionDetails> claimRejectionDetails = null;
        String claimLinesRejectionCodeSql = SP_CALL_PREFIX + spClaimRejectionReason + "(:claimHccId, :claimLineHccId, :claimFactKey, :state, :lob, :product, :returnStatus)}";
        MapSqlParameterSource claimRejectionCodeParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId, Types.VARCHAR)
                .addValue(CLAIM_LINE_HCC_ID, claimLineHccId,
                        Types.VARCHAR).addValue(CLAIM_FACT_KEY, claimFactKey, Types.VARCHAR)
                .addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR)
                .addValue(RETURN_STATUS, 0, Types.NUMERIC);
        log.info("Going for rejection details DB call");
        long startServiceRequestTime = System.currentTimeMillis();
        claimRejectionDetails = namedParameterJdbcTemplate.query(claimLinesRejectionCodeSql, claimRejectionCodeParams, claimRejectionCodeMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spClaimRejectionReason,endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(claimRejectionDetails);
    }

    public CompletableFuture<List<MedicalClaimLines>> getMedicalClaimLinesWithFactKey(String claimHccId, String claimFactKey, String state, String lob, String product) throws Exception {
        log.info("Inside getMedicalClaimLinesWithFactKey() in AsyncExecutorUtils class");

        List<MedicalClaimLines> medicalClaimLines = null;
        String claimLinesVersionSql =
                SP_CALL_PREFIX + spMedicalClaimLinesVersion + "(:claimHccId, :claimFactKey, :state, :lob, :product, :returnStatus)}";
        MapSqlParameterSource claimLinesVersionsParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR).addValue(CLAIM_FACT_KEY, claimFactKey, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        medicalClaimLines = namedParameterJdbcTemplate.query(claimLinesVersionSql, claimLinesVersionsParams,
                medicalClaimLinesMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimLinesVersion, endServiceRequestTime - startServiceRequestTime);

        return CompletableFuture.completedFuture(medicalClaimLines);
    }

    public CompletableFuture<List<MedicalClaimLines>> getMedicalClaimLinesWithoutFactKey(String claimHccId, String state, String lob, String product) {
        log.info("Inside getMedicalClaimLinesWithoutFactKey() in AsyncExecutorUtils class");

        List<MedicalClaimLines> medicalClaimLines = null;
        String claimLinesSql =
                SP_CALL_PREFIX + spMedicalClaimLines + "(:claimHccId, :state, :lob, :product, :returnStatus)}";
        MapSqlParameterSource claimLinesParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        medicalClaimLines = namedParameterJdbcTemplate.query(claimLinesSql, claimLinesParams,
                medicalClaimLinesMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimLines, endServiceRequestTime - startServiceRequestTime);

        return CompletableFuture.completedFuture(medicalClaimLines);
    }

    public CompletableFuture<MedicalClaimLineDetails> getMedicalClaimLineDetailsWithoutFactKey(String claimHccId, String claimLineHccId, String state, String lob, String product) {
        log.info("Inside getMedicalClaimLineDetailsWithoutFactKey() in AsyncExecutorUtils class");

        String claimLineDetailSql =
                SP_CALL_PREFIX + spMedicalClaimLineDtl + "(:claimHccId, :claimLineHccId, :state, :lob, :product, :claimNotesSeparator, :claimNotesDelimiter, :returnStatus)}";
        MapSqlParameterSource claimLineDetailsParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(CLAIM_LINE_HCC_ID, claimLineHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(CLAIM_NOTES_SEPARATOR, claimNotesPrioritySeparator, Types.VARCHAR).addValue(CLAIM_NOTES_DELIMITTER, claimNotesDelimiter, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        MedicalClaimLineDetails claimLineDetail = namedParameterJdbcTemplate.queryForObject(claimLineDetailSql, claimLineDetailsParams,
                medicalClaimLineDetailsMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimLineDtl, endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(claimLineDetail);
    }

    public CompletableFuture<MedicalClaimLineDetails> getMedicalClaimLineDetailsWithFactKey(String claimHccId, String claimLineHccId, String claimFactKey, String state, String lob, String product) {
        log.info("Inside getMedicalClaimLineDetailsWithFactKey() in AsyncExecutorUtils class");

        String claimLineDetailVersionSql =
                SP_CALL_PREFIX + spMedicalClaimLineVersionDtl + "(:claimHccId, :claimLineHccId, :claimFactKey, :state, :lob, :product, :claimNotesSeparator, :claimNotesDelimiter, :returnStatus)}";
        MapSqlParameterSource claimLineDetailsVersionsParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(CLAIM_LINE_HCC_ID, claimLineHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR).addValue(CLAIM_FACT_KEY, claimFactKey, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(CLAIM_NOTES_SEPARATOR, claimNotesPrioritySeparator, Types.VARCHAR).addValue(CLAIM_NOTES_DELIMITTER, claimNotesDelimiter, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        MedicalClaimLineDetails claimLineDetail = namedParameterJdbcTemplate.queryForObject(claimLineDetailVersionSql, claimLineDetailsVersionsParams,
                medicalClaimLineDetailsMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimLineVersionDtl, endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(claimLineDetail);
    }

    public CompletableFuture<MedicalClaimDetails> getMedicalClaimDetailsWithoutFactKey(String claimHccId, String state, String lob, String product) {
        log.info("Inside getMedicalClaimDetailsWithoutFactKey() in AsyncExecutorUtils class");

        String claimDetailsSql =
                SP_CALL_PREFIX + spMedicalClaimDtl + "(:claimHccId, :state, :lob, :product, :claimNotesSeparator, :claimNotesDelimiter, :returnStatus)}";
        MapSqlParameterSource claimDetailsParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(CLAIM_NOTES_SEPARATOR, claimNotesPrioritySeparator, Types.VARCHAR).addValue(CLAIM_NOTES_DELIMITTER, claimNotesDelimiter, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        MedicalClaimDetails medicalClaimDetails = namedParameterJdbcTemplate.queryForObject(claimDetailsSql, claimDetailsParams,
                medicalClaimDetailsMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimDtl, endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(medicalClaimDetails);
    }

    public CompletableFuture<MedicalClaimDetails> getMedicalClaimDetailsWithFactKey(String claimHccId, String claimFactKey, String state, String lob, String product) {
        log.info("Inside getMedicalClaimDetailsWithFactKey() in AsyncExecutorUtils class");

        String claimDetailsVersionSql =
                SP_CALL_PREFIX + spMedicalClaimVersionDtl + "(:claimHccId, :claimFactKey, :state, :lob, :product, :claimNotesSeparator, :claimNotesDelimiter, :returnStatus)}";
        MapSqlParameterSource claimDetailsVersionParams = new MapSqlParameterSource().addValue(CLAIM_HCC_ID, claimHccId,
                        Types.VARCHAR).addValue(STATE, state, Types.VARCHAR).addValue(LOB, lob, Types.VARCHAR).addValue(CLAIM_FACT_KEY, claimFactKey, Types.VARCHAR)
                .addValue(PRODUCT, product, Types.VARCHAR).addValue(CLAIM_NOTES_SEPARATOR, claimNotesPrioritySeparator, Types.VARCHAR).addValue(CLAIM_NOTES_DELIMITTER, claimNotesDelimiter, Types.VARCHAR).addValue(RETURN_STATUS, 0, Types.NUMERIC);
        long startServiceRequestTime = System.currentTimeMillis();
        MedicalClaimDetails medicalClaimDetails = namedParameterJdbcTemplate.queryForObject(claimDetailsVersionSql, claimDetailsVersionParams,
                medicalClaimDetailsMapper);
        long endServiceRequestTime = System.currentTimeMillis();
        log.info(DB_SP_EXECUTION_LOG, spMedicalClaimVersionDtl, endServiceRequestTime - startServiceRequestTime);
        return CompletableFuture.completedFuture(medicalClaimDetails);
    }
}
