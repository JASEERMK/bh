package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ClaimAvailabilityCheckMapper implements RowMapper<ClaimHeaderSearchResponse> {

    @Override
    public ClaimHeaderSearchResponse mapRow(ResultSet rs, int i) throws SQLException {
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        if(StringUtils.isNotBlank(rs.getString("CLAIM_HCC_ID"))) {
            claimHeaderSearchResponse.setDataAvailabilityFlag("True");
        }
        return claimHeaderSearchResponse;
    }
}
