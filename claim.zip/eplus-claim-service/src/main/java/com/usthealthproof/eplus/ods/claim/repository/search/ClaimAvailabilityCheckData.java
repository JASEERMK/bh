package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.mapper.search.ClaimAvailabilityCheckMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class ClaimAvailabilityCheckData {

    @Value("${claims.spProviderClaimDataCheck}")
    private String spProviderClaimDataCheck;
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private ClaimAvailabilityCheckMapper claimAvailabilityCheckMapper;

    public ClaimHeaderSearchResponse providerClaimDataAvailabilityCheck(ClaimHeaderSearchRequest claimHeaderSearchRequest) {
        log.info("Inside providerClaimDataAvailabilityCheck() in ClaimAvailabilityCheckData");
        
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        try {
            String providerClaimDataCheckSql = "{CALL " + spProviderClaimDataCheck
                    + "(:claimNumber, :providerID, :providerType, :memberNumber, :claimStatus, :serviceFromDate, :serviceToDate, :serviceCode, :diagnosisCode, :product, :lob, :state, :returnStatus)}";
            MapSqlParameterSource claimDataCheckParams = new MapSqlParameterSource().addValue("claimNumber",
                            claimHeaderSearchRequest.getClaimNumber(), Types.VARCHAR)
                    .addValue("providerID", claimHeaderSearchRequest.getProviderId(), Types.VARCHAR)
                    .addValue("providerType", claimHeaderSearchRequest.getProviderIdType(), Types.VARCHAR)
                    .addValue("memberNumber", claimHeaderSearchRequest.getMemberNumber(), Types.VARCHAR)
                    .addValue("claimStatus", claimHeaderSearchRequest.getClaimStatus(), Types.VARCHAR)
                    .addValue("serviceFromDate", claimHeaderSearchRequest.getServiceFromDate(), Types.VARCHAR)
                    .addValue("serviceToDate", claimHeaderSearchRequest.getServiceToDate(), Types.VARCHAR)
                    .addValue("serviceCode", claimHeaderSearchRequest.getServiceCode(), Types.VARCHAR)
                    .addValue("diagnosisCode", claimHeaderSearchRequest.getDiagnosisCode(), Types.VARCHAR)
                    .addValue("product", claimHeaderSearchRequest.getProduct(), Types.VARCHAR)
                    .addValue("lob", claimHeaderSearchRequest.getLob(), Types.VARCHAR)
                    .addValue("state", claimHeaderSearchRequest.getState(), Types.VARCHAR)
                    .addValue("returnStatus", 0, Types.NUMERIC);

            long startServiceRequestTime = System.currentTimeMillis();
            claimHeaderSearchResponse = namedParameterJdbcTemplate.queryForObject(providerClaimDataCheckSql, claimDataCheckParams,
                    claimAvailabilityCheckMapper);
            long endServiceRequestTime = System.currentTimeMillis();
            log.info("Completed the DB call. Query execution time for {} is {}", spProviderClaimDataCheck,
                    endServiceRequestTime - startServiceRequestTime);
            log.debug("Response from DB: {}", claimHeaderSearchResponse);
        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "ProviderClaimDataCheck");
            throw jdbcException;
        } catch (EmptyResultDataAccessException emptyResultException) {
            log.error("EmptyResultDataAccessException occurred for the MedicalClaimDetails service request and the exception is: ",
                    emptyResultException);
            claimHeaderSearchResponse.setDataAvailabilityFlag("False");
            return claimHeaderSearchResponse;
        } catch (Exception exception) {
            log.error(ClaimConstants.EXCEPTION_MESSAGE + "ProviderClaimDataCheck");
            throw exception;
        }
        return claimHeaderSearchResponse;
    }
}
