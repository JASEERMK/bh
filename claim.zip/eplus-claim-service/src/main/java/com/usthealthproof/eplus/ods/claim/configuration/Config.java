package com.usthealthproof.eplus.ods.claim.configuration;

import com.zaxxer.hikari.HikariDataSource;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

@Configuration
@Setter
@Getter
@EnableAsync
public class Config {
	@Value("${spring.datasource.integrationDbUrl}")
	private String integrationDbUrl;
	@Value("${spring.datasource.driverClassName}")
	private String dbDriverClass;
	@Value("${spring.datasource.username}")
	private String dbUsername;
	@Value("${spring.datasource.password}")
	private String dbPassword;
	@Value("${spring.datasource.url}")
	private String url;
	@Value("${springdoc.servers.url}")
	private String swaggerServerUrl;

	/**
	 * Swagger Document API: http://localhost:8080/eplus/eplus-claim-service/api-docs
	 * Swagger UI: http://localhost:8080/eplus/eplus-claim-service/index.html
	 */

	@Bean
	public OpenAPI springShopOpenAPI() {
		List<Server> servers = new ArrayList<>();
		Server server = new Server();
		server.setUrl(swaggerServerUrl);
		servers.add(server);
		return new OpenAPI().servers(servers).info(new Info().title("Claim Service API").description(
						"Claim service provides robust functionality for searching claims based on various filter conditions, enabling users to quickly locate specific claims. Users can apply filters such as claim number, member number, etc., to narrow down their search results. Furthermore, the service provides distinct endpoints for retrieving comprehensive data related to each claim."
								+ "We are offering the claims service, which gives a member or provider the ability to retrieve the information they need about their claims. Below are the APIs that the service offers:\n"
								+ "- Member Claim Search (Medical/Dental/Vision/Pharmacy)\n"
								+ "- Provider Claim Search (Medical)\n"
								+ "- Medical Claim Details\n"
								+ "- Medical Claim Lines\n"
								+ "- Medical Claim Line Details\n"
								+ "- Dental Claim Details\n"
								+ "- Dental Claim Lines\n"
								+ "- Vision Claim Details\n"
								+ "- Vision Claim Lines\n"
								+ "- Vision Claim Line Details\n"
								+ "- Pharmacy Claim Details\n"
								+ "- External Claim Messages\n"
								+ "- Denial Codes\n \n"
								+ "The consumers are provided with a url and credentials to get the access token. The service calls are made with valid access token in the header. \n \n"
								+ "For every failure a problemDetails object with error message and status will be available in the response.\n \n")
				.version("5.23.2"));
	}

	@Bean(name = "asyncExecutor")
	public Executor asyncExecutor() {

		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(4);
		executor.setMaxPoolSize(4);
		executor.setQueueCapacity(100);
		executor.setThreadNamePrefix("AsynchThread-");
		executor.initialize();
		return executor;
	}
	@Bean
	@Qualifier("integrationDataSource")
	public HikariDataSource integrationDataSource() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setDriverClassName(dbDriverClass);
		dataSource.setUsername(dbUsername);
		dataSource.setPassword(dbPassword);
		dataSource.setJdbcUrl(integrationDbUrl);
		return dataSource;
	}
	@Bean
	@Qualifier("odsDataSource")
	@Primary
	public HikariDataSource odsDataSource() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setDriverClassName(dbDriverClass);
		dataSource.setUsername(dbUsername);
		dataSource.setPassword(dbPassword);
		dataSource.setJdbcUrl(url);
		return dataSource;
	}
	@Bean
	@Qualifier("integrationJdbcTemplate")
	JdbcTemplate integrationJdbcTemplate(@Qualifier("integrationDataSource") HikariDataSource integrationDataSource) {
		return new JdbcTemplate(integrationDataSource);
	}
	@Bean
	JdbcTemplate jdbcTemplate(@Qualifier("odsDataSource") HikariDataSource odsDataSource) {
		return new JdbcTemplate(odsDataSource);
	}
	@Bean
	@Qualifier("namedParameterJdbcTemplate")
	NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("integrationDataSource") HikariDataSource integrationDataSource) {
		return new NamedParameterJdbcTemplate(integrationDataSource);
	}


}
