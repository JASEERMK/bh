package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.Types;
import java.util.List;

@Repository
@Slf4j
public class VisionClaimLinesData {

	@Value("${claims.spVisionClaimLines}")
	private String spVisionClaimLines;
	@Autowired
	private VisionClaimLinesMapper visionClaimLinesMapper;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	private static final String VISION_CLAIM_LINES = "VisionClaimLines";

	/**
	 * get all the vision claim lines of particular claimNumber
	 *
	 * @param claimHccId
	 * @return
	 */
	public List<VisionClaimLines> getVisionClaimLines(String claimHccId, String state, String lob, String product) {
		log.info("Inside getVisionClaimLines() in VisionClaimLinesData class");

		List<VisionClaimLines> visionClaimLines;
		try {
			MapSqlParameterSource visionClaimLinesParams = new MapSqlParameterSource().addValue("claimId",
							claimHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String visionClaimLinesSql = "{CALL " + spVisionClaimLines
					+ "(:claimId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			visionClaimLines = namedParameterJdbcTemplate.query(visionClaimLinesSql, visionClaimLinesParams,
					visionClaimLinesMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spVisionClaimLines,
                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", visionClaimLines);
			if (CollectionUtils.isEmpty(visionClaimLines)) {
				throw new ClaimNotFoundException(ClaimConstants.VISION_CLAIM_LINES_NOT_FOUND + claimHccId);
			}
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + VISION_CLAIM_LINES);
			throw jdbcException;
		} catch (ClaimNotFoundException claimNotFoundException) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + VISION_CLAIM_LINES,
					claimNotFoundException);
			throw claimNotFoundException;
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + VISION_CLAIM_LINES);
			throw ex;
		}
		log.info("VisionClaimLines data fetched successfully.");
		return visionClaimLines;
	}

}
