package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonPropertyOrder({ "diagnosisCode", "diagnosisDescription" })
@Schema(description = "Wrapper class for diagnosis details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Diagnoses implements Serializable, Comparable<Diagnoses> {
	private static final long serialVersionUID = 7347610391459636640L;

	@Schema(description = "Diagnosis code")
	@JsonProperty("diagnosisCode")
	private String diagnosisCode;

	@Schema(description = "Diagnosis description")
	@JsonProperty("diagnosisDescription")
	private String diagnosisDescription;

	@Override
	public int compareTo(Diagnoses obj) {
		return this.getDiagnosisCode().compareTo(obj.getDiagnosisCode());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((diagnosisCode == null) ? 0 : diagnosisCode.hashCode());
		result = prime * result + ((diagnosisDescription == null) ? 0 : diagnosisDescription.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Diagnoses other = (Diagnoses) obj;
		if (diagnosisCode == null) {
			if (other.diagnosisCode != null)
				return false;
		} else if (!diagnosisCode.equals(other.diagnosisCode))
			return false;
		if (diagnosisDescription == null) {
			if (other.diagnosisDescription != null)
				return false;
		} else if (!diagnosisDescription.equals(other.diagnosisDescription))
			return false;
		return true;
	}

}
