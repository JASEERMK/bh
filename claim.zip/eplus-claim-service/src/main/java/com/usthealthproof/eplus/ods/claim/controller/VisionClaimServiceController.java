package com.usthealthproof.eplus.ods.claim.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLinesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Vision Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class VisionClaimServiceController {

	@Autowired
	private ClaimServices claimServices;
	@Autowired
	private Validator validator;

	/**
	 * get vision claim details
	 *
	 * @param claimHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@GetMapping(value = "/vision", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Vision Claim Details", description = "Details regarding Vision claims can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Vision claim details of the particular claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<VisionClaimDetails> getVisionClaimDetails(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){

		log.info("Inside getVisionClaimDetails() in VisionClaimServiceController class");
		log.debug("Vision claim detail service request received with claimHccId= {}", claimHccId);
		validator.validateRequestField(claimHccId);
		return new ResponseEntity<>(claimServices.findVisionClaimId(claimHccId, state, lob, product), HttpStatus.OK);
	}

	/**
	 * get all claim lines of the particular vision claim
	 *
	 * @param claimHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "Vision Claim Lines", description = "Service Lines information’s regarding Vision claims, can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "List of all the vision claim lines of the claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimLinesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/vision/claimlines", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<VisionClaimLinesResponse> getVisionClaimLines(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){

		log.info("Inside getVisionClaimLines() in VisionClaimServiceController class");
		log.debug("Vision claim lines service request received with claimHccId= {}", claimHccId);
		validator.validateRequestField(claimHccId);
		var visionClaimLinesResponse = new VisionClaimLinesResponse();
		List<VisionClaimLines> visionClaimLines = claimServices.getVisionClaimLines(claimHccId, state, lob, product);
		visionClaimLinesResponse.setVisionClaimLines(visionClaimLines);
		return new ResponseEntity<>(visionClaimLinesResponse, HttpStatus.OK);
	}

	/***
	 * get specific vision claim line details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "Vision Claim Line Details", description = "Service Line details regarding Vision claims, can be accessed through the specified service. Claim HCC ID and Claim Line HCC ID are the only request fields; thus, it must be supplied as requests.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Vision claim line detail of the particular claim", content = {
					@Content(schema = @Schema(implementation = VisionClaimLineDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/vision/claimline", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<VisionClaimLineDetailsResponse> getVisionClaimLineDetails(
			@Parameter(description = "Vision Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "Vision Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") @Pattern(regexp = "^(?!.*--)[a-zA-Z0-9._-]*$", message = "Invalid Request: claimLineHccId is not in valid format") String claimLineHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){


		log.info("Inside getVisionClaimLineDetails() in VisionClaimServiceController");
		log.debug("Vision claim line detail service request received with claimHccID= {} claimLineHccId= {}", claimHccId,
				claimLineHccId);
		validator.validateRequestField(claimHccId, claimLineHccId);
		var visionClaimLineDetailsResponse = new VisionClaimLineDetailsResponse();
		var visionClaimLineDetails = claimServices.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
		List<VisionClaimLineDetails> visionClaimLineDetailsList = new ArrayList<>();
		visionClaimLineDetailsList.add(visionClaimLineDetails);
		visionClaimLineDetailsList.sort(Comparator.naturalOrder());
		visionClaimLineDetailsResponse.setVisionClaimLineDetails(visionClaimLineDetailsList);
		return new ResponseEntity<>(visionClaimLineDetailsResponse, HttpStatus.OK);
	}

}



