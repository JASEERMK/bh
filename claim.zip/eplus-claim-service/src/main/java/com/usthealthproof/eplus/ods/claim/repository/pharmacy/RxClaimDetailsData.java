package com.usthealthproof.eplus.ods.claim.repository.pharmacy;

import com.usthealthproof.eplus.ods.claim.configuration.Config;
import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.pharmacy.RxClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class RxClaimDetailsData {

	@Autowired
	private RxClaimDetailsMapper rxClaimDetailsMapper;
	@Value("${claims.spRxClaimDetails}")
	private String spRxClaimDetails;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public RxClaimDetails findRxClaimId(String claimHccId, String state, String lob, String product) {
		log.info("Inside findRxClaimId() in RxClaimDetailsData class");

		RxClaimDetails rxClaimDetails;
		try {
			MapSqlParameterSource rxClaimDetailsParams = new MapSqlParameterSource().addValue("claimId",
							claimHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String rxClaimDetailSql = "{CALL " + spRxClaimDetails
					+ "(:claimId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			rxClaimDetails = namedParameterJdbcTemplate.queryForObject(rxClaimDetailSql, rxClaimDetailsParams,
					rxClaimDetailsMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spRxClaimDetails,
			                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", rxClaimDetails);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "RxClaimDetails");
			throw jdbcException;
		} catch (EmptyResultDataAccessException emptyResultException) {
			log.error("EmptyResultDataAccessException occurred for the RXClaimDetails service request and the exception is: ",
					emptyResultException);
			throw new ClaimNotFoundException(ClaimConstants.RX_CLAIM_DETAILS_NOT_FOUND + claimHccId);
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + "RxClaimDetails");
			throw ex;
		}
		log.info("RxClaimDetails data fetched successfully.");
		return rxClaimDetails;
	}

}
