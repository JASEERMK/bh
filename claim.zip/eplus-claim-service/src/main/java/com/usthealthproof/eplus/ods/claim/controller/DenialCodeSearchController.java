package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Claims Search Services")
@Validated
@Slf4j
public class DenialCodeSearchController {

    @Autowired
    private ClaimServices claimServices;

    /**
     * API to get the Denial code and Description for a particular claim id
     *
     * @param claimHccId
     * @return
     */
    @Operation(summary = "Retrieve all denial codes for a particular claim", description = "The API provides the denial code and description if a claim is denied, helping to identify the reason for the denial. Claim HCC ID is the only request field; thus, it must be supplied as a request.", method = "GET", responses = {
            @ApiResponse(responseCode = "200", description = "Claim Denial Codes", content = {
                    @Content(schema = @Schema(implementation = DenialCodes.class))}),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "404", description = "No data found", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = "/denialcodes")
    @ResponseBody
    public ResponseEntity<DenialCodes> getdenialcodesbyclaim(
            @Parameter(description = "Claim HCC ID", required = true)
            @RequestParam(value = "claimHccId", required = true)
            @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format")
            @NotBlank(message = ClaimConstants.CLAIM_ID_NOT_FOUND)
            @Validated String claimHccId,
            @Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
            @Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
            @Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){
        log.info("Inside getdenialcodesbyclaim() in DenialCodeSearchController class");
        log.debug("Denial Code service request received with:- claimHccId: {}, state: {}, lob: {}, product: {}", claimHccId,state, lob, product);

        DenialCodes denialCodes;
        denialCodes = claimServices.getDenialCodes(claimHccId, state, lob, product);
        log.info("Successfully generated denial code response");
        return new ResponseEntity<>(denialCodes, HttpStatus.OK);
    }

}
