package com.usthealthproof.eplus.ods.claim.exception;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.Arrays;

@ControllerAdvice
@Slf4j
public class ApplicationRequestExceptionHandler {

	/**
	 * Exception Handler for MethodArgumentNotValidException types
	 *
	 * @param ex
	 * @param headers
	 * @param status
	 * @param request
	 * @return
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		log.error("MethodArgumentNotValidException Caught : {} {}", ex.getMessage(), ex);
		String errorMessage = ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();
		return new ResponseEntity<>(setErrorDetails(errorMessage, ClaimConstants.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Common Method for the Util function for setting the error details
	 */
	private ErrorResponse setErrorDetails(String message, String status) {
		log.info("Inside setErrorDetails() in ApplicationRequestExceptionHandler class");
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(createProblemDetails(message, status));
		return errorResponse;
	}

	private ProblemDetails createProblemDetails(String message, String status) {
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(Arrays.asList(message));
		return problemDetails;
	}

}
