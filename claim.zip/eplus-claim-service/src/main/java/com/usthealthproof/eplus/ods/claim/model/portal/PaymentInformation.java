package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for payment information details")
public class PaymentInformation implements Serializable {

	private static final long serialVersionUID = -7632746129564160492L;

	@Schema(description = "Type of payment(check, ACH, etc.)")
	@JsonProperty("paymentType")
	private String paymentType;

	@Schema(description = "The date on which this payment was received")
	@JsonProperty("paymentDate")
	private String paymentDate;

	@Schema(description = "Amount being paid")
	@JsonProperty("paymentAmount")
	private String paymentAmount;

	@Schema(description = "Check number associated with the payment")
	@JsonProperty("paymentNumber")
	private String paymentNumber;

	@Schema(description = "Payment Issued To")
	@JsonProperty("paymentIssuedTo")
	private String paymentIssuedTo;

}
