package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.portal.ClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.portal.Diagnoses;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimLineDetails;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedCaseInsensitiveMap;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

@Repository
@Slf4j
public class ClaimDetailsData {

	@Autowired
	private JdbcTemplate integrationJdbcTemplate;

	@Autowired
	private ClaimDetailsMapper claimDetailsMapper;

	@Value("${sp.spPortalMedicalClaimDetails}")
	private String spPortalMedicalClaimDetails;
	@Value("${sp.spPortalVisionClaimDetails}")
	private String spPortalVisionClaimDetails;
	@Value("${sp.spPortalDentalClaimDetails}")
	private String spPortalDentalClaimDetails;
	/**
	 * get the claim details Info
	 *
	 * @param claimDetailsRequest
	 * @return
	 */
	public ClaimDetailsResponse getClaimDetailsInfo(ClaimDetailsRequest claimDetailsRequest) throws SQLException {
		log.info("Inside getClaimDetailsInfo() in ClaimDetailsData class");
		
		List<ClaimDetails> claimDetailsList = new ArrayList<>();
		ClaimDetailsResponse claimDetailsResponse = new ClaimDetailsResponse();
		try {
			if (StringUtils.isBlank(claimDetailsRequest.getClaimTypes())) {
				log.info("Claim type is empty, so executing medicalClaimDetails SP");
				claimDetailsList = getClaimDetails(claimDetailsRequest,spPortalMedicalClaimDetails);
			} else {
				log.info("Started {} claim details SP", claimDetailsRequest.getClaimTypes());
				switch (claimDetailsRequest.getClaimTypes().toLowerCase()) {
				case ClaimConstants.MEDICAL_CLAIM_TYPE:
					claimDetailsList = getClaimDetails(claimDetailsRequest,spPortalMedicalClaimDetails);
					break;
				case ClaimConstants.DENTAL_CLAIM_TYPE:
					claimDetailsList = getClaimDetails(claimDetailsRequest,spPortalDentalClaimDetails);
					break;
				case ClaimConstants.VISION_CLAIM_TYPE:
					claimDetailsList = getVisionClaimDetails(claimDetailsRequest,spPortalVisionClaimDetails);
					break;
				default: break;
				}
			}
			log.info("Completed the DB call");
			if (!CollectionUtils.isEmpty(claimDetailsList)) {
				ClaimDetails claimDetails = getResults(claimDetailsList);
				claimDetailsResponse.setResults(claimDetails);
				claimDetailsResponse.setStatus(ClaimConstants.SUCCESS);
			} else {
				throw new ClaimNotFoundException(ClaimConstants.NO_DATA_FOUND + "|404");
			}
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error("CannotGetJdbcConnectionException occurred for the claim details request");
			throw jdbcException;
		} catch (Exception e) {
			log.error("Exception occurred for the claim details request");
			throw e;
		}
		log.info("ClaimDetailsInfo fetched successfully");
		return claimDetailsResponse;
	}

	private List<ClaimDetails> getClaimDetails(ClaimDetailsRequest claimDetailsRequest,String storedProcedure) throws SQLException {
		log.info("Inside getClaimDetails() in ClaimDetailsData class");
		
		List<ClaimDetails> claimDetailsList;
		log.debug("MemberNumber {} claimNumber {}",claimDetailsRequest.getMemberNumber(),
				claimDetailsRequest.getClaimNumber());
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(integrationJdbcTemplate)
				.withProcedureName(storedProcedure)
				.declareParameters(
						new SqlParameter("MEMBER_HCC_ID", Types.VARCHAR),
						new SqlParameter("CLAIM_HCC_ID", Types.VARCHAR),
						new SqlOutParameter(ClaimConstants.RETURN_STATUS, Types.NUMERIC)
				).returningResultSet(ClaimConstants.RESULT, claimDetailsMapper);
		long startServiceRequestTime = System.currentTimeMillis();
		Map<String, Object> out = simpleJdbcCall.execute(claimDetailsRequest.getMemberNumber(),
				claimDetailsRequest.getClaimNumber(), 0);
		long endServiceRequestTime = System.currentTimeMillis();
		log.info("Completed the DB call. Query execution time for {} is {}", storedProcedure,
				endServiceRequestTime - startServiceRequestTime);
		log.debug("Details out {}", out);
		if (out.get(ClaimConstants.RETURN_STATUS).toString().equalsIgnoreCase("1.0000")) {
			log.info("Error occurred while executing the SP {}", out.get(ClaimConstants.RESULT_SET2));
			List<LinkedCaseInsensitiveMap<String>> errorCodeList = (List<LinkedCaseInsensitiveMap<String>>) out.get(ClaimConstants.RESULT_SET2);
			throw new SQLException(errorCodeList.get(0).get("ErrorMessage"));
		}
		claimDetailsList = (List<ClaimDetails>) out.get(ClaimConstants.RESULT);
		return claimDetailsList;
	}

	private List<ClaimDetails> getVisionClaimDetails(ClaimDetailsRequest claimDetailsRequest,String storedProcedure) throws SQLException {
		log.info("Inside getVisionClaimDetails() in ClaimDetailsData class");
		
		List<ClaimDetails> claimDetailsList;
		log.debug("claimNumber {} MemberNumber {}",claimDetailsRequest.getClaimNumber(),
				claimDetailsRequest.getMemberNumber());
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(integrationJdbcTemplate)
				.withProcedureName(storedProcedure)
				.declareParameters(
						new SqlParameter("CLAIM_ID", Types.VARCHAR),
						new SqlParameter("MEMBER_HCC_ID", Types.VARCHAR),
						new SqlOutParameter(ClaimConstants.RETURN_STATUS, Types.NUMERIC)
				).returningResultSet(ClaimConstants.RESULT,claimDetailsMapper);
		long startServiceRequestTime = System.currentTimeMillis();
		Map<String, Object> out = simpleJdbcCall.execute(claimDetailsRequest.getClaimNumber(),
				claimDetailsRequest.getMemberNumber(),0);
		long endServiceRequestTime = System.currentTimeMillis();
		log.info("Completed the DB call. Query execution time for {} is {}",storedProcedure,
				endServiceRequestTime - startServiceRequestTime);
		log.debug("Details out {}", out);
		if (out.get(ClaimConstants.RETURN_STATUS).toString().equalsIgnoreCase("1.0000")) {
			log.info("Error occurred while executing the SP {}", out.get(ClaimConstants.RESULT_SET2));
			List<LinkedCaseInsensitiveMap<String>> errorCodeList = (List<LinkedCaseInsensitiveMap<String>>) out.get(ClaimConstants.RESULT_SET2);
			throw new SQLException(errorCodeList.get(0).get("ErrorMessage"));
		}
		claimDetailsList = (List<ClaimDetails>) out.get(ClaimConstants.RESULT);
		return claimDetailsList;
	}

	/**
	 * constructs new ClaimSearchDetails objects with claim lines and diagnosis list
	 *
	 * @param claimDetailsList
	 * @return
	 */
	private ClaimDetails getResults(List<ClaimDetails> claimDetailsList) {
		log.info("Inside getResults() in ClaimDetailsData class");
		ClaimDetails claimDetails = claimDetailsList.get(0);
		// find unique claim lines list
		claimDetails.setClaimLineDetailsList(getClaimLinesList(claimDetailsList));
		// find unique diagnosis list
		List<Diagnoses> diagnosesList = getDiagnosisList(claimDetailsList);
		if (!diagnosesList.isEmpty()) {
			claimDetails.setDiagnosesList(diagnosesList);
		}
		return claimDetails;
	}

	/**
	 * getDiagnosisList will provide unique diagnosisCode and sorted order
	 *
	 * @param claimDetailsList
	 * @return
	 */
	private List<Diagnoses> getDiagnosisList(List<ClaimDetails> claimDetailsList) {
		log.info("Inside getDiagnosisList() in ClaimDetailsData class");
		Set<Diagnoses> uniqueDiagnosis = new TreeSet<>();
		for (ClaimDetails cd : claimDetailsList) {
			if (!CollectionUtils.isEmpty(cd.getDiagnosesList()))
				uniqueDiagnosis.addAll(cd.getDiagnosesList());
		}
		return new ArrayList<>(uniqueDiagnosis);
	}

	/**
	 * getClaimLinesList will provide unique claimLineNumber and sorted order
	 *
	 * @param claimDetailsList
	 * @return
	 */
	private List<ClaimLineDetails> getClaimLinesList(List<ClaimDetails> claimDetailsList) {
		log.info("Inside getClaimLinesList() in ClaimDetailsData class");
		Set<ClaimLineDetails> uniqueLines = new TreeSet<>();
		for (ClaimDetails cd : claimDetailsList) {
			if (!CollectionUtils.isEmpty(cd.getClaimLineDetailsList())) {
				uniqueLines.addAll(cd.getClaimLineDetailsList());
			}
		}
		return new ArrayList<>(uniqueLines);
	}
}
