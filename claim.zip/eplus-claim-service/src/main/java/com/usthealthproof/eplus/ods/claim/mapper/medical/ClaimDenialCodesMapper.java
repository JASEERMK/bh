package com.usthealthproof.eplus.ods.claim.mapper.medical;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ods.claim.model.search.DenialCode;

@Component
public class ClaimDenialCodesMapper implements RowMapper<DenialCode> {

    @Override
    public DenialCode mapRow(ResultSet rs, int i) throws SQLException {

        var denialCode = new DenialCode();
        denialCode.setCode(rs.getString("adjudication_message_code"));
        denialCode.setDescription(rs.getString("adjudication_message_desc"));

        return denialCode;
    }
}
