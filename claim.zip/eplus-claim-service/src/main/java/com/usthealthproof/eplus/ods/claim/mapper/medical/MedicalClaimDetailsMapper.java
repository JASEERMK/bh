package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.mapper.util.APIUtils;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MedicalClaimDetailsMapper implements RowMapper<MedicalClaimDetails> {

	@Autowired
	private DateUtils dateUtils;
	@Autowired
	private APIUtils apiUtils;

	@Override
	public MedicalClaimDetails mapRow(ResultSet rs, int i) throws SQLException {


		var medicalClaimDetails = new MedicalClaimDetails();
		medicalClaimDetails.setMemberId(rs.getString("memberHccId"));
		medicalClaimDetails.setClaimHccId(rs.getString("claimHccId"));
		medicalClaimDetails.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		medicalClaimDetails.setServiceEndDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceEndDate")));
		medicalClaimDetails.setStatus(rs.getString("status"));
		medicalClaimDetails.setBilledAmount(rs.getString("billedAmount"));
		medicalClaimDetails.setClaimReceiptDate(dateUtils.getFormattedApplicationDate(rs.getString("claimReceiptDate")));
		medicalClaimDetails.setAdmissionDate(dateUtils.getFormattedApplicationDate(rs.getString("admissionDate")));
		medicalClaimDetails.setDischargeDate(dateUtils.getFormattedApplicationDate(rs.getString("dischargeDate")));
		medicalClaimDetails.setProcessTime(dateUtils.getFormattedApplicationDate(rs.getString("processtime")));
		medicalClaimDetails.setAllowedAmount(rs.getString("allowed_amount"));
		medicalClaimDetails.setPaidAmount(rs.getString("paid_amount"));
		medicalClaimDetails.setMemberResponsibility(rs.getString("member_responsibility"));
		medicalClaimDetails.setAmountDeductible(rs.getString("amount_deductible"));
		medicalClaimDetails.setCopayAmount(rs.getString("copay_amount"));
		medicalClaimDetails.setCoinsuranceAmount(rs.getString("coinsurance_amount"));
		medicalClaimDetails.setCreatedBy(rs.getString("created_by"));
		medicalClaimDetails.setModifiedBy(rs.getString("modified_by"));
		medicalClaimDetails.setIsAdjusted(rs.getString("is_adjusted"));
		medicalClaimDetails.setPayeeID(rs.getString("Payee_ID"));
		medicalClaimDetails.setPayeeName(rs.getString("Payee_Name"));
		medicalClaimDetails.setPayee(rs.getString("Payee"));
		medicalClaimDetails.setClaimPayer(rs.getString("Claim_Payor"));
		medicalClaimDetails.setDateEntered(dateUtils.getFormattedApplicationDate(rs.getString("Date_Entered")));
		medicalClaimDetails.setDeliveryType(rs.getString("Delivery_Type"));
		medicalClaimDetails.setExternalClaimID(rs.getString("External_ClaimID"));
		medicalClaimDetails.setPaymentDate(dateUtils.getFormattedApplicationDate(rs.getString("Payment_Date")));
		medicalClaimDetails.setTotalAmount(rs.getString("total_amount"));
		medicalClaimDetails.setPaymentNumber(rs.getString("Payment_Number"));
		medicalClaimDetails.setMemberPenalty(rs.getString("member_penalty"));
		medicalClaimDetails.setNonCoveredAmount(rs.getString("non_covered_amount"));
		medicalClaimDetails.setBonusAmount(rs.getString("bonus_amount"));
		medicalClaimDetails.setProviderPenalty(rs.getString("provider_penalty"));
		medicalClaimDetails.setProviderId(rs.getString("providerId"));
		medicalClaimDetails.setProviderName(rs.getString("providerName"));
		medicalClaimDetails.setTypeOfBill(rs.getString("type_of_bill"));
		medicalClaimDetails.setClaimType(rs.getString("claim_type"));
		medicalClaimDetails.setDiagnosisCodeDesc(rs.getString("diagnosisCode_desc"));
		medicalClaimDetails.setPrimaryDiagnosis(rs.getString("primarydiagnosis"));
		medicalClaimDetails.setSecondaryDiagnosis(rs.getString("secondarydiagnosis"));
		medicalClaimDetails.setPaymentStatus(rs.getString("payment_status"));
		medicalClaimDetails.setCobPaid(rs.getString("cob_paid"));
		medicalClaimDetails.setCobCoPay(rs.getString("cob_copay"));
		medicalClaimDetails.setCobCoInsurance(rs.getString("cob_coinsurance"));
		medicalClaimDetails.setCobDeductible(rs.getString("cob_deductible"));
		medicalClaimDetails.setCobBilled(rs.getString("cob_billed"));
		medicalClaimDetails.setCobAllowed(rs.getString("cob_allowed"));
		medicalClaimDetails.setCobDiscount(rs.getString("cob_discount"));
		medicalClaimDetails.setCobMemberPenalty(rs.getString("cob_member_penalty"));
		medicalClaimDetails.setCobMemberResponsibility(rs.getString("cob_member_responsibility"));
		medicalClaimDetails.setCobProviderPenalty(rs.getString("cob_provider_penalty"));
		medicalClaimDetails.setCobNonCovered(rs.getString("cob_noncovered"));
		medicalClaimDetails.setCobPerDayLimit(rs.getString("cob_per_daylimit"));
		medicalClaimDetails.setCobTax(rs.getString("cob_tax"));
		medicalClaimDetails.setCreatedBy(rs.getString("created_by"));
		medicalClaimDetails.setModifiedBy(rs.getString("modified_by"));
		medicalClaimDetails.setClaimNote(apiUtils.getClaimNotes(rs.getString("CLAIM_NOTE")));
		//		Added as part of Version2
		medicalClaimDetails.setClaimSource(rs.getString("claim_source_name"));
		medicalClaimDetails.setClearinghouseNo(rs.getString("clearing_house_trace_number"));
		medicalClaimDetails.setPatientAccountNo(rs.getString("patient_account_number"));
		medicalClaimDetails.setIsConverted(rs.getString("is_converted"));
		medicalClaimDetails.setIsRenewed(rs.getString("is_renewed"));
		medicalClaimDetails.setIsVoided(rs.getString("is_voided"));
		medicalClaimDetails.setMedicalRecordNo(rs.getString("medical_record_number"));
		medicalClaimDetails.setAdmissionType(rs.getString("admit_type_name"));
		medicalClaimDetails.setAdmissionSource(rs.getString("admit_source_name"));
		medicalClaimDetails.setSupplierTaxId(rs.getString("supplier_tax_id"));
		medicalClaimDetails.setSupplierNpi(rs.getString("supplier_npi"));
		medicalClaimDetails.setRenderingLocationId(rs.getString("supplier_location_hcc_id"));
		medicalClaimDetails.setRenderingLocationName(rs.getString("supplier_location_name"));
		medicalClaimDetails.setRenderingLocationNpi(rs.getString("supplier_location_npi"));
		medicalClaimDetails.setRenderingProviderAddress(rs.getString("provider_address"));
		medicalClaimDetails.setBalanceBilledAmount(rs.getString("balance_billed_amount"));
		medicalClaimDetails.setBulkCheckAmount(rs.getString("bulk_check_amount"));
		medicalClaimDetails.setClearedCheckDate(rs.getString("cleared_check_date"));
		//		Added as part of v23.1 - CPB-2711
		medicalClaimDetails.setFrequencyCode(rs.getString("frequency_code"));
		medicalClaimDetails.setReferringPhysician(rs.getString("referring_practitioner_hcc_id"));
		medicalClaimDetails.setReferringPhysicianNpi(rs.getString("practitioner_npi"));
		medicalClaimDetails.setTransactionNumber(rs.getString("transaction_no"));

		// Added as part of cpb3134
		medicalClaimDetails.setMemberName(rs.getString("MemberName"));
		// Added as part of CPB-3167
		medicalClaimDetails.setClaimFactKey(rs.getString("claim_fact_key"));
		// Added as part of cpb-4203
		medicalClaimDetails.setSubmittedDrgCodeAndDesc(rs.getString("Submtd_DRG_Code_Desc"));
		medicalClaimDetails.setAprDrgCodeAndDesc(rs.getString("APR_Code_Description"));
		medicalClaimDetails.setIllnessCodeAndDesc(rs.getString("Severity_of_Illness_Code_Desc"));
//		Added as part of CPB-4404
		medicalClaimDetails.setSccfNo(rs.getString("BlueCard_SCCF_No"));
		// Added as part of API-19
		medicalClaimDetails.setCheckNumber(rs.getString("external_payment_id"));
		// Added as part of API-358
		medicalClaimDetails.setProviderSpeciality(rs.getString("Provider_Speciality"));
		// Added as part of API-1729
		medicalClaimDetails.setReferringPhysicianName(rs.getString("referring_practitioner_name"));
		return medicalClaimDetails;
	}

}