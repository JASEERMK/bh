package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class VisionClaimDetailsData {


	@Autowired
	private VisionClaimDetailsMapper visionClaimDetailsMapper;
	@Value("${claims.spVisionClaimDetails}")
	private String spVisionClaimDetails;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public VisionClaimDetails findVisionClaimId(String claimHccId, String state, String lob, String product) {
		log.info("Inside findVisionClaimId() in VisionClaimDetailsData class");

		VisionClaimDetails visionClaimDetails;
		try {
			MapSqlParameterSource visionClaimDetailsParams = new MapSqlParameterSource().addValue("claimId",
							claimHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String visionClaimDetailSql = "{CALL " + spVisionClaimDetails
					+ "(:claimId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			visionClaimDetails = namedParameterJdbcTemplate.queryForObject(visionClaimDetailSql, visionClaimDetailsParams,
					visionClaimDetailsMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spVisionClaimDetails,
			                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", visionClaimDetails);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "VisionClaimDetails");
			throw jdbcException;
		} catch (EmptyResultDataAccessException emptyResultException) {
			log.error("EmptyResultDataAccessException occurred for the VisionClaimDetails service request and the exception is: ",
					emptyResultException);
			throw new ClaimNotFoundException(ClaimConstants.VISION_CLAIM_DETAILS_NOT_FOUND + claimHccId);
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + "VisionClaimDetails");
			throw ex;
		}
		log.info("VisionClaimDetails data fetched successfully.");
		return visionClaimDetails;
	}

}
