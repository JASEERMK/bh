package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Repository
@Slf4j
public class MedicalClaimDetailsData {

    @Autowired
    private AsyncExecutorUtils asyncExecutorUtils;

    /**
     * get the claims details
     *
     * @param claimHccId
     * @param claimFactKey
     * @param state
     * @param lob
     * @param product
     * @return
     * @throws Exception
     */
    public MedicalClaimDetails findClaimId(String claimHccId, String claimFactKey, String state, String lob, String product) throws Exception {
        log.info("Inside findClaimId() in MedicalClaimDetailsData class");

        MedicalClaimDetails medicalClaimDetails = null;
        CompletableFuture<MedicalClaimDetails> claimDetailsCompletableFuture = null;
        try {
            CompletableFuture<List<String>> claimFactKeysCompletableFuture = asyncExecutorUtils.getClaimFactKeys(claimHccId);

            log.info("Going for ClaimDetails DB call");
            if (StringUtils.isNotBlank(claimFactKey)) {
                claimDetailsCompletableFuture = asyncExecutorUtils.getMedicalClaimDetailsWithFactKey(claimHccId, claimFactKey, state, lob, product);
            } else {
                claimDetailsCompletableFuture = asyncExecutorUtils.getMedicalClaimDetailsWithoutFactKey(claimHccId, state, lob, product);
            }
            if (claimDetailsCompletableFuture != null && claimDetailsCompletableFuture.get() != null) {
                medicalClaimDetails = claimDetailsCompletableFuture.get();
            }
            if (medicalClaimDetails != null && claimFactKeysCompletableFuture != null && claimFactKeysCompletableFuture.get() != null) {
                medicalClaimDetails.setClaimFactKeys(claimFactKeysCompletableFuture.get());
            } else {
                throw new ClaimNotFoundException(ClaimConstants.CLAIM_DETAILS_NOT_FOUND + claimHccId);
            }
            log.debug("Response from DB: {}", medicalClaimDetails);
        } catch (ExecutionException executionException) {
            log.error("ExecutionException occurred : ", executionException);
            if (executionException.getCause() instanceof EmptyResultDataAccessException) {
                log.error("EmptyResultDataAccessException occurred for the MedicalClaimDetails service request.");
                throw new ClaimNotFoundException(
                        ClaimConstants.CLAIM_DETAILS_NOT_FOUND + claimHccId);
            } else {
                log.error("ExecutionException other than EmptyResultDataAccessException occurred.");
                throw new Exception();
            }
        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "MedicalClaimDetails");
            throw jdbcException;
        } catch (EmptyResultDataAccessException emptyResultException) {
            log.error("EmptyResultDataAccessException occurred for the MedicalClaimDetails service request and the exception is: ",
                    emptyResultException);
            throw new ClaimNotFoundException(ClaimConstants.CLAIM_DETAILS_NOT_FOUND + claimHccId);
        } catch (ClaimNotFoundException claimNotFoundException) {
            log.error("ClaimNotFoundException occurred for the getClaimFactKeys service request");
            throw claimNotFoundException;
		} catch (Exception ex) {
            log.error(ClaimConstants.EXCEPTION_MESSAGE + "MedicalClaimDetails");
            throw ex;
        }
        log.info("MedicalClaimDetails data fetched successfully.");
        return medicalClaimDetails;
    }
}