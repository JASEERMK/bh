package com.usthealthproof.eplus.ods.claim.repository.denialcode;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimDenialCodesMapper;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCode;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

@Repository
@Slf4j
public class DenialCodeSearchData {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @Autowired
    private ClaimDenialCodesMapper claimDenialCodesMapper;
    @Value("${claims.spGetClaimDenialCodeDesc}")
    private String spGetClaimDenialCodeDesc;


    public DenialCodes getDenialCodes(String claimHccId,String state,String lob,String product) {
        log.info("Inside claim getDenialCodes Repo()");
        DenialCodes denialCodes = new DenialCodes();
        List<DenialCode> denialcodeList = new ArrayList<>();

        try {
            String claimDenialCodeSql =
                    "{CALL " + spGetClaimDenialCodeDesc + "(:claimHccId, :product, :lob, :state, :returnStatus)}";
            MapSqlParameterSource claimDenialCodeParams = new MapSqlParameterSource()
                    .addValue("claimHccId", claimHccId, Types.VARCHAR)
                    .addValue("product", product, Types.VARCHAR)
                    .addValue("lob", lob, Types.VARCHAR)
                    .addValue("state", state, Types.VARCHAR)
                    .addValue("returnStatus", 0, Types.NUMERIC);
            log.info("Going for DB call");
            long startServiceRequestTime = System.currentTimeMillis();
            denialcodeList = namedParameterJdbcTemplate.query(claimDenialCodeSql, claimDenialCodeParams, claimDenialCodesMapper);
            long endServiceRequestTime = System.currentTimeMillis();
            log.info("Completed the DB call. Query execution time for {} is {}", spGetClaimDenialCodeDesc, endServiceRequestTime - startServiceRequestTime);

        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error("CannotGetJdbcConnectionException occurred: ", jdbcException);
            throw jdbcException;
        }

        if (CollectionUtils.isEmpty(denialcodeList)) {
            throw new ClaimNotFoundException(ClaimHeaderSearchConstants.NO_DATA_FOUND);
        } else {
            denialCodes.setDenialCodes(denialcodeList);
            denialCodes.setClaimId(claimHccId);
        }

        return denialCodes;
    }

}
