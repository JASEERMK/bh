package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.search.MemberClaimSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.List;

@Repository
@Slf4j
public class MemberClaimSearchData {

	@Autowired
	private MemberClaimSearchMapper claimSearchMapper;
	@Value("${claims.spMedicalMemberClaimSearch}")
	private String spMedicalMemberClaimSearch;
	@Value("${claims.spDentalMemberClaimSearch}")
	private String spDentalMemberClaimSearch;
	@Value("${claims.spVisionMemberClaimSearch}")
	private String spVisionMemberClaimSearch;
	@Value("${claims.spRxMemberClaimSearch}")
	private String spRxMemberClaimSearch;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


	private static final String MEMBER_CLAIM_SEARCH = "MemberClaimSearch";

	/**
	 * Method to get MemberClaimSearchData details
	 *
	 * @param claimHeaderSearchRequest
	 * @param claimHeaderSearchResponse
	 * @return
	 */

	public ClaimHeaderSearchResponse getClaimHeaderDetails(ClaimHeaderSearchRequest claimHeaderSearchRequest,
			ClaimHeaderSearchResponse claimHeaderSearchResponse) {
		log.info("Inside member getClaimHeaderDetails() in MemberClaimSearchData class");

        try {
			String claimType = claimHeaderSearchRequest.getClaimTypes();
			String memberClaimSearchSql;
			claimSearchMapper.claimType = claimType;
			String memberClaimSearchSp=getSPNameBasedOnClaimType(claimType);

			MapSqlParameterSource memberClaimSearchParams = new MapSqlParameterSource().addValue("claimNumber",
							claimHeaderSearchRequest.getClaimNumber(), Types.VARCHAR)
					.addValue("memberNumber", claimHeaderSearchRequest.getMemberNumber(), Types.VARCHAR)
					.addValue("serviceFromDate", claimHeaderSearchRequest.getServiceFromDate(), Types.VARCHAR)
					.addValue("serviceToDate", claimHeaderSearchRequest.getServiceToDate(), Types.VARCHAR)
					.addValue("claimStatus", claimHeaderSearchRequest.getClaimStatus(), Types.VARCHAR)
					.addValue("product", claimHeaderSearchRequest.getProduct(), Types.VARCHAR)
					.addValue("lob", claimHeaderSearchRequest.getLob(), Types.VARCHAR)
					.addValue("state", claimHeaderSearchRequest.getState(), Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);



			if(ClaimHeaderSearchConstants.MEDICAL.equalsIgnoreCase(claimType))
			{
				memberClaimSearchSql=	"{CALL " + memberClaimSearchSp
						+ "(:claimNumber, :memberNumber, :serviceFromDate, :serviceToDate, :claimStatus, :diagnosisCode, :serviceCode, :state, :lob, :product, :returnStatus)}";
				memberClaimSearchParams.addValue("serviceCode", claimHeaderSearchRequest.getServiceCode(), Types.VARCHAR)
						.addValue("diagnosisCode", claimHeaderSearchRequest.getDiagnosisCode(), Types.VARCHAR);

			}
			else {
				memberClaimSearchSql = "{CALL " + memberClaimSearchSp
						+ "(:claimNumber, :memberNumber, :serviceFromDate, :serviceToDate, :claimStatus, :state, :lob, :product, :returnStatus)}";
			}

			log.info("Going for DB call ");
			long startServiceRequestTime = System.currentTimeMillis();
            List<ClaimSearchModel> claimSearchModelList = namedParameterJdbcTemplate.query(memberClaimSearchSql, memberClaimSearchParams,
                    claimSearchMapper);
            long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call . Query execution time for {} is {}", memberClaimSearchSp,
					endServiceRequestTime - startServiceRequestTime);
			if(claimSearchModelList.isEmpty())
			{
				throw new ClaimNotFoundException(ClaimHeaderSearchConstants.NO_DATA_FOUND);
			} else {
			claimHeaderSearchResponse.setResults(claimSearchModelList);
		    }

		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + MEMBER_CLAIM_SEARCH);
			throw jdbcException;
		} catch (ClaimNotFoundException claimNotFoundException) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + MEMBER_CLAIM_SEARCH);
			throw claimNotFoundException;
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + MEMBER_CLAIM_SEARCH);
			throw ex;
		}
		log.info("MemberClaimSearch data fetched successfully");
		return claimHeaderSearchResponse;
	}


	private String getSPNameBasedOnClaimType(String claimType) {
		log.info("Inside getSPNameBasedOnClaimType() in MemberClaimSearchData class");

		if (StringUtils.equalsIgnoreCase(ClaimHeaderSearchConstants.MEDICAL,claimType)) {
			return spMedicalMemberClaimSearch;
		} else if (StringUtils.equalsIgnoreCase(ClaimHeaderSearchConstants.DENTAL,claimType)) {
			return spDentalMemberClaimSearch;
		} else if (StringUtils.equalsIgnoreCase(ClaimHeaderSearchConstants.VISION,claimType)) {
			return spVisionMemberClaimSearch;
		} else if (StringUtils.equalsIgnoreCase(ClaimHeaderSearchConstants.RX,claimType)) {
			return spRxMemberClaimSearch;
		}
		return null;
	}

}
