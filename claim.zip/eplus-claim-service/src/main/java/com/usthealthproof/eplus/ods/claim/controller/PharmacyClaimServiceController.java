package com.usthealthproof.eplus.ods.claim.controller;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Pharmacy Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class PharmacyClaimServiceController {

	@Autowired
	private ClaimServices claimServices;
	@Autowired
	private Validator validator;

	/**
	 * get Rx claim details
	 *
	 * @param claimHccId
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */

	@GetMapping(value = "/rx", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Pharmacy Claim Details", description = "Details regarding Pharmacy claims can be accessed through the specified service. Claim HCC ID is the only request field; thus, it must be supplied as a request", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Pharmacy claim details of the particular claim", content = {
					@Content(schema = @Schema(implementation = RxClaimDetails.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<RxClaimDetails> getRxClaimDetails(
			@Parameter(description = "Pharmacy Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){

		log.info("Inside getRxClaimDetails() in PharmacyClaimServiceController class");
		log.debug("Rx claim detail service request received with claimHccId= {}", claimHccId);
		validator.validateRequestField(claimHccId);
		return new ResponseEntity<>(claimServices.findRxClaimId(claimHccId, state, lob, product), HttpStatus.OK);
	}

}
