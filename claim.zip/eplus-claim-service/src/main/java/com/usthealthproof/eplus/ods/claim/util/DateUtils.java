package com.usthealthproof.eplus.ods.claim.util;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class DateUtils {

	@Value("${claims.applicationDateFormat}")
	private String applicationDateFormat;
	@Value("${claims.clientDateFormat}")
	private String clientDateFormat;

	/**
	 * convert the date format
	 * 
	 * @param applicationDate
	 * @return
	 */
	public String getFormattedApplicationDate(String applicationDate) {
		if (StringUtils.isNotBlank(applicationDate)) {
			return LocalDate.parse(applicationDate, DateTimeFormatter.ofPattern(ClaimConstants.DATE_FORMAT))
					.format(DateTimeFormatter.ofPattern(applicationDateFormat));
		}

		return null;
	}

	public String getFormattedClientDate(String clientDate) {
		if (StringUtils.isNotBlank(clientDate)) {
			return LocalDate.parse(clientDate, DateTimeFormatter.ofPattern(ClaimConstants.DATE_FORMAT))
					.format(DateTimeFormatter.ofPattern(clientDateFormat));
		}

		return null;
	}
}
