package com.usthealthproof.eplus.ods.claim.model.portal.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim search request details")
public class ClaimSearchRequest implements Serializable {

	private static final long serialVersionUID = 5762506219668204770L;

	@Schema(description = "Claim types")
	@JsonProperty("claimTypes")
	@Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Claim types is not in valid format")
	private String claimTypes;

	@Schema(description = "Claim number")
	@JsonProperty("claimNumber")
	@Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Claim number is not in valid format")
	private String claimNumber;

	@Schema(description = "Service start date")
	@JsonProperty("serviceFromDate")
	@Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: Service start date is not in valid format")
	private String serviceFromDate;

	@Schema(description = "Service end date")
	@JsonProperty("serviceToDate")
	@Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: Service end date is not in valid format")
	private String serviceToDate;

	@Schema(description = "Member number")
	@JsonProperty("memberNumber")
	@Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: Member number is not in valid format")
	private String memberNumber;

	@Schema(description = "Member IDs List", hidden = true)
	private List<String> memberIds;

	@Schema(description = "Header details")
	@JsonProperty("userIdentities")
	@Pattern(regexp = "^[^<>]*$", message = "Invalid Request: userIdentities is not in valid format")
	private String userIdentities;

	@Schema(description = "Medical Groups to be Excluded", hidden = true)
	private List<String> excludedMedicalGroups;
	@Schema(description = "Medical Groups to be Included", hidden = true)
	private List<String> includedMedicalGroups;
	@Schema(description = "Provider to be Excluded", hidden = true)
	private List<String> excludedProvider;
	@Schema(description = "Provider to be Included", hidden = true)
	private List<String> includedProvider;

}
