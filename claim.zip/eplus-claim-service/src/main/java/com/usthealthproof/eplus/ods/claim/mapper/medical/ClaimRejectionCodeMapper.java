package com.usthealthproof.eplus.ods.claim.mapper.medical;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;

@Component
public class ClaimRejectionCodeMapper implements RowMapper<ClaimRejectionDetails> {

	@Override
	public ClaimRejectionDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		var claimRejectionDetails = new ClaimRejectionDetails();
		claimRejectionDetails.setRejectionCodeDesc(rs.getString("Reject_reason"));
		claimRejectionDetails.setClaimLineNumber(rs.getString("claim_line_hcc_id"));
		return claimRejectionDetails;
	}
}
