package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Wrapper class containing medical external message details")
public class MedicalExternalMessagesResponse implements Serializable {

	private static final long serialVersionUID = 4536139842098851701L;
	@JsonProperty("externalMessages")
	private List<MedicalExternalMessage> externalMessages;
}
