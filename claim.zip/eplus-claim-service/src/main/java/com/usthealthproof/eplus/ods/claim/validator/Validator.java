package com.usthealthproof.eplus.ods.claim.validator;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.RequestValidationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

import static org.apache.commons.lang3.StringUtils.isAnyBlank;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
@Slf4j
public class Validator {

    @Value("${claims.clientDateFormat}")
    private String clientDateFormat;
    @Value("${claims.providerClaimsDateRangeLimit}")
    private String providerClaimsDateRangeLimit;
    @Value("${claims.memberClaimsDateRangeLimit}")
    private String memberClaimsDateRangeLimit;

    /**
     * Validation method for Member claim search requests
     *
     * @param claimTypes
     * @param serviceFromDate
     * @param serviceToDate
     * @param memberNumber
     * @param claimStatus
     * @param claimNumber
     */
    public void validateMemberSearchRequest(String claimTypes, String serviceFromDate, String serviceToDate, String memberNumber,
                                            String claimStatus, String claimNumber) {
        if (StringUtils.isBlank(claimTypes)) {
            log.error(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND);
        } else if (!ClaimHeaderSearchConstants.CLAIM_TYPES.contains(claimTypes.toLowerCase())) {
            log.error(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND);
        }

        validateRequestServiceDates(serviceFromDate, serviceToDate);
        validateDateRange(serviceFromDate, serviceToDate, memberClaimsDateRangeLimit);

        if (StringUtils.isBlank(claimNumber) && StringUtils.isAnyBlank(memberNumber, serviceFromDate, serviceToDate, claimStatus)) {
            throw new RequestValidationException(ClaimHeaderSearchConstants.MANDATORY_MISSING);
        }
    }

    /**
     * Validation method for Provider claim search requests
     *
     * @param claimTypes
     * @param serviceFromDate
     * @param serviceToDate
     * @param claimNumber
     * @param providerId
     * @param providerType
     */
    public void validateProviderSearchRequest(String claimTypes, String serviceFromDate, String serviceToDate, String claimNumber,
                                              String providerId, String providerType) {
        if (StringUtils.isBlank(claimTypes)) {
            log.error(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND);
        } else if (!StringUtils.equalsIgnoreCase("MEDICAL", claimTypes)) {
            log.error(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND);
        }
        validateProviderIdAndTypeDependency(providerId, providerType);
        validateRequestServiceDates(serviceFromDate, serviceToDate);
        validateDateRange(serviceFromDate, serviceToDate, providerClaimsDateRangeLimit);

        if (StringUtils.isBlank(claimNumber)){
            providerIdConditionalMandatoryCheck(providerId);
            ProviderTypeConditionalMandatoryCheck(providerType);
            serviceDatesConditionalMandatoryCheck(serviceFromDate, serviceToDate);

        }
    }
    private void validateProviderIdAndTypeDependency(String providerId, String providerType) {
        if(StringUtils.isBlank(providerId) && StringUtils.isNotBlank(providerType)){
            throw new RequestValidationException(ClaimHeaderSearchConstants.PROVIDER_ID_NOT_FOUND);
        }
        if(StringUtils.isBlank(providerType) && StringUtils.isNotBlank(providerId)){
            throw new RequestValidationException(ClaimHeaderSearchConstants.PROVIDER_TYPE_NOT_FOUND);
        }
        if (StringUtils.isNotBlank(providerType)) {
            isProviderTypeInvalid(providerType);
        }
    }
    private void serviceDatesConditionalMandatoryCheck(String serviceFromDate, String serviceToDate) {
        if(StringUtils.isAnyBlank(serviceFromDate, serviceToDate)){
            throw new RequestValidationException(ClaimHeaderSearchConstants.SERVICE_DATES_REQUIRED);
        }
    }

    public void providerIdConditionalMandatoryCheck(String providerId) {
        log.info("Inside providerIdConditionalMandatoryCheck()");

        if (StringUtils.isBlank(providerId)) {
            log.error(ClaimHeaderSearchConstants.PROVIDER_ID_NOT_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.PROVIDER_ID_NOT_FOUND);
        }
    }

    public void ProviderTypeConditionalMandatoryCheck(String providerType) {
        log.info("Inside ProviderTypeConditionalMandatoryCheck()");

        if (StringUtils.isBlank(providerType)) {
            log.error(ClaimHeaderSearchConstants.PROVIDER_TYPE_NOT_FOUND);
            throw new RequestValidationException(ClaimHeaderSearchConstants.PROVIDER_TYPE_NOT_FOUND);
        }
    }


    /**
     * Request level validation for medical, vision & dental and rxClaim services
     *
     * @param claimHccId
     */
    public void validateRequestField(String claimHccId) {
        log.info("Inside validateRequestField() in Validator class");

        if (isBlank(claimHccId)) {
            log.info("Invalid request ie. claimHccId is empty/null/blank");
            throw new RequestValidationException(ClaimConstants.CLAIM_ID_NOT_FOUND);
        }
    }

    /**
     * Request level validation for medical, vision & dental claim Line detail
     * services
     *
     * @param claimHccId
     * @param claimLineHccId
     */
    public void validateRequestField(String claimHccId, String claimLineHccId) {
        log.info("Inside validateRequestField() in Validator class having claimLineHccId also");

        if (isAnyBlank(claimHccId, claimLineHccId)) {
            log.info("Invalid request ie. either claimHccId or claimLineHccId is empty/null/blank");
            throw new RequestValidationException(ClaimConstants.CLAIM_LINE_ID_NOT_FOUND);
        }
    }

    public void isProviderTypeInvalid(String providerType) {
        log.info("Inside isProviderTypeInvalid() in Validator class");

        if (!ClaimHeaderSearchConstants.PROVIDER_TYPES.contains(providerType.toLowerCase())) {
            log.error(ClaimHeaderSearchConstants.PROVIDER_TYPE_INVALID);
            throw new RequestValidationException(ClaimHeaderSearchConstants.PROVIDER_TYPE_INVALID);
        }
    }

    /**
     * Method to validate request service dates
     *
     * @param serviceFromDate
     * @param serviceToDate
     */
    public void validateRequestServiceDates(String serviceFromDate, String serviceToDate) {
        log.info("Inside validateRequestServiceDates() in Validator class");


        if (StringUtils.isNotBlank(serviceFromDate)) {
            if (isBlank(serviceToDate)) {
                log.info(ClaimHeaderSearchConstants.LOG_ERROR_MSG_SERVICE_TO_DATE);
                throw new RequestValidationException(ClaimHeaderSearchConstants.SEARCH_SERVICE_TO_DATE_REQUIRED);
            }
            validateDateFormat(ClaimHeaderSearchConstants.SERVICE_FROM_DATE, serviceFromDate);

        }
        if (StringUtils.isNotBlank(serviceToDate)) {
            if (isBlank(serviceFromDate)) {
                log.info(ClaimHeaderSearchConstants.LOG_ERROR_MSG_SERVICE_FROM_DATE);
                throw new RequestValidationException(ClaimHeaderSearchConstants.SEARCH_SERVICE_FROM_DATE_REQUIRED);
            }
            validateDateFormat(ClaimHeaderSearchConstants.SERVICE_TO_DATE, serviceToDate);

        }


    }

    /**
     * Validate date format
     *
     * @param errorMessage
     * @param date
     */
    public void validateDateFormat(String errorMessage, String date) {
        log.info("Inside validateDateFormat() in Validator class");

        try {
            var dateFormatter = DateTimeFormatter.ofPattern(clientDateFormat);
            LocalDate.parse(date, dateFormatter);

        } catch (DateTimeParseException e) {
            log.error(errorMessage);
            throw new RequestValidationException(errorMessage);
        }
    }

    /**
     * validate date range
     *
     * @param serviceFromDate
     * @param serviceToDate
     * @param dateRangeLimit
     */
    public void validateDateRange(String serviceFromDate, String serviceToDate, String dateRangeLimit) {

        var dateFormatter = DateTimeFormatter.ofPattern(clientDateFormat);
        if (!StringUtils.isAnyBlank(serviceFromDate, serviceToDate)) {
            LocalDate fromDate = LocalDate.parse(serviceFromDate, dateFormatter);
            LocalDate toDate = LocalDate.parse(serviceToDate, dateFormatter);
            if (StringUtils.containsIgnoreCase(dateRangeLimit, "day")) {
                int daysLimit = Integer.parseInt(dateRangeLimit.replaceAll("\\D+", ""));
                LocalDate maxAllowedEndDate = fromDate.plusDays(daysLimit);
                if (toDate.isAfter(maxAllowedEndDate)) {
                    log.error(ClaimHeaderSearchConstants.LOG_ERROR_MSG_DATE_RANGE, dateRangeLimit);
                    throw new RequestValidationException(String.format(ClaimHeaderSearchConstants.DATE_RANGE_EXCEEDS_LIMIT, dateRangeLimit));
                }
            } else if (StringUtils.containsIgnoreCase(dateRangeLimit, "month")) {
                int monthsLimit = Integer.parseInt(dateRangeLimit.replaceAll("\\D+", ""));
                LocalDate maxAllowedEndDate = fromDate.plusMonths(monthsLimit);
                if (toDate.isAfter(maxAllowedEndDate)) {
                    log.error(ClaimHeaderSearchConstants.LOG_ERROR_MSG_DATE_RANGE, dateRangeLimit);
                    throw new RequestValidationException(String.format(ClaimHeaderSearchConstants.DATE_RANGE_EXCEEDS_LIMIT, dateRangeLimit));
                }
            }
            else {
                throw new RequestValidationException(ClaimHeaderSearchConstants.DATE_RANGE_LIMIT_NOT_CONFIGURED);
            }

        }
    }

}
