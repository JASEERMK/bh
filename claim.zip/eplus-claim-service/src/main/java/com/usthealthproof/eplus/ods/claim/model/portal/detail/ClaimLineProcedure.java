package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim Line level details")
public class ClaimLineProcedure implements Serializable {

	private static final long serialVersionUID = -5832358739639718772L;

	@Schema(description = "Identification code for the procedure performed")
	@JsonProperty("procedureCode")
	private String procedureCode;

	@Schema(description = "Procedure description")
	@JsonProperty("procedureDescription")
	private String procedureDescription;

}
