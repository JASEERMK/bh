package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalExternalMessageDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.Types;
import java.util.List;

@Repository
@Slf4j
public class MedicalExternalMessageDetailsData {

	@Autowired
	private MedicalExternalMessageDetailsMapper medicalExternalMessageDetailsMapper;
	@Value("${claims.spExternalMessageDetails}")
	private String spExternalMessageDetails;
	@Value("${claims.spExternalMessageDetailsVersion}")
	private String spExternalMessageDetailsVersion;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final String EXTERNAL_MESSAGE_DETAILS = "ExternalMessageDetails";

	public List<MedicalExternalMessage> getExternalMessageDetails(String claimHccId, String claimLineHccId, String claimFactKey, String state, String lob, String product) {
		log.info("Inside getExternalMessageDetails() in MedicalExternalMessageDetailsData class");

		List<MedicalExternalMessage> medicalExternalMessages = null;
		try {
			log.info("Going for DB call");
			if (StringUtils.isBlank(claimFactKey)) {
				String claimSql = "{CALL " + spExternalMessageDetails + "(:claimHccId, :claimLineHccId, :state, :lob, :product, :returnStatus)}";
				MapSqlParameterSource claimParameters = new MapSqlParameterSource()
						.addValue("claimHccId", claimHccId, Types.VARCHAR)
						.addValue("claimLineHccId", claimLineHccId, Types.VARCHAR)
						.addValue("state", state, Types.VARCHAR)
						.addValue("lob", lob, Types.VARCHAR)
						.addValue("product", product, Types.VARCHAR)
						.addValue("returnStatus", 0, Types.NUMERIC);

				long startServiceRequestTime = System.currentTimeMillis();
				medicalExternalMessages = namedParameterJdbcTemplate.query(claimSql, claimParameters, medicalExternalMessageDetailsMapper);
				long endServiceRequestTime = System.currentTimeMillis();
				log.info("Completed the DB call. Query execution time for {} is {}", spExternalMessageDetails, endServiceRequestTime - startServiceRequestTime);
			} else {
				String claimSql = "{CALL " + spExternalMessageDetailsVersion + "(:claimHccId, :claimLineHccId, :claimFactKey, :state, :lob, :product, :returnStatus)}";
				MapSqlParameterSource claimParameters = new MapSqlParameterSource()
						.addValue("claimHccId", claimHccId, Types.VARCHAR)
						.addValue("claimLineHccId", claimLineHccId, Types.VARCHAR)
						.addValue("claimFactKey", claimFactKey, Types.VARCHAR)
						.addValue("state", state, Types.VARCHAR)
						.addValue("lob", lob, Types.VARCHAR)
						.addValue("product", product, Types.VARCHAR)
						.addValue("returnStatus", 0, Types.NUMERIC);

				long startServiceRequestTime = System.currentTimeMillis();
				medicalExternalMessages = namedParameterJdbcTemplate.query(claimSql, claimParameters, medicalExternalMessageDetailsMapper);
				long endServiceRequestTime = System.currentTimeMillis();
				log.info("Completed the DB call. Query execution time for {} is {}", spExternalMessageDetailsVersion, endServiceRequestTime - startServiceRequestTime);
			}
			log.debug("Response from DB {}", medicalExternalMessages);
			if (CollectionUtils.isEmpty(medicalExternalMessages)) {
				throw new ClaimNotFoundException(ClaimConstants.NO_EXTERNAL_MESSGAES_FOUND);
			}
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + EXTERNAL_MESSAGE_DETAILS);
			throw jdbcException;
		} catch (ClaimNotFoundException claimNotFoundException) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + EXTERNAL_MESSAGE_DETAILS);
			throw claimNotFoundException;
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + EXTERNAL_MESSAGE_DETAILS);
			throw ex;
		}
		log.info("ExternalMessageDetails data fetched successfully.");
		return medicalExternalMessages;
	}
}
