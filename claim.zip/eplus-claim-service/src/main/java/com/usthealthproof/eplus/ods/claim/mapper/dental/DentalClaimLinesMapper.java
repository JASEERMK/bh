package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class DentalClaimLinesMapper implements RowMapper<DentalClaimLines> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public DentalClaimLines mapRow(ResultSet rs, int i) throws SQLException {

		var dentalClaimLines = new DentalClaimLines();
		dentalClaimLines.setClaimLineNumber(rs.getString("claimlinenumber"));
		dentalClaimLines.setClaimHccId(rs.getString("claimhccid"));
		dentalClaimLines.setServiceCodeDescription(rs.getString("Codedescription"));
		dentalClaimLines.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("service_start_date")));
		dentalClaimLines.setStatus(rs.getString("status"));

		return dentalClaimLines;
	}

}
