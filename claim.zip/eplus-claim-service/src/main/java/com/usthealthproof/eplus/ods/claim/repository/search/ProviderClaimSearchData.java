package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.exception.RequestValidationException;
import com.usthealthproof.eplus.ods.claim.mapper.search.ProviderClaimSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class ProviderClaimSearchData {

	@Autowired
	private ProviderClaimSearchMapper claimSearchMapper;
	@Value("${claims.spMedicalProviderClaimSearch}")
	private String spMedicalProviderClaimSearch;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final String PROVIDER_CLAIM_SEARCH = "ProviderClaimSearch";

	/**
	 * Method to get ProviderClaimsearchData details
	 * 
	 * @param claimHeaderSearchRequest
	 * @param claimHeaderSearchResponse
	 * @return
	 */

	public ClaimHeaderSearchResponse getClaimHeaderDetails(ClaimHeaderSearchRequest claimHeaderSearchRequest,
			ClaimHeaderSearchResponse claimHeaderSearchResponse) {
		log.info("Inside provider getClaimHeaderDetails() in ProviderClaimSearchData class");

		List<ClaimSearchModel> claimSearchModelList = new ArrayList<>();
		try {
			String claimType = claimHeaderSearchRequest.getClaimTypes();
			String providerClaimSP = getQuery(claimType);
			String providerClaimSearchSql = "{CALL " + providerClaimSP
					+ "(:claimNumber, :providerId, :providerType, :memberNumber, :claimStatus, :serviceFromDate, :serviceToDate, :serviceCode, :diagnosisCode, :product, :lob, :state, :returnStatus)}";

			MapSqlParameterSource providerClaimSearchParams = new MapSqlParameterSource().addValue("claimNumber",
							claimHeaderSearchRequest.getClaimNumber(), Types.VARCHAR)
					.addValue("providerId", claimHeaderSearchRequest.getProviderId(), Types.VARCHAR)
					.addValue("providerType", claimHeaderSearchRequest.getProviderIdType(), Types.VARCHAR)
					.addValue("memberNumber", claimHeaderSearchRequest.getMemberNumber(), Types.VARCHAR)
					.addValue("claimStatus", claimHeaderSearchRequest.getClaimStatus(), Types.VARCHAR)
					.addValue("serviceFromDate", claimHeaderSearchRequest.getServiceFromDate(), Types.VARCHAR)
					.addValue("serviceToDate", claimHeaderSearchRequest.getServiceToDate(), Types.VARCHAR)
					.addValue("serviceCode", claimHeaderSearchRequest.getServiceCode(), Types.VARCHAR)
					.addValue("diagnosisCode", claimHeaderSearchRequest.getDiagnosisCode(), Types.VARCHAR)
					.addValue("product", claimHeaderSearchRequest.getProduct(), Types.VARCHAR)
					.addValue("lob", claimHeaderSearchRequest.getLob(), Types.VARCHAR)
					.addValue("state", claimHeaderSearchRequest.getState(), Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			claimSearchModelList = namedParameterJdbcTemplate.query(providerClaimSearchSql, providerClaimSearchParams,
					claimSearchMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", providerClaimSP,
					endServiceRequestTime - startServiceRequestTime);
			if (claimSearchModelList.isEmpty()) {
				throw new ClaimNotFoundException(ClaimHeaderSearchConstants.NO_DATA_FOUND);
			} else {
				claimHeaderSearchResponse.setResults(claimSearchModelList);
			}
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + PROVIDER_CLAIM_SEARCH);
			throw jdbcException;
		} catch (ClaimNotFoundException claimNotFoundException) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + PROVIDER_CLAIM_SEARCH);
			throw claimNotFoundException;
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + PROVIDER_CLAIM_SEARCH);
			throw ex;
		}
		log.info("ProviderClaimSearch data fetched successfully.");
		return claimHeaderSearchResponse;
	}

	private String getQuery(String claimType) {
		if (claimType.equalsIgnoreCase(ClaimHeaderSearchConstants.MEDICAL)) {
			return spMedicalProviderClaimSearch;
		} else {
			log.info("For providerClaimSearch the allowed claim type is Medical, but received claim type is : {}", claimType);
			throw new RequestValidationException(ClaimHeaderSearchConstants.INVALID_PROVIDER_CLAIM_SEARCH_TYPE);
		}
	}
}
