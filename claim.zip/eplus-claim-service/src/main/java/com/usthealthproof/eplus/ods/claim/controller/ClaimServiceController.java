package com.usthealthproof.eplus.ods.claim.controller;
import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.util.DecodedUserIdentity;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Hidden
@RequestMapping("/v2/claims")
@RestController
@Tag(name = "Claims Service", description = "REST APIs for Portal Claims")
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class ClaimServiceController {

	@Autowired
	private ClaimServices claimService;
	@Autowired
	private ClaimHeaderSearchService claimHeaderSearchService;
	@Autowired
	private DecodedUserIdentity decodedUserIdentity;

	/**
	 * API to perform claim header search and to view the search results
	 *
	 * @param claimSearchRequest
	 * @return
	 * @throws Throwable
	 */

	@PostMapping(value = "/search", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Retrieves Claims based on criteria", description = "Provide valid claims Criteria", method = "POST", responses = {
			@ApiResponse(responseCode = "200", description = "claim search details", content = {
					@Content(schema = @Schema(implementation = ClaimSearchResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid member number", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<ClaimSearchResponse> getClaimSearchInfo(@Valid @RequestBody ClaimSearchRequest claimSearchRequest)
			throws Throwable {
		log.info("Inside getClaimSearchInfo() of ClaimServiceController class");
		log.debug("Portal claim search request:- {}",claimSearchRequest);
		UserIdentityRequest userIdentityRequest = decodedUserIdentity.getMemberHeaderDetails(claimSearchRequest.getUserIdentities());
		return new ResponseEntity<>(claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest),
				HttpStatus.OK);
	}

	/**
	 * API to get Claim Details Information
	 *
	 * @param claimDetailsRequest
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/claim", produces = { MediaType.APPLICATION_JSON_VALUE })
	@Operation(summary = "Retrieves claim details", method = "POST", description = "Provide valid ClaimHccId and Member Number", responses = {
			@ApiResponse(responseCode = "200", description = "claim number details", content = {
					@Content(schema = @Schema(implementation = ClaimDetailsResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid member number", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@ResponseBody
	public ResponseEntity<ClaimDetailsResponse> getClaimDetailsInfo(@Valid @RequestBody ClaimDetailsRequest claimDetailsRequest)
			throws Exception {
		log.info("Inside getClaimDetailsInfo() of ClaimServiceController class");
		log.debug("Portal claim details request:- {}",claimDetailsRequest);
		ClaimDetailsResponse claimDetailsInfo = claimService.getClaimDetailsInfo(claimDetailsRequest);
		return new ResponseEntity<>(claimDetailsInfo, HttpStatus.OK);
	}

}
