package com.usthealthproof.eplus.ods.claim.service;

import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimProviderSearchData;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimSearchData;
import com.usthealthproof.eplus.ods.claim.repository.search.ClaimAvailabilityCheckData;
import com.usthealthproof.eplus.ods.claim.repository.search.MemberClaimSearchData;
import com.usthealthproof.eplus.ods.claim.repository.search.ProviderClaimSearchData;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

@Service
public class ClaimHeaderSearchService {

	@Autowired
	MemberClaimSearchData memberClaimSearchData;

	@Autowired
	ProviderClaimSearchData providerClaimSearchData;
	@Autowired
	ClaimProviderSearchData claimProviderSearchData;
	@Autowired
	ClaimSearchData claimSearchData;
	@Autowired
	ClaimAvailabilityCheckData claimAvailabilityCheckData;

	@Value("${sp.spPortalMemberMedicalClaimSearch}")
	private String spPortalMemberMedicalClaimSearch;
	@Value("${sp.spPortalMemberDentalClaimSearch}")
	private String spPortalMemberDentalClaimSearch;
	@Value("${sp.spPortalMemberVisionClaimSearch}")
	private String spPortalMemberVisionClaimSearch;
	@Value("${sp.spPortalSponsorMedicalClaimSearch}")
	private String spPortalSponsorMedicalClaimSearch;
	@Value("${sp.spPortalSponsorVisionClaimSearch}")
	private String spPortalSponsorVisionClaimSearch;
	@Value("${sp.spPortalSponsorDentalClaimSearch}")
	private String spPortalSponsorDentalClaimSearch;

	/**
	 * claim header details service for CRM
	 *
	 * @param claimHeaderSearchRequest
	 * @param claimHeaderSearchResponse
	 * @return
	 */
	public ClaimHeaderSearchResponse getMemberClaimSearch(ClaimHeaderSearchRequest claimHeaderSearchRequest,
			ClaimHeaderSearchResponse claimHeaderSearchResponse) {
		return memberClaimSearchData.getClaimHeaderDetails(claimHeaderSearchRequest, claimHeaderSearchResponse);

	}

	public ClaimHeaderSearchResponse getProviderClaimSearch(ClaimHeaderSearchRequest claimHeaderSearchRequest,
			ClaimHeaderSearchResponse claimHeaderSearchResponse) {
		return providerClaimSearchData.getClaimHeaderDetails(claimHeaderSearchRequest, claimHeaderSearchResponse);
	}

	/**
	 * claim header search for H3O
	 *
	 * @param claimSearchRequest
	 * @param userIdentityRequest
	 * @return
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	public ClaimSearchResponse getClaimHeaderSearchInfo(ClaimSearchRequest claimSearchRequest,
														UserIdentityRequest userIdentityRequest) throws ExecutionException, InterruptedException, SQLException {
		try {
			if (StringUtils.equalsIgnoreCase(userIdentityRequest.getApp_name(), "Member")) {
				return claimSearchData.getClaimHeaderSearchInfo(claimSearchRequest,spPortalMemberMedicalClaimSearch,spPortalMemberDentalClaimSearch,spPortalMemberVisionClaimSearch);
			} else if (StringUtils.equalsIgnoreCase(userIdentityRequest.getApp_name(), "Provider")) {
				return claimProviderSearchData.getClaimHeaderSearchInfoForProvider(userIdentityRequest, claimSearchRequest);
			}else if (StringUtils.equalsIgnoreCase(userIdentityRequest.getApp_name(), "Sponsor")) {
				return claimSearchData.getClaimHeaderSearchInfo(claimSearchRequest,spPortalSponsorMedicalClaimSearch,spPortalSponsorDentalClaimSearch,spPortalSponsorVisionClaimSearch);
			}
		}catch(ExecutionException ee){
			throw ee;
		}catch(InterruptedException ie){
			throw ie;
		}catch (ClaimNotFoundException ndf){
			throw ndf;
		} catch (SQLException e) {
            throw e;
        }
        return null;
	}

	public ClaimHeaderSearchResponse providerClaimDataAvailabilityCheck(ClaimHeaderSearchRequest claimHeaderSearchRequest) {
		return claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(claimHeaderSearchRequest);
	}
}
