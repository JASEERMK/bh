package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Repository
@Slf4j
public class MedicalClaimLinesData {

    @Autowired
    private AsyncExecutorUtils asyncExecutorUtils;

    private static final String MEDICAL_CLAIM_LINES = "MedicalClaimLines";

    /**
     * get all the claim lines of particular claimNumber
     *
     * @param claimHccId
     * @param claimFactKey
     * @param state
     * @param lob
     * @param product
     * @return
     */
    public List<MedicalClaimLines> getClaimLines(String claimHccId, String claimFactKey, String state, String lob, String product) throws Exception {
        log.info("Inside getClaimLines() in MedicalClaimLinesData class");

        List<MedicalClaimLines> medicalClaimLinesResponse = null;
        CompletableFuture<List<MedicalClaimLines>> medicalClaimLines = null;
        try {
            CompletableFuture<List<ClaimRejectionDetails>> rejectionDescCompletableFuture = asyncExecutorUtils.getRejectionCodeDesc(claimHccId, null, claimFactKey, state, lob, product);
        	log.info("Going for ClaimLines DB call");
            if (StringUtils.isNotBlank(claimFactKey)) {
                medicalClaimLines = asyncExecutorUtils.getMedicalClaimLinesWithFactKey(claimHccId, claimFactKey, state, lob, product);

            } else {
                medicalClaimLines = asyncExecutorUtils.getMedicalClaimLinesWithoutFactKey(claimHccId, state, lob, product);
            }
            if (medicalClaimLines != null && medicalClaimLines.get() != null) {
                medicalClaimLinesResponse = mapRejectionCodeAndDescToClaimLinesResponse(medicalClaimLines, rejectionDescCompletableFuture);
            }
			log.debug("Response from DB: {}", medicalClaimLinesResponse);
            if (CollectionUtils.isEmpty(medicalClaimLinesResponse)) {
                log.info(ClaimConstants.CLAIM_LINES_NOT_FOUND + "{}", claimHccId);
                throw new ClaimNotFoundException(ClaimConstants.CLAIM_LINES_NOT_FOUND + claimHccId);
            }
        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + MEDICAL_CLAIM_LINES);
            throw jdbcException;
        } catch (ClaimNotFoundException claimNotFoundException) {
            log.error(ClaimConstants.CLAIM_NOT_FOUND + MEDICAL_CLAIM_LINES);
            throw claimNotFoundException;
        } catch (Exception ex) {
            log.error(ClaimConstants.EXCEPTION_MESSAGE + MEDICAL_CLAIM_LINES);
            throw ex;
        }
        log.info("MedicalClaimLines data fetched successfully.");
        return medicalClaimLinesResponse;
    }

    private List<MedicalClaimLines> mapRejectionCodeAndDescToClaimLinesResponse(CompletableFuture<List<MedicalClaimLines>> medicalClaimLines, CompletableFuture<List<ClaimRejectionDetails>> rejectionDescCompletableFuture) throws InterruptedException, ExecutionException {
        List<MedicalClaimLines> medicalClaimLinesResponse = medicalClaimLines.get();
        if (rejectionDescCompletableFuture != null && rejectionDescCompletableFuture.get() != null ) {
            for (MedicalClaimLines claimLine : medicalClaimLinesResponse) {
                String rejectionCodeDesc = rejectionDescCompletableFuture.get().stream()
                        .collect(Collectors.toMap(ClaimRejectionDetails::getClaimLineNumber, ClaimRejectionDetails::getRejectionCodeDesc)).getOrDefault(claimLine.getClaimLineNumber(), "");
                if (StringUtils.isNotBlank(rejectionCodeDesc)) {
                    claimLine.setUserMessage(rejectionCodeDesc);
                }
            }
        }
        return medicalClaimLinesResponse;
    }
}

