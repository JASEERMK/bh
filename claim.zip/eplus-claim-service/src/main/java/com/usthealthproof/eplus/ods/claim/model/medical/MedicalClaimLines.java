package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class for medical Claim Lines details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)

public class MedicalClaimLines implements Serializable, Comparable<MedicalClaimLines> {

	private static final long serialVersionUID = -3950173175057043273L;
	@Schema(description = "Claim Line Number")
	private String claimLineNumber;
	@Schema(description = "Billed Amount")
	private String billedAmount;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Paid Amount")
	private String paidAmount;
	@JsonIgnore
	private Integer orderField;
	@Schema(description = "User Message")
	private String userMessage;
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;

	@Override
	public int compareTo(MedicalClaimLines medicalClaimLines) {
		if (null != this.getOrderField() && null !=medicalClaimLines && null != medicalClaimLines.getOrderField()) {
			int orderField1 = this.getOrderField();
			int orderField2 = medicalClaimLines.getOrderField();
			return orderField1 - orderField2;
		}
        return 0;
    }
}
