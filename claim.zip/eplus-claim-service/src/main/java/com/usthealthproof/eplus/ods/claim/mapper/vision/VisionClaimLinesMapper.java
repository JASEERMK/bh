package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class VisionClaimLinesMapper implements RowMapper<VisionClaimLines> {

	@Override
	public VisionClaimLines mapRow(ResultSet rs, int i) throws SQLException {

		var visionClaimLines = new VisionClaimLines();
		visionClaimLines.setClaimHccId(rs.getString("claimhccid"));
		visionClaimLines.setClaimLineNumber(rs.getString("claimlinenumber"));
		visionClaimLines.setStatus(rs.getString("status"));
		visionClaimLines.setServiceStartDate(rs.getString("service_date"));

		return visionClaimLines;
	}

}
