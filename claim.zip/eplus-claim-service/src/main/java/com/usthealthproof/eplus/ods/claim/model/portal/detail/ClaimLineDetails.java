package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim Line level details")
public class ClaimLineDetails implements Serializable, Comparable<ClaimLineDetails> {
	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "ID of the claim line")
	@JsonProperty("lineNumber")
	private String claimLineNumber;

	@Schema(description = "Status of the claim line")
	@JsonProperty("status")
	private String status;

	@Schema(description = "Service from date")
	@JsonProperty("serviceFromDate")
	private String serviceStartDate;

	@Schema(description = "Service to date")
	@JsonProperty("serviceToDate")
	private String serviceEndDate;

	@JsonProperty("billedAmount")
	private String billedAmount;

	@Schema(description = "Number of services")
	@JsonProperty("serviceUnits")
	private String serviceUnits;

	@Schema(description = "Deductible amount")
	@JsonProperty("deductibleAmount")
	private String deductibleAmount;

	@Schema(description = "Amount not covered")
	@JsonProperty("amountNotCovered")
	private String amountNotCovered;

	@Schema(description = "Amount paid")
	@JsonProperty("paidAmount")
	private String paidAmount;

	@Schema(description = "Coinsurance amount")
	@JsonProperty("coinsuranceAmount")
	private String coinsuranceAmount;

	@Schema(description = "Copay amount")
	@JsonProperty("copayAmount")
	private String copayAmount;

	@Schema(description = "Amount for which the patient is responsible")
	@JsonProperty("patientResponsibilityAmount")
	private String patientResponsibilityAmount;

	@Schema(description = "List containing Procedure details")
	@JsonProperty("claimLineProcedures")
	private List<ClaimLineProcedure> claimLineProcedureList;

	@Override
	public int compareTo(ClaimLineDetails obj) {
		return this.getClaimLineNumber().compareTo(obj.getClaimLineNumber());
	}
}