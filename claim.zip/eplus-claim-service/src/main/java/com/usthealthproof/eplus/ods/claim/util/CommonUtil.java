package com.usthealthproof.eplus.ods.claim.util;

import java.util.Arrays;

import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;

public class CommonUtil {
	private CommonUtil() {
	}

	public static ProblemDetails getProblemDetails(String message, String status) {
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(Arrays.asList(message));
		return problemDetails;
	}

}
