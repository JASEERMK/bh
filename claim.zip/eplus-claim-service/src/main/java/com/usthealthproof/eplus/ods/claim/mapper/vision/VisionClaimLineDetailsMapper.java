package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class VisionClaimLineDetailsMapper implements RowMapper<VisionClaimLineDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public VisionClaimLineDetails mapRow(ResultSet rs, int i) throws SQLException {

		var visionClaimLineDetails = new VisionClaimLineDetails();
		visionClaimLineDetails.setClaimHccId(rs.getString("claimhccid"));
		visionClaimLineDetails.setClaimLineNumber(rs.getString("claimlinenumber"));
		visionClaimLineDetails.setCodeDescription(rs.getString("Codedescription"));
		visionClaimLineDetails.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		/** Updated Query change - AR21042021 **/
		visionClaimLineDetails.setAuthorizationNumber(rs.getString("authorization_id"));
		visionClaimLineDetails.setServiceException(rs.getString("service_exception"));
		visionClaimLineDetails.setAllowedAmount(rs.getString("allowedamount"));
		visionClaimLineDetails.setDeductible(rs.getString("deductible"));
		visionClaimLineDetails.setCopay(rs.getString("co_pay"));
		visionClaimLineDetails.setCoinsurance(rs.getString("co_insurance"));
		visionClaimLineDetails.setOverMax(rs.getString("overmax"));
		visionClaimLineDetails.setCobAmount(rs.getString("cob_amount"));
		visionClaimLineDetails.setPaymentNotes(rs.getString("payment_notes"));
		visionClaimLineDetails.setBilledAmount(rs.getString("billed_amount"));

		return visionClaimLineDetails;
	}

}
