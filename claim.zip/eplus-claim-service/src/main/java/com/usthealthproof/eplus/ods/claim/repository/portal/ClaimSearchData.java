package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.util.PortalClaimSearchUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Repository
@Slf4j
public class ClaimSearchData {
	@Autowired
	PortalClaimSearchUtil portalClaimSearchUtil;

	private static final String CLAIM_SEARCH = "claim search";

	public ClaimSearchResponse getClaimHeaderSearchInfo(ClaimSearchRequest claimSearchRequest, String spMedical, String spDental, String spVision) throws InterruptedException, ExecutionException, SQLException {
		log.info("Inside getClaimHeaderSearchInfo() in ClaimSearchData class");
		
		ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();
		List<ClaimSearchModel> claimSearchModelList = null;
		try {
			if (StringUtils.isBlank(claimSearchRequest.getClaimTypes())) {
				log.info("Claim type is empty, so executing the medicalClaimSearch SP");
				claimSearchModelList = portalClaimSearchUtil.getClaimSearchResult(claimSearchRequest,spMedical);
			} else {
				log.info("Started {} claim search SP ", claimSearchRequest.getClaimTypes());
				switch (claimSearchRequest.getClaimTypes().toLowerCase()) {
				case ClaimConstants.MEDICAL_CLAIM_TYPE:
					claimSearchModelList= portalClaimSearchUtil.getClaimSearchResult(claimSearchRequest,spMedical);
					break;
				case ClaimConstants.DENTAL_CLAIM_TYPE:
					claimSearchModelList = portalClaimSearchUtil.getClaimSearchResult(claimSearchRequest,spDental);
					break;
				case ClaimConstants.VISION_CLAIM_TYPE:
					claimSearchModelList = portalClaimSearchUtil.getClaimSearchResult(claimSearchRequest,spVision);
					break;
				case ClaimConstants.CLAIM_TYPE_ALL:
					claimSearchModelList = getAllClaimSearchResult(claimSearchRequest,spMedical,spDental,spVision);
					break;
				default:
					break;
				}
			}
			log.info(ClaimConstants.DB_CALL_COMPLETED);
			claimSearchResponse = portalClaimSearchUtil.setClaimSearchResponse(claimSearchModelList);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + CLAIM_SEARCH);
			throw jdbcException;
		} catch (ClaimNotFoundException ndfe) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + CLAIM_SEARCH);
			throw ndfe;
		} catch (Exception e) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + CLAIM_SEARCH);
			throw e;
		}
		log.info("ClaimSearchInfo fetched successfully");
		return claimSearchResponse;
	}

	private List<ClaimSearchModel> getAllClaimSearchResult(ClaimSearchRequest claimSearchRequest, String spMedical,
			String spDental, String spVision) throws InterruptedException, ExecutionException, SQLException {
		log.info("Inside getAllClaimSearchResult() in ClaimSearchData class");
		
		List<ClaimSearchModel> claimSearchResults = new ArrayList<>();
		List<CompletableFuture<List<ClaimSearchModel>>> completableFutureList = new ArrayList<>();
		List<String> spList = Arrays.asList(spMedical, spDental, spVision);
		for (String sp : spList) {
			if(StringUtils.isBlank(sp)) continue;
			CompletableFuture<List<ClaimSearchModel>> claimSearchCompleatableFuture = null;
			claimSearchCompleatableFuture = portalClaimSearchUtil.getAllClaimSearchResult(claimSearchRequest,sp);
			completableFutureList.add(claimSearchCompleatableFuture);
		}
		for (CompletableFuture<List<ClaimSearchModel>> claimSearchResponseCompletableFuture : completableFutureList) {
			claimSearchResults.addAll(claimSearchResponseCompletableFuture.get());
		}
		return claimSearchResults;
	}
}
