package com.usthealthproof.eplus.ods.claim.model.search;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Object for holding the denial code and description")
public class DenialCode implements Serializable {

	private static final long serialVersionUID = -6435420302650121082L;
	@Schema(description = "Denial Code")
	private String code;
	
	@Schema(description = "Denial Description")
	private String description;
}
