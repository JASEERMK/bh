package com.usthealthproof.eplus.ods.claim.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ClaimHeaderSearchConstants {

	private ClaimHeaderSearchConstants() {
	}

	public static final String SUPPLIER_HCC_ID = "supplierid";
	public static final String SUPPLIER_LOCATION_HCC_ID = "supplierlocationid";
	public static final String ATTENDING_PRACTITIONER_HCC_ID = "attendingpractitionerid";
	public static final String RENDERING_PRACTITIONER_HCC_ID = "renderingpractitionerid";
	public static final String NO_DATA_FOUND = "No data found";
	public static final String MEMBER_NUMBER_NOT_FOUND = "Member number not found in the request";
	public static final String PROVIDER_ID_NOT_FOUND = "Provider Id not found in the request";
	public static final String PROVIDER_TYPE_NOT_FOUND = "Provider Type not found in the request";
	public static final String PROVIDER_TYPE_INVALID = "Provider Type is invalid in the request";
	public static final String LOG_ERROR_MSG_SERVICE_FROM_DATE = "Invalid request ie. Service from Date cannot be empty/null/blank if Service to Date is present";
	public static final String LOG_ERROR_MSG_SERVICE_TO_DATE = "Invalid request ie. Service to Date cannot be empty/null/blank if Service From Date is present";
	public static final String SEARCH_SERVICE_FROM_DATE_REQUIRED = "Please provide a valid service from date";
	public static final String SEARCH_SERVICE_TO_DATE_REQUIRED = "Please provide a valid service to date";
	public static final String SERVICE_TO_DATE = "Given Service To Date is invalid date format, expected date format is YYYY-MM-DD";
	public static final String SERVICE_FROM_DATE = "Given Service From Date is invalid date format, expected date format is YYYY-MM-DD";
	public static final String CLAIM_TYPE_NOT_FOUND = "Claim Type is not found in the request";
	public static final String INVALID_CLAIM_TYPE_FOUND = "Invalid Claim type";
	public static final String MANDATORY_MISSING = "Mandatory fields missing";
	public static final String SERVICE_DATES_REQUIRED = "Invalid Request: Service dates are required";
	public static final String MEDICAL = "medical";
	public static final String DENTAL = "dental";
	public static final String VISION = "vision";
	public static final String RX = "rx";
	public static final List<String> CLAIM_TYPES = new ArrayList<>(Arrays.asList(MEDICAL, DENTAL, VISION, RX));
	public static final List<String> PROVIDER_TYPES = new ArrayList<>(Arrays.asList(SUPPLIER_HCC_ID, SUPPLIER_LOCATION_HCC_ID,
			ATTENDING_PRACTITIONER_HCC_ID, RENDERING_PRACTITIONER_HCC_ID));
	public static final String INVALID_PROVIDER_CLAIM_SEARCH_TYPE = "Invalid Request: Provider Claim Search request is not valid";
	public static final String LOG_ERROR_MSG_DATE_RANGE = "The date range between serviceFromDate and serviceToDate exceeded {}";
	public static final String DATE_RANGE_EXCEEDS_LIMIT = "Date range exceeds %s, please adjust your start date and end date";
	public static final String DATE_RANGE_LIMIT_NOT_CONFIGURED = "Date range limit not set. Please configure the required limit.";

}
