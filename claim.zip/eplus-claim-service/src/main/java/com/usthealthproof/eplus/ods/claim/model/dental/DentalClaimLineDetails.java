package com.usthealthproof.eplus.ods.claim.model.dental;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing dental claim line level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DentalClaimLineDetails implements Serializable {

	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "Unique identifier of the dental claim")
	private String claimHccId;

	@Schema(description = "Service Code")
	private String codeDescription;

	@Schema(description = "Service Start Date")
	private String serviceStartDate;

	@Schema(description = "Tooth")
	private String tooth;

	@Schema(description = "Surface")
	private String surface;

	@Schema(description = "Area Of Oral Cavity")
	private String areaOfOralCavity;

	@Schema(description = "Authorization number for dental claim")
	private String authorizationNumber;

	@Schema(description = "Service Exception Message")
	private String serviceException;

	@Schema(description = "Allowed Amount")
	private String allowedAmount;

	@Schema(description = "Net Paid Amount")
	private String paidAmount;

	@Schema(description = "Deductible Amount")
	private String deductible;

	@Schema(description = "Copay Computed")
	private String coPay;

	@Schema(description = "Over Max")
	private String overMax;

	@Schema(description = "Coordination of benefit collected")
	private String cobAmount;

	@Schema(description = "Coinsurance Computed")
	private String coInsurance;

	@Schema(description = "Payment Notes")
	private String paymentNotes;

	@Schema(description = "Billed Amount")
	private String billedAmount;

}
