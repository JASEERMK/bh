package com.usthealthproof.eplus.ods.claim.model.portal;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class AclEntity {
	private List<Container> containers;
}
