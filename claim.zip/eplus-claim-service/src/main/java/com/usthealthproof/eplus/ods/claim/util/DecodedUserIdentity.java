package com.usthealthproof.eplus.ods.claim.util;

import com.google.gson.Gson;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Component
@Slf4j
public class DecodedUserIdentity {
	public UserIdentityRequest getMemberHeaderDetails(String headerRequest) throws Exception {
		log.info("Inside getMemberHeaderDetails() in DecodedUserIdentity class");

		UserIdentityRequest userIdentityRequest = null;
		if (StringUtils.isNotBlank(headerRequest)) {
			try {
				byte[] decodedBytes = Base64.getDecoder().decode(headerRequest);
				String decodedString = new String(decodedBytes);
				Gson gson = new Gson();
				userIdentityRequest = gson.fromJson(decodedString, UserIdentityRequest.class);
				log.debug("userIdentityRequest: {}", userIdentityRequest);
			} catch (Exception ex) {
				log.info("Some error occurred while parsing the headerRequest into the object, may be because of Invalid User Identity Header");
				throw ex;
			}
		}
		return userIdentityRequest;
	}

}
