package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MedicalClaimLinesMapper implements RowMapper<MedicalClaimLines> {

	@Override
	public MedicalClaimLines mapRow(ResultSet rs, int i) throws SQLException {

		var medicalClaimLines = new MedicalClaimLines();
		medicalClaimLines.setClaimLineNumber(rs.getString("claimLineNumber"));
		medicalClaimLines.setBilledAmount(rs.getString("billedAmount"));
		medicalClaimLines.setStatus(rs.getString("status"));
		// this field is for sorting
		medicalClaimLines.setOrderField(rs.getInt("order_field"));
		medicalClaimLines.setUserMessage(rs.getString("userMessage"));
		medicalClaimLines.setPaidAmount(rs.getString("paidAmount"));
		// Added as part of CPB-3167
		medicalClaimLines.setClaimFactKey(rs.getString("claim_fact_key"));
		return medicalClaimLines;
	}
}