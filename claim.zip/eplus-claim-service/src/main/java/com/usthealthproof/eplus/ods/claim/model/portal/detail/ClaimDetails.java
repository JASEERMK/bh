package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.ods.claim.model.portal.Diagnoses;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.PaymentInformation;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for claim details")
public class ClaimDetails implements Serializable {

	private static final long serialVersionUID = -427889981973809232L;

	@Schema(description = "Number of the associated claim")
	@JsonProperty("claimNumber")
	private String claimNumber;

	@Schema(description = "Claim status")
	@JsonProperty("claimStatus")
	private String claimStatus;

	@Schema(description = "Type of claim, can be one of: Professional, Institutional, Dental ")
	@JsonProperty("claimType")
	private String claimType;

	@Schema(description = "Date on which the service occurred")
	@JsonProperty("serviceDate")
	private String serviceDate;

	@Schema(description = "Total Submitted amount")
	@JsonProperty("totalSubmittedAmount")
	private String totalSubmittedAmount;

	@Schema(description = "Total Patient Responsibility Amount")
	@JsonProperty("totalPatientResponsibilityAmount")
	private String totalPatientResponsibilityAmount;

	@Schema(description = "Total amount paid")
	@JsonProperty("totalPaidAmount")
	private String totalPaidAmount;

	@Schema(description = "The sum of all the co-pay amounts")
	@JsonProperty("totalCopayAmount")
	private String totalCopayAmount;

	@Schema(description = "The sum of all the coinsurance amounts")
	@JsonProperty("totalCoinsuranceAmount")
	private String totalCoinsuranceAmount;

	@Schema(description = "The sum of all the deductible amounts")
	@JsonProperty("totalDeductibleAmount")
	private String totalDeductibleAmount;

	@Schema(description = "Total billed amount")
	@JsonProperty("totalBilledAmount")
	private String totalBilledAmount;

	@Schema(description = "Status of payment")
	@JsonProperty("paymentStatus")
	private String paymentStatus;

	@Schema(description = "Payment date")
	@JsonProperty("paymentDate")
	private String paymentDate;

	@Schema(description = "List containing payment details related to the claim")
	@JsonProperty("paymentInformation")
	private List<PaymentInformation> paymentInformationList;

	@Schema(description = "Patient details")
	@JsonProperty("patient")
	private Patient patient;

	@Schema(description = "Provider details")
	private Provider provider;

	@Schema(description = "List containing Claim Line level details")
	@JsonProperty("claimLines")
	private List<ClaimLineDetails> claimLineDetailsList;

	@Schema(description = "List containing diagnosis details related to the claim")
	@JsonProperty("diagnoses")
	private List<Diagnoses> diagnosesList;

	@Schema(description = "Timestamp and modified by person with date")
	private String modifiedBy;

}
