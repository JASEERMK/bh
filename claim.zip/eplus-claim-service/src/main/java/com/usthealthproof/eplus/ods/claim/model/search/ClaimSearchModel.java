package com.usthealthproof.eplus.ods.claim.model.search;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Object for holding the claim search response")
public class ClaimSearchModel implements Serializable {

	private static final long serialVersionUID = -6435420302650121082L;
	@Schema(description = "Claim Number")
	private String claimNumber;

	@Schema(description = "Service Date - Only relevant for Member search for Medical/Dental/Vision claims")
	private String dos;

	@Schema(description = "Claim Status")
	private String claimStatus;

	@Schema(description = "Provider Name - Only relevant for Member search for Medical/Dental/Vision claims")
	private String providerName;

	@Schema(description = "Billed Amount - Only relevant for Member search for Medical claims")
	private String billedAmount;

	@Schema(description = "Date Paid - Only relevant for Member search for Dental and vision claims")
	private String datePaid;

	@Schema(description = "Pharmacy Name - Only relevant for Member search for Pharmacy claims")
	private String pharmacyName;

	@Schema(description = "Drug Name - Only relevant for Member search for Pharmacy claims")
	private String drugName;

	@Schema(description = "Date Filled - Only relevant for Member search for Pharmacy claims")
	private String dateFilled;

	@Schema(description = "Member Name - Only relevant for provider claim search ")
	private String memberName;

	@Schema(description = "Patient Account Number - Only relevant for provider claim search")
	private String patientAccountNumber;

	@Schema(description = "Member ID - Only relevant for provider claim search")
	private String memberId;

	// A part of cpb-4243
	@Schema(description = "Prescription ID - Only relevant for Member search for Pharmacy claims")
	private String prescriptionId;
}
