package com.usthealthproof.eplus.ods.claim.model.vision;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Response class containing responses of vision claim lines details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VisionClaimLinesResponse implements Serializable {

	private static final long serialVersionUID = -6571036395855981011L;
	@Schema(description = "List containing claim line level details of the vision claim")
	@JsonProperty("visionClaimLines")
	private List<VisionClaimLines> visionClaimLines;

}
