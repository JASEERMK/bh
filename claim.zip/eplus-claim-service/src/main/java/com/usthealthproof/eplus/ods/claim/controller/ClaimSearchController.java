package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Claims Search Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class ClaimSearchController {

	@Autowired
	private ClaimHeaderSearchService claimHeaderSearchService;
	@Autowired
	private Validator validator;

	/**
	 * claim header details service for CRM
	 *
	 * @param claimTypes
	 * @param claimNumber
	 * @param serviceFromDate
	 * @param serviceToDate
	 * @param claimStatus
	 * @param memberNumber
	 * @param state
	 * @param lob
	 * @param product
	 * @param serviceCode
	 * @param diagnosisCode
	 * @return
	 */

	@Operation(summary = "Member claims search", description = "A member's claims can be retrieved through this service; depending on the filter conditions, all the member's claims will be returned as a response. This API allows us to search for claims in three separate categories: medical, dental, vision and pharmacy. The following search parameters can be used to find member claims: claim types, member number, claim number, service from date, service to date, claim status, service code, diagnosis code. The claim types is the required field among these. All the other arguments are optional if the claim number is provided. Besides that, there are other conditional necessary cases that we need to pass, such as the member number, service from date, service to date and claim status if the claim number is not provided. Furthermore, we can use the other parameters in the filters however we see appropriate; it is entirely optional. For medical claim searches only, the service code and diagnosis code are applicable. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Claim Member Search Details", content = {
					@Content(schema = @Schema(implementation = ClaimHeaderSearchResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/member/claimSearch")
	@ResponseBody
	public ResponseEntity<ClaimHeaderSearchResponse> getClaimDetails(

			@Parameter(description = "Claim Types", required = true) @RequestParam(value = "claimTypes") @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimTypes is not in valid format") String claimTypes,
			@Parameter(description = "Claim Number", required = false) @RequestParam(value = "claimNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimNumber is not in valid format") String claimNumber,
			@Parameter(description = "Service From Date", required = false) @RequestParam(value = "serviceFromDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceFromDate is not in valid format") String serviceFromDate,
			@Parameter(description = "Service To Date", required = false) @RequestParam(value = "serviceToDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceToDate is not in valid format") String serviceToDate,
			@Parameter(description = "Claim Status", required = false) @RequestParam(value = "claimStatus", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimStatus is not in valid format") String claimStatus,
			@Parameter(description = "Member Number", required = false) @RequestParam(value = "memberNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$"	, message = "Invalid Request: memberNumber is not in valid format") String memberNumber,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[a-zA-Z]+$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String product,
			@Parameter(description = "Service Code", hidden = false) @RequestParam(value = "serviceCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: serviceCode is not in valid format") String serviceCode,
			@Parameter(description = "Diagnosis Code", hidden = false) @RequestParam(value = "diagnosisCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: diagnosisCode is not in valid format") String diagnosisCode)

	{
		log.info("Inside getClaimDetails() in ClaimSearchController class");
		log.debug(
				"Member claimSearch request:- ClaimTypes: {}, claimNumber: {}, serviceFromDate: {}, serviceToDate: {}, claimStatus: {}, memberNumber: {}, state: {}, lob: {}, product: {}",
				claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, state, lob, product);

		ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
		ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();

		validator.validateMemberSearchRequest(claimTypes,serviceFromDate, serviceToDate, memberNumber, claimStatus, claimNumber);

		claimHeaderSearchRequest.setMemberNumber(memberNumber);
		claimHeaderSearchRequest.setServiceFromDate(serviceFromDate);
		claimHeaderSearchRequest.setServiceToDate(serviceToDate);
		claimHeaderSearchRequest.setClaimTypes(claimTypes);
		claimHeaderSearchRequest.setClaimStatus(claimStatus);
		claimHeaderSearchRequest.setClaimNumber(claimNumber);
		claimHeaderSearchRequest.setState(state);
		claimHeaderSearchRequest.setLob(lob);
		claimHeaderSearchRequest.setProduct(product);
		claimHeaderSearchRequest.setServiceCode(serviceCode);
		claimHeaderSearchRequest.setDiagnosisCode(diagnosisCode);
		claimHeaderSearchResponse = claimHeaderSearchService.getMemberClaimSearch(claimHeaderSearchRequest,
				claimHeaderSearchResponse);
		return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
	}

	/**
	 * claim header details service for CRM
	 *
	 * @param providerId
	 * @param providerType
	 * @param claimTypes
	 * @param claimNumber
	 * @param serviceFromDate
	 * @param serviceToDate
	 * @param claimStatus
	 * @param memberNumber
	 * @param state
	 * @param lob
	 * @param product
	 * @param serviceCode
	 * @param diagnosisCode
	 * @return
	 */


	@Operation(summary = "Provider claims search", description = "A provider's claims can be retrieved through this service; depending on the filter conditions, all the provider's claims will be returned as a response. This API allows us to search for medical claims only. The following search parameters can be used to find provider's claims: provider ID, provider type, claim types, claim number, service from date, service to date, claim status, member number, service code, diagnosis code. The claim types is the required field among these. All the other arguments are optional if the claim number is provided. Besides that, there are other conditional necessary cases that we need to pass, such as the provider ID, provider type, service from date and service to date if the claim number is not provided. Furthermore, we can use the other parameters in the filters however we see appropriate; it is entirely optional. Additionally, it does not permit searching using just one date field; both the start and end date fields must be provided if data to be retrieved based on date filters. Similarly, if provider ID is supplied, the provider type must also be provided, and vice versa.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Claim Provider Search Details", content = {
					@Content(schema = @Schema(implementation = ClaimHeaderSearchResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/provider/claimSearch")
	@ResponseBody
	public ResponseEntity<ClaimHeaderSearchResponse> getProviderClaimDetails(

			@Parameter(description = "Provider Id", required = false) @RequestParam(value = "providerId", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: providerId is not in valid format") String providerId,
			@Parameter(description = "Provider Type", required = false) @RequestParam(value = "providerType", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: providerType is not in valid format") String providerType,
			@Parameter(description = "Claim Types", required = true) @RequestParam(value = "claimTypes") @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimTypes is not in valid format") String claimTypes,
			@Parameter(description = "Claim Number", required = false) @RequestParam(value = "claimNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimNumber is not in valid format") String claimNumber,
			@Parameter(description = "Service From Date", required = false) @RequestParam(value = "serviceFromDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceFromDate is not in valid format") String serviceFromDate,
			@Parameter(description = "Service To Date", required = false) @RequestParam(value = "serviceToDate", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,*|;!]*$", message = "Invalid Request: serviceToDate is not in valid format") String serviceToDate,
			@Parameter(description = "Claim Status", required = false) @RequestParam(value = "claimStatus", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimStatus is not in valid format") String claimStatus,
			@Parameter(description = "Member Number", required = false) @RequestParam(value = "memberNumber", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: memberNumber is not in valid format") String memberNumber,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: LOB is not in valid format") String product,
			@Parameter(description = "Service Code", hidden = false) @RequestParam(value = "serviceCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: serviceCode is not in valid format") String serviceCode,
			@Parameter(description = "Diagnosis Code", hidden = false) @RequestParam(value = "diagnosisCode", required = false) @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: diagnosisCode is not in valid format") String diagnosisCode)

	{
		log.info("Inside getProviderClaimDetails() in ClaimSearchController class");
		log.debug(
				"Provider claimSearch request:- ClaimTypes: {}, claimNumber: {}, serviceFromDate: {}, serviceToDate: {}, claimStatus: {}, memberNumber: {}, providerId: {}, providerType: {}, state: {}, lob: {}, product: {}",
				claimTypes, claimNumber, serviceFromDate, serviceToDate, claimStatus, memberNumber, providerId, providerType,
				state, lob, product);

		ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
		ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();

		validator.validateProviderSearchRequest(claimTypes, serviceFromDate, serviceToDate, claimNumber, providerId, providerType);

		claimHeaderSearchRequest.setMemberNumber(memberNumber);
		claimHeaderSearchRequest.setServiceFromDate(serviceFromDate);
		claimHeaderSearchRequest.setServiceToDate(serviceToDate);
		claimHeaderSearchRequest.setClaimTypes(claimTypes);
		claimHeaderSearchRequest.setClaimStatus(claimStatus);
		claimHeaderSearchRequest.setClaimNumber(claimNumber);
		claimHeaderSearchRequest.setProviderId(providerId);
		claimHeaderSearchRequest.setProviderIdType(providerType);
		claimHeaderSearchRequest.setState(state);
		claimHeaderSearchRequest.setLob(lob);
		claimHeaderSearchRequest.setProduct(product);
		claimHeaderSearchRequest.setServiceCode(serviceCode);
		claimHeaderSearchRequest.setDiagnosisCode(diagnosisCode);

		claimHeaderSearchResponse = claimHeaderSearchService.getProviderClaimSearch(claimHeaderSearchRequest,
				claimHeaderSearchResponse);
		return new ResponseEntity<>(claimHeaderSearchResponse, HttpStatus.OK);
	}

}
