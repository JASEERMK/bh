package com.usthealthproof.eplus.ods.claim.model.medical;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class ClaimRejectionDetails {

    //Added as part of API-1467
    @Schema(description = "Rejection Code and Description")
    private String rejectionCodeDesc;
    @Schema(description = "Claim Line Number")
    private String claimLineNumber;

}
