package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class DentalClaimDetailsData {


	@Autowired
	private DentalClaimDetailsMapper dentalClaimDetailsMapper;
	@Value("${claims.spDentalClaimDetail}")
	String spDentalClaimDetail;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * get the Dental claims details
	 *
	 * @param claimHccId
	 * @return
	 */
	public DentalClaimDetails findDentalClaimId(String claimHccId, String state, String lob, String product) {
		log.info("Inside findDentalClaimId() in DentalClaimDetailsData class");

        DentalClaimDetails dentalClaimDetails;
        try {
			MapSqlParameterSource dentalClaimDetailsParams = new MapSqlParameterSource().addValue("claimId",
					claimHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String dentalClaimDetailSql = "{CALL " + spDentalClaimDetail
					+ "(:claimId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			dentalClaimDetails = namedParameterJdbcTemplate.queryForObject(dentalClaimDetailSql, dentalClaimDetailsParams,
					dentalClaimDetailsMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spDentalClaimDetail,
                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", dentalClaimDetails);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "DentalClaimDetails");
			throw jdbcException;
		} catch (EmptyResultDataAccessException emptyResultException) {
			log.error("EmptyResultDataAccessException occurred for the DentalClaimDetails service request and the exception is: ",
					emptyResultException);
			throw new ClaimNotFoundException(ClaimConstants.DENTAL_CLAIM_DETAILS_NOT_FOUND + claimHccId);
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + "DentalClaimDetails");
			throw ex;
		}
		log.info("DentalClaimDetails data fetched successfully.");
		return dentalClaimDetails;
	}
}