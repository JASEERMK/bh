package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class VisionClaimLineDetailsData {

	@Autowired
	private VisionClaimLineDetailsMapper visionClaimLineDetailsMapper;
	@Value("${claims.spVisionClaimLineDetails}")
	private String spVisionClaimLineDetails;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * get the vision claim line details of the particular claim number
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @return
	 */
	public VisionClaimLineDetails getVisionClaimLineDetails(String claimHccId, String claimLineHccId, String state, String lob, String product) {
		log.info("Inside getVisionClaimLineDetails() in VisionClaimLineDetailsData class");

		VisionClaimLineDetails visionClaimLineDetail;
		try {
			MapSqlParameterSource visionClaimLineDetailParams = new MapSqlParameterSource().addValue("claimId",
							claimHccId, Types.VARCHAR)
					.addValue("claimLineId", claimLineHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String visionClaimLineDetailSql = "{CALL " + spVisionClaimLineDetails
					+ "(:claimId, :claimLineId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			visionClaimLineDetail = namedParameterJdbcTemplate.queryForObject(visionClaimLineDetailSql,
					visionClaimLineDetailParams, visionClaimLineDetailsMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spVisionClaimLineDetails,
					endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", visionClaimLineDetail);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "VisionClaimLineDetails");
			throw jdbcException;
		} catch (EmptyResultDataAccessException emptyResultException) {
			log.error("EmptyResultDataAccessException occurred for the VisionClaimLineDetails service request and the exception is: ",
					emptyResultException);
			throw new ClaimNotFoundException(ClaimConstants.VISION_CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId
					+ " and claim line number : " + claimLineHccId);
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + "VisionClaimLineDetails");
			throw ex;
		}
		log.info("VisionClaimLineDetails data fetched successfully.");
		return visionClaimLineDetail;
	}

}
