package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class UserIdentityRequest {

	@JsonProperty("app_name")
	private String app_name;

	@JsonProperty("method_name")
	private String method_name;

	@JsonProperty("user_name")
	private String user_name;

	@JsonProperty("web_session_id")
	private String web_session_id;

	@JsonProperty("correlation_id")
	private String correlation_id;

	@JsonProperty("members")
	private List<Members> members;

	@JsonProperty("acl_entities")
	private List<AclEntity> acl_entities;
}
