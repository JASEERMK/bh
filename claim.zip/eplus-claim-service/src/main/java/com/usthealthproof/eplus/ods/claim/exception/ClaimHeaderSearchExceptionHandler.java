package com.usthealthproof.eplus.ods.claim.exception;

import java.util.ArrayList;
import java.util.List;

import com.usthealthproof.eplus.ods.claim.mapper.util.APIUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;
import com.usthealthproof.eplus.ods.claim.util.CommonUtil;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@ControllerAdvice
@Slf4j
public class ClaimHeaderSearchExceptionHandler {
	@Autowired
	private APIUtils apiUtils;

	/**
	 * Exception Handler for Global exceptions
	 *
	 * @param e
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> globalException(Exception e, WebRequest request) {
		log.error("Exception Caught : {} {}", e.getMessage(), e);
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(CommonUtil.getProblemDetails(ClaimConstants.EXCEPTION_OCCURRED, ClaimConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Exception Handler for JDBC connection problems
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(CannotGetJdbcConnectionException.class)
	public final ResponseEntity<ErrorResponse> jdbcExceptionHandler(CannotGetJdbcConnectionException ex, WebRequest request) {
		log.error("CannotGetJdbcConnectionException Caught : {} {} ", ex.getMessage(), ex);
		ErrorResponse errorResponse = new ErrorResponse();
		if (StringUtils.containsIgnoreCase(ex.getMessage(), "Failed to obtain JDBC Connection")) {
			errorResponse.setProblemDetails(CommonUtil.getProblemDetails(ClaimConstants.JDBC_EXCEPTION, ClaimConstants.FAILURE));
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			errorResponse
					.setProblemDetails(CommonUtil.getProblemDetails(ClaimConstants.EXCEPTION_OCCURRED, ClaimConstants.FAILURE));
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Exception Handler for No Data Found
	 *
	 * @param ex
	 * @param request
	 * @return
	 */

	@ExceptionHandler(ClaimNotFoundException.class)
	public ResponseEntity<ErrorResponse> notFoundException(ClaimNotFoundException ex, WebRequest request) {
		log.error("ClaimNotFoundException Caught : {} {}", ex.getMessage(), ex);
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(CommonUtil.getProblemDetails(ex.getMessage(), ClaimConstants.SUCCESS));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	/**
	 * Exception Handler for Invalid requests
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(RequestValidationException.class)
	public final ResponseEntity<ErrorResponse> requestValidationHandler(RequestValidationException ex, WebRequest request) {
		log.error("RequestValidationException Caught : {} {}", ex.getMessage(), ex);
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(CommonUtil.getProblemDetails(ex.getMessage(), ClaimConstants.FAILURE));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for ConstraintViolationException types
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse> handleconstraintViolationException(ConstraintViolationException ex, WebRequest request) {
		log.error("ConstraintViolationException Caught : {} {}", ex.getMessage(), ex);
		List<String> errorMessage = new ArrayList<>();
		ex.getConstraintViolations().forEach(cv -> errorMessage.add(cv.getMessage()));
		return new ResponseEntity<>(setErrorDetailsAsList(errorMessage, ClaimConstants.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling Missing mandatory fields in the request
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public final ResponseEntity<ErrorResponse> missingServletRequestParameterException(MissingServletRequestParameterException ex,
																					   WebRequest request) {
		log.error("MissingServletRequestParameterException Caught. Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(apiUtils.setErrorDetails(ex.getMessage(), ClaimConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception Handler for handling the invalid URL's
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(NoResourceFoundException.class)
	public final ResponseEntity<ErrorResponse> noResourceFoundException(NoResourceFoundException ex, WebRequest request) {
		log.error("NoResourceFoundException Caught.  Error Message: {} and Exception: ", ex.getMessage(), ex);

		return new ResponseEntity<>(apiUtils.setErrorDetails(ClaimConstants.INVALID_REQUEST_URL, ClaimConstants.FAILURE), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Common Method for the error details having list of error messages
	 */
	private ErrorResponse setErrorDetailsAsList(List<String> list, String status) {
		log.info("Inside setErrorDetailsAsList() in ClaimHeaderSearchExceptionHandler class");
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(list);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

}
