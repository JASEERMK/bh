package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * claim header details service for CRM
 *
 * @param rs
 * @param i
 * @return
 * @throws SQLException
 */

@Component
public class ProviderClaimSearchMapper implements RowMapper<ClaimSearchModel> {

	@Autowired
	DateUtils dateUtils;

	@Override
	public ClaimSearchModel mapRow(ResultSet rs, int i) throws SQLException {
		var claimSearchModel = new ClaimSearchModel();

		claimSearchModel.setBilledAmount(rs.getString("billed_Amount"));
		claimSearchModel.setClaimNumber(rs.getString("claim_number"));
		claimSearchModel.setDos(dateUtils.getFormattedApplicationDate(rs.getString("dos")));
		claimSearchModel.setMemberName(rs.getString("member_Name"));
		claimSearchModel.setPatientAccountNumber(rs.getString("patient_acctno"));
		claimSearchModel.setClaimStatus(rs.getString("status"));
		claimSearchModel.setMemberId(rs.getString("member_id"));

		return claimSearchModel;

	}
}
