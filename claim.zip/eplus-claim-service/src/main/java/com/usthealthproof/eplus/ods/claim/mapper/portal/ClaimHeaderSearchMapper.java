package com.usthealthproof.eplus.ods.claim.mapper.portal;

import com.usthealthproof.eplus.ods.claim.model.portal.Name;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
@Slf4j
@Component
public class ClaimHeaderSearchMapper implements RowMapper<ClaimSearchModel> {

	@Autowired
	private DateUtils dateUtils;

	@Value("#{${claims.claimStatus}}")
	private Map<String, String> claimSearchStatusMap;
	private static final String CLAIM_STATUS = "claim_status";

	@Override
	public ClaimSearchModel mapRow(ResultSet rs, int i) throws SQLException {
		ClaimSearchModel claimSearchModel = new ClaimSearchModel();
		claimSearchModel.setClaimNumber(rs.getString("claim_number"));
		if (StringUtils.isNotBlank(rs.getString(CLAIM_STATUS))) {
			if (StringUtils.isNotBlank(claimSearchStatusMap.get(rs.getString(CLAIM_STATUS)))) {
				claimSearchModel.setClaimStatus(claimSearchStatusMap.get(rs.getString(CLAIM_STATUS)));
			} else {
				claimSearchModel.setClaimStatus(claimSearchStatusMap.get("Others"));
			}
		}
		claimSearchModel.setClaimType(rs.getString("claim_category"));
		claimSearchModel.setServiceDate(dateUtils.getFormattedClientDate(rs.getString("service_date")));
		claimSearchModel.setPaidDate(dateUtils.getFormattedClientDate(rs.getString("paid_date")));
		claimSearchModel.setPatient(getPatientInfo(rs));
		claimSearchModel.setProvider(getProviderInfo(rs));
		claimSearchModel.setTotalSubmittedAmount(rs.getString("total_submitted_amount"));
		claimSearchModel.setTotalPaidAmount(rs.getString("total_paid"));
		claimSearchModel.setTotalBilledAmount(rs.getString("total_billed"));
		return claimSearchModel;
	}

	private Patient getPatientInfo(ResultSet rs) throws SQLException {
		Patient patient = new Patient();
		patient.setMemberNumber(rs.getString("member_number"));
		Name patientName = new Name();
		patientName.setFirstName(rs.getString("MEMBER_FIRST_NAME"));
		patientName.setLastName(rs.getString("MEMBER_LAST_NAME"));
		patientName.setMiddleName(rs.getString("MEMBER_MIDDLE_NAME"));
		patient.setName(patientName);
		return patient;
	}

	private Provider getProviderInfo(ResultSet rs) throws SQLException {
		Provider provider = new Provider();
		Name providerName = new Name();
		providerName.setFirstName(rs.getString("provider_first_name"));
		providerName.setLastName(rs.getString("provider_last_name"));
		providerName.setMiddleName(rs.getString("provider_middle_name"));
		provider.setName(providerName);
		provider.setProviderNpi(rs.getString("provider_npi"));
		provider.setProviderTaxId(rs.getString("Provider_Taxid"));
		provider.setProviderId(rs.getString("provider_id"));
		provider.setPractitionerId(rs.getString("PRACTITIONER_HCC_ID"));
		provider.setSupplierLocationId(rs.getString("SUPPLIER_LOCATION_HCC_ID"));
		return provider;
	}

}
