package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class for medical Claim Line level details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MedicalClaimLineDetails implements Serializable {

	private static final long serialVersionUID = 1756479575055367543L;

	@Schema(description = "Claim Line Number")
	private String claimLineNumber;
	@Schema(description = "Claim HCC ID")
	private String claimHccId;
	@Schema(description = "claim Line Key")
	private String claimLineKey;
	@Schema(description = "Billed Amount")
	private String billedAmount;
	@Schema(description = "Denied")
	private String denied;
	@Schema(description = "Description")
	@JsonProperty(value = "denialCodeDesc")
	private String denialCodeDesc;
	@Schema(description = "Service Start Date")
	private String serviceStartDate;
	@Schema(description = "Service End Date")
	private String serviceEndDate;
	@Schema(description = "Error Level")
	private String errorLevel;
	@Schema(description = "External Source")
	private String externalSource;
	@Schema(description = "Amount Paid")
	private String paidAmount;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Deductible Amount")
	private String deductibleAmount;
	@Schema(description = "Allowed Amount")
	private String allowedAmount;
	@Schema(description = "Coinsurance Amount")
	private String coinsuranceAmount;
	@Schema(description = "Copay Amount")
	private String copayAmount;
	@Schema(description = "Disposition")
	private String disposition;
	@Schema(description = "Referring/Auth Number")
	@JsonProperty("Ref/Auth Number")
	private String refAuthNumber;
	@Schema(description = "Indicator used for service related to Early Periodic Screening, Diagnosis and Treatment(EPSDT)")
	private String epsdtIndicator;
	@Schema(description = "CPT Code Description")
	private String cptCodeDesc;
	@Schema(description = "Modifier Code Description")
	private String modifierCodeDesc;
	@Schema(description = "Revenue Code")
	private String revenueCode;
	@Schema(description = "Minute")
	private String minute;
	@Schema(description = "UOS")
	private String uos;
	@Schema(description = "Primary Diagnosis")
	private String primaryDiagnosis;
	@Schema(description = "Other Diagnosis Code")
	private String otherDiagnosisCodes;
	@Schema(description = "Other Diagnosis Desc")
	private String userMessageCodeDesc;
	@Schema(description = "Place of Service")
	private String placeOfService;
	@Schema(description = "Non Covered Amount")
	private String nonCoveredAmount;
	@Schema(description = "Balance Billed Amount")
	private String balanceBilledAmount;
	@Schema(description = "Member Penalty")
	private String memberPenalty;
	@Schema(description = "Member Responsibility")
	private String memberResponsibility;
	@Schema(description = "Provider Penalty")
	private String providerPenalty;
	@Schema(description = "Bonus Amount")
	private String bonusAmount;
	@Schema(description = "Other Discount")
	private String otherDiscount;
	@Schema(description = "HCC Amount")
	private String hccAmount;
	@Schema(description = "Coordination of Benefit Paid")
	private String cobPaid;
	@Schema(description = "Coordination of Benefit Copay")
	private String cobCopay;
	@Schema(description = "Coordination of Benefit CoInsurance")
	private String cobConInsurance;
	@Schema(description = "Coordination of Benefit Deductible")
	private String cobDeductible;
	@Schema(description = "Coordination of Benefit Allowed")
	private String cobAllowed;
	@Schema(description = "Coordination of Benefit Discount")
	private String cobDiscount;
	@Schema(description = "Coordination of Benefit Member Penalty")
	private String cobMemberPenalty;
	@Schema(description = "Coordination of Benefit Member Responsibility")
	private String cobMemberResponsibility;
	@Schema(description = "Coordination of Benefit Provider Penalty")
	private String cobProviderPenalty;
	@Schema(description = "Coordination of Benefit Non Covered Amount")
	private String cobNonCoveredAmount;
	@Schema(description = "Coordination of Benefit Per Day Limit")
	private String cobPerDayLimit;
	@Schema(description = "Coordination of Benefit Tax Amount")
	private String cobTaxAmount;
	@Schema(description = "List of Claim Notes")
	private List<ClaimNotes> claimNote;
//	Added as part of Version2
	@Schema(description = "Rendering Practitioner ID")
	private String renderingPractitionerId;
	@Schema(description = "Rendering Practitioner Name")
	private String renderingPractitionerName;
	@Schema(description = "Rendering Practitioner NPI")
	private String renderingPractitionerNpi;
//	Added as part of v23.1 - CPB-2711
	@Schema(description = "Benefit Tier")
	private String benefitTier;
	@Schema(description = "Tier Name")
	private String tierName;
	@Schema(description = "Benefit Label")
	private String benefitLabel;
	//	Added as part of CPB-3167
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;
	//Added as part of API-351
	@Schema(description = "Benefit Network")
	private String benefitNetwork;
	//Added as part of API-1467
	@Schema(description = "Rejection Code and Description")
	private String rejectionCodeDesc;

}
