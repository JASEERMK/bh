package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MemberClaimSearchMapper implements RowMapper<ClaimSearchModel> {

	@Autowired
	DateUtils dateUtils;

	public String claimType;

	/**
	 * claim header details service for CRM
	 *
	 * @param rs
	 * @param i
	 * @return
	 * @throws SQLException
	 */

	@Override
	public ClaimSearchModel mapRow(ResultSet rs, int i) throws SQLException {
		var claimSearchModel = new ClaimSearchModel();
		claimSearchModel.setClaimNumber(rs.getString("claim_number"));
		claimSearchModel.setClaimStatus(rs.getString("claim_status"));

		if (claimType.equalsIgnoreCase("medical") || claimType.equalsIgnoreCase("dental") || claimType.equalsIgnoreCase(
				"vision")) {

			claimSearchModel.setDos(dateUtils.getFormattedApplicationDate((rs.getString("dos"))));
			claimSearchModel.setProviderName(rs.getString("provider_name"));
			if (claimType.equalsIgnoreCase("medical")) {
				claimSearchModel.setBilledAmount(rs.getString("billed_amount"));
			}
			if (claimType.equalsIgnoreCase("dental") || claimType.equalsIgnoreCase("vision")) {
				claimSearchModel.setDatePaid(dateUtils.getFormattedApplicationDate(rs.getString("payment_date")));
			}
		}

		if (claimType.equalsIgnoreCase("rx")) {
			claimSearchModel.setDrugName(rs.getString("drugwithdosage"));
			claimSearchModel.setDateFilled(dateUtils.getFormattedApplicationDate(rs.getString("filled_date")));
			claimSearchModel.setPharmacyName(rs.getString("PHARMACY_NAME"));
			claimSearchModel.setPrescriptionId(rs.getString("prescription_id"));
		}

		return claimSearchModel;
	}
}
