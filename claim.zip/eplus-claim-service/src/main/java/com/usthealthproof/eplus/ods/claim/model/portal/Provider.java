package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for provider details")
public class Provider implements Serializable {
	private static final long serialVersionUID = 1884057718040146945L;

	@Schema(description = "Unique identifier of the Provider")
	@JsonProperty("providerId")
	private String providerId;

	@Schema(description = "Provider name")
	@JsonProperty("name")
	private Name name;

	@Schema(description = "National Provider Identifier for this provider")
	@JsonProperty("providerNpi")
	private String providerNpi;

	@Schema(description = "Supplier Location ID", hidden = true)
	private String supplierLocationId;

	@Schema(description = "Practitioner ID", hidden = true)
	private String practitionerId;

	@Schema(description = "Practitioner Role ID", hidden = true)
	private String practitionerRoleId;

	@Schema(description = "Provider Tax ID")
	@JsonProperty("providerTaxId")
	private String providerTaxId;
}
