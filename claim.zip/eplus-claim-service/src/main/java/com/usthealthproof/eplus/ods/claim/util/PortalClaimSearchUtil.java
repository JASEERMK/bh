package com.usthealthproof.eplus.ods.claim.util;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.mapper.portal.ClaimHeaderSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedCaseInsensitiveMap;

import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Component
@Slf4j
public class PortalClaimSearchUtil {
	@Autowired
	private JdbcTemplate integrationJdbcTemplate;
	@Autowired
	private ClaimHeaderSearchMapper claimHeaderSearchMapper;
	public  List<ClaimSearchModel> getClaimSearchResult(ClaimSearchRequest claimSearchRequest, String storedProcedure) throws SQLException {
		log.info("Inside getClaimSearchResult() in PortalClaimSearchUtil class");
		
		List<ClaimSearchModel> claimSearchModelList;
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(integrationJdbcTemplate).withProcedureName(storedProcedure)
				.declareParameters(new SqlParameter("MEMBER_NUMBER", Types.VARCHAR), new SqlParameter("CLAIM_NUMBER", Types.VARCHAR),
						new SqlParameter("SERVICE_START_DATE_HEADER", Types.DATE), new SqlParameter("SERVICE_END_DATE_HEADER", Types.DATE),
						new SqlOutParameter(ClaimConstants.RETURN_STATUS, Types.NUMERIC)).returningResultSet(ClaimConstants.RESULT_SET, claimHeaderSearchMapper);
		long startServiceRequestTime = System.currentTimeMillis();
		Map<String, Object> out = simpleJdbcCall.execute(claimSearchRequest.getMemberNumber(), claimSearchRequest.getClaimNumber(), claimSearchRequest.getServiceFromDate(),
				claimSearchRequest.getServiceToDate(), 0);
		long endServiceRequestTime = System.currentTimeMillis();
		log.debug("Details out {}", out);
		if (out.get(ClaimConstants.RETURN_STATUS).toString().equalsIgnoreCase("1.0000")) {
			log.info("Error occurred while executing the SP {}", out.get(ClaimConstants.RESULT_SET2));
			List<LinkedCaseInsensitiveMap<String>> errorCodeList = (List<LinkedCaseInsensitiveMap<String>>) out.get(ClaimConstants.RESULT_SET2);
			throw new SQLException(errorCodeList.get(0).get("ErrorMessage"));
		}
		claimSearchModelList = (List<ClaimSearchModel>) out.get(ClaimConstants.RESULT_SET);
		log.info("Query execution time for {} is {}", storedProcedure, endServiceRequestTime - startServiceRequestTime);
		return claimSearchModelList;
	}
	@Async("asyncExecutor")
	public CompletableFuture<List<ClaimSearchModel>> getAllClaimSearchResult(ClaimSearchRequest claimSearchRequest, String storedProcedure)
			throws SQLException {
		log.info("Inside getAllClaimSearchResult() in PortalClaimSearchUtil class class");
		log.info("Going to execute {}", storedProcedure);
		List<ClaimSearchModel> claimSearchModelList = getClaimSearchResult(claimSearchRequest, storedProcedure);
		return CompletableFuture.completedFuture(claimSearchModelList);
	}
	public ClaimSearchResponse setClaimSearchResponse(List<ClaimSearchModel> claimSearchModelList) {
		log.info("Inside setClaimSearchResponse() in PortalClaimSearchUtil class");
		ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();
		if (!CollectionUtils.isEmpty(claimSearchModelList)) {
			claimSearchResponse.setResults(claimSearchModelList);
			claimSearchResponse.setCount(claimSearchModelList.size());
			claimSearchResponse.setStatus(ClaimConstants.SUCCESS);
		}
		return claimSearchResponse;
	}

	public List<ClaimSearchModel> getProviderClaimSearchResult(ClaimSearchRequest claimSearchRequest, String storedProcedure) throws SQLException {
		log.info("Inside getProviderClaimSearchResult() in PortalClaimSearchUtil class");
		List<ClaimSearchModel> claimSearchModelList;

		String excludedProviders = claimSearchRequest.getExcludedProvider().stream()
				.collect(Collectors.joining(","));
		String includedProviders = claimSearchRequest.getIncludedProvider().stream()
				.collect(Collectors.joining(","));
		String includedMedicalGroups = claimSearchRequest.getIncludedMedicalGroups().stream()
				.collect(Collectors.joining(","));
		String excludedMedicalGroups = claimSearchRequest.getExcludedMedicalGroups().stream()
				.collect(Collectors.joining(","));

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(integrationJdbcTemplate).withProcedureName(storedProcedure)
				.declareParameters(new SqlParameter("member_hcc_id", Types.VARCHAR), new SqlParameter("claim_hcc_id", Types.VARCHAR),
						new SqlParameter("service_start_date", Types.DATE), new SqlParameter("service_end_date", Types.DATE),
						new SqlParameter("excluded_medical_groups", Types.VARCHAR), new SqlParameter("included_medical_groups", Types.VARCHAR),
						new SqlParameter("excluded_providers", Types.VARCHAR), new SqlParameter("included_providers", Types.VARCHAR),
						new SqlOutParameter(ClaimConstants.RETURN_STATUS, Types.NUMERIC)).returningResultSet(ClaimConstants.RESULT_SET, claimHeaderSearchMapper);

		long startServiceRequestTime = System.currentTimeMillis();
		Map<String, Object> out = simpleJdbcCall.execute(claimSearchRequest.getMemberNumber(), claimSearchRequest.getClaimNumber(),
				claimSearchRequest.getServiceFromDate(), claimSearchRequest.getServiceToDate(),
				excludedMedicalGroups,includedMedicalGroups,excludedProviders,includedProviders, 0);
		long endServiceRequestTime = System.currentTimeMillis();

		log.debug("Details out {}", out);
		if (out.get(ClaimConstants.RETURN_STATUS).toString().equalsIgnoreCase("1.0000")) {
			log.info("Error occurred while executing the SP {}", out.get(ClaimConstants.RESULT_SET2));
			List<LinkedCaseInsensitiveMap<String>> errorCodeList = (List<LinkedCaseInsensitiveMap<String>>) out.get(ClaimConstants.RESULT_SET2);
			throw new SQLException(errorCodeList.get(0).get("ErrorMessage"));
		}

		claimSearchModelList = (List<ClaimSearchModel>) out.get(ClaimConstants.RESULT_SET);
		log.info("Query execution time for {} is {}", storedProcedure, endServiceRequestTime - startServiceRequestTime);
		return claimSearchModelList;
	}

	@Async("asyncExecutor")
	public CompletableFuture<List<ClaimSearchModel>> getProviderAllClaimSearchResult(ClaimSearchRequest claimSearchRequest, String storedProcedure)
			throws SQLException {
		log.info("Inside getProviderAllClaimSearchResult() in portalClaimSearchUtil class");
		log.info("Going to execute {}", storedProcedure);
		List<ClaimSearchModel> claimSearchModelList = getProviderClaimSearchResult(claimSearchRequest, storedProcedure);
		return CompletableFuture.completedFuture(claimSearchModelList);
	}
}
