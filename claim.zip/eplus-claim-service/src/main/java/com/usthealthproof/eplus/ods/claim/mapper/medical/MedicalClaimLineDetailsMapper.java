package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.mapper.util.APIUtils;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MedicalClaimLineDetailsMapper implements RowMapper<MedicalClaimLineDetails> {

	@Autowired
	private DateUtils dateUtils;
	@Autowired
	private APIUtils apiUtils;

	@Override
	public MedicalClaimLineDetails mapRow(ResultSet rs, int i) throws SQLException {

		var medicalClaimLineDetails = new MedicalClaimLineDetails();
		medicalClaimLineDetails.setClaimLineNumber(rs.getString("claimLineNumber"));
		medicalClaimLineDetails.setClaimHccId(rs.getString("claimHccId"));
		medicalClaimLineDetails.setClaimLineKey(rs.getString("claimLineKey"));
		medicalClaimLineDetails.setBilledAmount(rs.getString("billedAmount"));
		medicalClaimLineDetails.setDenied(rs.getString("denied"));
		medicalClaimLineDetails.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		medicalClaimLineDetails.setServiceEndDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceEndDate")));
		medicalClaimLineDetails.setPlaceOfService(rs.getString("POScode_desc"));
		medicalClaimLineDetails.setDeductibleAmount(rs.getString("DeductibleAmount"));
		medicalClaimLineDetails.setCoinsuranceAmount(rs.getString("CoInsuranceAmount"));
		medicalClaimLineDetails.setCopayAmount(rs.getString("CopayAmount"));
		medicalClaimLineDetails.setPaidAmount(rs.getString("paidAmount"));
		medicalClaimLineDetails.setCptCodeDesc(rs.getString("CPTcode_desc"));
		medicalClaimLineDetails.setModifierCodeDesc(rs.getString("modifier_code_desc"));
		medicalClaimLineDetails.setRevenueCode(rs.getString("RevenueCode"));
		medicalClaimLineDetails.setMinute(rs.getString("Minute"));
		medicalClaimLineDetails.setUos(rs.getString("UOS"));
		medicalClaimLineDetails.setPrimaryDiagnosis(rs.getString("primary_diagnosis"));
		medicalClaimLineDetails.setOtherDiagnosisCodes(rs.getString("otherdiagnosiscodes"));
		medicalClaimLineDetails.setUserMessageCodeDesc(rs.getString("user_message_code_desc"));
		medicalClaimLineDetails.setNonCoveredAmount(rs.getString("NonCoveredAmount"));
		medicalClaimLineDetails.setBalanceBilledAmount(rs.getString("balance_billed_amount"));
		medicalClaimLineDetails.setMemberPenalty(rs.getString("MemberPenalty"));
		medicalClaimLineDetails.setMemberResponsibility(rs.getString("MemberResponsibility"));
		medicalClaimLineDetails.setProviderPenalty(rs.getString("ProviderPenalty"));
		medicalClaimLineDetails.setBonusAmount(rs.getString("BonusAmount"));
		medicalClaimLineDetails.setOtherDiscount(rs.getString("OtherDiscount"));
		medicalClaimLineDetails.setHccAmount(rs.getString("HCCAmount"));
		medicalClaimLineDetails.setCobPaid(rs.getString("cob_paid"));
		medicalClaimLineDetails.setCobCopay(rs.getString("cob_copay"));
		medicalClaimLineDetails.setCobConInsurance(rs.getString("cob_coninsurance"));
		medicalClaimLineDetails.setCobDeductible(rs.getString("cob_deductible"));
		medicalClaimLineDetails.setCobAllowed(rs.getString("cob_allowed"));
		medicalClaimLineDetails.setCobDiscount(rs.getString("cob_discount"));
		medicalClaimLineDetails.setCobMemberPenalty(rs.getString("cob_member_penalty"));
		medicalClaimLineDetails.setCobMemberResponsibility(rs.getString("cob_member_responsiblity"));
		medicalClaimLineDetails.setCobProviderPenalty(rs.getString("cob_provider_penalty"));
		medicalClaimLineDetails.setCobNonCoveredAmount(rs.getString("cob_non_covered_amount"));
		medicalClaimLineDetails.setCobPerDayLimit(rs.getString("cob_per_day_limit"));
		medicalClaimLineDetails.setCobTaxAmount(rs.getString("cob_tax_amount"));
		medicalClaimLineDetails.setErrorLevel(rs.getString("Error_Level__c"));
		medicalClaimLineDetails.setExternalSource(rs.getString("externalSource"));
		medicalClaimLineDetails.setStatus(rs.getString("status"));
		medicalClaimLineDetails.setRefAuthNumber(rs.getString("Ref_Auth_Number__c"));
		medicalClaimLineDetails.setDisposition(rs.getString("status"));
		medicalClaimLineDetails.setEpsdtIndicator(rs.getString("epsdt_indicator"));
		medicalClaimLineDetails.setAllowedAmount(rs.getString("allowedamount"));
		medicalClaimLineDetails.setDisposition(rs.getString("Disposition__c"));
		medicalClaimLineDetails.setClaimNote(apiUtils.getClaimNotes(rs.getString("claim_note")));
		medicalClaimLineDetails.setDenialCodeDesc(rs.getString("description"));
		//		Added as part of Version2
		medicalClaimLineDetails.setRenderingPractitionerId(rs.getString("RenderingPractitionerID"));
		medicalClaimLineDetails.setRenderingPractitionerName(rs.getString("RenderingPractitionerName"));
		medicalClaimLineDetails.setRenderingPractitionerNpi(rs.getString("RenderingPractitionerNPI"));
		//		Added as part of v23.1 - CPB-2711
		medicalClaimLineDetails.setBenefitTier(rs.getString("benefit_tier_type"));
		medicalClaimLineDetails.setTierName(rs.getString("benefit_tier_name"));
		medicalClaimLineDetails.setBenefitLabel(rs.getString("benefit_label"));
		// Added as part of CPB-3167
		medicalClaimLineDetails.setClaimFactKey(rs.getString("claim_fact_key"));
		//Added as part of API-351
		medicalClaimLineDetails.setBenefitNetwork(rs.getString("benefit_network"));
		return medicalClaimLineDetails;
	}

}
