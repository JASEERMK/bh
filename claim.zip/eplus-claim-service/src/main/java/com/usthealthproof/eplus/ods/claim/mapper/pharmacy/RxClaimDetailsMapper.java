package com.usthealthproof.eplus.ods.claim.mapper.pharmacy;

import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class RxClaimDetailsMapper implements RowMapper<RxClaimDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public RxClaimDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		var rxClaimDetails = new RxClaimDetails();
		rxClaimDetails.setMemberId(rs.getString("member_hcc_id"));
		rxClaimDetails.setClaimId(rs.getString("claim_id"));
		rxClaimDetails.setDrugName(rs.getString("drug_name"));
		rxClaimDetails.setStatus(rs.getString("status"));
		rxClaimDetails.setPharmacyName(rs.getString("pharmacy_name"));
		rxClaimDetails.setPrescriptionId(rs.getString("prescription_id"));
		rxClaimDetails.setSourceSystem(rs.getString("source_system"));
		rxClaimDetails.setSourceSystemId(rs.getString("source_system_id"));
		rxClaimDetails.setAdjudicatedDate(dateUtils.getFormattedApplicationDate(rs.getString("adjudicated_date")));
		rxClaimDetails.setPrescriptionWrittenDate(
				dateUtils.getFormattedApplicationDate(rs.getString("prescription_written_date")));
		rxClaimDetails.setFilledDate(dateUtils.getFormattedApplicationDate(rs.getString("filled_date")));
		rxClaimDetails.setDosage(rs.getString("dosage"));
		rxClaimDetails.setQuantity(rs.getString("quantity"));
		rxClaimDetails.setDaysSupply(rs.getString("days_supply"));
		rxClaimDetails.setFillsCount(rs.getString("fills_count"));
		rxClaimDetails.setPriorAuthorizationId(rs.getString("prior_authorization_id"));
		rxClaimDetails.setPartbPartdInd(rs.getString("partb_partd_ind"));
		rxClaimDetails.setSpecialtyRxInd(rs.getString("specialty_rx_ind"));
		rxClaimDetails.setFormularyInd(rs.getString("formulary_ind"));
		rxClaimDetails.setFormularyTier(rs.getString("formulary_tier"));
		rxClaimDetails.setMaintenanceDrug(rs.getString("maintenance_drug"));
		rxClaimDetails.setDispensedAsWrittenType(rs.getString("dispensed_as_written_type"));
		rxClaimDetails.setDrugType(rs.getString("drug_type"));
		rxClaimDetails.setDrugCategoryType(rs.getString("drug_category_type"));
		rxClaimDetails.setPharmacyAddress(rs.getString("pharmacy_address"));
		rxClaimDetails.setPharmacyTelephoneNumber(rs.getString("pharmacy_telephone_number"));
		rxClaimDetails.setPharmacyDispenseType(rs.getString("pharmacy_dispense_type"));
		rxClaimDetails.setPrescribingPhysicianName(rs.getString("prescribing_physician_name"));
		rxClaimDetails.setPrescribingPhysicianAddress(rs.getString("prescribing_physician_address"));
		rxClaimDetails.setPrescribingPhysicianSpecialtyCode(rs.getString("prescribing_physician_specialty_code"));
		rxClaimDetails.setDiagnosis(rs.getString("diagnosis"));
		rxClaimDetails.setIngredientCostAmount(rs.getString("ingredient_cost_amount"));
		rxClaimDetails.setDispenseFeeAmount(rs.getString("dispense_fee_amount"));
		rxClaimDetails.setSalesTaxAmount(rs.getString("sales_tax_amount"));
		rxClaimDetails.setDeductibleAmount(rs.getString("deductible_amount"));
		rxClaimDetails.setCopayAmount(rs.getString("copay_amount"));
		rxClaimDetails.setCoinsuranceAmount(rs.getString("coinsurance_amount"));
		rxClaimDetails.setOutOfPocketAmount(rs.getString("out_of_pocket_amount"));
		rxClaimDetails.setMemberPaidAmount(rs.getString("member_paid_amount"));
		rxClaimDetails.setPlanPaidAmount(rs.getString("plan_paid_amount"));
		rxClaimDetails.setCobIndicator(rs.getString("cob_indicator"));
		rxClaimDetails.setCobPaidAmount(rs.getString("cob_paid_amount"));
		rxClaimDetails.setCheckNumber(rs.getString("check_number"));
		rxClaimDetails.setAdjustmentReason(rs.getString("adjustment_reason"));
		rxClaimDetails.setAdjustmentType(rs.getString("adjustment_type"));
		rxClaimDetails.setRejectCount(rs.getString("reject_count"));
		rxClaimDetails.setRejectMessage1(rs.getString("reject_message_1"));
		rxClaimDetails.setRejectMessage2(rs.getString("reject_message_2"));
		rxClaimDetails.setRejectMessage3(rs.getString("reject_message_3"));
		rxClaimDetails.setFirstFilledDate(rs.getString("first_filled_date"));
		//Added as part of 3134
		rxClaimDetails.setMemberName(rs.getString("member_name"));
		rxClaimDetails.setProviderId(rs.getString("prescribing_physician_id"));
		rxClaimDetails.setProviderName(rs.getString("prescribing_physician_name"));
		return rxClaimDetails;
	}

}
