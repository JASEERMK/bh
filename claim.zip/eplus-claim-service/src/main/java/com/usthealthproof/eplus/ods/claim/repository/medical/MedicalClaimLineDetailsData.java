package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Repository
@Slf4j
public class MedicalClaimLineDetailsData {

    @Autowired
    private AsyncExecutorUtils asyncExecutorUtils;

    private static final String MEDICAL_CLAIM_LINE_DETAILS_LOG = "MedicalClaimLineDetails";

    /**
     * get the claim line details of the particular claim number
     *
     * @param claimHccId
     * @param claimLineHccId
     * @param claimFactKey
     * @param state
     * @param lob
     * @param product
     * @return
     */
    public MedicalClaimLineDetails getClaimLineDetails(String claimHccId, String claimLineHccId, String claimFactKey, String state, String lob, String product) throws Exception {
        log.info("Inside getClaimLineDetails() in MedicalClaimLineDetailsData class");

        MedicalClaimLineDetails claimLineDetail = null;
        CompletableFuture<MedicalClaimLineDetails> lineDetailsCompletableFuture = null;
        try {
            CompletableFuture<List<ClaimRejectionDetails>> rejectionCodesCompletableFuture = asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
            CompletableFuture<String> rejectionCodeDesc = rejectionCodesCompletableFuture
                    .thenApply(list -> Optional.ofNullable(list)
                            .orElse(Collections.emptyList())
                            .stream()
                            .map(ClaimRejectionDetails::getRejectionCodeDesc)
                            .findFirst()
                            .orElse("")
                    );

            log.info("Going for ClaimLineDetails DB call");
            if (StringUtils.isNotBlank(claimFactKey)) {
                lineDetailsCompletableFuture = asyncExecutorUtils.getMedicalClaimLineDetailsWithFactKey(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
            } else {
                lineDetailsCompletableFuture = asyncExecutorUtils.getMedicalClaimLineDetailsWithoutFactKey(claimHccId, claimLineHccId, state, lob, product);
            }
            if (lineDetailsCompletableFuture != null && lineDetailsCompletableFuture.get() !=null) {
                claimLineDetail = lineDetailsCompletableFuture.get();
            }
            if (claimLineDetail != null && rejectionCodeDesc !=null && rejectionCodeDesc.get() != null) {
                claimLineDetail.setRejectionCodeDesc(rejectionCodeDesc.get());
            }
			log.debug("ClaimLineDetailsResponse : {}", claimLineDetail);
        } catch (ExecutionException executionException) {
            log.error("ExecutionException occurred : ", executionException);
            if (executionException.getCause() instanceof ClaimNotFoundException || executionException.getCause() instanceof EmptyResultDataAccessException) {
                log.error("EmptyResultDataAccessException occurred for the MedicalClaimLineDetails service request.");
                throw new ClaimNotFoundException(
                        ClaimConstants.CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId + " and claim line number : " + claimLineHccId);
            } else {
                log.error("ExecutionException other than EmptyResultDataAccessException or ClaimNotFoundException occurred.");
                throw new Exception();
            }
        } catch (CannotGetJdbcConnectionException jdbcException) {
            log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + MEDICAL_CLAIM_LINE_DETAILS_LOG);
            throw jdbcException;
        } catch (EmptyResultDataAccessException emptyResultException) {
            log.error("EmptyResultDataAccessException occurred for the MedicalClaimLineDetails service request and the exception is: ",
                    emptyResultException);
            throw new ClaimNotFoundException(
                    ClaimConstants.CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId + " and claim line number : " + claimLineHccId);

        } catch (Exception ex) {
            log.error(ClaimConstants.EXCEPTION_MESSAGE + MEDICAL_CLAIM_LINE_DETAILS_LOG);
            throw ex;
        }
        log.info("MedicalClaimLineDetails data fetched successfully!!!");
        return claimLineDetail;
    }
}
