package com.usthealthproof.eplus.ods.claim.model.portal.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonPropertyOrder({ "claimNumber", "claimStatus", "claimType", "serviceDate", "receiveDate", "processDate", "paidDate",
		"patient", "provider", "totalSubmittedAmount", "totalPaidAmount","totalBilledAmount"})
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim search details")
public class ClaimSearchModel {

	@Schema(description = "Claim number")
	@JsonProperty("claimNumber")
	private String claimNumber;

	@Schema(description = "Service date")
	@JsonProperty("serviceDate")
	private String serviceDate;

	@Schema(description = "Receive date")
	@JsonProperty("receiveDate")
	private String receiveDate;

	@Schema(description = "Process date")
	@JsonProperty("processDate")
	private String processDate;

	@Schema(description = "Paid date")
	@JsonProperty("paidDate")
	private String paidDate;

	@JsonProperty("patient")
	@Schema(description = "Patient")
	private Patient patient;

	@JsonProperty("provider")
	@Schema(description = "Provider")
	private Provider provider;

	@Schema(description = "Claim status")
	@JsonProperty("claimStatus")
	private String claimStatus;

	@Schema(description = "Claim type")
	@JsonProperty("claimType")
	private String claimType;

	@Schema(description = "Total submitted amount")
	@JsonProperty("totalSubmittedAmount")
	private String totalSubmittedAmount;

	@Schema(description = "total paid amount")
	@JsonProperty("totalPaidAmount")
	private String totalPaidAmount;

	@Schema(description = "Total billed amount")
	@JsonProperty("totalBilledAmount")
	private String totalBilledAmount;

}
