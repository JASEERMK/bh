package com.usthealthproof.eplus.ods.claim.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ClaimNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -4579912482375101659L;
	/**
	 * claim not found exception with message
	 * 
	 * @param message
	 */
	public ClaimNotFoundException(String message) {
		super(message);
	}
}
