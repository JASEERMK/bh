package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class VisionClaimDetailsMapper implements RowMapper<VisionClaimDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public VisionClaimDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		var visionClaimDetails = new VisionClaimDetails();
		visionClaimDetails.setMemberId(rs.getString("memberKey"));
		visionClaimDetails.setInsureId(rs.getString("insurer_id"));
		visionClaimDetails.setInsurerName(rs.getString("insurere_name"));
		visionClaimDetails.setProviderId(rs.getString("providerKey"));
		visionClaimDetails.setProviderName(rs.getString("provider_name"));
		visionClaimDetails.setFromDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		visionClaimDetails.setEndDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceEndDate")));
		visionClaimDetails.setLocationId(rs.getString("location_id"));
		visionClaimDetails.setLocationName(rs.getString("location_name"));
		visionClaimDetails.setPayeeId(rs.getString("payee_other_id"));
		visionClaimDetails.setPayeeName(rs.getString("payee_other_name"));
		visionClaimDetails.setNetworkId(rs.getString("network_id"));
		visionClaimDetails.setNetworkName(rs.getString("network_name"));
		visionClaimDetails.setReceivedDate(dateUtils.getFormattedApplicationDate(rs.getString("claim_received_date")));
		visionClaimDetails.setEnteredDate(dateUtils.getFormattedApplicationDate(rs.getString("claim_entered_date")));
		visionClaimDetails.setPaymentDate(dateUtils.getFormattedApplicationDate(rs.getString("Payment_Date")));
		visionClaimDetails.setCheckNumber(rs.getString("Payment_Number"));
		visionClaimDetails.setPaidAmount(rs.getString("paid_amount"));
		visionClaimDetails.setNetPaidAmount(rs.getString("net_paid_amount"));
		visionClaimDetails.setBilledAmount(rs.getString("billedAmount"));
		visionClaimDetails.setAllowedAmount(rs.getString("allowed"));
		visionClaimDetails.setDeductibleAmount(rs.getString("deductible"));
		visionClaimDetails.setCopayAmount(rs.getString("co_pay"));
		visionClaimDetails.setCoinsuranceAmount(rs.getString("coinsurance_amount"));
		visionClaimDetails.setOverMax(rs.getString("over_max"));
		visionClaimDetails.setCobAmount(rs.getString("cob_amount"));
		visionClaimDetails.setOriginalPaidAmount(rs.getString("paid_amount"));
		visionClaimDetails.setPaymentStatus(rs.getString("payment_status"));
		visionClaimDetails.setPayMember(rs.getString("pay_member"));
		visionClaimDetails.setPaymentNotes(rs.getString("payment_notes"));
		visionClaimDetails.setEftFlag(rs.getString("eft_flag"));
		visionClaimDetails.setEftAccount(rs.getString("eft_account"));
		visionClaimDetails.setCheckCleared(rs.getString("check_cleared"));
		visionClaimDetails.setPaymentAmount(rs.getString("payment_amount"));
		visionClaimDetails.setCreatedBy(rs.getString("createdBy"));
		visionClaimDetails.setLastModifiedBy(rs.getString("lastModifiedBy"));
		//Added as part of cpb3134
		visionClaimDetails.setMemberName(rs.getString("member_name"));
		return visionClaimDetails;
	}

}
