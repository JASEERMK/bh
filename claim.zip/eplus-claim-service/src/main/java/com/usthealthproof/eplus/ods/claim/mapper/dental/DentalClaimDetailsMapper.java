package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class DentalClaimDetailsMapper implements RowMapper<DentalClaimDetails> {

	@Autowired
	private DateUtils dateUtils;

	@Override
	public DentalClaimDetails mapRow(ResultSet rs, int i) throws SQLException {

		var dentalClaimDetails = new DentalClaimDetails();
		dentalClaimDetails.setMemberId(rs.getString("memberKey"));
		dentalClaimDetails.setPayMember(rs.getString("pay_member"));
		dentalClaimDetails.setInsurerId(rs.getString("insurer_id"));
		dentalClaimDetails.setInsurerName(rs.getString("insurer_name"));
		dentalClaimDetails.setProviderKey(rs.getString("providerKey"));
		dentalClaimDetails.setProviderId(rs.getString("providerKey"));
		dentalClaimDetails.setProviderName(rs.getString("provider_name"));
		dentalClaimDetails.setServiceStartDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceStartDate")));
		dentalClaimDetails.setServiceEndDate(dateUtils.getFormattedApplicationDate(rs.getString("serviceEndDate")));
		dentalClaimDetails.setLocationId(rs.getString("location_id"));
		dentalClaimDetails.setLocationName(rs.getString("location_name"));
		dentalClaimDetails.setPayeeOtherId(rs.getString("payee_other_id"));
		dentalClaimDetails.setPayeeOtherName(rs.getString("payee_other_name"));
		dentalClaimDetails.setNetworkId(rs.getString("network_id"));
		dentalClaimDetails.setNetworkName(rs.getString("network_name"));
		dentalClaimDetails.setClaimReceivedDate(dateUtils.getFormattedApplicationDate(rs.getString("claim_received_date")));
		dentalClaimDetails.setClaimEnteredDate(dateUtils.getFormattedApplicationDate(rs.getString("claim_entered_date")));
		dentalClaimDetails.setMissingTeeth(rs.getString("missing_teeth"));
		dentalClaimDetails.setPaymentDate(dateUtils.getFormattedApplicationDate(rs.getString("Payment_Date")));
		dentalClaimDetails.setPaymentNumber(rs.getString("Payment_Number"));
		dentalClaimDetails.setNetPaidAmount(rs.getString("net_paid_amount"));
		dentalClaimDetails.setBilledAmount(rs.getString("billedAmount"));
		dentalClaimDetails.setAllowed(rs.getString("allowed"));
		dentalClaimDetails.setPaidAmount(rs.getString("paid_amount"));
		dentalClaimDetails.setDeductible(rs.getString("deductible"));
		dentalClaimDetails.setCoPay(rs.getString("co_pay"));
		dentalClaimDetails.setCoinsuranceAmount(rs.getString("coinsurance_amount"));
		dentalClaimDetails.setOverMax(rs.getString("over_max"));
		dentalClaimDetails.setCobAmount(rs.getString("cob_amount"));
		dentalClaimDetails.setPaymentStatus(rs.getString("payment_status"));
		dentalClaimDetails.setPaymentNotes(rs.getString("payment_notes"));
		dentalClaimDetails.setEftFlag(rs.getString("eft_flag"));
		dentalClaimDetails.setEftAccount(rs.getString("eft_account"));
		dentalClaimDetails.setCheckCleared(rs.getString("check_cleared"));
		dentalClaimDetails.setCreatedBy(rs.getString("created_by"));
		dentalClaimDetails.setLastModifiedBy(rs.getString("last_modified_by"));
		//Added as part of 3134
		dentalClaimDetails.setMemberName(rs.getString("pay_member"));
		return dentalClaimDetails;
	}

}
