package com.usthealthproof.eplus.ods.claim.model.portal;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class Container {

	private Boolean exclude;
	private String type;
	private List<String> entity_ids;
}
