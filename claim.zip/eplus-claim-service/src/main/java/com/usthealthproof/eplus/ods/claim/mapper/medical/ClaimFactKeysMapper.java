package com.usthealthproof.eplus.ods.claim.mapper.medical;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class ClaimFactKeysMapper implements RowMapper<String> {

	@Override
	public String mapRow(ResultSet rs, int i) throws SQLException {

		return rs.getString("CLAIM_FACT_KEY");
	}

}
