package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@JsonPropertyOrder({ "firstName", "lastName", "middleName", "prefix", "suffix" })
@Schema(description = "Wrapper class for name details")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name implements Serializable {

	private static final long serialVersionUID = 4750991263296071617L;
	@Schema(description = "First name")
	@JsonProperty("firstName")
	private String firstName;

	@Schema(description = "Last name")
	@JsonProperty("lastName")
	private String lastName;

	@Schema(description = "Middle name")
	@JsonProperty("middleName")
	private String middleName;

	@Schema(description = "Name prefix(e.g. Mr, Ms, Mrs,Dr)")
	@JsonProperty("prefix")
	private String prefix;

	@Schema(description = "Name suffix(e.g. Jr, II, III)")
	@JsonProperty("suffix")
	private String suffix;

}
