package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

@Repository
@Slf4j
public class DentalClaimLineDetailsData {

	@Autowired
	private DentalClaimLineDetailsMapper dentalClaimLineDetailsMapper;
	@Value("${claims.spDentalClaimLineDetails}")
	String spDentalClaimLineDetails;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * get the Dental claim line details of the particular claim number
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @return
	 */
	public DentalClaimLineDetails getDentalClaimLineDetails(String claimHccId, String claimLineHccId, String state, String lob, String product) {
		log.info("Inside getDentalClaimLineDetails() in DentalClaimLineDetailsData class");

		DentalClaimLineDetails dentalClaimLineDetail;
		try {
			MapSqlParameterSource dentalClaimLineDetailParams = new MapSqlParameterSource().addValue("claimId",
					claimHccId, Types.VARCHAR)
					.addValue("claimLineId", claimLineHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String dentalClaimLineDetailSql = "{CALL " + spDentalClaimLineDetails
					+ "(:claimId, :claimLineId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			dentalClaimLineDetail = namedParameterJdbcTemplate.queryForObject(dentalClaimLineDetailSql, dentalClaimLineDetailParams,
					dentalClaimLineDetailsMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spDentalClaimLineDetails,
                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", dentalClaimLineDetail);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + "DentalClaimLineDetails");
			throw jdbcException;
		} catch (EmptyResultDataAccessException emptyResultException) {
			log.error(
					"EmptyResultDataAccessException occurred for the DentalClaimLineDetails service request and the exception is: ",
					emptyResultException);
			throw new ClaimNotFoundException(ClaimConstants.DENTAL_CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId
					+ " and claim line number : " + claimLineHccId);
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + "DentalClaimLineDetails");
			throw ex;
		}
		log.info("DentalClaimLineDetails data fetched successfully.");
		return dentalClaimLineDetail;
	}

}
