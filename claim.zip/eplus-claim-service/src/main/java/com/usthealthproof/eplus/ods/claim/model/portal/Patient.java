package com.usthealthproof.eplus.ods.claim.model.portal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for patient details")
public class Patient implements Serializable {

	private static final long serialVersionUID = 8197080178697684387L;
	@Schema(description = "Member Number")
	@JsonProperty("memberNumber")
	private String memberNumber;

	@Schema(description = "Patient name")
	@JsonProperty("name")
	private Name name;

}
