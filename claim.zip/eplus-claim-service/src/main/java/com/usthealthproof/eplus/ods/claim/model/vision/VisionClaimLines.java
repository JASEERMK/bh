package com.usthealthproof.eplus.ods.claim.model.vision;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing vision claim lines")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class VisionClaimLines implements Serializable {
	private static final long serialVersionUID = -5266418191711309774L;

	@Schema(description = "Claim Line ID")
	private String claimLineNumber;
	@Schema(description = "Unique Identifier of the Vision Claim")
	private String claimHccId;
	@Schema(description = "status")
	private String status;
	@Schema(description = "Start Date of the Vision Claim")
	private String serviceStartDate;

}
