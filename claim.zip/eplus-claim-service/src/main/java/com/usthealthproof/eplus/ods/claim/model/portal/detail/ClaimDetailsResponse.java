package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response class containing claim details")
public class ClaimDetailsResponse implements Serializable {

	private static final long serialVersionUID = 6449185798426888339L;
	@Schema(description = "Claim details")
	private ClaimDetails results;
	@Schema(description = "Response Status: SUCCESS or FAILURE")
	private String status;

}
