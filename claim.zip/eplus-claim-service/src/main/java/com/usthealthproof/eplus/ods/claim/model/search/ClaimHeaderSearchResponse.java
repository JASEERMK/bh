package com.usthealthproof.eplus.ods.claim.model.search;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Wrapper class containing response of claim search details")
public class ClaimHeaderSearchResponse implements Serializable {

	private static final long serialVersionUID = -803678982375984053L;
	@Schema(description = "Results")
	private List<ClaimSearchModel> results;
	@Schema(description = "Flag to indicate whether there is any data available for the request", hidden = true)
	private String dataAvailabilityFlag;

}
