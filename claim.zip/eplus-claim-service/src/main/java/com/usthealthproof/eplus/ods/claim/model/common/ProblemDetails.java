package com.usthealthproof.eplus.ods.claim.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Problem Details class")
public class ProblemDetails implements Serializable {
	private static final long serialVersionUID = 1375014372202494792L;
	@Schema(description = "Error Information")
	private List<String> errors;
	@Schema(description = "Error Status like SUCCESS or FAILURE")
	private String status;

}
