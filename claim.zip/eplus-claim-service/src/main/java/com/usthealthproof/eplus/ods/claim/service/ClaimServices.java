package com.usthealthproof.eplus.ods.claim.service;

import java.sql.SQLException;
import java.util.List;

import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.repository.denialcode.DenialCodeSearchData;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimDetailsData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimLinesData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimLinesData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalExternalMessageDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.pharmacy.RxClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimLinesData;

@Service
public class ClaimServices {

	@Autowired
	private MedicalClaimDetailsData medicalClaimDetailsData;
	@Autowired
	private MedicalClaimLineDetailsData medicalClaimLineDetailsData;
	@Autowired
	private MedicalClaimLinesData medicalClaimLinesData;
	@Autowired
	private VisionClaimLineDetailsData visionClaimLineDetailsData;
	@Autowired
	private VisionClaimDetailsData visionClaimDetailsData;
	@Autowired
	private VisionClaimLinesData visionClaimLinesData;
	@Autowired
	private DentalClaimDetailsData dentalClaimDetailsData;
	@Autowired
	private DentalClaimLineDetailsData dentalClaimLineDetailsData;
	@Autowired
	private DentalClaimLinesData dentalClaimLinesData;
	@Autowired
	private RxClaimDetailsData rxClaimDetailsData;
	@Autowired
	private MedicalExternalMessageDetailsData medicalExternalMessageDetailsData;
	@Autowired
	private ClaimDetailsData claimDetailsData;
	@Autowired
	private DenialCodeSearchData denialCodeSearchData;

	public MedicalClaimDetails findClaimId(String claimHccId, String claimFactKey, String state, String lob, String product)
			throws Exception {
		return medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
	}

	public List<MedicalClaimLines> getClaimLines(String claimHccId, String claimFactKey, String state, String lob,
			String product) throws Exception {
		return medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);
	}

	public MedicalClaimLineDetails getClaimLineDetails(String claimHccId, String claimLineHccId, String claimFactKey,
			String state, String lob, String product) throws Exception {
		return medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
	}

	public VisionClaimDetails findVisionClaimId(String claimHccId, String state, String lob, String product) {
		return visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product);
	}

	public List<VisionClaimLines> getVisionClaimLines(String claimHccId, String state, String lob, String product) {
		return visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product);
	}

	public VisionClaimLineDetails getVisionClaimLineDetails(String claimHccId, String claimLineHccId, String state, String lob,
			String product) {
		return visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
	}

	public DentalClaimDetails findDentalClaimId(String claimHccId, String state, String lob, String product) {
		return dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product);
	}

	public List<DentalClaimLines> getDentalClaimLines(String claimHccId, String state, String lob, String product) {
		return dentalClaimLinesData.getDentalClaimLines(claimHccId, state, lob, product);
	}

	public DentalClaimLineDetails getDentalClaimLineDetails(String claimHccId, String claimLineHccId, String state, String lob,
			String product) {
		return dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
	}

	public RxClaimDetails findRxClaimId(String claimHccId, String state, String lob, String product) {
		return rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product);
	}

	public List<MedicalExternalMessage> getExternalMessageDetails(String claimHccId, String claimLineHccId, String claimFactKey,
			String state, String lob, String product) {
		return medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob,
				product);

	}

	public ClaimDetailsResponse getClaimDetailsInfo(ClaimDetailsRequest claimDetailsRequest) throws SQLException {
		return claimDetailsData.getClaimDetailsInfo(claimDetailsRequest);
	}

	public DenialCodes getDenialCodes(String claimHccId, String state, String lob, String product) {
		return denialCodeSearchData.getDenialCodes(claimHccId,state,lob,product);
	}

}
