package com.usthealthproof.eplus.ods.claim.model.pharmacy;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(description = "Response class containing Rx claim details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class RxClaimDetails implements Serializable {
	private static final long serialVersionUID = 3774024749927375867L;
	@Schema(description = "Member ID")
	private String memberId;
	@Schema(description = "Claim ID")
	private String claimId;
	@Schema(description = "Drug Name")
	private String drugName;
	@Schema(description = "Filled Date")
	private String filledDate;
	@Schema(description = "Status")
	private String status;
	@Schema(description = "Name of Pharmacy")
	private String pharmacyName;
	@Schema(description = "Prescription ID")
	private String prescriptionId;
	@Schema(description = "Source System")
	private String sourceSystem;
	@Schema(description = "Identifier of Source System")
	private String sourceSystemId;
	@Schema(description = "Adjudicated Date")
	private String adjudicatedDate;
	@Schema(description = "Date on which prescription was written")
	private String prescriptionWrittenDate;
	@Schema(description = "Dosage")
	private String dosage;
	@Schema(description = "Quantity")
	private String quantity;
	@Schema(description = "Days Supply")
	private String daysSupply;
	@Schema(description = "Fills Count")
	private String fillsCount;
	@Schema(description = "Prior Authorization ID")
	private String priorAuthorizationId;
	@Schema(description = "PartB PartD Ind")
	private String partbPartdInd;
	@Schema(description = "Specialty Rx Ind")
	private String specialtyRxInd;
	@Schema(description = "Formulary Ind")
	private String formularyInd;
	@Schema(description = "Formulary Tier")
	private String formularyTier;
	@Schema(description = "Maintenance Drug")
	private String maintenanceDrug;
	@Schema(description = "Dispensed as Written Type")
	private String dispensedAsWrittenType;
	@Schema(description = "Type of Drug")
	private String drugType;
	@Schema(description = "Category Type of Drug")
	private String drugCategoryType;
	@Schema(description = "Pharmacy Address")
	private String pharmacyAddress;
	@Schema(description = "Telephone Number of Pharmacy")
	private String pharmacyTelephoneNumber;
	@Schema(description = "Pharmacy's Dispense Type")
	private String pharmacyDispenseType;
	@Schema(description = "Name of Prescribing Physician")
	private String prescribingPhysicianName;
	@Schema(description = "Address of Prescribing Physician")
	private String prescribingPhysicianAddress;
	@Schema(description = "Specialty Code of Prescribing Physician")
	private String prescribingPhysicianSpecialtyCode;
	@Schema(description = "Diagnosis")
	private String diagnosis;
	@Schema(description = "Ingredient Cost Amount")
	private String ingredientCostAmount;
	@Schema(description = "Dispense Fee Amount")
	private String dispenseFeeAmount;
	@Schema(description = "Amount of Sales Tax")
	private String salesTaxAmount;
	@Schema(description = "Deductible Amount")
	private String deductibleAmount;
	@Schema(description = "Copay Amount")
	private String copayAmount;
	@Schema(description = "Coinsurance Amount")
	private String coinsuranceAmount;
	@Schema(description = "OutOfPocket Amount")
	private String outOfPocketAmount;
	@Schema(description = "Amount Paid by Member")
	private String memberPaidAmount;
	@Schema(description = "Plan Paid Amount")
	private String planPaidAmount;
	@Schema(description = "COB Indicator")
	private String cobIndicator;
	@Schema(description = "Amount Paid for COB")
	private String cobPaidAmount;
	@Schema(description = "Check Number")
	private String checkNumber;
	@Schema(description = "Reason for Adjustment")
	private String adjustmentReason;
	@Schema(description = "Type of Adjustment")
	private String adjustmentType;
	@Schema(description = "Reject Count")
	private String rejectCount;
	@Schema(description = "Reject Message 1")
	private String rejectMessage1;
	@Schema(description = "Reject Message 2")
	private String rejectMessage2;
	@Schema(description = "Reject Message 3")
	private String rejectMessage3;
	@Schema(description = "First Filled Date")
	private String firstFilledDate;
	//Added as part of 3134
	@Schema(description = "Member Name")
	private String memberName;
	@Schema(description = "Provider ID")
	private String providerId;
	@Schema(description = "Provider Name")
	private String providerName;
}
