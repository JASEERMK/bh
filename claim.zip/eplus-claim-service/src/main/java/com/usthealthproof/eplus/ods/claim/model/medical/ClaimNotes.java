package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
@Schema(description = "Response class containing medical claim details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ClaimNotes implements Serializable {

	private static final long serialVersionUID = -427889981973809232L;
	@Schema(description = "Serial Number")
	private Integer serialNo;
	@Schema(description = "Claim Note")
	private String claimNote;
	@Schema(description = "Priority")
	private Integer priority;

}
