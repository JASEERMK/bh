package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.configuration.Config;
import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.Types;
import java.util.List;

@Repository
@Slf4j
public class DentalClaimLinesData {


	@Autowired
	private DentalClaimLinesMapper dentalClaimLinesMapper;
	@Value("${claims.spDentalClaimLines}")
	String spDentalClaimLines;
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final String DENTAL_CLAIM_LINES = "DentalClaimLines";

	/**
	 * get all the Dental claim lines of particular claimNumber
	 *
	 * @param claimHccId
	 * @return
	 */
	public List<DentalClaimLines> getDentalClaimLines(String claimHccId, String state, String lob, String product) {
		log.info("Inside getDentalClaimLines() in DentalClaimLinesData class");

        List<DentalClaimLines> dentalClaimLines;
        try {
			MapSqlParameterSource dentalClaimLinesParams = new MapSqlParameterSource().addValue("claimId",
					claimHccId, Types.VARCHAR)
					.addValue("state", state, Types.VARCHAR)
					.addValue("lob", lob, Types.VARCHAR)
					.addValue("product", product, Types.VARCHAR)
					.addValue("returnStatus", 0, Types.NUMERIC);
			String dentalClaimLinesSql = "{CALL " + spDentalClaimLines
					+ "(:claimId, :state, :lob, :product, :returnStatus)}";
			log.info("Going for DB call");
			long startServiceRequestTime = System.currentTimeMillis();
			dentalClaimLines = namedParameterJdbcTemplate.query(dentalClaimLinesSql, dentalClaimLinesParams,
					dentalClaimLinesMapper);
			long endServiceRequestTime = System.currentTimeMillis();
			log.info("Completed the DB call. Query execution time for {} is {}", spDentalClaimLines,
                    endServiceRequestTime - startServiceRequestTime);
			log.debug("Response from DB: {}", dentalClaimLines);
			if (CollectionUtils.isEmpty(dentalClaimLines)) {
				throw new ClaimNotFoundException(ClaimConstants.DENTAL_CLAIM_LINES_NOT_FOUND + claimHccId);
			}
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + DENTAL_CLAIM_LINES);
			throw jdbcException;
		} catch (ClaimNotFoundException claimNotFoundException) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + DENTAL_CLAIM_LINES);
			throw claimNotFoundException;
		} catch (Exception ex) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + DENTAL_CLAIM_LINES);
			throw ex;
		}
		log.info("DentalClaimLines data fetched successfully.");
		return dentalClaimLines;
	}

}
