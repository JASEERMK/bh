package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(description = "Wrapper class containing medical claim details")
public class MedicalClaimLinesResponse implements Serializable {
	private static final long serialVersionUID = 5688619150101404711L;
	@JsonProperty("medicalClaimLines")
	@Schema(description = "List for holding the medical claim lines")
	private List<MedicalClaimLines> medicalClaimLines;
}
