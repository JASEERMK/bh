package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessagesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/v1/claims")
@RestController
@Tag(name = "Medical Claims Services")
@Validated
@Slf4j
@SecurityRequirement(name = "ClaimService")
public class ExternalMessageController {

	@Autowired
	private ClaimServices claimServices;
	@Autowired
	private Validator validator;

	/**
	 * Retrieves specific external messages details
	 *
	 * @param claimHccId
	 * @param claimLineHccId
	 * @param claimFactKey
	 * @param state
	 * @param lob
	 * @param product
	 * @return
	 */
	@Operation(summary = "External messages details", description = "The external message service is responsible for retrieving the message from the external system and displaying the denial or payment reason.", method = "GET", responses = {
			@ApiResponse(responseCode = "200", description = "Medical external message details of the particular claim", content = {
					@Content(schema = @Schema(implementation = MedicalExternalMessagesResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "404", description = "No data found", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
					@Content(schema = @Schema(implementation = ErrorResponse.class)) }) })
	@GetMapping(value = "/external/messages", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<MedicalExternalMessagesResponse> getExternalmessageDetails(
			@Parameter(description = "Medical Claim Id", required = true) @RequestParam(value = "claimHccId") @Pattern(regexp = "^(?!.*--)[^<>'=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: claimHccId is not in valid format") String claimHccId,
			@Parameter(description = "Medical Claim Line Id", required = true) @RequestParam(value = "claimLineHccId") @Pattern(regexp = "^(?!.*--)[a-zA-Z0-9._-]*$", message = "Invalid Request: claimLineHccId is not in valid format") String claimLineHccId,
			@Parameter(description = "Medical Claim Fact Key", required = false) @RequestParam(value = "claimFactKey", required = false) @Pattern(regexp = "^\\d*$", message = "Invalid Request: claimFactKey is not in valid format") String claimFactKey,
			@Parameter(description = "State", hidden = true) @RequestParam(value = "state", required = false) @Pattern(regexp = "^[A-Za-z]*$", message = "Invalid Request: state is not in valid format") String state,
			@Parameter(description = "LOB", hidden = true) @RequestParam(value = "lob", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: lob is not in valid format") String lob,
			@Parameter(description = "Product", hidden = true) @RequestParam(value = "product", required = false) @Pattern(regexp = "^(?!.*--)[^<>=&%#+()@,/*|\\\\;!]*$", message = "Invalid Request: product is not in valid format") String product){


		log.info("Inside getExternalmessageDetails() in ExternalMessageController class");
		log.debug("External Message detail service request received with claimHccID= {}, claimLineHccId= {}, claimFactKey= {}, state= {}, lob= {}, product= {}",
				claimHccId, claimLineHccId, claimFactKey, state, lob, product);
		validator.validateRequestField(claimHccId, claimLineHccId);

		List<MedicalExternalMessage> medicalExternalMessages = claimServices.getExternalMessageDetails(claimHccId, claimLineHccId,
				claimFactKey, state, lob, product);
		var medicalExternalMessagesResponse = new MedicalExternalMessagesResponse();
		medicalExternalMessagesResponse.setExternalMessages(medicalExternalMessages);
		return new ResponseEntity<>(medicalExternalMessagesResponse, HttpStatus.OK);
	}
}
