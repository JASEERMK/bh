package com.usthealthproof.eplus.ods.claim.model.medical;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
@Schema(description = "Response class containing medical claim details")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MedicalClaimDetails implements Serializable {

	private static final long serialVersionUID = -427889981973809232L;
	@Schema(description = "Unique identifier of the member")
	private String memberId;
	@Schema(description = "Unique identifier of the claim")
	private String claimHccId;
	@Schema(description = "Date on which the provided service began")
	private String serviceStartDate;
	@Schema(description = "Date on which the provided service ended")
	private String serviceEndDate;
	@Schema(description = "Claim Status")
	private String status;
	@Schema(description = "Billed Amount")
	private String billedAmount;
	@Schema(description = "Receipt date of claim document")
	private String claimReceiptDate;
	@Schema(description = "Admission Date")
	private String admissionDate;
	@Schema(description = "Date upon which the member is discharged")
	private String dischargeDate;
	@Schema(description = "Type of claim, can be one of: Professional, Institutional, Dental ")
	private String claimType;
	@Schema(description = "Status of Payment")
	private String paymentStatus;
	@Schema(description = "Process Time")
	private String processTime;
	@Schema(description = "Sum of the allowed amounts on the claim")
	private String allowedAmount;
	@Schema(description = "Amount Paid")
	private String paidAmount;
	@Schema(description = "Amount for which the member is responsible")
	private String memberResponsibility;
	@Schema(description = "Deductible Amount")
	private String amountDeductible;
	@Schema(description = "Copay Amount")
	private String copayAmount;
	@Schema(description = "Coinsurance Amount")
	private String coinsuranceAmount;
	@Schema(description = "Timestamp and created by person with date")
	private String createdBy;
	@Schema(description = "Modified By")
	private String modifiedBy;
	@Schema(description = "Adjusted")
	private String isAdjusted;
	@Schema(description = "Payee ID")
	private String payeeID;
	@Schema(description = "Payee Name")
	private String payeeName;
	@Schema(description = "Payee")
	private String payee;
	@Schema(description = "Claim Payer")
	private String claimPayer;
	@Schema(description = "Date Entered")
	private String dateEntered;
	@Schema(description = "The method by which the claim was received")
	private String deliveryType;
	@Schema(description = "External number assigned to the claim")
	private String externalClaimID;
	@Schema(description = "Payment Date")
	private String paymentDate;
	@Schema(description = "Amount of the payment")
	private String totalAmount;
	@Schema(description = "Number associated with the payment(check number, ACH number, etc.)")
	private String paymentNumber;
	@Schema(description = "Member Penalty")
	private String memberPenalty;
	@Schema(description = "Non Covered Amount")
	private String nonCoveredAmount;
	@Schema(description = "Bonus Amount")
	private String bonusAmount;
	@Schema(description = "Provider Penalty")
	private String providerPenalty;
	@Schema(description = "Provider ID")
	private String providerId;
	@Schema(description = "Provider Name")
	private String providerName;
	@Schema(description = "Type of Bill")
	private String typeOfBill;
	@Schema(description = "Diagnosis Code Desc")
	private String diagnosisCodeDesc;
	@Schema(description = "Primary Diagnosis")
	private String primaryDiagnosis;
	@Schema(description = "Secondary Diagnosis")
	private String secondaryDiagnosis;
	@Schema(description = "Coordination of benefit Paid")
	private String cobPaid;
	@Schema(description = "Coordination of benefit Copay")
	private String cobCoPay;
	@Schema(description = "Coordination of benefit Insurance")
	private String cobCoInsurance;
	@Schema(description = "Coordination of benefit Deductible")
	private String cobDeductible;
	@Schema(description = "Coordination of benefit Billed")
	private String cobBilled;
	@Schema(description = "Coordination of benefit Allowed")
	private String cobAllowed;
	@Schema(description = "Coordination of benefit Discount")
	private String cobDiscount;
	@Schema(description = "Coordination of benefit Member Penalty")
	private String cobMemberPenalty;
	@Schema(description = "Coordination of benefit Member Responsibility")
	private String cobMemberResponsibility;
	@Schema(description = "Coordination of benefit Provider Penalty")
	private String cobProviderPenalty;
	@Schema(description = "Coordination of benefit Non Covered")
	private String cobNonCovered;
	@Schema(description = "Coordination of benefit Per Day Limit")
	private String cobPerDayLimit;
	@Schema(description = "Coordination of benefit Tax")
	private String cobTax;
	@Schema(description = "List of claim notes")
	private List<ClaimNotes> claimNote;
//	Added as part of Version2
	@Schema(description = "Claim Source")
	private String claimSource;
	@Schema(description = "Clearinghouse Number")
	private String clearinghouseNo;
	@Schema(description = "Patient Account Number")
	private String patientAccountNo;
	@Schema(description = "Is Converted")
	private String isConverted;
	@Schema(description = "Is Renewed")
	private String isRenewed;
	@Schema(description = "Is Voided")
	private String isVoided;
	@Schema(description = "Medical Record Number")
	private String medicalRecordNo;
	@Schema(description = "Admission Type")
	private String admissionType;
	@Schema(description = "Admission Source")
	private String admissionSource;
	@Schema(description = "Supplier TAX ID")
	private String supplierTaxId;
	@Schema(description = "Supplier NPI")
	private String supplierNpi;
	@Schema(description = "Rendering Location ID")
	private String renderingLocationId;
	@Schema(description = "Rendering Location Name")
	private String renderingLocationName;
	@Schema(description = "Rendering Location NPI")
	private String renderingLocationNpi;
	@Schema(description = "Rendering Provider Address")
	private String renderingProviderAddress;
	@Schema(description = "Balance Billed Amount")
	private String balanceBilledAmount;
	@Schema(description = "Bulk Check Amount")
	private String bulkCheckAmount;
	@Schema(description = "Cleared Check Date")
	private String clearedCheckDate;
//	Added as part of v23.1 - CPB-2711
	@Schema(description = "Frequency Code")
	private String frequencyCode;
	@Schema(description = "Referring Physician")
	private String referringPhysician;
	@Schema(description = "Referring Physician NPI")
	private String referringPhysicianNpi;
	@Schema(description = "Transaction Number")
	private String transactionNumber;
//	Added as part of cpb-3134
	@Schema(description = "Member Name")
	private String memberName;
//    Added as part of CPB-3167
	@Schema(description = "List of Claim Fact Keys")
	private List<String> claimFactKeys;
	@Schema(description = "Claim Fact Key Value")
	private String claimFactKey;
//	Added as part of cpb-4203
	@Schema(description = "Submitted DRG Code and Description")
	private String submittedDrgCodeAndDesc;
	@Schema(description = "Approved DRG Code and Description")
	private String aprDrgCodeAndDesc;
	@Schema(description = "Severity of Illness Code & Description")
	private String illnessCodeAndDesc;
//	Added as part of CPB-4404
	@Schema(description = "BlueCard SCCF Number")
	private String sccfNo;
	// Added as part of API-19
	@Schema(description = "Check Number")
	private String checkNumber;
	//Added as part of API-358
	@Schema(description = "Provider Speciality")
	private String providerSpeciality;
	// New field added as part of API-1729
	@Schema(description = "Referring Physician Name")
	private String referringPhysicianName;

}
