package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class MedicalExternalMessageDetailsMapper implements RowMapper<MedicalExternalMessage> {

	@Override
	public MedicalExternalMessage mapRow(ResultSet rs, int i) throws SQLException {

		var medicalExternalMessage = new MedicalExternalMessage();
		medicalExternalMessage.setAction(rs.getString("ACTION"));
		medicalExternalMessage.setMessageCode(rs.getString("MESSAGE_CODE"));
		medicalExternalMessage.setDescription(rs.getString("DESCRIPTION"));
		medicalExternalMessage.setSource(rs.getString("SOURCE"));
		// Added as part of CPB-3167
		medicalExternalMessage.setClaimFactKey(rs.getString("CLAIM_FACT_KEY"));

		return medicalExternalMessage;
	}
}
