package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.AclEntity;
import com.usthealthproof.eplus.ods.claim.model.portal.Container;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.util.PortalClaimSearchUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.springframework.util.CollectionUtils.isEmpty;

@Repository
@Slf4j
public class ClaimProviderSearchData {

	@Autowired
	PortalClaimSearchUtil portalClaimSearchUtil;
	@Value("${sp.spPortalProviderMedicalClaimSearch}")
	private String spPortalProviderMedicalClaimSearch;
	@Value("${sp.spPortalProviderVisionClaimSearch}")
	private String spPortalProviderVisionClaimSearch;
	@Value("${sp.spPortalProviderDentalClaimSearch}")
	private String spPortalProviderDentalClaimSearch;

	private static final String PROVIDER_CLAIM_SEARCH = "provider claim search";

	public ClaimSearchResponse getClaimHeaderSearchInfoForProvider(UserIdentityRequest userIdentityRequest,
			ClaimSearchRequest claimSearchRequest)
			throws ExecutionException, InterruptedException, SQLException {
		log.info("Inside getClaimHeaderSearchInfoForProvider() in ClaimProviderSearchData class");
		
		ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();
		List<CompletableFuture<ClaimSearchResponse>> completableFutureList = new ArrayList<>();
		Set<AclEntity> aclEntities = new HashSet<>(userIdentityRequest.getAcl_entities());
		for (AclEntity aclEntity : aclEntities) {
			List<String> excludedMedicalGroups = new ArrayList<>();
			List<String> includedMedicalGroups = new ArrayList<>();
			List<String> excludedProvider = new ArrayList<>();
			List<String> includedProvider = new ArrayList<>();

			setIncludedAndExcludedProviders(aclEntity, excludedMedicalGroups, includedMedicalGroups, excludedProvider, includedProvider);

			claimSearchRequest.setExcludedProvider(excludedProvider);
			claimSearchRequest.setIncludedProvider(includedProvider);
			claimSearchRequest.setExcludedMedicalGroups(excludedMedicalGroups);
			claimSearchRequest.setIncludedMedicalGroups(includedMedicalGroups);

			CompletableFuture<ClaimSearchResponse> claimSearchCompleatableFuture = null;
			Thread.sleep(100L); // Intentional delay
			claimSearchCompleatableFuture = getClaimHeaderSearchInfo(claimSearchRequest);
			completableFutureList.add(claimSearchCompleatableFuture);
		}
		getProviderSearchResponse(completableFutureList,claimSearchResponse);
		return claimSearchResponse;
	}

	private static void setIncludedAndExcludedProviders(AclEntity aclEntity, List<String> excludedMedicalGroups, List<String> includedMedicalGroups, List<String> excludedProvider, List<String> includedProvider) {
		for (Container container : aclEntity.getContainers()) {
			if (container.getType().equalsIgnoreCase("medical_groups")) {
				if (container.getExclude() == Boolean.TRUE) {
					excludedMedicalGroups.addAll(container.getEntity_ids());
				} else {
					includedMedicalGroups.addAll(container.getEntity_ids());
				}
			} else if (container.getType().equalsIgnoreCase("providers")) {
				if (container.getExclude() == Boolean.TRUE) {
					excludedProvider.addAll(container.getEntity_ids());
				} else {
					includedProvider.addAll(container.getEntity_ids());
				}
			}
		}
	}

	private void getProviderSearchResponse(List<CompletableFuture<ClaimSearchResponse>> completableFutureList, ClaimSearchResponse claimSearchResponse) throws ExecutionException, InterruptedException {
		log.info("Inside getProviderSearchResponse() in ClaimProviderSearchData class");
		
		List<ClaimSearchModel> providerClaimSearchResults = new ArrayList<>();
		ClaimSearchResponse providerClaimSearchResponse;
		for (CompletableFuture<ClaimSearchResponse> claimSearchResponseCompletableFuture : completableFutureList) {
			providerClaimSearchResponse = claimSearchResponseCompletableFuture.get();
			if (null != providerClaimSearchResponse && !CollectionUtils.isEmpty(providerClaimSearchResponse.getResults())) {
				providerClaimSearchResults.addAll(providerClaimSearchResponse.getResults());
			}
		}
		List<ClaimSearchModel> uniqueProviderClaimSearchResults = providerClaimSearchResults.stream()
				.collect(collectingAndThen(toCollection(() -> new TreeSet<>(comparing(ClaimSearchModel::getClaimNumber))),
						ArrayList::new));
		List<ClaimSearchModel> results = uniqueProviderClaimSearchResults.stream()
				.filter(claimSearchModel -> isNotEmpty(claimSearchModel.getPatient()
						.getMemberNumber())).toList();
		if(!isEmpty(results)){
			claimSearchResponse.setCount(results.size());
			claimSearchResponse.setResults(results);
			claimSearchResponse.setStatus(ClaimConstants.SUCCESS);
		}else {
			throw new ClaimNotFoundException(ClaimConstants.NO_DATA_FOUND);
		}
	}

	@Async("asyncExecutor")
	private CompletableFuture<ClaimSearchResponse> getClaimHeaderSearchInfo(ClaimSearchRequest claimSearchRequest)
			throws InterruptedException, ExecutionException, SQLException {
		log.info("Inside getClaimHeaderSearchInfo() in ClaimProviderSearchData class");
		
		ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();
		List<ClaimSearchModel> claimSearchModelList = null;
		try {
			if (StringUtils.isBlank(claimSearchRequest.getClaimTypes())) {
				log.info("Claim type is empty, so executing the medicalClaimSearch SP for provider");
				claimSearchModelList = portalClaimSearchUtil.getProviderClaimSearchResult(claimSearchRequest,spPortalProviderMedicalClaimSearch);
			} else {
				log.info("Started {} claim search SP for provider", claimSearchRequest.getClaimTypes());
				switch (claimSearchRequest.getClaimTypes().toLowerCase()) {
				case ClaimConstants.MEDICAL_CLAIM_TYPE:
					claimSearchModelList= portalClaimSearchUtil.getProviderClaimSearchResult(claimSearchRequest,spPortalProviderMedicalClaimSearch);
					break;
				case ClaimConstants.DENTAL_CLAIM_TYPE:
					claimSearchModelList = portalClaimSearchUtil.getProviderClaimSearchResult(claimSearchRequest,spPortalProviderDentalClaimSearch);
					break;
				case ClaimConstants.VISION_CLAIM_TYPE:
					claimSearchModelList = portalClaimSearchUtil.getProviderClaimSearchResult(claimSearchRequest,spPortalProviderVisionClaimSearch);
					break;
				case ClaimConstants.CLAIM_TYPE_ALL:
					claimSearchModelList = getAllClaimSearchResultForProvider(claimSearchRequest);
					break;
				default:
					break;
				}
			}
			log.info(ClaimConstants.DB_CALL_COMPLETED);
			claimSearchResponse = portalClaimSearchUtil.setClaimSearchResponse(claimSearchModelList);
		} catch (CannotGetJdbcConnectionException jdbcException) {
			log.error(ClaimConstants.JDBC_CONNECTION_EXCEPTION + PROVIDER_CLAIM_SEARCH);
			throw jdbcException;
		} catch (ClaimNotFoundException ndfe) {
			log.error(ClaimConstants.CLAIM_NOT_FOUND + PROVIDER_CLAIM_SEARCH);
			throw ndfe;
		} catch (Exception e) {
			log.error(ClaimConstants.EXCEPTION_MESSAGE + PROVIDER_CLAIM_SEARCH);
			throw e;
		}
		log.info("ClaimSearchInfo for Provider fetched successfully.");
		return CompletableFuture.completedFuture(claimSearchResponse);
	}

	private List<ClaimSearchModel> getAllClaimSearchResultForProvider(ClaimSearchRequest claimSearchRequest)
			throws InterruptedException, ExecutionException, SQLException {
		log.info("Inside getAllClaimSearchResultForProvider() in ClaimProviderSearchData class");
		
		List<ClaimSearchModel> providerClaimSearchResults = new ArrayList<>();
		List<CompletableFuture<List<ClaimSearchModel>>> completableFutureList = new ArrayList<>();
		List<String> spList = Arrays.asList(spPortalProviderMedicalClaimSearch, spPortalProviderDentalClaimSearch, spPortalProviderVisionClaimSearch);
		for (String sp : spList) {
			if(StringUtils.isBlank(sp)) continue;
			CompletableFuture<List<ClaimSearchModel>> claimSearchCompleatableFuture = null;
			claimSearchCompleatableFuture = portalClaimSearchUtil.getProviderAllClaimSearchResult(claimSearchRequest,sp);
			completableFutureList.add(claimSearchCompleatableFuture);
		}
		for (CompletableFuture<List<ClaimSearchModel>> claimSearchResponseCompletableFuture : completableFutureList) {
			providerClaimSearchResults.addAll(claimSearchResponseCompletableFuture.get());
		}
		return providerClaimSearchResults;
	}
}
