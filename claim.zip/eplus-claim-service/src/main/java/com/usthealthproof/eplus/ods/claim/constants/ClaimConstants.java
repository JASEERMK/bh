package com.usthealthproof.eplus.ods.claim.constants;

import org.springframework.stereotype.Component;

@Component
public class ClaimConstants {

	private ClaimConstants() {
	}

	public static final String CLAIM_LINES_NOT_FOUND = "Claim lines not found for the given claim number : ";
	public static final String CLAIM_LINE_DETAILS_NOT_FOUND = "Claim line details not found for the given claim number : ";
	public static final String CLAIM_DETAILS_NOT_FOUND = "Claim details not found for the given claim number : ";
	public static final String VISION_CLAIM_LINES_NOT_FOUND = "Vision Claim lines not found for the given claim number : ";
	public static final String VISION_CLAIM_LINE_DETAILS_NOT_FOUND = "Vision Claim line details not found for the given claim number : ";
	public static final String VISION_CLAIM_DETAILS_NOT_FOUND = "Vision Claim details not found for the given claim number : ";
	public static final String DENTAL_CLAIM_LINES_NOT_FOUND = "Dental Claim lines not found for the given claim number : ";
	public static final String DENTAL_CLAIM_LINE_DETAILS_NOT_FOUND = "Dental Claim line details not found for the given claim number : ";
	public static final String DENTAL_CLAIM_DETAILS_NOT_FOUND = "Dental Claim details not found for the given claim number : ";
	public static final String CLAIM_ID_NOT_FOUND = "ClaimId is mandatory field for proceeding with the request";
	public static final String CLAIM_LINE_ID_NOT_FOUND = "ClaimId and ClaimLineHccId are mandatory fields for proceeding with the request";
	public static final String EXCEPTION_OCCURRED = "Something went wrong, please check the log for more details";
	public static final String RX_CLAIM_DETAILS_NOT_FOUND = "RX Claim details not found for the given claim number : ";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String JDBC_EXCEPTION = "Error occurred during Search. Please contact your supervisor";
	public static final String NO_EXTERNAL_MESSGAES_FOUND = "No external message found";
	public static final String NO_DATA_FOUND = "No data found for the requested ";
	public static final String MEDICAL_CLAIM_TYPE = "medical";
	public static final String DENTAL_CLAIM_TYPE = "dental";
	public static final String VISION_CLAIM_TYPE = "vision";
	public static final String CLAIM_TYPE_ALL = "all";
	public static final String RETURN_STATUS = "returnstatus";
	public static final String RESULT = "result";
	public static final String RESULT_SET2 = "#result-set-2";
	public static final String RESULT_SET = "resultset";
	public static final String DB_CALL_COMPLETED = "Completed the DB call";

	public static final String JDBC_CONNECTION_EXCEPTION = "CannotGetJdbcConnectionException occurred for the request - ";

	public static final String EXCEPTION_MESSAGE = "Exception occurred for the request - ";
	public static final String CLAIM_NOT_FOUND = "ClaimNotFoundException occurred for the request - ";
	public static final String INVALID_REQUEST_URL = "Invalid Request: No static resource found";
}
