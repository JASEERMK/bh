package com.usthealthproof.eplus.ods.claim.model.portal.search;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@JsonPropertyOrder({ "claimNumber", "serviceDate", "totalSubmittedAmount", "totalPaidAmount","totalBilledAmount",
		"paymentInformation", "paymentDate", "patient", "provider", "procedures", "diagnoses" })
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Wrapper class for Claim search details")
public class ClaimSearchDetails implements Serializable {

	private static final long serialVersionUID = -427889981973809232L;

	@Schema(description = "Claim number")
	@JsonProperty("claimNumber")
	private String claimNumber;

	@Schema(description = "Service date")
	@JsonProperty("serviceDate")
	private String serviceDate;

	@Schema(description = "Total submitted amount")
	@JsonProperty("totalSubmittedAmount")
	private String totalSubmittedAmount;

	@Schema(description = "total paid amount")
	@JsonProperty("totalPaidAmount")
	private String totalPaidAmount;

	@Schema(description = "Total billed amount")
	@JsonProperty("totalBilledAmount")
	private String totalBilledAmount;

	@Schema(description = "Payment Information")
	@JsonProperty("paymentInformation")
	private String paymentInformation;

	@Schema(description = "Payment date")
	@JsonProperty("paymentDate")
	private String paymentDate;

	@Schema(description = "Object to hold the patient details")
	private Patient patient;

	@Schema(description = "Object to hold the provider details")
	private Provider provider;

	@Schema(description = "Procedures")
	private String procedures;

	@Schema(description = "Diagnoses")
	private String diagnoses;

}
