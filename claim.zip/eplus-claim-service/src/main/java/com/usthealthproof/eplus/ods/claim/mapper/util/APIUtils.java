package com.usthealthproof.eplus.ods.claim.mapper.util;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.usthealthproof.eplus.ods.claim.model.medical.ClaimNotes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

@Component
@Slf4j
public class APIUtils {
	@Value("${claims.claimNotesDelimiter}")
	private String claimNotesDelimiter;
	@Value("${claims.claimNotesPrioritySeparator}")
	private String claimNotesPrioritySeparator;



	public List<ClaimNotes> getClaimNotes(String claimNotesFromQuery) {
		List<ClaimNotes> claimNoteListResponse = null;
		if (StringUtils.isNotBlank(claimNotesFromQuery)) {
			List<ClaimNotes> claimNoteList = new ArrayList<>();
			List<String> claimNotesSeparated = Arrays.asList(StringUtils.splitByWholeSeparator(claimNotesFromQuery, claimNotesDelimiter));
			for (String claimNotes : claimNotesSeparated) {
				List<String> claimNoteValues = Arrays.asList(StringUtils.splitByWholeSeparator(claimNotes, claimNotesPrioritySeparator));
				if (null != claimNoteValues && claimNoteValues.size() > 1 && StringUtils.isNotBlank(claimNoteValues.get(0))
						&& StringUtils.isNotBlank(claimNoteValues.get(1))) {
					var claimNote = new ClaimNotes();
					claimNote.setClaimNote(claimNoteValues.get(0).trim());
					claimNote.setPriority(NumberUtils.toInt(claimNoteValues.get(1).trim(), 0));
					claimNoteList.add(claimNote);
				}
			}

			if (!claimNoteList.isEmpty()) {
				claimNoteList.sort(Comparator.comparing(ClaimNotes::getPriority));
				int serialNumber = 1;
				claimNoteListResponse = new ArrayList<>();
				for (ClaimNotes claimNote : claimNoteList) {
					claimNote.setSerialNo(serialNumber++);
					claimNoteListResponse.add(claimNote);
				}
			}

		}

		return claimNoteListResponse;

	}

	/**
	 * Common Method for the Util function for setting the error details
	 */
	public ErrorResponse setErrorDetails(String message, String status) {
		log.info("Inside setErrorDetails() in APIUtils class");
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(createProblemDetails(message, status));
		return errorResponse;
	}

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setErrors(Arrays.asList(errorMsg));
		problemDetails.setStatus(status);
		return problemDetails;
	}

}
