package com.usthealthproof.eplus.ods.claim.model.dental;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Wrapper class containing list of dental claim lines")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DentalClaimLinesResponse implements Serializable {

	private static final long serialVersionUID = -7356417349453999652L;
	@Schema(description = "List containing claim lines of the dental claim")
	@JsonProperty("dentalClaimLines")
	private List<DentalClaimLines> dentalClaimLines;
}
