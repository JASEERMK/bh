package com.usthealthproof.eplus.ods.claim.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.util.DecodedUserIdentity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ClaimServiceControllerTest {

    @InjectMocks
    private ClaimServiceController claimServiceController;

    @Mock
    private ClaimServices claimService;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Mock
    private ClaimHeaderSearchService claimHeaderSearchService;

    @Mock
    private DecodedUserIdentity decodedUserIdentity;

    private ClaimSearchRequest claimSearchRequest;
    private ClaimSearchResponse claimSearchResponse;
    private UserIdentityRequest userIdentityRequest;
    private ClaimDetailsRequest claimDetailsRequest;
    private ClaimDetailsResponse claimDetailsResponse;

    @BeforeEach
    void setUp() {
        claimSearchRequest = new ClaimSearchRequest();
        claimSearchResponse = new ClaimSearchResponse();
        userIdentityRequest = new UserIdentityRequest();
        claimDetailsRequest = new ClaimDetailsRequest();
        claimDetailsResponse = new ClaimDetailsResponse();
    }

    @Test
    void testGetClaimSearchInfo() throws Throwable {
        when(decodedUserIdentity.getMemberHeaderDetails(any())).thenReturn(userIdentityRequest);
        when(claimHeaderSearchService.getClaimHeaderSearchInfo(any(), any())).thenReturn(claimSearchResponse);

        ResponseEntity<ClaimSearchResponse> response = claimServiceController.getClaimSearchInfo(claimSearchRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(claimSearchResponse, response.getBody());

        verify(decodedUserIdentity, times(1)).getMemberHeaderDetails(any());
        verify(claimHeaderSearchService, times(1)).getClaimHeaderSearchInfo(any(), any());
    }

    @Test
    void testGetClaimDetailsInfo() throws Exception {
        when(claimService.getClaimDetailsInfo(any())).thenReturn(claimDetailsResponse);

        ResponseEntity<ClaimDetailsResponse> response = claimServiceController.getClaimDetailsInfo(claimDetailsRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(claimDetailsResponse, response.getBody());

        verify(claimService, times(1)).getClaimDetailsInfo(any());
    }

    @ParameterizedTest
    @CsvSource({
            "Medical<",
            "Medical>",
            "Medical=",
            "Medical&",
            "Medical%",
            "Medical#",
            "Medical&",
            "Medical(",
            "Medical)",
            "Medical@",
            "Medical\\,",
            "Medical/",
            "Medical*",
            "Medical|",
            "Medical;",
            "Medical!",
            "Medical--",
            "Medical\\\\",
    })
    @WithMockUser
    void testGetClaimSearchInfo_invalidClaimTypePattern(String pattern) throws Exception {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        claimSearchRequest.setClaimTypes(pattern);
        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.post("/v2/claims/search")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimSearchRequest)));

        response.andDo(print()).andExpect(status().isBadRequest());
    }

    @ParameterizedTest
    @CsvSource({
            "M001<",
            "M001>",
            "M001'",
            "M001=",
            "M001&",
            "M001%",
            "M001#",
            "M001&",
            "M001(",
            "M001)",
            "M001@",
            "M001\\,8",
            "M001/",
            "M001*",
            "M001|",
            "M001;",
            "M001!",
            "M001--",
            "M001--",
            "M001\\\\"
    })
    @WithMockUser
    void testGetClaimDetailsInfo_invalidMemberNumberPattern(String pattern) throws Exception {
        ClaimDetailsRequest claimDetailsRequest = new ClaimDetailsRequest();
        claimDetailsRequest.setMemberNumber(pattern);
        ResultActions response = mockMvc.perform(MockMvcRequestBuilders.post("/v2/claims/claim")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(claimDetailsRequest)));

        response.andDo(print()).andExpect(status().isBadRequest());
    }
}
