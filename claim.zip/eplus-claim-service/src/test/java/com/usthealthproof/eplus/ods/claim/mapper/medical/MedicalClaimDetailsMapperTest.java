package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.mapper.util.APIUtils;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimNotes;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class MedicalClaimDetailsMapperTest {

    @InjectMocks
    private MedicalClaimDetailsMapper medicalClaimDetailsMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("memberHccId")).thenReturn("member123");
        when(resultSet.getString("claimHccId")).thenReturn("claim123");
        when(resultSet.getString("serviceStartDate")).thenReturn("2023-01-01");
        when(resultSet.getString("serviceEndDate")).thenReturn("2023-01-10");
        when(resultSet.getString("status")).thenReturn("processed");
        when(resultSet.getString("billedAmount")).thenReturn("1000");
        when(resultSet.getString("claimReceiptDate")).thenReturn("2023-01-05");
        when(resultSet.getString("admissionDate")).thenReturn("2023-01-02");
        when(resultSet.getString("dischargeDate")).thenReturn("2023-01-09");
        when(resultSet.getString("processtime")).thenReturn("2023-01-07");
        when(resultSet.getString("allowed_amount")).thenReturn("800");
        when(resultSet.getString("paid_amount")).thenReturn("750");
        when(resultSet.getString("member_responsibility")).thenReturn("250");
        when(resultSet.getString("amount_deductible")).thenReturn("100");
        when(resultSet.getString("copay_amount")).thenReturn("50");
        when(resultSet.getString("coinsurance_amount")).thenReturn("20");
        when(resultSet.getString("created_by")).thenReturn("user1");
        when(resultSet.getString("modified_by")).thenReturn("user2");
        when(resultSet.getString("is_adjusted")).thenReturn("no");
        when(resultSet.getString("Payee_ID")).thenReturn("payee123");
        when(resultSet.getString("Payee_Name")).thenReturn("Payee Name");
        when(resultSet.getString("Payee")).thenReturn("Payee");
        when(resultSet.getString("Claim_Payor")).thenReturn("Claim Payer");
        when(resultSet.getString("Date_Entered")).thenReturn("2023-01-01");
        when(resultSet.getString("Delivery_Type")).thenReturn("Delivery Type");
        when(resultSet.getString("External_ClaimID")).thenReturn("External123");
        when(resultSet.getString("Payment_Date")).thenReturn("2023-01-15");
        when(resultSet.getString("total_amount")).thenReturn("1000");
        when(resultSet.getString("Payment_Number")).thenReturn("Payment123");
        when(resultSet.getString("member_penalty")).thenReturn("10");
        when(resultSet.getString("non_covered_amount")).thenReturn("5");
        when(resultSet.getString("bonus_amount")).thenReturn("0");
        when(resultSet.getString("provider_penalty")).thenReturn("0");
        when(resultSet.getString("providerId")).thenReturn("provider123");
        when(resultSet.getString("providerName")).thenReturn("Provider Name");
        when(resultSet.getString("type_of_bill")).thenReturn("Type of Bill");
        when(resultSet.getString("claim_type")).thenReturn("Claim Type");
        when(resultSet.getString("diagnosisCode_desc")).thenReturn("Diagnosis Code Description");
        when(resultSet.getString("primarydiagnosis")).thenReturn("Primary Diagnosis");
        when(resultSet.getString("secondarydiagnosis")).thenReturn("Secondary Diagnosis");
        when(resultSet.getString("payment_status")).thenReturn("Paid");
        when(resultSet.getString("cob_paid")).thenReturn("100");
        when(resultSet.getString("cob_copay")).thenReturn("10");
        when(resultSet.getString("cob_coinsurance")).thenReturn("5");
        when(resultSet.getString("cob_deductible")).thenReturn("15");
        when(resultSet.getString("cob_billed")).thenReturn("110");
        when(resultSet.getString("cob_allowed")).thenReturn("90");
        when(resultSet.getString("cob_discount")).thenReturn("20");
        when(resultSet.getString("cob_member_penalty")).thenReturn("5");
        when(resultSet.getString("cob_member_responsibility")).thenReturn("25");
        when(resultSet.getString("cob_provider_penalty")).thenReturn("0");
        when(resultSet.getString("cob_noncovered")).thenReturn("10");
        when(resultSet.getString("cob_per_daylimit")).thenReturn("200");
        when(resultSet.getString("cob_tax")).thenReturn("15");
        when(resultSet.getString("modified_by")).thenReturn("user2");
        when(resultSet.getString("CLAIM_NOTE")).thenReturn("Claim Note");
        when(resultSet.getString("claim_source_name")).thenReturn("Claim Source");
        when(resultSet.getString("clearing_house_trace_number")).thenReturn("Trace123");
        when(resultSet.getString("patient_account_number")).thenReturn("Account123");
        when(resultSet.getString("is_converted")).thenReturn("yes");
        when(resultSet.getString("is_renewed")).thenReturn("no");
        when(resultSet.getString("is_voided")).thenReturn("no");
        when(resultSet.getString("medical_record_number")).thenReturn("Record123");
        when(resultSet.getString("admit_type_name")).thenReturn("Admit Type");
        when(resultSet.getString("admit_source_name")).thenReturn("Admit Source");
        when(resultSet.getString("supplier_tax_id")).thenReturn("Tax123");
        when(resultSet.getString("supplier_npi")).thenReturn("NPI123");
        when(resultSet.getString("supplier_location_hcc_id")).thenReturn("Location123");
        when(resultSet.getString("supplier_location_name")).thenReturn("Location Name");
        when(resultSet.getString("supplier_location_npi")).thenReturn("Location NPI");
        when(resultSet.getString("provider_address")).thenReturn("Provider Address");
        when(resultSet.getString("balance_billed_amount")).thenReturn("50");
        when(resultSet.getString("bulk_check_amount")).thenReturn("500");
        when(resultSet.getString("cleared_check_date")).thenReturn("2023-01-20");
        when(resultSet.getString("frequency_code")).thenReturn("F123");
        when(resultSet.getString("referring_practitioner_hcc_id")).thenReturn("Practitioner123");
        when(resultSet.getString("practitioner_npi")).thenReturn("NPI456");
        when(resultSet.getString("transaction_no")).thenReturn("T123");
        when(resultSet.getString("MemberName")).thenReturn("Member Name");
        when(resultSet.getString("claim_fact_key")).thenReturn("FactKey123");
        when(resultSet.getString("Submtd_DRG_Code_Desc")).thenReturn("DRG Code Desc");
        when(resultSet.getString("APR_Code_Description")).thenReturn("APR Code Desc");
        when(resultSet.getString("Severity_of_Illness_Code_Desc")).thenReturn("Illness Code Desc");
        when(resultSet.getString("BlueCard_SCCF_No")).thenReturn("SCCF123");
        when(resultSet.getString("external_payment_id")).thenReturn("PaymentID123");
        when(resultSet.getString("Provider_Speciality")).thenReturn("Speciality");
        when(resultSet.getString("referring_practitioner_name")).thenReturn("Physician Name");

        // Setup mock behavior for DateUtils and APIUtils
        when(dateUtils.getFormattedApplicationDate(anyString())).thenAnswer(invocation -> invocation.getArgument(0));

        List<ClaimNotes> mockClaimNotes = new ArrayList<>();
        ClaimNotes note1 = new ClaimNotes();
        note1.setClaimNote("Note 1");
        note1.setPriority(1);
        mockClaimNotes.add(note1);
        ClaimNotes note2 = new ClaimNotes();
        note2.setClaimNote("Note 2");
        note2.setPriority(2);
        mockClaimNotes.add(note2);

        when(apiUtils.getClaimNotes(anyString())).thenReturn(mockClaimNotes);

        // Execute mapRow
        MedicalClaimDetails result = medicalClaimDetailsMapper.mapRow(resultSet, 1);

        // Verify the result
        assertEquals("member123", result.getMemberId());
        assertEquals("claim123", result.getClaimHccId());
        assertEquals("2023-01-01", result.getServiceStartDate());
        assertEquals("2023-01-10", result.getServiceEndDate());
        assertEquals("processed", result.getStatus());
        assertEquals("1000", result.getBilledAmount());
        assertEquals("2023-01-05", result.getClaimReceiptDate());
        assertEquals("2023-01-02", result.getAdmissionDate());
        assertEquals("2023-01-09", result.getDischargeDate());
        assertEquals("2023-01-07", result.getProcessTime());
        assertEquals("800", result.getAllowedAmount());
        assertEquals("750", result.getPaidAmount());
        assertEquals("250", result.getMemberResponsibility());
        assertEquals("100", result.getAmountDeductible());
        assertEquals("50", result.getCopayAmount());
        assertEquals("20", result.getCoinsuranceAmount());
        assertEquals("user1", result.getCreatedBy());
        assertEquals("user2", result.getModifiedBy());
        assertEquals("no", result.getIsAdjusted());
        assertEquals("payee123", result.getPayeeID());
        assertEquals("Payee Name", result.getPayeeName());
        assertEquals("Payee", result.getPayee());
        assertEquals("Claim Payer", result.getClaimPayer());
        assertEquals("2023-01-01", result.getDateEntered());
        assertEquals("Delivery Type", result.getDeliveryType());
        assertEquals("External123", result.getExternalClaimID());
        assertEquals("2023-01-15", result.getPaymentDate());
        assertEquals("1000", result.getTotalAmount());
        assertEquals("Payment123", result.getPaymentNumber());
        assertEquals("10", result.getMemberPenalty());
        assertEquals("5", result.getNonCoveredAmount());
        assertEquals("0", result.getBonusAmount());
        assertEquals("0", result.getProviderPenalty());
        assertEquals("provider123", result.getProviderId());
        assertEquals("Provider Name", result.getProviderName());
        assertEquals("Type of Bill", result.getTypeOfBill());
        assertEquals("Claim Type", result.getClaimType());
        assertEquals("Diagnosis Code Description", result.getDiagnosisCodeDesc());
        assertEquals("Primary Diagnosis", result.getPrimaryDiagnosis());
        assertEquals("Secondary Diagnosis", result.getSecondaryDiagnosis());
        assertEquals("Paid", result.getPaymentStatus());
        assertEquals("100", result.getCobPaid());
        assertEquals("10", result.getCobCoPay());
        assertEquals("5", result.getCobCoInsurance());
        assertEquals("15", result.getCobDeductible());
        assertEquals("110", result.getCobBilled());
        assertEquals("90", result.getCobAllowed());
        assertEquals("20", result.getCobDiscount());
        assertEquals("5", result.getCobMemberPenalty());
        assertEquals("25", result.getCobMemberResponsibility());
        assertEquals("0", result.getCobProviderPenalty());
        assertEquals("10", result.getCobNonCovered());
        assertEquals("200", result.getCobPerDayLimit());
        assertEquals("15", result.getCobTax());
        assertEquals("user1", result.getCreatedBy());
        assertEquals("user2", result.getModifiedBy());
        assertEquals(2, result.getClaimNote().size());
        assertEquals("Note 1", result.getClaimNote().get(0).getClaimNote()); // Verify the first note
        assertEquals("Note 2", result.getClaimNote().get(1).getClaimNote()); // Verify the second note

        assertEquals("Claim Source", result.getClaimSource());
        assertEquals("Trace123", result.getClearinghouseNo());
        assertEquals("Account123", result.getPatientAccountNo());
        assertEquals("yes", result.getIsConverted());
        assertEquals("no", result.getIsRenewed());
        assertEquals("no", result.getIsVoided());
        assertEquals("Record123", result.getMedicalRecordNo());
        assertEquals("Admit Type", result.getAdmissionType());
        assertEquals("Admit Source", result.getAdmissionSource());
        assertEquals("Tax123", result.getSupplierTaxId());
        assertEquals("NPI123", result.getSupplierNpi());
        assertEquals("Location123", result.getRenderingLocationId());
        assertEquals("Location Name", result.getRenderingLocationName());
        assertEquals("Location NPI", result.getRenderingLocationNpi());
        assertEquals("Provider Address", result.getRenderingProviderAddress());
        assertEquals("50", result.getBalanceBilledAmount());
        assertEquals("500", result.getBulkCheckAmount());
        assertEquals("2023-01-20", result.getClearedCheckDate());
        assertEquals("F123", result.getFrequencyCode());
        assertEquals("Practitioner123", result.getReferringPhysician());
        assertEquals("NPI456", result.getReferringPhysicianNpi());
        assertEquals("T123", result.getTransactionNumber());
        assertEquals("Member Name", result.getMemberName());
        assertEquals("FactKey123", result.getClaimFactKey());
        assertEquals("DRG Code Desc", result.getSubmittedDrgCodeAndDesc());
        assertEquals("APR Code Desc", result.getAprDrgCodeAndDesc());
        assertEquals("Illness Code Desc", result.getIllnessCodeAndDesc());
        assertEquals("SCCF123", result.getSccfNo());
        assertEquals("PaymentID123", result.getCheckNumber());
        assertEquals("Speciality", result.getProviderSpeciality());
        assertEquals("Physician Name", result.getReferringPhysicianName());

        // Verify the interactions with mocks
        verify(resultSet, times(1)).getString("memberHccId");
        verify(resultSet, times(1)).getString("claimHccId");
        verify(resultSet, times(1)).getString("serviceStartDate");
        verify(resultSet, times(1)).getString("serviceEndDate");
        verify(resultSet, times(1)).getString("status");
        verify(resultSet, times(1)).getString("billedAmount");
        verify(resultSet, times(1)).getString("claimReceiptDate");
        verify(resultSet, times(1)).getString("admissionDate");
        verify(resultSet, times(1)).getString("dischargeDate");
        verify(resultSet, times(1)).getString("processtime");
        verify(resultSet, times(1)).getString("allowed_amount");
        verify(resultSet, times(1)).getString("paid_amount");
        verify(resultSet, times(1)).getString("member_responsibility");
        verify(resultSet, times(1)).getString("amount_deductible");
        verify(resultSet, times(1)).getString("copay_amount");
        verify(resultSet, times(1)).getString("coinsurance_amount");

        verify(resultSet, times(2)).getString("created_by");
        verify(resultSet, times(2)).getString("modified_by");
        verify(resultSet, times(1)).getString("is_adjusted");
        verify(resultSet, times(1)).getString("Payee_ID");
        verify(resultSet, times(1)).getString("Payee_Name");
        verify(resultSet, times(1)).getString("Payee");
        verify(resultSet, times(1)).getString("Claim_Payor");
        verify(resultSet, times(1)).getString("Date_Entered");
        verify(resultSet, times(1)).getString("Delivery_Type");
        verify(resultSet, times(1)).getString("External_ClaimID");
        verify(resultSet, times(1)).getString("Payment_Date");
        verify(resultSet, times(1)).getString("total_amount");
        verify(resultSet, times(1)).getString("Payment_Number");
        verify(resultSet, times(1)).getString("member_penalty");
        verify(resultSet, times(1)).getString("non_covered_amount");
        verify(resultSet, times(1)).getString("bonus_amount");
        verify(resultSet, times(1)).getString("provider_penalty");
        verify(resultSet, times(1)).getString("providerId");
        verify(resultSet, times(1)).getString("providerName");
        verify(resultSet, times(1)).getString("type_of_bill");
        verify(resultSet, times(1)).getString("claim_type");
        verify(resultSet, times(1)).getString("diagnosisCode_desc");
        verify(resultSet, times(1)).getString("primarydiagnosis");
        verify(resultSet, times(1)).getString("secondarydiagnosis");
        verify(resultSet, times(1)).getString("payment_status");
        verify(resultSet, times(1)).getString("cob_paid");
        verify(resultSet, times(1)).getString("cob_copay");
        verify(resultSet, times(1)).getString("cob_coinsurance");
        verify(resultSet, times(1)).getString("cob_deductible");
        verify(resultSet, times(1)).getString("cob_billed");
        verify(resultSet, times(1)).getString("cob_allowed");
        verify(resultSet, times(1)).getString("cob_discount");
        verify(resultSet, times(1)).getString("cob_member_penalty");
        verify(resultSet, times(1)).getString("cob_member_responsibility");
        verify(resultSet, times(1)).getString("cob_provider_penalty");
        verify(resultSet, times(1)).getString("cob_noncovered");
        verify(resultSet, times(1)).getString("cob_per_daylimit");
        verify(resultSet, times(1)).getString("cob_tax");
        verify(resultSet, times(2)).getString("modified_by");
        verify(resultSet, times(1)).getString("CLAIM_NOTE");
        verify(resultSet, times(1)).getString("claim_source_name");
        verify(resultSet, times(1)).getString("clearing_house_trace_number");
        verify(resultSet, times(1)).getString("patient_account_number");
        verify(resultSet, times(1)).getString("is_converted");
        verify(resultSet, times(1)).getString("is_renewed");
        verify(resultSet, times(1)).getString("is_voided");
        verify(resultSet, times(1)).getString("medical_record_number");
        verify(resultSet, times(1)).getString("admit_type_name");
        verify(resultSet, times(1)).getString("admit_source_name");
        verify(resultSet, times(1)).getString("supplier_tax_id");
        verify(resultSet, times(1)).getString("supplier_npi");
        verify(resultSet, times(1)).getString("supplier_location_hcc_id");
        verify(resultSet, times(1)).getString("supplier_location_name");
        verify(resultSet, times(1)).getString("supplier_location_npi");
        verify(resultSet, times(1)).getString("provider_address");
        verify(resultSet, times(1)).getString("balance_billed_amount");
        verify(resultSet, times(1)).getString("bulk_check_amount");
        verify(resultSet, times(1)).getString("cleared_check_date");
        verify(resultSet, times(1)).getString("frequency_code");
        verify(resultSet, times(1)).getString("referring_practitioner_hcc_id");
        verify(resultSet, times(1)).getString("practitioner_npi");
        verify(resultSet, times(1)).getString("transaction_no");
        verify(resultSet, times(1)).getString("MemberName");
        verify(resultSet, times(1)).getString("claim_fact_key");
        verify(resultSet, times(1)).getString("Submtd_DRG_Code_Desc");
        verify(resultSet, times(1)).getString("APR_Code_Description");
        verify(resultSet, times(1)).getString("Severity_of_Illness_Code_Desc");
        verify(resultSet, times(1)).getString("BlueCard_SCCF_No");
        verify(resultSet, times(1)).getString("external_payment_id");
        verify(resultSet, times(1)).getString("Provider_Speciality");
        verify(resultSet, times(1)).getString("referring_practitioner_name");
    }
}
