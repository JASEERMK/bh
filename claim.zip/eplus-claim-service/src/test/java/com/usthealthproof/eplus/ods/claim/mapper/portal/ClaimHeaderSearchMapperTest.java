package com.usthealthproof.eplus.ods.claim.mapper.portal;

import com.usthealthproof.eplus.ods.claim.model.portal.Name;
import com.usthealthproof.eplus.ods.claim.model.portal.Patient;
import com.usthealthproof.eplus.ods.claim.model.portal.Provider;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class ClaimHeaderSearchMapperTest {

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet rs;

    @InjectMocks
    private ClaimHeaderSearchMapper claimHeaderSearchMapper;

    private Map<String, String> claimSearchStatusMap;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        claimSearchStatusMap = new HashMap<>();
        claimSearchStatusMap.put("Paid", "Paid");
        claimSearchStatusMap.put("Others", "Others");

        // Use reflection to set the private field
        setPrivateField(claimHeaderSearchMapper, "claimSearchStatusMap", claimSearchStatusMap);
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void testMapRow_withValidClaimStatus() throws SQLException {
        when(rs.getString("claim_number")).thenReturn("12345");
        when(rs.getString("claim_status")).thenReturn("Paid");
        when(rs.getString("claim_category")).thenReturn("Medical");
        when(rs.getString("service_date")).thenReturn("2023-01-01");
        when(dateUtils.getFormattedClientDate("2023-01-01")).thenReturn("01-Jan-2023");
        when(rs.getString("paid_date")).thenReturn("2023-01-15");
        when(dateUtils.getFormattedClientDate("2023-01-15")).thenReturn("15-Jan-2023");
        when(rs.getString("total_submitted_amount")).thenReturn("1000");
        when(rs.getString("total_paid")).thenReturn("800");
        when(rs.getString("total_billed")).thenReturn("1200");
        when(rs.getString("member_number")).thenReturn("M123");
        when(rs.getString("MEMBER_FIRST_NAME")).thenReturn("John");
        when(rs.getString("MEMBER_LAST_NAME")).thenReturn("Doe");
        when(rs.getString("MEMBER_MIDDLE_NAME")).thenReturn("A");
        when(rs.getString("provider_first_name")).thenReturn("Dr. Jane");
        when(rs.getString("provider_last_name")).thenReturn("Smith");
        when(rs.getString("provider_middle_name")).thenReturn("B");
        when(rs.getString("provider_npi")).thenReturn("1234567890");
        when(rs.getString("Provider_Taxid")).thenReturn("987654321");
        when(rs.getString("provider_id")).thenReturn("P123");
        when(rs.getString("PRACTITIONER_HCC_ID")).thenReturn("HCC123");
        when(rs.getString("SUPPLIER_LOCATION_HCC_ID")).thenReturn("HCC456");

        ClaimSearchModel claimSearchModel = claimHeaderSearchMapper.mapRow(rs, 0);

        assertEquals("12345", claimSearchModel.getClaimNumber());
        assertEquals("Paid", claimSearchModel.getClaimStatus());
        assertEquals("Medical", claimSearchModel.getClaimType());
        assertEquals("01-Jan-2023", claimSearchModel.getServiceDate());
        assertEquals("15-Jan-2023", claimSearchModel.getPaidDate());
        assertEquals("1000", claimSearchModel.getTotalSubmittedAmount());
        assertEquals("800", claimSearchModel.getTotalPaidAmount());
        assertEquals("1200", claimSearchModel.getTotalBilledAmount());

        Patient patient = claimSearchModel.getPatient();
        assertEquals("M123", patient.getMemberNumber());
        Name patientName = patient.getName();
        assertEquals("John", patientName.getFirstName());
        assertEquals("Doe", patientName.getLastName());
        assertEquals("A", patientName.getMiddleName());

        Provider provider = claimSearchModel.getProvider();
        assertEquals("1234567890", provider.getProviderNpi());
        assertEquals("987654321", provider.getProviderTaxId());
        assertEquals("P123", provider.getProviderId());
        assertEquals("HCC123", provider.getPractitionerId());
        assertEquals("HCC456", provider.getSupplierLocationId());
        Name providerName = provider.getName();
        assertEquals("Dr. Jane", providerName.getFirstName());
        assertEquals("Smith", providerName.getLastName());
        assertEquals("B", providerName.getMiddleName());
    }

    @Test
    void testMapRow_withInvalidClaimStatus() throws SQLException {
        when(rs.getString("claim_number")).thenReturn("12345");
        when(rs.getString("claim_status")).thenReturn("UnknownStatus");
        when(rs.getString("claim_category")).thenReturn("Medical");
        when(rs.getString("service_date")).thenReturn("2023-01-01");
        when(dateUtils.getFormattedClientDate("2023-01-01")).thenReturn("01-Jan-2023");
        when(rs.getString("paid_date")).thenReturn("2023-01-15");
        when(dateUtils.getFormattedClientDate("2023-01-15")).thenReturn("15-Jan-2023");
        when(rs.getString("total_submitted_amount")).thenReturn("1000");
        when(rs.getString("total_paid")).thenReturn("800");
        when(rs.getString("total_billed")).thenReturn("1200");
        when(rs.getString("member_number")).thenReturn("M123");
        when(rs.getString("MEMBER_FIRST_NAME")).thenReturn("John");
        when(rs.getString("MEMBER_LAST_NAME")).thenReturn("Doe");
        when(rs.getString("MEMBER_MIDDLE_NAME")).thenReturn("A");
        when(rs.getString("provider_first_name")).thenReturn("Dr. Jane");
        when(rs.getString("provider_last_name")).thenReturn("Smith");
        when(rs.getString("provider_middle_name")).thenReturn("B");
        when(rs.getString("provider_npi")).thenReturn("1234567890");
        when(rs.getString("Provider_Taxid")).thenReturn("987654321");
        when(rs.getString("provider_id")).thenReturn("P123");
        when(rs.getString("PRACTITIONER_HCC_ID")).thenReturn("HCC123");
        when(rs.getString("SUPPLIER_LOCATION_HCC_ID")).thenReturn("HCC456");

        ClaimSearchModel claimSearchModel = claimHeaderSearchMapper.mapRow(rs, 0);

        assertEquals("12345", claimSearchModel.getClaimNumber());
        assertEquals("Others", claimSearchModel.getClaimStatus());
        assertEquals("Medical", claimSearchModel.getClaimType());
        assertEquals("01-Jan-2023", claimSearchModel.getServiceDate());
        assertEquals("15-Jan-2023", claimSearchModel.getPaidDate());
        assertEquals("1000", claimSearchModel.getTotalSubmittedAmount());
        assertEquals("800", claimSearchModel.getTotalPaidAmount());
        assertEquals("1200", claimSearchModel.getTotalBilledAmount());

        Patient patient = claimSearchModel.getPatient();
        assertEquals("M123", patient.getMemberNumber());
        Name patientName = patient.getName();
        assertEquals("John", patientName.getFirstName());
        assertEquals("Doe", patientName.getLastName());
        assertEquals("A", patientName.getMiddleName());

        Provider provider = claimSearchModel.getProvider();
        assertEquals("1234567890", provider.getProviderNpi());
        assertEquals("987654321", provider.getProviderTaxId());
        assertEquals("P123", provider.getProviderId());
        assertEquals("HCC123", provider.getPractitionerId());
        assertEquals("HCC456", provider.getSupplierLocationId());
        Name providerName = provider.getName();
        assertEquals("Dr. Jane", providerName.getFirstName());
        assertEquals("Smith", providerName.getLastName());
        assertEquals("B", providerName.getMiddleName());
    }
}
