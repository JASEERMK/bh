package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.vision.*;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class VisionClaimServiceControllerTest {

    @InjectMocks
    private VisionClaimServiceController visionClaimServiceController;

    @Mock
    private ClaimServices claimServices;

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private Validator validator;

    private String claimHccId;
    private String state;
    private String lob;
    private String product;
    private VisionClaimDetails visionClaimDetails;
    private List<VisionClaimLines> visionClaimLines;
    private VisionClaimLineDetails visionClaimLineDetails;

    @BeforeEach
    void setUp() {
        claimHccId = "validClaimHccId";
        state = "TX";
        lob = "Medical";
        product = "Health";
        visionClaimDetails = new VisionClaimDetails();
        visionClaimLines = List.of(new VisionClaimLines());
        visionClaimLineDetails = new VisionClaimLineDetails();
    }

    @Test
    void testGetVisionClaimDetails() {
        when(claimServices.findVisionClaimId(anyString(), anyString(), anyString(), anyString())).thenReturn(visionClaimDetails);

        ResponseEntity<VisionClaimDetails> response = visionClaimServiceController.getVisionClaimDetails(claimHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(visionClaimDetails, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).findVisionClaimId(claimHccId, state, lob, product);
    }

    @Test
    void testGetVisionClaimLines() {
        when(claimServices.getVisionClaimLines(anyString(), anyString(), anyString(), anyString())).thenReturn(visionClaimLines);

        ResponseEntity<VisionClaimLinesResponse> response = visionClaimServiceController.getVisionClaimLines(claimHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(visionClaimLines, response.getBody().getVisionClaimLines());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).getVisionClaimLines(claimHccId, state, lob, product);
    }

    @Test
    void testGetVisionClaimLineDetails() {
        String claimLineHccId = "validClaimLineHccId";
        when(claimServices.getVisionClaimLineDetails(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(visionClaimLineDetails);

        ResponseEntity<VisionClaimLineDetailsResponse> response = visionClaimServiceController.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(visionClaimLineDetails, response.getBody().getVisionClaimLineDetails().get(0));

        verify(validator, times(1)).validateRequestField(claimHccId, claimLineHccId);
        verify(claimServices, times(1)).getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
    }

    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\"
    })

    void testGetVisionClaimDetails_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/vision")
                        .param("claimHccId", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\",
    })

    void testGetVisionClaimLines_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/vision/claimlines")
                        .param("claimHccId", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\",
    })

    void testGetVisionClaimLineDetails_invalidClaimFactKeyPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/vision/claimline")
                        .param("claimHccId", "1234")
                        .param("claimLineHccId",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimLineHccId is not in valid format"));
    }
}
