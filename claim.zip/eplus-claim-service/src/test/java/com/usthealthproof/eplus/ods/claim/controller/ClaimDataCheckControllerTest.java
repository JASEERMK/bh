package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.validation.annotation.Validated;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@Validated
@SpringBootTest
@AutoConfigureMockMvc
class ClaimDataCheckControllerTest {

    @InjectMocks
    private ClaimDataCheckController claimDataCheckController;

    @Mock
    private ClaimHeaderSearchService claimHeaderSearchService;

    @Mock
    private Validator validator;

    @Autowired
    private MockMvc mockMvc;



    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void providerClaimDataAvailabilityCheck_validRequest_success() throws Exception {
        ClaimHeaderSearchResponse expectedResponse = new ClaimHeaderSearchResponse();
        when(claimHeaderSearchService.providerClaimDataAvailabilityCheck(any(ClaimHeaderSearchRequest.class)))
                .thenReturn(expectedResponse);
        ResponseEntity<ClaimHeaderSearchResponse> response = claimDataCheckController.providerClaimDataAvailabilityCheck(
                "providerId",
                "providerType",
                "claimTypes",
                "claimNumber",
                "serviceFromDate",
                "serviceToDate",
                "claimStatus",
                "serviceCode",
                "diagnosisCode",
                "memberNumber",
                "state",
                "lob",
                "product");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedResponse, response.getBody());
    }
    @Test
    void providerClaimDataAvailabilityCheck_serviceThrowsException_throwsRuntimeException() throws Exception {
        when(claimHeaderSearchService.providerClaimDataAvailabilityCheck(any(ClaimHeaderSearchRequest.class)))
                .thenThrow(new RuntimeException("Service Error"));
        try {
            claimDataCheckController.providerClaimDataAvailabilityCheck(
                    "providerId",
                    "providerType",
                    "claimTypes",
                    "claimNumber",
                    "serviceFromDate",
                    "serviceToDate",
                    "claimStatus",
                    "serviceCode",
                    "diagnosisCode",
                    "memberNumber",
                    "state",
                    "lob",
                    "product");
        } catch (RuntimeException e) {
            assertEquals("Service Error", e.getMessage());
        }
    }

    @ParameterizedTest
    @CsvSource({
            "M001<",
            "M001>",
            "M001'",
            "M001=",
            "M001&",
            "M001%",
            "M001#",
            "M001&",
            "M001(",
            "M001)",
            "M001@",
            "M001\\,8",
            "M001/",
            "M001*",
            "M001|",
            "M001;",
            "M001!",
            "M001--",
            "M001--",
            "M001\\\\"
    })

    void testGetClaimDetails_invalidMemberNumberPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/provider/claimSearch/isAvailable")
                        .param("claimTypes", "medical")
                        .param("memberNumber", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: memberNumber is not in valid format"));
    }




    @ParameterizedTest
    @CsvSource({
            "Medical<",
            "Medical>",
            "Medical=",
            "Medical&",
            "Medical%",
            "Medical#",
            "Medical&",
            "Medical(",
            "Medical)",
            "Medical@",
            "Medical\\,",
            "Medical/",
            "Medical*",
            "Medical|",
            "Medical;",
            "Medical!",
            "Medical--",
            "Medical\\\\",
    })

    void testGetClaimDetails_invalidClaimTypePattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/provider/claimSearch/isAvailable")
                        .param("claimTypes", pattern))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                        .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimTypes is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "USA<",
            "USA>",
            "USA=",

    })
    void testGetClaimDetails_invalidStatePattern_commaCharacter(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/provider/claimSearch/isAvailable")
                        .param("claimTypes", "medical")
                        .param("state", pattern))
                        .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: state is not in valid format"));
    }
}