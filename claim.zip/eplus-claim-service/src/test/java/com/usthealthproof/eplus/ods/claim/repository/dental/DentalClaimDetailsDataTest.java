package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DentalClaimDetailsDataTest {

    @Mock
    private DentalClaimDetailsMapper dentalClaimDetailsMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private DentalClaimDetailsData dentalClaimDetailsData;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindDentalClaimIdSuccess() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        DentalClaimDetails expectedDetails = new DentalClaimDetails();

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimDetailsMapper)))
                .thenReturn(expectedDetails);

        DentalClaimDetails result = dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testFindDentalClaimIdJdbcConnectionException() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("JDBC Connection Error"));

        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () ->
                dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product));

        assertEquals("JDBC Connection Error", thrown.getMessage());
    }

    @Test
    void testFindDentalClaimIdEmptyResultDataAccessException() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimDetailsMapper)))
                .thenThrow(new EmptyResultDataAccessException("No data", 1));

        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () ->
                dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product));

        assertEquals(ClaimConstants.DENTAL_CLAIM_DETAILS_NOT_FOUND + claimHccId, thrown.getMessage());
    }

    @Test
    void testFindDentalClaimIdGenericException() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimDetailsMapper)))
                .thenThrow(new RuntimeException("Generic error"));

        RuntimeException thrown = assertThrows(RuntimeException.class, () ->
                dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product));

        assertEquals("Generic error", thrown.getMessage());
    }
}
