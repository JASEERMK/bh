package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@Slf4j
public class VisionClaimDetailsDataTest {

    @InjectMocks
    private VisionClaimDetailsData visionClaimDetailsData;

    @Mock
    private VisionClaimDetailsMapper visionClaimDetailsMapper;
    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindVisionClaimId_Success() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        VisionClaimDetails visionClaimDetails = new VisionClaimDetails();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimDetailsMapper)))
                .thenReturn(visionClaimDetails);

        // Act
        VisionClaimDetails result = visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product);

        // Assert
        assertNotNull(result);
        assertEquals(visionClaimDetails, result);
    }

    @Test
    public void testFindVisionClaimId_EmptyResult() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimDetailsMapper)))
                .thenThrow(new EmptyResultDataAccessException(1));

        // Act & Assert
        ClaimNotFoundException exception = assertThrows(ClaimNotFoundException.class, () -> {
            visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product);
        });

        assertTrue(exception.getMessage().contains(ClaimConstants.VISION_CLAIM_DETAILS_NOT_FOUND));
    }

    @Test
    public void testFindVisionClaimId_CannotGetJdbcConnectionException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database connection error"));

        // Act & Assert
        CannotGetJdbcConnectionException exception = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product);
        });

        assertEquals("Database connection error", exception.getMessage());
        }

    @Test
    public void testFindVisionClaimId_GeneralException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimDetailsMapper)))
                .thenThrow(new RuntimeException("General error"));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product);
        });

        assertEquals("General error", exception.getMessage());
    }
}
