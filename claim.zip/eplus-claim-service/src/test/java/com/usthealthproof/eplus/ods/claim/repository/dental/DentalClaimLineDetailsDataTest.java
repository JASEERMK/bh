package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.dao.EmptyResultDataAccessException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DentalClaimLineDetailsDataTest {

    @Mock
    private DentalClaimLineDetailsMapper dentalClaimLineDetailsMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private DentalClaimLineDetailsData dentalClaimLineDetailsData;

    private String spDentalClaimLineDetails = "spDentalClaimLineDetails";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dentalClaimLineDetailsData.spDentalClaimLineDetails = spDentalClaimLineDetails;
    }

    @Test
    void testGetDentalClaimLineDetailsSuccess() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        DentalClaimLineDetails expectedDetails = new DentalClaimLineDetails();

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimLineDetailsMapper)))
                .thenReturn(expectedDetails);

        DentalClaimLineDetails result = dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testGetDentalClaimLineDetailsJdbcConnectionException() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimLineDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("JDBC Connection Error"));

        assertThrows(CannotGetJdbcConnectionException.class, () ->
                dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product));
    }

    @Test
    void testGetDentalClaimLineDetailsEmptyResultDataAccessException() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimLineDetailsMapper)))
                .thenThrow(new EmptyResultDataAccessException("No data", 1));

        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () ->
                dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product));

        assertEquals(ClaimConstants.DENTAL_CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId + " and claim line number : " + claimLineHccId, thrown.getMessage());
    }

    @Test
    void testGetDentalClaimLineDetailsGenericException() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(dentalClaimLineDetailsMapper)))
                .thenThrow(new RuntimeException("Generic error"));

        assertThrows(RuntimeException.class, () ->
                dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product));
    }
}
