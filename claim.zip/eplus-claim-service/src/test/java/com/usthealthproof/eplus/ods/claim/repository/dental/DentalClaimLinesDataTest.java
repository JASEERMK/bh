package com.usthealthproof.eplus.ods.claim.repository.dental;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.dental.DentalClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class DentalClaimLinesDataTest {

    @Mock
    private DentalClaimLinesMapper dentalClaimLinesMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private DentalClaimLinesData dentalClaimLinesData;

    private String spDentalClaimLines = "spDentalClaimLines";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dentalClaimLinesData.spDentalClaimLines = spDentalClaimLines;
    }

    @Test
    void testGetDentalClaimLinesSuccess() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        List<DentalClaimLines> expectedLines = Collections.singletonList(new DentalClaimLines());

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(DentalClaimLinesMapper.class)))
                .thenReturn(expectedLines);

        List<DentalClaimLines> result = dentalClaimLinesData.getDentalClaimLines(claimHccId, state, lob, product);

        assertNotNull(result);
        assertEquals(expectedLines, result);
    }

    @Test
    void testGetDentalClaimLinesEmptyResult() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(DentalClaimLinesMapper.class)))
                .thenReturn(Collections.emptyList());

        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () ->
                dentalClaimLinesData.getDentalClaimLines(claimHccId, state, lob, product));

        assertEquals(ClaimConstants.DENTAL_CLAIM_LINES_NOT_FOUND + claimHccId, thrown.getMessage());
    }

    @Test
    void testGetDentalClaimLinesJdbcConnectionException() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(DentalClaimLinesMapper.class)))
                .thenThrow(new CannotGetJdbcConnectionException("JDBC Connection Error"));

        assertThrows(CannotGetJdbcConnectionException.class, () ->
                dentalClaimLinesData.getDentalClaimLines(claimHccId, state, lob, product));
    }

    @Test
    void testGetDentalClaimLinesGenericException() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(DentalClaimLinesMapper.class)))
                .thenThrow(new RuntimeException("Generic error"));

        assertThrows(RuntimeException.class, () ->
                dentalClaimLinesData.getDentalClaimLines(claimHccId, state, lob, product));
    }
}
