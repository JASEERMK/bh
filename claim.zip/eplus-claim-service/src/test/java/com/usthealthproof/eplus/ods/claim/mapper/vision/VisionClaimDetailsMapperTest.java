package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class VisionClaimDetailsMapperTest {

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @InjectMocks
    private VisionClaimDetailsMapper visionClaimDetailsMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        when(resultSet.getString("memberKey")).thenReturn("12345");
        when(resultSet.getString("insurer_id")).thenReturn("67890");
        when(resultSet.getString("insurere_name")).thenReturn("ABC Insurance");
        when(resultSet.getString("providerKey")).thenReturn("11121");
        when(resultSet.getString("provider_name")).thenReturn("Dr. Smith");
        when(resultSet.getString("serviceStartDate")).thenReturn("2022-01-01");
        when(resultSet.getString("serviceEndDate")).thenReturn("2022-01-31");
        when(dateUtils.getFormattedApplicationDate("2022-01-01")).thenReturn("01/01/2022");
        when(dateUtils.getFormattedApplicationDate("2022-01-31")).thenReturn("01/31/2022");
        when(resultSet.getString("location_id")).thenReturn("22232");
        when(resultSet.getString("location_name")).thenReturn("Main Clinic");
        when(resultSet.getString("payee_other_id")).thenReturn("33343");
        when(resultSet.getString("payee_other_name")).thenReturn("Payee Name");
        when(resultSet.getString("network_id")).thenReturn("44454");
        when(resultSet.getString("network_name")).thenReturn("Network Name");
        when(resultSet.getString("claim_received_date")).thenReturn("2022-02-01");
        when(dateUtils.getFormattedApplicationDate("2022-02-01")).thenReturn("02/01/2022");
        when(resultSet.getString("claim_entered_date")).thenReturn("2022-02-05");
        when(dateUtils.getFormattedApplicationDate("2022-02-05")).thenReturn("02/05/2022");
        when(resultSet.getString("Payment_Date")).thenReturn("2022-02-10");
        when(dateUtils.getFormattedApplicationDate("2022-02-10")).thenReturn("02/10/2022");
        when(resultSet.getString("Payment_Number")).thenReturn("55565");
        when(resultSet.getString("paid_amount")).thenReturn("100.00");
        when(resultSet.getString("net_paid_amount")).thenReturn("90.00");
        when(resultSet.getString("billedAmount")).thenReturn("150.00");
        when(resultSet.getString("allowed")).thenReturn("120.00");
        when(resultSet.getString("deductible")).thenReturn("10.00");
        when(resultSet.getString("co_pay")).thenReturn("5.00");
        when(resultSet.getString("coinsurance_amount")).thenReturn("15.00");
        when(resultSet.getString("over_max")).thenReturn("0.00");
        when(resultSet.getString("cob_amount")).thenReturn("20.00");
        when(resultSet.getString("payment_status")).thenReturn("Paid");
        when(resultSet.getString("pay_member")).thenReturn("N");
        when(resultSet.getString("payment_notes")).thenReturn("No notes");
        when(resultSet.getString("eft_flag")).thenReturn("Y");
        when(resultSet.getString("eft_account")).thenReturn("123456789");
        when(resultSet.getString("check_cleared")).thenReturn("Y");
        when(resultSet.getString("payment_amount")).thenReturn("90.00");
        when(resultSet.getString("createdBy")).thenReturn("Admin");
        when(resultSet.getString("lastModifiedBy")).thenReturn("Admin");
        when(resultSet.getString("member_name")).thenReturn("John Doe");

        VisionClaimDetails visionClaimDetails = visionClaimDetailsMapper.mapRow(resultSet, 1);

        assertEquals("12345", visionClaimDetails.getMemberId());
        assertEquals("67890", visionClaimDetails.getInsureId());
        assertEquals("ABC Insurance", visionClaimDetails.getInsurerName());
        assertEquals("11121", visionClaimDetails.getProviderId());
        assertEquals("Dr. Smith", visionClaimDetails.getProviderName());
        assertEquals("01/01/2022", visionClaimDetails.getFromDate());
        assertEquals("01/31/2022", visionClaimDetails.getEndDate());
        assertEquals("22232", visionClaimDetails.getLocationId());
        assertEquals("Main Clinic", visionClaimDetails.getLocationName());
        assertEquals("33343", visionClaimDetails.getPayeeId());
        assertEquals("Payee Name", visionClaimDetails.getPayeeName());
        assertEquals("44454", visionClaimDetails.getNetworkId());
        assertEquals("Network Name", visionClaimDetails.getNetworkName());
        assertEquals("02/01/2022", visionClaimDetails.getReceivedDate());
        assertEquals("02/05/2022", visionClaimDetails.getEnteredDate());
        assertEquals("02/10/2022", visionClaimDetails.getPaymentDate());
        assertEquals("55565", visionClaimDetails.getCheckNumber());
        assertEquals("100.00", visionClaimDetails.getPaidAmount());
        assertEquals("90.00", visionClaimDetails.getNetPaidAmount());
        assertEquals("150.00", visionClaimDetails.getBilledAmount());
        assertEquals("120.00", visionClaimDetails.getAllowedAmount());
        assertEquals("10.00", visionClaimDetails.getDeductibleAmount());
        assertEquals("5.00", visionClaimDetails.getCopayAmount());
        assertEquals("15.00", visionClaimDetails.getCoinsuranceAmount());
        assertEquals("0.00", visionClaimDetails.getOverMax());
        assertEquals("20.00", visionClaimDetails.getCobAmount());
        assertEquals("Paid", visionClaimDetails.getPaymentStatus());
        assertEquals("N", visionClaimDetails.getPayMember());
        assertEquals("No notes", visionClaimDetails.getPaymentNotes());
        assertEquals("Y", visionClaimDetails.getEftFlag());
        assertEquals("123456789", visionClaimDetails.getEftAccount());
        assertEquals("Y", visionClaimDetails.getCheckCleared());
        assertEquals("90.00", visionClaimDetails.getPaymentAmount());
        assertEquals("Admin", visionClaimDetails.getCreatedBy());
        assertEquals("Admin", visionClaimDetails.getLastModifiedBy());
        assertEquals("John Doe", visionClaimDetails.getMemberName());
    }
}
