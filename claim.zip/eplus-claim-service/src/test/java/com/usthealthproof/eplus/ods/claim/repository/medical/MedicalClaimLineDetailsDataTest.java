package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MedicalClaimLineDetailsDataTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimLineDetailsMapper medicalClaimLineDetailsMapper;

    @Mock
    private AsyncExecutorUtils asyncExecutorUtils;

    @InjectMocks
    private MedicalClaimLineDetailsData medicalClaimLineDetailsData;


    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimLineDetails_JdbcConnectionException() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "67890";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(List.of());
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenReturn(claimLinesFuture);

        when(asyncExecutorUtils.getMedicalClaimLineDetailsWithFactKey(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenThrow(new CannotGetJdbcConnectionException("Cannot get JDBC connection"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Cannot get JDBC connection", thrown.getMessage());
    }

    @Test
    void testGetClaimLineDetails_ExecutionException_ClaimNotFoundException() throws Exception {

        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(List.of());
        when(asyncExecutorUtils.getRejectionCodeDesc(any(), any(), any(),any(), any(), any())).thenReturn(claimLinesFuture);

        CompletableFuture<MedicalClaimLineDetails> mockFuture = mock(CompletableFuture.class);
        ExecutionException executionException = new ExecutionException("Mocked Execution Exception", new EmptyResultDataAccessException(1));

        doReturn(mockFuture).when(asyncExecutorUtils).getMedicalClaimLineDetailsWithFactKey(any(), any(), any(), any(), any(), any());
        doThrow(executionException).when(mockFuture).get();

        assertThrows(ClaimNotFoundException.class, () ->
                medicalClaimLineDetailsData.getClaimLineDetails("HCC123", "Line123", "FactKey123", "State1", "LOB1", "Product1")
        );
    }

    @Test
    void testGetClaimLineDetails_ExecutionException_Exception() throws Exception {

        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(List.of());
        when(asyncExecutorUtils.getRejectionCodeDesc(any(), any(), any(),any(), any(), any())).thenReturn(claimLinesFuture);

        CompletableFuture<MedicalClaimLineDetails> mockFuture = mock(CompletableFuture.class);
        ExecutionException executionException = new ExecutionException("Mocked Execution Exception", new Exception());

        doReturn(mockFuture).when(asyncExecutorUtils).getMedicalClaimLineDetailsWithFactKey(any(), any(), any(), any(), any(), any());
        doThrow(executionException).when(mockFuture).get();

        assertThrows(Exception.class, () ->
                medicalClaimLineDetailsData.getClaimLineDetails("HCC123", "Line123", "FactKey123", "State1", "LOB1", "Product1")
        );
    }

    @Test
    public void testGetClaimLineDetails_EmptyResultException() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "67890";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(List.of());
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey,state, lob, product)).thenReturn(claimLinesFuture);

        // Mock claimLineDetailsUtils throwing EmptyResultDataAccessException
        CompletableFuture<MedicalClaimLineDetails> failedFuture = new CompletableFuture<>();
        failedFuture.completeExceptionally(new EmptyResultDataAccessException(1));
        when(asyncExecutorUtils.getMedicalClaimLineDetailsWithFactKey(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenThrow(new EmptyResultDataAccessException(0));

        // Act
        Exception exception = assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        // Assert
        String expectedMessage = ClaimConstants.CLAIM_LINE_DETAILS_NOT_FOUND + claimHccId + " and claim line number : " + claimLineHccId;
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage), "Exception message does not match. Expected to contain: " + expectedMessage + ", but got: " + actualMessage);
    }

    @Test
    public void testGetClaimLineDetails_GenericException() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "67890";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey, state, lob, product))
                .thenThrow(new RuntimeException("Generic runtime exception"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Generic runtime exception", thrown.getMessage());
    }

    @Test
    public void testGetClaimLineDetails_ClaimFactKeyBlank() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "67890";
        String claimFactKey = ""; // Blank claimFactKey
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";
        MedicalClaimLineDetails mockClaimLineDetails = new MedicalClaimLineDetails();
        mockClaimLineDetails.setRejectionCodeDesc("abc,ase");

        List<ClaimRejectionDetails> medicalClaimLinesList = new ArrayList<>();
        ClaimRejectionDetails rejectionDetails = new ClaimRejectionDetails();
        rejectionDetails.setRejectionCodeDesc("abc,ase");
        medicalClaimLinesList.add(rejectionDetails);
        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(medicalClaimLinesList);
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenReturn(claimLinesFuture);

        // Mock claimLineDetailsUtils response
        MedicalClaimLineDetails mockDetails = new MedicalClaimLineDetails();
        CompletableFuture<MedicalClaimLineDetails> detailsFuture = CompletableFuture.completedFuture(mockDetails);
        when(asyncExecutorUtils.getMedicalClaimLineDetailsWithoutFactKey(claimHccId, claimLineHccId, state, lob, product)).thenReturn(detailsFuture);

        // Act
        MedicalClaimLineDetails result = medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        assertEquals(mockClaimLineDetails, result);
    }

    @Test
    public void testGetClaimLineDetails_Success() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "67890";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";
        MedicalClaimLineDetails mockClaimLineDetails = new MedicalClaimLineDetails();
        mockClaimLineDetails.setRejectionCodeDesc("abc,ase");

        List<ClaimRejectionDetails> medicalClaimLinesList = new ArrayList<>();
        ClaimRejectionDetails rejectionDetails = new ClaimRejectionDetails();
        rejectionDetails.setRejectionCodeDesc("abc,ase");
        medicalClaimLinesList.add(rejectionDetails);
        CompletableFuture<List<ClaimRejectionDetails>> claimLinesFuture = CompletableFuture.completedFuture(medicalClaimLinesList);
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenReturn(claimLinesFuture);

        // Mock claimLineDetailsUtils response
        MedicalClaimLineDetails mockDetails = new MedicalClaimLineDetails();
        CompletableFuture<MedicalClaimLineDetails> detailsFuture = CompletableFuture.completedFuture(mockDetails);
        when(asyncExecutorUtils.getMedicalClaimLineDetailsWithFactKey(claimHccId, claimLineHccId, claimFactKey, state, lob, product)).thenReturn(detailsFuture);

        // Act
        MedicalClaimLineDetails result = medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        // Assert
        assertEquals(mockClaimLineDetails, result);
    }
}
