package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class DentalClaimLinesMapperTest {

    @InjectMocks
    private DentalClaimLinesMapper dentalClaimLinesMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("claimlinenumber")).thenReturn("lineNumber123");
        when(resultSet.getString("claimhccid")).thenReturn("claimHccId123");
        when(resultSet.getString("service_start_date")).thenReturn("2023-01-01");
        when(resultSet.getString("status")).thenReturn("status123");
        when(resultSet.getString("Codedescription")).thenReturn("code-description");

        // Setup mock behavior for DateUtils
        when(dateUtils.getFormattedApplicationDate(anyString())).thenReturn("formattedDate");

        // Execute mapRow
        DentalClaimLines result = dentalClaimLinesMapper.mapRow(resultSet, 1);

        // Verify results
        assertEquals("lineNumber123", result.getClaimLineNumber());
        assertEquals("claimHccId123", result.getClaimHccId());
        assertEquals("formattedDate", result.getServiceStartDate());
        assertEquals("status123", result.getStatus());
        assertEquals("code-description", result.getServiceCodeDescription());
    }
}
