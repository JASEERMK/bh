package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class MedicalClaimDetailsDataTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimDetailsMapper medicalClaimDetailsMapper;

    @Mock
    private AsyncExecutorUtils asyncExecutorUtils;

    @InjectMocks
    private MedicalClaimDetailsData medicalClaimDetailsData;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindClaimId_Success_WithClaimFactKey() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";
        List<String> claimFactKeys = Collections.singletonList("factKey");

        MedicalClaimDetails expectedDetails = new MedicalClaimDetails();
        expectedDetails.setClaimFactKeys(claimFactKeys);

        CompletableFuture<List<String>> completableFuture = CompletableFuture.completedFuture(claimFactKeys);

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenReturn(completableFuture);

        MedicalClaimDetails mockDetails = new MedicalClaimDetails();
        CompletableFuture<MedicalClaimDetails> claimDetailsCompletableFuture = CompletableFuture.completedFuture(mockDetails);
        when(asyncExecutorUtils.getMedicalClaimDetailsWithFactKey(claimHccId, claimFactKey, state, lob, product)).thenReturn(claimDetailsCompletableFuture);

        // Act
        MedicalClaimDetails actualDetails = medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);

        // Assert
        assertNotNull(actualDetails);
        assertEquals(expectedDetails.getClaimFactKeys(), actualDetails.getClaimFactKeys());
    }

    @Test
    public void testFindClaimId_Success_WithoutClaimFactKey() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = null;
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";
        List<String> claimFactKeys = Collections.singletonList("factKey");

        MedicalClaimDetails expectedDetails = new MedicalClaimDetails();
        expectedDetails.setClaimFactKeys(claimFactKeys);

        CompletableFuture<List<String>> completableFuture = CompletableFuture.completedFuture(claimFactKeys);

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenReturn(completableFuture);

        MedicalClaimDetails mockDetails = new MedicalClaimDetails();
        CompletableFuture<MedicalClaimDetails> claimDetailsCompletableFuture = CompletableFuture.completedFuture(mockDetails);
        when(asyncExecutorUtils.getMedicalClaimDetailsWithoutFactKey(claimHccId, state, lob, product)).thenReturn(claimDetailsCompletableFuture);
        // Act
        MedicalClaimDetails actualDetails = medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);

        // Assert
        assertNotNull(actualDetails);
        assertEquals(expectedDetails.getClaimFactKeys(), actualDetails.getClaimFactKeys());
    }

    @Test
    public void testFindClaimId_NoClaimFactKeys() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<List<String>> completableFuture = CompletableFuture.completedFuture(Collections.emptyList());

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenReturn(completableFuture);

        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });
        assertEquals(ClaimConstants.CLAIM_DETAILS_NOT_FOUND + claimHccId, thrown.getMessage());
    }

    @Test
    public void testFindClaimId_JdbcException() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<List<String>> completableFuture = CompletableFuture.completedFuture(Collections.singletonList("factKey"));

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenThrow(new CannotGetJdbcConnectionException("Cannot get JDBC connection"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });
        assertEquals("Cannot get JDBC connection", thrown.getMessage());
    }

    @Test
    public void testFindClaimId_EmptyResult() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<List<String>> completableFuture = CompletableFuture.completedFuture(Collections.singletonList("factKey"));

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenThrow(new EmptyResultDataAccessException("No data found", 1));
        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });
        assertEquals(ClaimConstants.CLAIM_DETAILS_NOT_FOUND + claimHccId, thrown.getMessage());
    }

    @Test
    public void testFindClaimId_ExceptionHandling() {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        when(asyncExecutorUtils.getClaimFactKeys(claimHccId)).thenThrow(new RuntimeException("Generic runtime exception"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Generic runtime exception", thrown.getMessage());
    }

    @Test
    public void testFindClaimId_ExecutionException() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<MedicalClaimLineDetails> mockFuture = mock(CompletableFuture.class);
        ExecutionException executionException = new ExecutionException("Mocked Execution Exception", new EmptyResultDataAccessException(1));

        doReturn(mockFuture).when(asyncExecutorUtils).getMedicalClaimDetailsWithFactKey(any(), any(), any(), any(), any());
        doThrow(executionException).when(mockFuture).get();
        // Act & Assert
         assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });

    }

    @Test
    void testFindClaimId_ExecutionException_Generic() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        CompletableFuture<MedicalClaimLineDetails> mockFuture = mock(CompletableFuture.class);
        ExecutionException executionException = new ExecutionException("Mocked Execution Exception", new Exception());

        doReturn(mockFuture).when(asyncExecutorUtils).getMedicalClaimDetailsWithFactKey(any(), any(), any(), any(), any());
        doThrow(executionException).when(mockFuture).get();
        // Act & Assert
        assertThrows(Exception.class, () -> {
            medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product);
        });

    }
}
