package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimHeaderSearchService;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class ClaimSearchControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ClaimHeaderSearchService claimHeaderSearchService;

    @MockitoBean
    private Validator validator;

    @InjectMocks
    private ClaimSearchController claimSearchController;

    private ClaimHeaderSearchResponse claimHeaderSearchResponse;
    private ClaimHeaderSearchRequest claimHeaderSearchRequest;

    @BeforeEach
    void setUp() {
        claimHeaderSearchResponse = new ClaimHeaderSearchResponse();
        claimHeaderSearchRequest = new ClaimHeaderSearchRequest();
    }

    @Test
    void testGetClaimDetails() throws Exception {
        when(claimHeaderSearchService.getMemberClaimSearch(any(ClaimHeaderSearchRequest.class), any(ClaimHeaderSearchResponse.class)))
                .thenReturn(claimHeaderSearchResponse);

        mockMvc.perform(get("/v1/claims/member/claimSearch")
                        .param("claimTypes", "medical")
                        .param("claimNumber", "123")
                        .param("serviceFromDate", "2022-01-01")
                        .param("serviceToDate", "2022-12-31")
                        .param("claimStatus", "processed")
                        .param("memberNumber", "M001")
                        .param("state", "NY")
                        .param("lob", "HMO")
                        .param("product", "Premium")
                        .param("serviceCode", "SC001")
                        .param("diagnosisCode", "D001"))
                .andExpect(status().isOk());

        verify(validator).validateMemberSearchRequest(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString());
        verify(claimHeaderSearchService).getMemberClaimSearch(any(ClaimHeaderSearchRequest.class),
                any(ClaimHeaderSearchResponse.class));
    }

    @Test
    void testGetProviderClaimDetails() throws Exception {
        when(claimHeaderSearchService.getProviderClaimSearch(any(ClaimHeaderSearchRequest.class), any(ClaimHeaderSearchResponse.class)))
                .thenReturn(claimHeaderSearchResponse);

        mockMvc.perform(get("/v1/claims/provider/claimSearch")
                        .param("claimTypes", "medical")
                        .param("memberNumber", "M001")
                        .param("providerId", "P001")
                        .param("providerType", "Primary")
                        .param("state", "NY")
                        .param("lob", "HMO")
                        .param("product", "Premium")
                        .param("serviceCode", "SC001")
                        .param("diagnosisCode", "D001"))
                .andExpect(status().isOk());

        verify(validator).validateProviderSearchRequest("medical", null, null, null, "P001",
                "Primary");
        verify(claimHeaderSearchService).getProviderClaimSearch(any(ClaimHeaderSearchRequest.class),
                any(ClaimHeaderSearchResponse.class));
    }


    @ParameterizedTest
    @CsvSource({
            "Medical<",
            "Medical>",
            "Medical=",
            "Medical&",
            "Medical%",
            "Medical#",
            "Medical&",
            "Medical(",
            "Medical)",
            "Medical@",
            "Medical\\,",
            "Medical/",
            "Medical*",
            "Medical|",
            "Medical;",
            "Medical!",
            "Medical--"
    })

    void testGetClaimDetails_invalidMemberNumberPattern(String pattern) throws Exception {
            mockMvc.perform(get("/v1/claims/member/claimSearch")
                        .param("claimTypes", "medical")
                        .param("memberNumber", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: memberNumber is not in valid format"));
    }



    @ParameterizedTest
    @CsvSource({
            "Medical<",
            "Medical>",
            "Medical=",
            "Medical&",
            "Medical%",
            "Medical#",
            "Medical&",
            "Medical(",
            "Medical)",
            "Medical@",
            "Medical\\,",
            "Medical/",
            "Medical*",
            "Medical|",
            "Medical;",
            "Medical!",
            "Medical--",
            "Medical\\\\",
    })

    void testGetProviderClaimDetails_invalidClaimTypePattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/provider/claimSearch")
                        .param("claimTypes", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimTypes is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "2020-01-01<",
            "2020-01-01>",
            "2020-01-01=",
            "2020-01-01&",
            "2020-01-01%",
            "2020-01-01#",
            "2020-01-01&",
            "2020-01-01(",
            "2020-01-01)",
            "2020-01-01@",
            "2020-01-01*",
            "2020-01-01|",
            "2020-01-01;",
            "2020-01-01!",
            "2020-01-01--",
    })

    void testGetProviderClaimDetails_invalidDatePattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/provider/claimSearch")
                        .param("claimTypes", "medical")
                        .param("serviceToDate",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: serviceToDate is not in valid format"));
    }
}

