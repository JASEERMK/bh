package com.usthealthproof.eplus.ods.claim.mapper.util;

import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimFactKeysMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ClaimFactKeysMapperTest {

    private ClaimFactKeysMapper mapper;
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        mapper = new ClaimFactKeysMapper();
        resultSet = Mockito.mock(ResultSet.class);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Define the expected value
        String expectedClaimFactKey = "12345";

        // Mock the ResultSet behavior
        when(resultSet.getString("CLAIM_FACT_KEY")).thenReturn(expectedClaimFactKey);

        // Call the method under test
        String actualClaimFactKey = mapper.mapRow(resultSet, 1);

        // Assert that the actual value matches the expected value
        assertEquals(expectedClaimFactKey, actualClaimFactKey);
    }

    @Test
    public void testMapRowWhenResultSetIsNull() throws SQLException {
        // Define the behavior for a null result set scenario
        when(resultSet.getString("CLAIM_FACT_KEY")).thenReturn(null);

        // Call the method under test
        String actualClaimFactKey = mapper.mapRow(resultSet, 1);

        // Assert that the result is null
        assertEquals(null, actualClaimFactKey);
    }
}
