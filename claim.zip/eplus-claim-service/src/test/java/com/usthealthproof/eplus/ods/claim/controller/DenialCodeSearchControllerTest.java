package com.usthealthproof.eplus.ods.claim.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.usthealthproof.eplus.ods.claim.model.search.DenialCode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
public class DenialCodeSearchControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ClaimServices claimServices;

    @InjectMocks
    private DenialCodeSearchController denialCodeSearchController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(denialCodeSearchController).build();
    }

    @Test
    public void testGetDenialCodesByClaimSuccess() throws Exception {
        String claimHccId = "123ABC";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        DenialCode denialCode1 = new DenialCode();
        denialCode1.setCode("CODE1");
        denialCode1.setDescription("Description for CODE1");

        DenialCode denialCode2 = new DenialCode();
        denialCode2.setCode("CODE2");
        denialCode2.setDescription("Description for CODE2");

        List<DenialCode> denialCodes = Arrays.asList(denialCode1, denialCode2);

        DenialCodes mockResponse = new DenialCodes();
        mockResponse.setClaimId(claimHccId);
        mockResponse.setDenialCodes(denialCodes);

        when(claimServices.getDenialCodes(claimHccId,state,lob,product)).thenReturn(mockResponse);

        mockMvc.perform(get("/v1/claims/denialcodes")
                        .param("claimHccId", claimHccId)
                        .param("state",state)
                        .param("lob",lob)
                        .param("product",product)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.denialCodes").exists())  // Check that "denialCodes" exists
                .andExpect(jsonPath("$.denialCodes[0].code").value("CODE1"))  // Check first code
                .andExpect(jsonPath("$.denialCodes[1].code").value("CODE2")); // Check second code
    }

}
