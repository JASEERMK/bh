package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class PharmacyClaimServiceControllerTest {

    @InjectMocks
    private PharmacyClaimServiceController pharmacyClaimServiceController;

    @Mock
    private ClaimServices claimServices;

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private Validator validator;

    private String claimHccId;
    private String state;
    private String lob;
    private String product;
    private RxClaimDetails rxClaimDetails;

    @BeforeEach
    void setUp() {
        claimHccId = "validClaimHccId";
        state = "TX";
        lob = "Medical";
        product = "Health";
        rxClaimDetails = new RxClaimDetails();
    }

    @Test
    void testGetRxClaimDetails() {
        when(claimServices.findRxClaimId(anyString(), anyString(), anyString(), anyString())).thenReturn(rxClaimDetails);

        ResponseEntity<RxClaimDetails> response = pharmacyClaimServiceController.getRxClaimDetails(claimHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(rxClaimDetails, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).findRxClaimId(claimHccId, state, lob, product);
    }

    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\"
    })

    void testGetRxClaimDetails_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/rx")
                        .param("claimHccId", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }
}
