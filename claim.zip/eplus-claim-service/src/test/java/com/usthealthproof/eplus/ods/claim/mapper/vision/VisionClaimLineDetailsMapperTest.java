package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class VisionClaimLineDetailsMapperTest {

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @InjectMocks
    private VisionClaimLineDetailsMapper visionClaimLineDetailsMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        when(resultSet.getString("claimhccid")).thenReturn("HCC12345");
        when(resultSet.getString("claimlinenumber")).thenReturn("LN67890");
        when(resultSet.getString("Codedescription")).thenReturn("Service Description");
        when(resultSet.getString("serviceStartDate")).thenReturn("2022-01-01");
        when(dateUtils.getFormattedApplicationDate("2022-01-01")).thenReturn("01/01/2022");
        when(resultSet.getString("authorization_id")).thenReturn("AUTH123");
        when(resultSet.getString("service_exception")).thenReturn("None");
        when(resultSet.getString("allowedamount")).thenReturn("100.00");
        when(resultSet.getString("deductible")).thenReturn("10.00");
        when(resultSet.getString("co_pay")).thenReturn("5.00");
        when(resultSet.getString("co_insurance")).thenReturn("15.00");
        when(resultSet.getString("overmax")).thenReturn("0.00");
        when(resultSet.getString("cob_amount")).thenReturn("20.00");
        when(resultSet.getString("payment_notes")).thenReturn("No notes");
        when(resultSet.getString("billed_amount")).thenReturn("150.00");

        VisionClaimLineDetails visionClaimLineDetails = visionClaimLineDetailsMapper.mapRow(resultSet, 1);

        assertEquals("HCC12345", visionClaimLineDetails.getClaimHccId());
        assertEquals("LN67890", visionClaimLineDetails.getClaimLineNumber());
        assertEquals("Service Description", visionClaimLineDetails.getCodeDescription());
        assertEquals("01/01/2022", visionClaimLineDetails.getServiceStartDate());
        assertEquals("AUTH123", visionClaimLineDetails.getAuthorizationNumber());
        assertEquals("None", visionClaimLineDetails.getServiceException());
        assertEquals("100.00", visionClaimLineDetails.getAllowedAmount());
        assertEquals("10.00", visionClaimLineDetails.getDeductible());
        assertEquals("5.00", visionClaimLineDetails.getCopay());
        assertEquals("15.00", visionClaimLineDetails.getCoinsurance());
        assertEquals("0.00", visionClaimLineDetails.getOverMax());
        assertEquals("20.00", visionClaimLineDetails.getCobAmount());
        assertEquals("No notes", visionClaimLineDetails.getPaymentNotes());
        assertEquals("150.00", visionClaimLineDetails.getBilledAmount());
    }
}
