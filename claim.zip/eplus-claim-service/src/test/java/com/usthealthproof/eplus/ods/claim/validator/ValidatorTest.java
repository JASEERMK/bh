package com.usthealthproof.eplus.ods.claim.validator;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.RequestValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ValidatorTest {

    @InjectMocks
    private Validator validator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(validator, "clientDateFormat", "yyyy-MM-dd");
        ReflectionTestUtils.setField(validator, "providerClaimsDateRangeLimit", "15 Days");
        ReflectionTestUtils.setField(validator, "memberClaimsDateRangeLimit", "6 Months");
    }

    @Test
    void testValidateMemberSearchRequest_InvalidClaimType() {
        String invalidClaimType = "INVALID";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateMemberSearchRequest(invalidClaimType, "2024-01-01", "2024-02-01", "123", "status", "claimNumber");
        });

        assertEquals(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND, exception.getMessage());
    }

    @Test
    void testValidateMemberSearchRequest_MandatoryMissing() {
        String validClaimType = "medical";
        String blankServiceFromDate = "";
        String blankServiceToDate = "";
        String memberNumber = "member123";
        String claimStatus = "";
        String blankClaimNumber = "";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateMemberSearchRequest(validClaimType, blankServiceFromDate, blankServiceToDate, memberNumber, claimStatus, blankClaimNumber);
        });
        assertEquals(ClaimHeaderSearchConstants.MANDATORY_MISSING, exception.getMessage());
    }

    @Test
    void testValidateProviderSearchRequest_InvalidClaimType() {
        String invalidClaimType = "DENTAL";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest(invalidClaimType, "2024-01-01", "2024-02-01", "claimNumber", "providerId", "providerType");
        });

        assertEquals(ClaimHeaderSearchConstants.INVALID_CLAIM_TYPE_FOUND, exception.getMessage());
    }

    @Test
    void testValidateProviderSearchRequest_ProviderIdNotBlankProviderTypeBlank() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest("MEDICAL", "2024-01-01", "2024-02-01", "claimNumber", "providerId", "");
        });
        assertEquals(ClaimHeaderSearchConstants.PROVIDER_TYPE_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testValidateProviderSearchRequest_ProviderTypeNotBlankProviderIdBlank() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest("MEDICAL", "2024-01-01", "2024-02-01", "claimNumber", "", "providerType");
        });
        assertEquals(ClaimHeaderSearchConstants.PROVIDER_ID_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testValidateRequestField_EmptyClaimHccId() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateRequestField("");
        });
        assertEquals(ClaimConstants.CLAIM_ID_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testValidateRequestField_WithClaimLineHccId() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateRequestField("", "");
        });
        assertEquals(ClaimConstants.CLAIM_LINE_ID_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testIsProviderTypeInvalid_InvalidProviderType() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.isProviderTypeInvalid("invalidProviderType");
        });
        assertEquals(ClaimHeaderSearchConstants.PROVIDER_TYPE_INVALID, exception.getMessage());
    }

    @Test
    void testValidateRequestServiceDates_InvalidServiceFromDate() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateRequestServiceDates("2024-01-02>>", "2024-01-02");
        });
        assertEquals(ClaimHeaderSearchConstants.SERVICE_FROM_DATE, exception.getMessage());
    }

    @Test
    void testValidateRequestServiceDates_ServiceToDateBlank() {
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateRequestServiceDates("2024-01-01", "");
        });
        assertEquals(ClaimHeaderSearchConstants.SEARCH_SERVICE_TO_DATE_REQUIRED, exception.getMessage());
    }

    @Test
    void testValidateDateFormat_InvalidDate() {
        String invalidDate = "13-2024-01"; // invalid format

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateDateFormat("Invalid Date", invalidDate);
        });
        assertEquals("Invalid Date", exception.getMessage());
    }
    @Test
    void testValidateProviderSearchRequest_InvalidProviderType() {
        String validClaimType = "MEDICAL";
        String validServiceFromDate = "2024-01-01";
        String validServiceToDate = "2024-01-10";
        String claimNumber = "12345";
        String providerId = "providerId";
        String invalidProviderType = "invalidProviderType";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest(validClaimType, validServiceFromDate, validServiceToDate, claimNumber, providerId, invalidProviderType);
        });

        assertEquals(ClaimHeaderSearchConstants.PROVIDER_TYPE_INVALID, exception.getMessage());
    }
    @Test
    void testValidateProviderSearchRequest_ThrowsServiceDatesRequired() {
        String validClaimType = "MEDICAL";
        String blankServiceFromDate = "";
        String blankServiceToDate = "";
        String blankClaimNumber = "";
        String providerId = "S00000001";
        String providerType = "supplierid";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest(validClaimType, blankServiceFromDate, blankServiceToDate, blankClaimNumber, providerId, providerType);
        });
        assertEquals(ClaimHeaderSearchConstants.SERVICE_DATES_REQUIRED, exception.getMessage());
    }
    @Test
    void testValidateRequestServiceDates_ServiceToDateProvided_ServiceFromDateBlank() {
        String serviceFromDate = "";
        String serviceToDate = "2024-01-10";
        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateRequestServiceDates(serviceFromDate, serviceToDate);
        });
        assertEquals(ClaimHeaderSearchConstants.SEARCH_SERVICE_FROM_DATE_REQUIRED, exception.getMessage());
    }
    @Test
    void testValidateRequestServiceDates_ValidDates() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-01-10";
        validator.validateRequestServiceDates(serviceFromDate, serviceToDate);
    }
    @Test
    void testValidateMemberSearchRequest_ClaimTypesBlank() {
        String blankClaimTypes = "";
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-02-01";
        String memberNumber = "123";
        String claimStatus = "status";
        String claimNumber = "claimNumber";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateMemberSearchRequest(blankClaimTypes, serviceFromDate, serviceToDate, memberNumber, claimStatus, claimNumber);
        });

        assertEquals(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND, exception.getMessage());
    }
    @Test
    void testValidateProviderSearchRequest_ClaimTypesBlank() {
        String blankClaimTypes = "";
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-02-01";
        String claimNumber = "claimNumber";
        String providerId = "providerId";
        String providerType = "providerType";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateProviderSearchRequest(blankClaimTypes, serviceFromDate, serviceToDate, claimNumber, providerId, providerType);
        });

        assertEquals(ClaimHeaderSearchConstants.CLAIM_TYPE_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testValidateDateRange_WithinLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-02-01"; // Within 1 month

        validator.validateDateRange(serviceFromDate, serviceToDate, "6 Months");
    }
    @Test
    void testValidateDateRange_DaysExceedsLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-01-20"; // Exceeds 15 days limit

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateDateRange(serviceFromDate, serviceToDate, "15 Days");
        });
        assertEquals(String.format(ClaimHeaderSearchConstants.DATE_RANGE_EXCEEDS_LIMIT, "15 Days"), exception.getMessage());
    }

    @Test
    void testValidateDateRange_MonthsExceedsLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-08-01"; // Exceeds 6 months limit

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateDateRange(serviceFromDate, serviceToDate, "6 Months");
        });
        assertEquals(String.format(ClaimHeaderSearchConstants.DATE_RANGE_EXCEEDS_LIMIT, "6 Months"), exception.getMessage());
    }

    @Test
    void testValidateDateRange_WithinDaysLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-01-10"; // Within 15 days

        validator.validateDateRange(serviceFromDate, serviceToDate, "15 Days");
    }

    @Test
    void testValidateDateRange_WithinMonthsLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-02-01"; // Within 1 month

        validator.validateDateRange(serviceFromDate, serviceToDate, "6 Months");
    }

    @Test
    void testValidateDateRange_InvalidDateRangeLimit() {
        String serviceFromDate = "2024-01-01";
        String serviceToDate = "2024-02-01";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.validateDateRange(serviceFromDate, serviceToDate, "6 Years");
        });
        assertEquals(ClaimHeaderSearchConstants.DATE_RANGE_LIMIT_NOT_CONFIGURED, exception.getMessage());
    }

    @Test
    void testValidateDateRange_BlankServiceDates() {
        String serviceFromDate = "";
        String serviceToDate = "";

        validator.validateDateRange(serviceFromDate, serviceToDate, "6 Months");
    }
    @Test
    void testProviderIdConditionalMandatoryCheck_BlankProviderId() {
        String blankProviderId = "";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.providerIdConditionalMandatoryCheck(blankProviderId);
        });

        assertEquals(ClaimHeaderSearchConstants.PROVIDER_ID_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testProviderIdConditionalMandatoryCheck_ValidProviderId() {
        String validProviderId = "123";
        validator.providerIdConditionalMandatoryCheck(validProviderId);
    }

    @Test
    void testProviderTypeConditionalMandatoryCheck_BlankProviderType() {
        String blankProviderType = "";

        RequestValidationException exception = assertThrows(RequestValidationException.class, () -> {
            validator.ProviderTypeConditionalMandatoryCheck(blankProviderType);
        });

        assertEquals(ClaimHeaderSearchConstants.PROVIDER_TYPE_NOT_FOUND, exception.getMessage());
    }

    @Test
    void testProviderTypeConditionalMandatoryCheck_ValidProviderType() {
        String validProviderType = "supplierid";
        validator.ProviderTypeConditionalMandatoryCheck(validProviderType);
    }

}
