package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class DentalClaimDetailsMapperTest {

    @InjectMocks
    private DentalClaimDetailsMapper dentalClaimDetailsMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("memberKey")).thenReturn("member123");
        when(resultSet.getString("pay_member")).thenReturn("John Doe");
        when(resultSet.getString("insurer_id")).thenReturn("insurer123");
        when(resultSet.getString("insurer_name")).thenReturn("InsurerName");
        when(resultSet.getString("providerKey")).thenReturn("provider123");
        when(resultSet.getString("provider_name")).thenReturn("ProviderName");
        when(resultSet.getString("serviceStartDate")).thenReturn("2023-01-01");
        when(resultSet.getString("serviceEndDate")).thenReturn("2023-01-31");
        when(resultSet.getString("location_id")).thenReturn("loc123");
        when(resultSet.getString("location_name")).thenReturn("LocationName");
        when(resultSet.getString("payee_other_id")).thenReturn("payee123");
        when(resultSet.getString("payee_other_name")).thenReturn("PayeeName");
        when(resultSet.getString("network_id")).thenReturn("net123");
        when(resultSet.getString("network_name")).thenReturn("NetworkName");
        when(resultSet.getString("claim_received_date")).thenReturn("2023-02-01");
        when(resultSet.getString("claim_entered_date")).thenReturn("2023-02-02");
        when(resultSet.getString("missing_teeth")).thenReturn("None");
        when(resultSet.getString("Payment_Date")).thenReturn("2023-02-15");
        when(resultSet.getString("Payment_Number")).thenReturn("payment123");
        when(resultSet.getString("net_paid_amount")).thenReturn("100.00");
        when(resultSet.getString("billedAmount")).thenReturn("150.00");
        when(resultSet.getString("allowed")).thenReturn("120.00");
        when(resultSet.getString("paid_amount")).thenReturn("80.00");
        when(resultSet.getString("deductible")).thenReturn("10.00");
        when(resultSet.getString("co_pay")).thenReturn("5.00");
        when(resultSet.getString("coinsurance_amount")).thenReturn("20.00");
        when(resultSet.getString("over_max")).thenReturn("0.00");
        when(resultSet.getString("cob_amount")).thenReturn("0.00");
        when(resultSet.getString("payment_status")).thenReturn("Paid");
        when(resultSet.getString("payment_notes")).thenReturn("No issues");
        when(resultSet.getString("eft_flag")).thenReturn("Y");
        when(resultSet.getString("eft_account")).thenReturn("eft123");
        when(resultSet.getString("check_cleared")).thenReturn("Y");
        when(resultSet.getString("created_by")).thenReturn("user1");
        when(resultSet.getString("last_modified_by")).thenReturn("user2");

        // Setup mock behavior for DateUtils
        when(dateUtils.getFormattedApplicationDate(anyString())).thenReturn("formattedDate");

        // Execute mapRow
        DentalClaimDetails result = dentalClaimDetailsMapper.mapRow(resultSet, 1);

        // Verify results
        assertEquals("member123", result.getMemberId());
        assertEquals("John Doe", result.getPayMember());
        assertEquals("insurer123", result.getInsurerId());
        assertEquals("InsurerName", result.getInsurerName());
        assertEquals("provider123", result.getProviderId());
        assertEquals("ProviderName", result.getProviderName());
        assertEquals("formattedDate", result.getServiceStartDate());
        assertEquals("formattedDate", result.getServiceEndDate());
        assertEquals("loc123", result.getLocationId());
        assertEquals("LocationName", result.getLocationName());
        assertEquals("payee123", result.getPayeeOtherId());
        assertEquals("PayeeName", result.getPayeeOtherName());
        assertEquals("net123", result.getNetworkId());
        assertEquals("NetworkName", result.getNetworkName());
        assertEquals("formattedDate", result.getClaimReceivedDate());
        assertEquals("formattedDate", result.getClaimEnteredDate());
        assertEquals("None", result.getMissingTeeth());
        assertEquals("formattedDate", result.getPaymentDate());
        assertEquals("payment123", result.getPaymentNumber());
        assertEquals("100.00", result.getNetPaidAmount());
        assertEquals("150.00", result.getBilledAmount());
        assertEquals("120.00", result.getAllowed());
        assertEquals("80.00", result.getPaidAmount());
        assertEquals("10.00", result.getDeductible());
        assertEquals("5.00", result.getCoPay());
        assertEquals("20.00", result.getCoinsuranceAmount());
        assertEquals("0.00", result.getOverMax());
        assertEquals("0.00", result.getCobAmount());
        assertEquals("Paid", result.getPaymentStatus());
        assertEquals("No issues", result.getPaymentNotes());
        assertEquals("Y", result.getEftFlag());
        assertEquals("eft123", result.getEftAccount());
        assertEquals("Y", result.getCheckCleared());
        assertEquals("user1", result.getCreatedBy());
        assertEquals("user2", result.getLastModifiedBy());
        assertEquals("John Doe", result.getMemberName());
    }
}
