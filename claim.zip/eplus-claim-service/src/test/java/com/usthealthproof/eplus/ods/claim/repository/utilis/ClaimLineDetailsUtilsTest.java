package com.usthealthproof.eplus.ods.claim.repository.utilis;

import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ClaimLineDetailsUtilsTest {

    @InjectMocks
    private AsyncExecutorUtils asyncExecutorUtils;
    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimLineDetailsMapper medicalClaimLineDetailsMapper;


    private final String claimHccId = "20230421036904";
    private final String claimLineHccId = "1";
    private final String state = "PA";
    private final String lob = "Medicare";
    private final String product = "PA Medicare";

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMedicalClaimLineDetailsWithoutFactKey() throws Exception {

        MedicalClaimLineDetails expectedDetails = new MedicalClaimLineDetails();
        expectedDetails.setRejectionCodeDesc("");
        expectedDetails.setClaimHccId(claimLineHccId);
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimLineDetailsMapper)))
                .thenReturn(expectedDetails);

        CompletableFuture<MedicalClaimLineDetails> medicalClaimLineDetails = asyncExecutorUtils.getMedicalClaimLineDetailsWithoutFactKey(
                claimHccId, claimLineHccId, state, lob, product);
        MedicalClaimLineDetails actualDetails = medicalClaimLineDetails.get();
        assertNotNull(medicalClaimLineDetails);
        assertEquals(claimLineHccId, actualDetails.getClaimHccId());
    }

    @Test
    void testGetMedicalClaimLineDetailsWithFactKey() throws Exception {

        MedicalClaimLineDetails expectedDetails = new MedicalClaimLineDetails();
        expectedDetails.setRejectionCodeDesc("");
        expectedDetails.setClaimHccId(claimLineHccId);
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimLineDetailsMapper)))
                .thenReturn(expectedDetails);

        String claimFactKey = "901183";
        CompletableFuture<MedicalClaimLineDetails> medicalClaimLineDetails = asyncExecutorUtils.getMedicalClaimLineDetailsWithFactKey(
                claimHccId, claimLineHccId, claimFactKey,state, lob, product);
        MedicalClaimLineDetails actualDetails = medicalClaimLineDetails.get();
        assertNotNull(medicalClaimLineDetails);
        assertEquals(claimLineHccId, actualDetails.getClaimHccId());
    }
}
