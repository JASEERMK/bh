package com.usthealthproof.eplus.ods.claim.service;

import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimProviderSearchData;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimSearchData;
import com.usthealthproof.eplus.ods.claim.repository.search.ClaimAvailabilityCheckData;
import com.usthealthproof.eplus.ods.claim.repository.search.MemberClaimSearchData;
import com.usthealthproof.eplus.ods.claim.repository.search.ProviderClaimSearchData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClaimHeaderSearchServiceTest {

    @InjectMocks
    private ClaimHeaderSearchService claimHeaderSearchService;

    @Mock
    private MemberClaimSearchData memberClaimSearchData;
    @Mock
    private ProviderClaimSearchData providerClaimSearchData;
    @Mock
    private ClaimProviderSearchData claimProviderSearchData;
    @Mock
    private ClaimSearchData claimSearchData;
    @Mock
    private ClaimAvailabilityCheckData claimAvailabilityCheckData;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalMemberMedicalClaimSearch", "spPortalMemberMedicalClaimSearch");
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalMemberDentalClaimSearch", "spPortalMemberDentalClaimSearch");
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalMemberVisionClaimSearch", "spPortalMemberVisionClaimSearch");
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalSponsorMedicalClaimSearch", "spPortalSponsorMedicalClaimSearch");
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalSponsorVisionClaimSearch", "spPortalSponsorVisionClaimSearch");
        ReflectionTestUtils.setField(claimHeaderSearchService, "spPortalSponsorDentalClaimSearch", "spPortalSponsorDentalClaimSearch");
    }

    @Test
    public void testGetClaimHeaderSearchInfoForMember() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Member");

        ClaimSearchResponse response = new ClaimSearchResponse();
        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenReturn(response);

        ClaimSearchResponse result = claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest);
        assertNotNull(result);
        verify(claimSearchData, times(1)).getClaimHeaderSearchInfo(claimSearchRequest,
                "spPortalMemberMedicalClaimSearch", "spPortalMemberDentalClaimSearch", "spPortalMemberVisionClaimSearch");
    }

    @Test
    public void testGetClaimHeaderSearchInfoForProvider() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Provider");

        ClaimSearchResponse response = new ClaimSearchResponse();
        when(claimProviderSearchData.getClaimHeaderSearchInfoForProvider(any(UserIdentityRequest.class), any(ClaimSearchRequest.class)))
                .thenReturn(response);

        ClaimSearchResponse result = claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest);
        assertNotNull(result);
        verify(claimProviderSearchData, times(1)).getClaimHeaderSearchInfoForProvider(userIdentityRequest, claimSearchRequest);
    }

    @Test
    public void testGetClaimHeaderSearchInfoForSponsor() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Sponsor");

        ClaimSearchResponse response = new ClaimSearchResponse();
        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenReturn(response);

        ClaimSearchResponse result = claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest);
        assertNotNull(result);
        verify(claimSearchData, times(1)).getClaimHeaderSearchInfo(claimSearchRequest,
                "spPortalSponsorMedicalClaimSearch", "spPortalSponsorDentalClaimSearch", "spPortalSponsorVisionClaimSearch");
    }

    @Test
    public void testGetClaimHeaderSearchInfoThrowsExecutionException() throws SQLException, ExecutionException, InterruptedException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Member");

        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenThrow(new ExecutionException(new Throwable("Execution exception")));

        assertThrows(ExecutionException.class, () -> claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest));
    }

    @Test
    public void testGetClaimHeaderSearchInfoThrowsInterruptedException() throws SQLException, ExecutionException, InterruptedException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Member");

        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenThrow(new InterruptedException("Interrupted exception"));

        assertThrows(InterruptedException.class, () -> claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest));
    }

    @Test
    public void testGetClaimHeaderSearchInfoThrowsClaimNotFoundException() throws SQLException, ExecutionException, InterruptedException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Member");

        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenThrow(new ClaimNotFoundException("Claim not found"));

        assertThrows(ClaimNotFoundException.class, () -> claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest));
    }

    @Test
    public void testGetClaimHeaderSearchInfoThrowsSQLException() throws SQLException, ExecutionException, InterruptedException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        userIdentityRequest.setApp_name("Member");

        when(claimSearchData.getClaimHeaderSearchInfo(any(ClaimSearchRequest.class), anyString(), anyString(), anyString()))
                .thenThrow(new SQLException("SQL exception"));

        assertThrows(SQLException.class, () -> claimHeaderSearchService.getClaimHeaderSearchInfo(claimSearchRequest, userIdentityRequest));
    }

    @Test
    public void testGetMemberClaimSearch() {
        ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();

        when(memberClaimSearchData.getClaimHeaderDetails(any(ClaimHeaderSearchRequest.class), any(ClaimHeaderSearchResponse.class)))
                .thenReturn(claimHeaderSearchResponse);

        ClaimHeaderSearchResponse result = claimHeaderSearchService.getMemberClaimSearch(claimHeaderSearchRequest, claimHeaderSearchResponse);
        assertNotNull(result);
    }

    @Test
    public void testGetProviderClaimSearch() {
        ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();

        when(providerClaimSearchData.getClaimHeaderDetails(any(ClaimHeaderSearchRequest.class), any(ClaimHeaderSearchResponse.class)))
                .thenReturn(claimHeaderSearchResponse);

        ClaimHeaderSearchResponse result = claimHeaderSearchService.getProviderClaimSearch(claimHeaderSearchRequest, claimHeaderSearchResponse);
        assertNotNull(result);
    }

    @Test
    public void testProviderClaimDataAvailabilityCheck() {
        ClaimHeaderSearchRequest claimHeaderSearchRequest = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse claimHeaderSearchResponse = new ClaimHeaderSearchResponse();

        when(claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(any(ClaimHeaderSearchRequest.class)))
                .thenReturn(claimHeaderSearchResponse);

        ClaimHeaderSearchResponse result = claimHeaderSearchService.providerClaimDataAvailabilityCheck(claimHeaderSearchRequest);
        assertNotNull(result);
    }
}
