package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ProviderClaimSearchMapperTest {

    @InjectMocks
    private ProviderClaimSearchMapper providerClaimSearchMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("billed_Amount")).thenReturn("1500.00");
        when(resultSet.getString("claim_number")).thenReturn("123456789");
        when(resultSet.getString("dos")).thenReturn("2024-07-15");
        when(resultSet.getString("member_Name")).thenReturn("John Doe");
        when(resultSet.getString("patient_acctno")).thenReturn("PAT123456");
        when(resultSet.getString("status")).thenReturn("Approved");
        when(resultSet.getString("member_id")).thenReturn("MEM123456");
        when(dateUtils.getFormattedApplicationDate("2024-07-15")).thenReturn("15-07-2024");

        // Execute mapRow
        ClaimSearchModel result = providerClaimSearchMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("1500.00", result.getBilledAmount());
        assertEquals("123456789", result.getClaimNumber());
        assertEquals("15-07-2024", result.getDos());
        assertEquals("John Doe", result.getMemberName());
        assertEquals("PAT123456", result.getPatientAccountNumber());
        assertEquals("Approved", result.getClaimStatus());
        assertEquals("MEM123456", result.getMemberId());
    }
}
