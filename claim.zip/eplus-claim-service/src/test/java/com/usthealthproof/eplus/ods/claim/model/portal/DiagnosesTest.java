package com.usthealthproof.eplus.ods.claim.model.portal;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiagnosesTest {

    @Test
    public void testCompareTo() {
        Diagnoses diagnosis1 = new Diagnoses();
        diagnosis1.setDiagnosisCode("A01");

        Diagnoses diagnosis2 = new Diagnoses();
        diagnosis2.setDiagnosisCode("B02");

        Diagnoses diagnosis3 = new Diagnoses();
        diagnosis3.setDiagnosisCode("A01");

        // Test case where diagnosis1's diagnosisCode is less than diagnosis2's diagnosisCode
        assertTrue(diagnosis1.compareTo(diagnosis2) < 0, "Expected diagnosis1 to be less than diagnosis2");

        // Test case where diagnosis1's diagnosisCode is equal to diagnosis3's diagnosisCode
        assertEquals(0, diagnosis1.compareTo(diagnosis3), "Expected diagnosis1 to be equal to diagnosis3");

        // Test case where diagnosis2's diagnosisCode is greater than diagnosis1's diagnosisCode
        assertTrue(diagnosis2.compareTo(diagnosis1) > 0, "Expected diagnosis2 to be greater than diagnosis1");
    }

    @Test
    public void testEqualsAndHashCode() {
        Diagnoses diagnosis1 = new Diagnoses();
        diagnosis1.setDiagnosisCode("A01");
        diagnosis1.setDiagnosisDescription("Description1");

        Diagnoses diagnosis2 = new Diagnoses();
        diagnosis2.setDiagnosisCode("A01");
        diagnosis2.setDiagnosisDescription("Description1");

        Diagnoses diagnosis3 = new Diagnoses();
        diagnosis3.setDiagnosisCode("B02");
        diagnosis3.setDiagnosisDescription("Description2");

        // Test equality for identical objects
        assertEquals(diagnosis1, diagnosis2, "Expected diagnosis1 to be equal to diagnosis2");

        // Test equality for non-identical objects
        assertNotEquals(diagnosis1, diagnosis3, "Expected diagnosis1 to be not equal to diagnosis3");

        // Test hashCode for identical objects
        assertEquals(diagnosis1.hashCode(), diagnosis2.hashCode(), "Expected hashCode of diagnosis1 to be equal to hashCode of diagnosis2");

        // Test hashCode for non-identical objects
        assertNotEquals(diagnosis1.hashCode(), diagnosis3.hashCode(), "Expected hashCode of diagnosis1 to be not equal to hashCode of diagnosis3");
    }
}

