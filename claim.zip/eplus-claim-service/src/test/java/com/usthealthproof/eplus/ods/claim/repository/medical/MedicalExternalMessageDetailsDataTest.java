package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalExternalMessageDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class MedicalExternalMessageDetailsDataTest {

    @InjectMocks
    private MedicalExternalMessageDetailsData medicalExternalMessageDetailsData;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalExternalMessageDetailsMapper medicalExternalMessageDetailsMapper;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetExternalMessageDetails_WithClaimFactKey() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "lineId";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper)))
                .thenReturn(Collections.singletonList(new MedicalExternalMessage()));

        // Act
        List<MedicalExternalMessage> result = medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(namedParameterJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper));
    }

    @Test
    public void testGetExternalMessageDetails_WithoutClaimFactKey() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "lineId";
        String claimFactKey = "";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper)))
                .thenReturn(Collections.singletonList(new MedicalExternalMessage()));

        // Act
        List<MedicalExternalMessage> result = medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(namedParameterJdbcTemplate).query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper));
    }

    @Test
    public void testGetExternalMessageDetails_EmptyResult() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "lineId";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";


        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper)))
                .thenReturn(Collections.emptyList());

        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        assertEquals(ClaimConstants.NO_EXTERNAL_MESSGAES_FOUND, thrown.getMessage());
    }

    @Test
    public void testGetExternalMessageDetails_JdbcConnectionException() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "lineId";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database not available"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Database not available", thrown.getMessage());
    }

    @Test
    public void testGetExternalMessageDetails_GenericException() {
        // Arrange
        String claimHccId = "12345";
        String claimLineHccId = "lineId";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";



        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalExternalMessageDetailsMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Unexpected error", thrown.getMessage());
    }
}
