package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.AclEntity;
import com.usthealthproof.eplus.ods.claim.model.portal.Container;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.util.PortalClaimSearchUtil;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class ClaimProviderSearchDataTest {

    @Mock
    private PortalClaimSearchUtil portalClaimSearchUtil;

    @InjectMocks
    private ClaimProviderSearchData claimProviderSearchData;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimHeaderSearchInfoForProvider() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();
        AclEntity aclEntity = new AclEntity();
        Container container = new Container();
        container.setType("medical_groups");
        container.setExclude(true);
        container.setEntity_ids(Arrays.asList("entity1", "entity2"));
        aclEntity.setContainers(Collections.singletonList(container));
        userIdentityRequest.setAcl_entities(Collections.singletonList(aclEntity));

        ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();
        List<ClaimSearchModel> claimSearchModels = new ArrayList<>();
        claimSearchResponse.setResults(claimSearchModels);

        when(portalClaimSearchUtil.getProviderClaimSearchResult(any(ClaimSearchRequest.class), any(String.class)))
                .thenReturn(claimSearchModels);
        when(portalClaimSearchUtil.setClaimSearchResponse(any(List.class)))
                .thenReturn(claimSearchResponse);
    }

    @Test
    public void testGetClaimHeaderSearchInfoForProvider_ThrowsClaimNotFoundException() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        UserIdentityRequest userIdentityRequest = new UserIdentityRequest();

        Container container = new Container();
        container.setType("medical_groups");
        container.setExclude(true);
        container.setEntity_ids(Arrays.asList("entity1", "entity2"));

        Container container1 = new Container();
        container1.setType("medical_groups");
        container1.setExclude(false);
        container1.setEntity_ids(Arrays.asList("entity3", "entity4"));

        Container container2 = new Container();
        container2.setType("providers");
        container2.setExclude(true);
        container2.setEntity_ids(Arrays.asList("entity5", "entity6"));

        Container container3 = new Container();
        container3.setType("providers");
        container3.setExclude(false);
        container3.setEntity_ids(Arrays.asList("entity7", "entity8"));

        AclEntity aclEntity = new AclEntity();
        aclEntity.setContainers(Arrays.asList(container,container1,container2,container3));
        userIdentityRequest.setAcl_entities(Collections.singletonList(aclEntity));

        when(portalClaimSearchUtil.getProviderClaimSearchResult(any(ClaimSearchRequest.class), any(String.class)))
                .thenReturn(Collections.emptyList());

        assertThrows(ClaimNotFoundException.class, () -> {
            claimProviderSearchData.getClaimHeaderSearchInfoForProvider(userIdentityRequest, claimSearchRequest);
        });
    }

    @Test
    public void testGetClaimHeaderSearchInfo_ThrowsCannotGetJdbcConnectionException() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();

        when(portalClaimSearchUtil.getProviderClaimSearchResult(any(ClaimSearchRequest.class), any(String.class)))
                .thenThrow(new CannotGetJdbcConnectionException(""));

         }

    @Test
    public void testGetClaimHeaderSearchInfo_ThrowsClaimNotFoundExceptionInAsyncMethod() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        ClaimSearchResponse claimSearchResponse = new ClaimSearchResponse();

        when(portalClaimSearchUtil.getProviderClaimSearchResult(any(ClaimSearchRequest.class), any(String.class)))
                .thenThrow(new ClaimNotFoundException(ClaimConstants.NO_DATA_FOUND));

    }

    @Test
    public void testGetAllClaimSearchResultForProvider() throws ExecutionException, InterruptedException, SQLException {
        ClaimSearchRequest claimSearchRequest = new ClaimSearchRequest();
        List<ClaimSearchModel> claimSearchModels = new ArrayList<>();
        CompletableFuture<List<ClaimSearchModel>> completableFuture = CompletableFuture.completedFuture(claimSearchModels);

        when(portalClaimSearchUtil.getProviderAllClaimSearchResult(any(ClaimSearchRequest.class), any(String.class)))
                .thenReturn(completableFuture);

    }
}
