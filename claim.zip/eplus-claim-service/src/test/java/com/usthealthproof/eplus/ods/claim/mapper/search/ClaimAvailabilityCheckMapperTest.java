package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ClaimAvailabilityCheckMapperTest {

    @InjectMocks
    private ClaimAvailabilityCheckMapper claimAvailabilityCheckMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow_DataAvailable() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("CLAIM_HCC_ID")).thenReturn("some_id");

        // Execute mapRow
        ClaimHeaderSearchResponse result = claimAvailabilityCheckMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("True", result.getDataAvailabilityFlag());
    }

    @Test
    public void testMapRow_NoDataAvailable() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("CLAIM_HCC_ID")).thenReturn("");

        // Execute mapRow
        ClaimHeaderSearchResponse result = claimAvailabilityCheckMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals(null, result.getDataAvailabilityFlag());
    }

    @Test
    public void testMapRow_NullData() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("CLAIM_HCC_ID")).thenReturn(null);

        // Execute mapRow
        ClaimHeaderSearchResponse result = claimAvailabilityCheckMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals(null, result.getDataAvailabilityFlag());
    }
}
