package com.usthealthproof.eplus.ods.claim.util;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.doThrow;

import com.google.gson.Gson;
import com.usthealthproof.eplus.ods.claim.model.portal.UserIdentityRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Base64;

class DecodedUserIdentityTest {

    private DecodedUserIdentity decodedUserIdentity;
    private Logger logger;

    @BeforeEach
    void setUp() {
        decodedUserIdentity = spy(DecodedUserIdentity.class);
        logger = LoggerFactory.getLogger(DecodedUserIdentity.class);
    }

    @Test
    void testGetMemberHeaderDetails_InvalidHeader() {
        String invalidHeaderRequest = "WV::;DE:Medicaid:";

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            decodedUserIdentity.getMemberHeaderDetails(invalidHeaderRequest);
        });

        assertTrue(exception.getMessage().contains("Illegal base64 character"));
    }


    @Test
    void testGetMemberHeaderDetails_NullOrBlankHeader() throws Exception {
        assertNull(decodedUserIdentity.getMemberHeaderDetails(null));
        assertNull(decodedUserIdentity.getMemberHeaderDetails(""));
        assertNull(decodedUserIdentity.getMemberHeaderDetails("  "));
    }

    @Test
    void testGetMemberHeaderDetails_ValidHeader() throws Exception {
        String validJson = """
        {
            "app_name": "MyApp",
            "method_name": "MyMethod",
            "user_name": "testUser",
            "web_session_id": "session123",
            "correlation_id": "corr123",
            "members": [],
            "acl_entities": []
        }
        """;
        String validHeaderRequest = Base64.getEncoder().encodeToString(validJson.getBytes());

        UserIdentityRequest result = decodedUserIdentity.getMemberHeaderDetails(validHeaderRequest);

        assertNotNull(result);
        assertEquals("MyApp", result.getApp_name());
        assertEquals("MyMethod", result.getMethod_name());
        assertEquals("testUser", result.getUser_name());
        assertEquals("session123", result.getWeb_session_id());
        assertEquals("corr123", result.getCorrelation_id());
        assertNotNull(result.getMembers());
        assertNotNull(result.getAcl_entities());
    }

}