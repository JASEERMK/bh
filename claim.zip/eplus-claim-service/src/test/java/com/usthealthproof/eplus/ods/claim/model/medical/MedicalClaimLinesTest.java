package com.usthealthproof.eplus.ods.claim.model.medical;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MedicalClaimLinesTest {

    @Test
    public void testCompareTo() {
        MedicalClaimLines claimLine1 = new MedicalClaimLines();
        claimLine1.setOrderField(1);

        MedicalClaimLines claimLine2 = new MedicalClaimLines();
        claimLine2.setOrderField(2);

        MedicalClaimLines claimLine3 = new MedicalClaimLines();
        claimLine3.setOrderField(1);

        // Test case where claimLine1's orderField is less than claimLine2's orderField
        assertTrue(claimLine1.compareTo(claimLine2) < 0, "Expected claimLine1 to be less than claimLine2");

        // Test case where claimLine1's orderField is equal to claimLine3's orderField
        assertEquals(0, claimLine1.compareTo(claimLine3), "Expected claimLine1 to be equal to claimLine3");

        // Test case where claimLine2's orderField is greater than claimLine1's orderField
        assertTrue(claimLine2.compareTo(claimLine1) > 0, "Expected claimLine2 to be greater than claimLine1");
    }

    @Test
    public void testCompareToNullCase() {
        MedicalClaimLines claimLine1 = new MedicalClaimLines();
        claimLine1.setOrderField(null);

        MedicalClaimLines claimLine2 = new MedicalClaimLines();
        claimLine2.setOrderField(null);

        MedicalClaimLines claimLine3 = new MedicalClaimLines();
        claimLine3.setOrderField(0);
        assertTrue(claimLine1.compareTo(claimLine2) == 0, "Expected claimLine1 to be less than claimLine2");
    }
}
