package com.usthealthproof.eplus.ods.claim.repository.denialcode;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimDenialCodesMapper;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCode;

public class DenialCodeSearchDataTest {

    @InjectMocks
    private DenialCodeSearchData denialCodeSearchData;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private ClaimDenialCodesMapper claimDenialCodesMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    public void testGetDenailCodesNoDataFound() {
        String claimHccId = "123ABC";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";
        List<DenialCode> emptyDenialCodesList = new ArrayList<>();

        String storedProcedureCall = "{CALL spGetClaimDenialCodeDesc(:claimHccId, :product, :lob, :state, :returnStatus)}";
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("claimHccId", claimHccId, Types.VARCHAR)
                .addValue("product", product, Types.VARCHAR)
                .addValue("lob", lob, Types.VARCHAR)
                .addValue("state", state, Types.VARCHAR)
                .addValue("returnStatus", 0, Types.NUMERIC);

        when(namedParameterJdbcTemplate.query(eq(storedProcedureCall), eq(params), eq(claimDenialCodesMapper)))
                .thenReturn(emptyDenialCodesList);

        assertThrows(ClaimNotFoundException.class, () -> {
            denialCodeSearchData.getDenialCodes(claimHccId,state,lob,product);
        });
    }


    @Test
    public void testGetDenailCodesJdbcConnectionFailure() {
        String claimHccId = "123ABC";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        String storedProcedureCall = "{CALL spGetClaimDenialCodeDesc(:claimHccId, :product, :lob, :state, :returnStatus)}";
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("claimHccId", claimHccId, Types.VARCHAR)
                .addValue("product", product, Types.VARCHAR)
                .addValue("lob", lob, Types.VARCHAR)
                .addValue("state", state, Types.VARCHAR)
                .addValue("returnStatus", 0, Types.NUMERIC);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimDenialCodesMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Connection failure"));

        assertThrows(CannotGetJdbcConnectionException.class, () -> {
            denialCodeSearchData.getDenialCodes(claimHccId,state,lob,product);
        });
    }


    @Test
    public void testGetDenailCodesSuccess() {
        String claimHccId = "123ABC";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";


        List<DenialCode> mockDenialCodes = new ArrayList<>();
        DenialCode denialCode1 = new DenialCode();
        denialCode1.setCode("DEN1");
        denialCode1.setDescription("Denial code 1");
        mockDenialCodes.add(denialCode1);

        String storedProcedureCall = "{CALL spGetClaimDenialCodeDesc(:claimHccId, :product, :lob, :state, :returnStatus)}";
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("claimHccId", claimHccId, Types.VARCHAR)
                .addValue("product", product, Types.VARCHAR)
                .addValue("lob", lob, Types.VARCHAR)
                .addValue("state", state, Types.VARCHAR)
                .addValue("returnStatus", 0, Types.NUMERIC);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimDenialCodesMapper)))
                .thenReturn(mockDenialCodes);

        DenialCodes result = denialCodeSearchData.getDenialCodes(claimHccId,state,lob,product);

        assertNotNull(result);
        assertEquals(claimHccId, result.getClaimId());
        assertEquals(1, result.getDenialCodes().size());
        assertEquals("DEN1", result.getDenialCodes().get(0).getCode());
        assertEquals("Denial code 1", result.getDenialCodes().get(0).getDescription());
    }

}
