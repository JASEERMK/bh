package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

public class MedicalClaimLinesMapperTest {

    @InjectMocks
    private MedicalClaimLinesMapper medicalClaimLinesMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("claimLineNumber")).thenReturn("CL123");
        when(resultSet.getString("billedAmount")).thenReturn("1000");
        when(resultSet.getString("status")).thenReturn("processed");
        when(resultSet.getInt("order_field")).thenReturn(1);
        when(resultSet.getString("userMessage")).thenReturn("User Message");
        when(resultSet.getString("paidAmount")).thenReturn("900");
        when(resultSet.getString("claim_fact_key")).thenReturn("FactKey123");

        // Execute mapRow
        MedicalClaimLines result = medicalClaimLinesMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("CL123", result.getClaimLineNumber());
        assertEquals("1000", result.getBilledAmount());
        assertEquals("processed", result.getStatus());
        assertEquals(1, result.getOrderField());
        assertEquals("User Message", result.getUserMessage());
        assertEquals("900", result.getPaidAmount());
        assertEquals("FactKey123", result.getClaimFactKey());
    }
}
