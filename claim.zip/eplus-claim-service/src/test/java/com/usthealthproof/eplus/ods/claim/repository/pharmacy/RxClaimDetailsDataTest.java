package com.usthealthproof.eplus.ods.claim.repository.pharmacy;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.pharmacy.RxClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

public class RxClaimDetailsDataTest {

    @InjectMocks
    private RxClaimDetailsData rxClaimDetailsData;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private RxClaimDetailsMapper rxClaimDetailsMapper;
    @Mock
    private Logger log;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindRxClaimId_Success() {
        // Arrange
        String claimHccId = "12345";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        RxClaimDetails expectedRxClaimDetails = new RxClaimDetails();

        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(rxClaimDetailsMapper)))
                .thenReturn(expectedRxClaimDetails);

        // Act
        RxClaimDetails actualRxClaimDetails = rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product);

        // Assert
        assertEquals(expectedRxClaimDetails, actualRxClaimDetails);
    }

    @Test
    public void testFindRxClaimId_JdbcConnectionException() {
        // Arrange
        String claimHccId = "12345";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(rxClaimDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database not available"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product);
        });

        assertEquals("Database not available", thrown.getMessage());
    }

    @Test
    public void testFindRxClaimId_EmptyResultDataAccessException() {
        // Arrange
        String claimHccId = "12345";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(rxClaimDetailsMapper)))
                .thenThrow(new EmptyResultDataAccessException(1));

        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product);
        });

        assertEquals(ClaimConstants.RX_CLAIM_DETAILS_NOT_FOUND + claimHccId, thrown.getMessage());

    }

    @Test
    public void testFindRxClaimId_GenericException() {
        // Arrange
        String claimHccId = "12345";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(rxClaimDetailsMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product);
        });

        assertEquals("Unexpected error", thrown.getMessage());
    }
}
