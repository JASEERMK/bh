package com.usthealthproof.eplus.ods.claim.mapper.util;

import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimRejectionCodeMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ClaimLinesUtilsMapperTest {

    @Mock
    private APIUtils apiUtils;

    @InjectMocks
    private ClaimRejectionCodeMapper claimRejectionCodeMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testMapRow() throws SQLException {
        // Mock ResultSet
        ResultSet resultSet = mock(ResultSet.class);

        // Simulating data from ResultSet
        when(resultSet.getString("Reject_reason")).thenReturn("63 - Payment denied because this procedure code", "47 - Payment denied");
        when(resultSet.getString("claim_line_hcc_id")).thenReturn("LINE_001");

        // Invoke the method
        ClaimRejectionDetails result = claimRejectionCodeMapper.mapRow(resultSet, 1);

        // Assertions
        assertNotNull(result);
        assertEquals("LINE_001", result.getClaimLineNumber());
    }
}
