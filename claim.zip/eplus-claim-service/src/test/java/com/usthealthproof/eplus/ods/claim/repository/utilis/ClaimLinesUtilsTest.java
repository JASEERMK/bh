package com.usthealthproof.eplus.ods.claim.repository.utilis;

import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimRejectionCodeMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class ClaimLinesUtilsTest {

    @InjectMocks
    private AsyncExecutorUtils asyncExecutorUtils;
    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimLinesMapper medicalClaimLinesMapper;

    @Mock
    private ClaimRejectionCodeMapper claimRejectionCodeMapper;

    private final String claimHccId = "20230421036904";
    private final String claimLineHccId = "1";
    private final String state = "PA";
    private final String lob = "Medicare";
    private final String product = "PA Medicare";

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetRejectionCodeDesc() throws Exception {

        List<ClaimRejectionDetails> medicalClaimLines = new ArrayList<>();
        ClaimRejectionDetails claimLines = new ClaimRejectionDetails();
        claimLines.setClaimLineNumber(claimLineHccId);
        claimLines.setRejectionCodeDesc("");
        medicalClaimLines.add(claimLines);
        String claimFactKey = "90511";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimRejectionCodeMapper)))
                .thenReturn(medicalClaimLines);
        CompletableFuture<List<ClaimRejectionDetails>> claimLinesDetails = asyncExecutorUtils.getRejectionCodeDesc(
                claimHccId,claimLineHccId, claimFactKey, state, lob, product);
        List<ClaimRejectionDetails> actualDetails = claimLinesDetails.get();
        assertNotNull(claimLinesDetails);
        assertEquals(claimLineHccId, actualDetails.get(0).getClaimLineNumber());
    }

    @Test
    void testGetMedicalClaimLinesWithFactKey() throws Exception {

        List<MedicalClaimLines> medicalClaimLines = new ArrayList<>();
        MedicalClaimLines claimLines = new MedicalClaimLines();
        claimLines.setClaimLineNumber(claimLineHccId);
        medicalClaimLines.add(claimLines);
        String claimFactKey = "90511";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimLinesMapper)))
                .thenReturn(medicalClaimLines);
        CompletableFuture<List<MedicalClaimLines>> claimLinesDetails = asyncExecutorUtils.getMedicalClaimLinesWithFactKey(
                claimHccId, claimFactKey, state, lob, product);
        List<MedicalClaimLines> actualDetails = claimLinesDetails.get();
        assertNotNull(claimLinesDetails);
        assertEquals(claimLineHccId, actualDetails.get(0).getClaimLineNumber());
    }

    @Test
    void testGetMedicalClaimLinesWithoutFactKey() throws Exception {

        List<MedicalClaimLines> medicalClaimLines = new ArrayList<>();
        MedicalClaimLines claimLines = new MedicalClaimLines();
        claimLines.setClaimLineNumber(claimLineHccId);
        medicalClaimLines.add(claimLines);
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimLinesMapper)))
                .thenReturn(medicalClaimLines);
        CompletableFuture<List<MedicalClaimLines>> claimLinesDetails = asyncExecutorUtils.getMedicalClaimLinesWithoutFactKey(
                claimHccId, state, lob, product);
        List<MedicalClaimLines> actualDetails = claimLinesDetails.get();
        assertNotNull(claimLinesDetails);
        assertEquals(claimLineHccId, actualDetails.get(0).getClaimLineNumber());
    }

}
