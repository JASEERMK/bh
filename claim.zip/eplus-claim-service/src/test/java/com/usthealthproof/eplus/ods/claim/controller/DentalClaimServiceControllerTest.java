package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetailResponse;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLinesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class DentalClaimServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @InjectMocks
    private DentalClaimServiceController dentalClaimServiceController;

    @Mock
    private ClaimServices claimServices;

    @Mock
    private Validator validator;

    private String claimHccId;
    private String claimLineHccId;
    private String state;
    private String lob;
    private String product;
    private DentalClaimDetails dentalClaimDetails;
    private DentalClaimLinesResponse dentalClaimLinesResponse;
    private DentalClaimLineDetailResponse dentalClaimLineDetailResponse;

    @BeforeEach
    void setUp() {
        claimHccId = "123";
        claimLineHccId = "validClaimLineHccId";
        state = "TX";
        lob = "Medical";
        product = "Health";
        dentalClaimDetails = new DentalClaimDetails();
        dentalClaimLinesResponse = new DentalClaimLinesResponse();
        dentalClaimLineDetailResponse = new DentalClaimLineDetailResponse();
    }

    @Test
    void testGetDentalClaimDetails() {
        when(claimServices.findDentalClaimId(anyString(), anyString(), anyString(), anyString())).thenReturn(dentalClaimDetails);

        ResponseEntity<DentalClaimDetails> response = dentalClaimServiceController.getDentalClaimDetails(claimHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(dentalClaimDetails, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).findDentalClaimId(claimHccId, state, lob, product);
    }

    @Test
    void testGetDentalClaimLines() {
        DentalClaimLines dentalClaimLines = new DentalClaimLines();
        when(claimServices.getDentalClaimLines(claimHccId,state,lob,product)).thenReturn(List.of(dentalClaimLines));
        dentalClaimLinesResponse.setDentalClaimLines(List.of(dentalClaimLines));

        ResponseEntity<DentalClaimLinesResponse> response = dentalClaimServiceController.getDentalClaimLines(claimHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(dentalClaimLinesResponse, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).getDentalClaimLines(claimHccId, state, lob, product);
    }

    @Test
    void testGetDentalClaimLineDetails() {
        DentalClaimLineDetails dentalClaimLineDetails = new DentalClaimLineDetails();
        when(claimServices.getDentalClaimLineDetails(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(dentalClaimLineDetails);
        dentalClaimLineDetailResponse.setDentalClaimLineDetailsList(List.of(dentalClaimLineDetails));

        ResponseEntity<DentalClaimLineDetailResponse> response = dentalClaimServiceController.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(dentalClaimLineDetailResponse, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId, claimLineHccId);
        verify(claimServices, times(1)).getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
    }

    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "K1234566>",
            "K1234566=",
            "K1234566&",
            "K1234566%",
            "K1234566#",
            "K1234566&",
            "K1234566(",
            "K1234566)",
            "K1234566@",
            "K1234566\\,",
            "K1234566/",
            "K1234566*",
            "K1234566|",
            "K1234566;",
            "K1234566!",
            "K1234566--",
    })

    void testGetDentalClaimDetails_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/dental/claimlines")
                        .param("claimHccId", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "Medicaid<",
            "Medicaid>",
            "Medicaid=",
            "Medicaid&",
            "Medicaid%",
            "Medicaid#",
            "Medicaid&",
            "Medicaid(",
            "Medicaid)",
            "Medicaid@",
            "Medicaid\\,",
            "Medicaid/",
            "Medicaid*",
            "Medicaid|",
            "Medicaid;",
            "Medicaid!",
            "Medicaid--",
    })

    void testGetDentalClaimDetails_invalidLobPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/dental/claimline")
                        .param("claimHccId", "12345")
                        .param("claimLineHccId","123")
                        .param("lob",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: lob is not in valid format"));
    }

}
