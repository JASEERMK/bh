package com.usthealthproof.eplus.ods.claim.model.portal.detail;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClaimLineDetailsTest {

    @Test
    public void testCompareTo() {
        // Create instances of ClaimLineDetails
        ClaimLineDetails claimLine1 = new ClaimLineDetails();
        claimLine1.setClaimLineNumber("001");

        ClaimLineDetails claimLine2 = new ClaimLineDetails();
        claimLine2.setClaimLineNumber("002");

        ClaimLineDetails claimLine3 = new ClaimLineDetails();
        claimLine3.setClaimLineNumber("001");

        // Test case where claimLine1's claimLineNumber is less than claimLine2's claimLineNumber
        assertTrue(claimLine1.compareTo(claimLine2) < 0, "Expected claimLine1 to be less than claimLine2");

        // Test case where claimLine1's claimLineNumber is equal to claimLine3's claimLineNumber
        assertEquals(0, claimLine1.compareTo(claimLine3), "Expected claimLine1 to be equal to claimLine3");

        // Test case where claimLine2's claimLineNumber is greater than claimLine1's claimLineNumber
        assertTrue(claimLine2.compareTo(claimLine1) > 0, "Expected claimLine2 to be greater than claimLine1");
    }
}
