package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.exception.RequestValidationException;
import com.usthealthproof.eplus.ods.claim.mapper.search.ProviderClaimSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

public class ProviderClaimSearchDataTest {

    @InjectMocks
    private ProviderClaimSearchData providerClaimSearchData;

    @Mock
    private ProviderClaimSearchMapper claimSearchMapper;
    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimHeaderDetails_Success() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        ClaimSearchModel claimSearchModel = new ClaimSearchModel();
        List<ClaimSearchModel> claimSearchModelList = Collections.singletonList(claimSearchModel);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenReturn(claimSearchModelList);
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);

        // Act
        ClaimHeaderSearchResponse actualResponse = providerClaimSearchData.getClaimHeaderDetails(request, response);

        // Assert
        assertEquals(claimSearchModelList, actualResponse.getResults());

    }

    @Test
    public void testGetClaimHeaderDetails_JdbcConnectionException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database not available"));
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            providerClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Database not available", thrown.getMessage());

    }

    @Test
    public void testGetClaimHeaderDetails_ClaimNotFoundException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenReturn(Collections.emptyList());
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);

        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            providerClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals(ClaimHeaderSearchConstants.NO_DATA_FOUND, thrown.getMessage());

    }

    @Test
    public void testGetClaimHeaderDetails_GenericException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            providerClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Unexpected error", thrown.getMessage());

    }

    @Test
    public void testGetClaimHeaderDetails_InvalidClaimType() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        request.setClaimTypes("INVALID_CLAIM_TYPE");

        // Act & Assert
        RequestValidationException thrown = assertThrows(RequestValidationException.class, () -> {
            providerClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals(ClaimHeaderSearchConstants.INVALID_PROVIDER_CLAIM_SEARCH_TYPE, thrown.getMessage());
         }
}
