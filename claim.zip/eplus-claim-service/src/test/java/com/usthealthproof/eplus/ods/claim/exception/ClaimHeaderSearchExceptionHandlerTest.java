package com.usthealthproof.eplus.ods.claim.exception;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.Collections;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class ClaimHeaderSearchExceptionHandlerTest {

    @InjectMocks
    private ClaimHeaderSearchExceptionHandler exceptionHandler;

    @Mock
    private WebRequest webRequest;

    @Mock
    private ConstraintViolation<String> constraintViolation;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGlobalExceptionHandler() {
        Exception exception = new Exception("Generic exception");

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.globalException(exception, webRequest);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.FAILURE, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList(ClaimConstants.EXCEPTION_OCCURRED), errorResponse.getProblemDetails().getErrors());
    }

    @Test
    void testJdbcExceptionHandler_withMessageContainingFailure() {
        CannotGetJdbcConnectionException exception = new CannotGetJdbcConnectionException("Failed to obtain JDBC Connection");

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.jdbcExceptionHandler(exception, webRequest);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.FAILURE, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList(ClaimConstants.JDBC_EXCEPTION), errorResponse.getProblemDetails().getErrors());
    }

    @Test
    void testJdbcExceptionHandler_withDifferentMessage() {
        CannotGetJdbcConnectionException exception = new CannotGetJdbcConnectionException("Other JDBC issue");

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.jdbcExceptionHandler(exception, webRequest);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.FAILURE, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList(ClaimConstants.EXCEPTION_OCCURRED), errorResponse.getProblemDetails().getErrors());
    }

    @Test
    void testNotFoundExceptionHandler() {
        ClaimNotFoundException exception = new ClaimNotFoundException("Claim not found");

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.notFoundException(exception, webRequest);

        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.SUCCESS, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList("Claim not found"), errorResponse.getProblemDetails().getErrors());
    }

    @Test
    void testRequestValidationHandler() {
        RequestValidationException exception = new RequestValidationException("Validation failed");

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.requestValidationHandler(exception, webRequest);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.FAILURE, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList("Validation failed"), errorResponse.getProblemDetails().getErrors());
    }

    @Test
    void testHandleConstraintViolationException() {
        Set<ConstraintViolation<String>> violations = Collections.singleton(constraintViolation);
        when(constraintViolation.getMessage()).thenReturn("Constraint violation error");
        ConstraintViolationException exception = new ConstraintViolationException(violations);

        ResponseEntity<ErrorResponse> responseEntity = exceptionHandler.handleconstraintViolationException(exception, webRequest);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        ErrorResponse errorResponse = responseEntity.getBody();
        assertEquals(ClaimConstants.FAILURE, errorResponse.getProblemDetails().getStatus());
        assertEquals(Collections.singletonList("Constraint violation error"), errorResponse.getProblemDetails().getErrors());
    }
    @Test
    void testMissingServletRequestParameterException() {
        MissingServletRequestParameterException exception =
                new MissingServletRequestParameterException("paramName", "String");
    }

    @Test
    void testNoResourceFoundException() {
        HttpMethod HttpMethod = org.springframework.http.HttpMethod.valueOf("/v1/claims/rxss");
        NoResourceFoundException exception = new NoResourceFoundException(HttpMethod, "no resource found");

    }


}
