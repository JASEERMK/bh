package com.usthealthproof.eplus.ods.claim.mapper.pharmacy;

import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class RxClaimDetailsMapperTest {

    @InjectMocks
    private RxClaimDetailsMapper rxClaimDetailsMapper;

    @Mock
    private ResultSet resultSet;

    @Mock
    private DateUtils dateUtils;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("member_hcc_id")).thenReturn("member123");
        when(resultSet.getString("claim_id")).thenReturn("claim456");
        when(resultSet.getString("drug_name")).thenReturn("DrugName");
        when(resultSet.getString("status")).thenReturn("Active");
        when(resultSet.getString("pharmacy_name")).thenReturn("PharmacyName");
        when(resultSet.getString("prescription_id")).thenReturn("prescription789");
        when(resultSet.getString("source_system")).thenReturn("SystemA");
        when(resultSet.getString("source_system_id")).thenReturn("source123");
        when(resultSet.getString("adjudicated_date")).thenReturn("2024-07-01");
        when(resultSet.getString("prescription_written_date")).thenReturn("2024-06-15");
        when(resultSet.getString("filled_date")).thenReturn("2024-07-05");
        when(resultSet.getString("dosage")).thenReturn("100mg");
        when(resultSet.getString("quantity")).thenReturn("30");
        when(resultSet.getString("days_supply")).thenReturn("30");
        when(resultSet.getString("fills_count")).thenReturn("1");
        when(resultSet.getString("prior_authorization_id")).thenReturn("auth123");
        when(resultSet.getString("partb_partd_ind")).thenReturn("PartB");
        when(resultSet.getString("specialty_rx_ind")).thenReturn("Specialty");
        when(resultSet.getString("formulary_ind")).thenReturn("Formulary");
        when(resultSet.getString("formulary_tier")).thenReturn("Tier1");
        when(resultSet.getString("maintenance_drug")).thenReturn("Yes");
        when(resultSet.getString("dispensed_as_written_type")).thenReturn("TypeA");
        when(resultSet.getString("drug_type")).thenReturn("TypeB");
        when(resultSet.getString("drug_category_type")).thenReturn("Category1");
        when(resultSet.getString("pharmacy_address")).thenReturn("123 Pharmacy St");
        when(resultSet.getString("pharmacy_telephone_number")).thenReturn("123-456-7890");
        when(resultSet.getString("pharmacy_dispense_type")).thenReturn("Retail");
        when(resultSet.getString("prescribing_physician_name")).thenReturn("Dr. Smith");
        when(resultSet.getString("prescribing_physician_address")).thenReturn("456 Doctor Ave");
        when(resultSet.getString("prescribing_physician_specialty_code")).thenReturn("Specialty123");
        when(resultSet.getString("diagnosis")).thenReturn("ConditionX");
        when(resultSet.getString("ingredient_cost_amount")).thenReturn("100.00");
        when(resultSet.getString("dispense_fee_amount")).thenReturn("5.00");
        when(resultSet.getString("sales_tax_amount")).thenReturn("1.00");
        when(resultSet.getString("deductible_amount")).thenReturn("10.00");
        when(resultSet.getString("copay_amount")).thenReturn("15.00");
        when(resultSet.getString("coinsurance_amount")).thenReturn("20.00");
        when(resultSet.getString("out_of_pocket_amount")).thenReturn("25.00");
        when(resultSet.getString("member_paid_amount")).thenReturn("30.00");
        when(resultSet.getString("plan_paid_amount")).thenReturn("50.00");
        when(resultSet.getString("cob_indicator")).thenReturn("COB");
        when(resultSet.getString("cob_paid_amount")).thenReturn("40.00");
        when(resultSet.getString("check_number")).thenReturn("check001");
        when(resultSet.getString("adjustment_reason")).thenReturn("Reason1");
        when(resultSet.getString("adjustment_type")).thenReturn("Type1");
        when(resultSet.getString("reject_count")).thenReturn("1");
        when(resultSet.getString("reject_message_1")).thenReturn("Message1");
        when(resultSet.getString("reject_message_2")).thenReturn("Message2");
        when(resultSet.getString("reject_message_3")).thenReturn("Message3");
        when(resultSet.getString("first_filled_date")).thenReturn("2024-07-01");
        when(resultSet.getString("member_name")).thenReturn("John Doe");
        when(resultSet.getString("prescribing_physician_id")).thenReturn("physician001");
        when(resultSet.getString("prescribing_physician_name")).thenReturn("Dr. Smith");

        // Mock DateUtils behavior
        when(dateUtils.getFormattedApplicationDate("2024-07-01")).thenReturn("01-Jul-2024");
        when(dateUtils.getFormattedApplicationDate("2024-06-15")).thenReturn("15-Jun-2024");
        when(dateUtils.getFormattedApplicationDate("2024-07-05")).thenReturn("05-Jul-2024");

        // Execute mapRow
        RxClaimDetails result = rxClaimDetailsMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("member123", result.getMemberId());
        assertEquals("claim456", result.getClaimId());
        assertEquals("DrugName", result.getDrugName());
        assertEquals("Active", result.getStatus());
        assertEquals("PharmacyName", result.getPharmacyName());
        assertEquals("prescription789", result.getPrescriptionId());
        assertEquals("SystemA", result.getSourceSystem());
        assertEquals("source123", result.getSourceSystemId());
        assertEquals("01-Jul-2024", result.getAdjudicatedDate());
        assertEquals("15-Jun-2024", result.getPrescriptionWrittenDate());
        assertEquals("05-Jul-2024", result.getFilledDate());
        assertEquals("100mg", result.getDosage());
        assertEquals("30", result.getQuantity());
        assertEquals("30", result.getDaysSupply());
        assertEquals("1", result.getFillsCount());
        assertEquals("auth123", result.getPriorAuthorizationId());
        assertEquals("PartB", result.getPartbPartdInd());
        assertEquals("Specialty", result.getSpecialtyRxInd());
        assertEquals("Formulary", result.getFormularyInd());
        assertEquals("Tier1", result.getFormularyTier());
        assertEquals("Yes", result.getMaintenanceDrug());
        assertEquals("TypeA", result.getDispensedAsWrittenType());
        assertEquals("TypeB", result.getDrugType());
        assertEquals("Category1", result.getDrugCategoryType());
        assertEquals("123 Pharmacy St", result.getPharmacyAddress());
        assertEquals("123-456-7890", result.getPharmacyTelephoneNumber());
        assertEquals("Retail", result.getPharmacyDispenseType());
        assertEquals("Dr. Smith", result.getPrescribingPhysicianName());
        assertEquals("456 Doctor Ave", result.getPrescribingPhysicianAddress());
        assertEquals("Specialty123", result.getPrescribingPhysicianSpecialtyCode());
        assertEquals("ConditionX", result.getDiagnosis());
        assertEquals("100.00", result.getIngredientCostAmount());
        assertEquals("5.00", result.getDispenseFeeAmount());
        assertEquals("1.00", result.getSalesTaxAmount());
        assertEquals("10.00", result.getDeductibleAmount());
        assertEquals("15.00", result.getCopayAmount());
        assertEquals("20.00", result.getCoinsuranceAmount());
        assertEquals("25.00", result.getOutOfPocketAmount());
        assertEquals("30.00", result.getMemberPaidAmount());
        assertEquals("50.00", result.getPlanPaidAmount());
        assertEquals("COB", result.getCobIndicator());
        assertEquals("40.00", result.getCobPaidAmount());
        assertEquals("check001", result.getCheckNumber());
        assertEquals("Reason1", result.getAdjustmentReason());
        assertEquals("Type1", result.getAdjustmentType());
        assertEquals("1", result.getRejectCount());
        assertEquals("Message1", result.getRejectMessage1());
        assertEquals("Message2", result.getRejectMessage2());
        assertEquals("Message3", result.getRejectMessage3());
        assertEquals("2024-07-01", result.getFirstFilledDate());
        assertEquals("John Doe", result.getMemberName());
        assertEquals("physician001", result.getProviderId());
        assertEquals("Dr. Smith", result.getProviderName());
    }
}
