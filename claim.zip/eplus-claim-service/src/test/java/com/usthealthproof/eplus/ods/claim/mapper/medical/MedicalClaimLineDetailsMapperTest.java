package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.mapper.util.APIUtils;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class MedicalClaimLineDetailsMapperTest {

    @InjectMocks
    private MedicalClaimLineDetailsMapper medicalClaimLineDetailsMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private APIUtils apiUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("claimLineNumber")).thenReturn("CL123");
        when(resultSet.getString("claimHccId")).thenReturn("HCC123");
        when(resultSet.getString("claimLineKey")).thenReturn("Key123");
        when(resultSet.getString("billedAmount")).thenReturn("1000");
        when(resultSet.getString("denied")).thenReturn("no");
        when(resultSet.getString("serviceStartDate")).thenReturn("2023-01-01");
        when(resultSet.getString("serviceEndDate")).thenReturn("2023-01-10");
        when(resultSet.getString("POScode_desc")).thenReturn("POS Description");
        when(resultSet.getString("DeductibleAmount")).thenReturn("100");
        when(resultSet.getString("CoInsuranceAmount")).thenReturn("50");
        when(resultSet.getString("CopayAmount")).thenReturn("20");
        when(resultSet.getString("paidAmount")).thenReturn("900");
        when(resultSet.getString("CPTcode_desc")).thenReturn("CPT Description");
        when(resultSet.getString("modifier_code_desc")).thenReturn("Modifier Description");
        when(resultSet.getString("RevenueCode")).thenReturn("Revenue123");
        when(resultSet.getString("Minute")).thenReturn("10");
        when(resultSet.getString("UOS")).thenReturn("1");
        when(resultSet.getString("primary_diagnosis")).thenReturn("Primary Diagnosis");
        when(resultSet.getString("otherdiagnosiscodes")).thenReturn("Other Diagnosis");
        when(resultSet.getString("user_message_code_desc")).thenReturn("User Message");
        when(resultSet.getString("NonCoveredAmount")).thenReturn("50");
        when(resultSet.getString("balance_billed_amount")).thenReturn("150");
        when(resultSet.getString("MemberPenalty")).thenReturn("5");
        when(resultSet.getString("MemberResponsibility")).thenReturn("25");
        when(resultSet.getString("ProviderPenalty")).thenReturn("10");
        when(resultSet.getString("BonusAmount")).thenReturn("0");
        when(resultSet.getString("OtherDiscount")).thenReturn("5");
        when(resultSet.getString("HCCAmount")).thenReturn("30");
        when(resultSet.getString("cob_paid")).thenReturn("100");
        when(resultSet.getString("cob_copay")).thenReturn("10");
        when(resultSet.getString("cob_coninsurance")).thenReturn("5");
        when(resultSet.getString("cob_deductible")).thenReturn("15");
        when(resultSet.getString("cob_allowed")).thenReturn("80");
        when(resultSet.getString("cob_discount")).thenReturn("10");
        when(resultSet.getString("cob_member_penalty")).thenReturn("5");
        when(resultSet.getString("cob_member_responsibility")).thenReturn("25");
        when(resultSet.getString("cob_provider_penalty")).thenReturn("0");
        when(resultSet.getString("cob_non_covered_amount")).thenReturn("5");
        when(resultSet.getString("cob_per_day_limit")).thenReturn("200");
        when(resultSet.getString("cob_tax_amount")).thenReturn("15");
        when(resultSet.getString("Error_Level__c")).thenReturn("Error Level");
        when(resultSet.getString("externalSource")).thenReturn("External Source");
        when(resultSet.getString("status")).thenReturn("processed");
        when(resultSet.getString("Ref_Auth_Number__c")).thenReturn("Auth123");
        when(resultSet.getString("epsdt_indicator")).thenReturn("Y");
        when(resultSet.getString("allowedamount")).thenReturn("1000");
        when(resultSet.getString("Disposition__c")).thenReturn("Disposition");
        when(resultSet.getString("description")).thenReturn("Denial Code Description");
        when(resultSet.getString("RenderingPractitionerID")).thenReturn("Practitioner123");
        when(resultSet.getString("RenderingPractitionerName")).thenReturn("Practitioner Name");
        when(resultSet.getString("RenderingPractitionerNPI")).thenReturn("NPI123");
        when(resultSet.getString("benefit_tier_type")).thenReturn("Tier Type");
        when(resultSet.getString("benefit_tier_name")).thenReturn("Tier Name");
        when(resultSet.getString("benefit_label")).thenReturn("Benefit Label");
        when(resultSet.getString("claim_fact_key")).thenReturn("FactKey123");
        when(resultSet.getString("benefit_network")).thenReturn("Network");

        // Setup mock behavior for DateUtils and APIUtils
        when(dateUtils.getFormattedApplicationDate(anyString())).thenAnswer(invocation -> invocation.getArgument(0));

        // Setup mock behavior for APIUtils
        when(apiUtils.getClaimNotes(anyString())).thenReturn(null);

        // Execute mapRow
        MedicalClaimLineDetails result = medicalClaimLineDetailsMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("CL123", result.getClaimLineNumber());
        assertEquals("HCC123", result.getClaimHccId());
        assertEquals("Key123", result.getClaimLineKey());
        assertEquals("1000", result.getBilledAmount());
        assertEquals("no", result.getDenied());
        assertEquals("2023-01-01", result.getServiceStartDate());
        assertEquals("2023-01-10", result.getServiceEndDate());
        assertEquals("POS Description", result.getPlaceOfService());
        assertEquals("100", result.getDeductibleAmount());
        assertEquals("50", result.getCoinsuranceAmount());
        assertEquals("20", result.getCopayAmount());
        assertEquals("900", result.getPaidAmount());
        assertEquals("CPT Description", result.getCptCodeDesc());
        assertEquals("Modifier Description", result.getModifierCodeDesc());
        assertEquals("Revenue123", result.getRevenueCode());
        assertEquals("10", result.getMinute());
        assertEquals("1", result.getUos());
        assertEquals("Primary Diagnosis", result.getPrimaryDiagnosis());
        assertEquals("Other Diagnosis", result.getOtherDiagnosisCodes());
        assertEquals("User Message", result.getUserMessageCodeDesc());
        assertEquals("50", result.getNonCoveredAmount());
        assertEquals("150", result.getBalanceBilledAmount());
        assertEquals("5", result.getMemberPenalty());
        assertEquals("25", result.getMemberResponsibility());
        assertEquals("10", result.getProviderPenalty());
        assertEquals("0", result.getBonusAmount());
        assertEquals("5", result.getOtherDiscount());
        assertEquals("30", result.getHccAmount());
        assertEquals("100", result.getCobPaid());
        assertEquals("10", result.getCobCopay());
        assertEquals("5", result.getCobConInsurance());
        assertEquals("15", result.getCobDeductible());
        assertEquals("80", result.getCobAllowed());
        assertEquals("10", result.getCobDiscount());
        assertEquals("5", result.getCobMemberPenalty());
        assertEquals(null, result.getCobMemberResponsibility());
        assertEquals("0", result.getCobProviderPenalty());
        assertEquals("5", result.getCobNonCoveredAmount());
        assertEquals("200", result.getCobPerDayLimit());
        assertEquals("15", result.getCobTaxAmount());
        assertEquals("Error Level", result.getErrorLevel());
        assertEquals("External Source", result.getExternalSource());
        assertEquals("processed", result.getStatus());
        assertEquals("Auth123", result.getRefAuthNumber());
        assertEquals("Y", result.getEpsdtIndicator());
        assertEquals("1000", result.getAllowedAmount());
        assertEquals("Disposition", result.getDisposition());
        assertEquals("Denial Code Description", result.getDenialCodeDesc());
        assertEquals("Practitioner123", result.getRenderingPractitionerId());
        assertEquals("Practitioner Name", result.getRenderingPractitionerName());
        assertEquals("NPI123", result.getRenderingPractitionerNpi());
        assertEquals("Tier Type", result.getBenefitTier());
        assertEquals("Tier Name", result.getTierName());
        assertEquals("Benefit Label", result.getBenefitLabel());
        assertEquals("FactKey123", result.getClaimFactKey());
        assertEquals("Network", result.getBenefitNetwork());
    }
}
