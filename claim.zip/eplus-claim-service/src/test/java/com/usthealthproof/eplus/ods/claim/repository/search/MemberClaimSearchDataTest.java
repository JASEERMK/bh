package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.constants.ClaimHeaderSearchConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.search.MemberClaimSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class MemberClaimSearchDataTest {

    @InjectMocks
    private MemberClaimSearchData memberClaimSearchData;
    @Mock
    private MemberClaimSearchMapper claimSearchMapper;
    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
            ReflectionTestUtils.setField(memberClaimSearchData, "spMedicalMemberClaimSearch", "spMedicalMemberClaimSearch");
            ReflectionTestUtils.setField(memberClaimSearchData, "spDentalMemberClaimSearch", "spDentalMemberClaimSearch");
            ReflectionTestUtils.setField(memberClaimSearchData, "spVisionMemberClaimSearch", "spVisionMemberClaimSearch");
            ReflectionTestUtils.setField(memberClaimSearchData, "spRxMemberClaimSearch", "spRxMemberClaimSearch");
    }

    @Test
    public void testGetClaimHeaderDetails_Success() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(MemberClaimSearchMapper.class)))
                .thenReturn(List.of(new ClaimSearchModel()));

        // Act
        ClaimHeaderSearchResponse result = memberClaimSearchData.getClaimHeaderDetails(request, response);

        // Assert
        assertNotNull(result);
        assertFalse(result.getResults().isEmpty());
    }

    @Test
    public void testGetClaimHeaderDetails_JdbcConnectionException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(MemberClaimSearchMapper.class)))
                .thenReturn(Collections.emptyList());

        // Act & Assert
        assertThrows(ClaimNotFoundException.class, () ->
                memberClaimSearchData.getClaimHeaderDetails(request, response));
    }
    @Test
    public void testGetClaimHeaderDetails_GenericException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        request.setClaimTypes(ClaimHeaderSearchConstants.MEDICAL);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            memberClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Unexpected error", thrown.getMessage());
    }

    @Test
    public void testGetClaimHeaderDetails_GenericException_Dental() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        request.setClaimTypes(ClaimHeaderSearchConstants.DENTAL);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            memberClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Unexpected error", thrown.getMessage());
    }

    @Test
    public void testGetClaimHeaderDetails_GenericException_Vision() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        request.setClaimTypes(ClaimHeaderSearchConstants.VISION);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            memberClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Unexpected error", thrown.getMessage());

    }
    @Test
    public void testGetClaimHeaderDetails_GenericException_Rx() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse response = new ClaimHeaderSearchResponse();
        request.setClaimTypes(ClaimHeaderSearchConstants.RX);

        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimSearchMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            memberClaimSearchData.getClaimHeaderDetails(request, response);
        });

        assertEquals("Unexpected error", thrown.getMessage());
    }



    @Test
    public void testGetSPNameBasedOnClaimType() throws Exception {

        Method method = MemberClaimSearchData.class.getDeclaredMethod("getSPNameBasedOnClaimType", String.class);
        method.setAccessible(true);

        String claimType = "MEDICAL";
        String result = (String) method.invoke(memberClaimSearchData, claimType);

        assertEquals("spMedicalMemberClaimSearch", result);
    }
    @Test
    public void testGetSPNameBasedOnClaimType_Dental() throws Exception {

        Method method = MemberClaimSearchData.class.getDeclaredMethod("getSPNameBasedOnClaimType", String.class);
        method.setAccessible(true);

        String claimType = "DENTAL";
        String result = (String) method.invoke(memberClaimSearchData, claimType);

        assertEquals("spDentalMemberClaimSearch", result);
    }
    @Test
    public void testGetSPNameBasedOnClaimType_Vision() throws Exception {

        Method method = MemberClaimSearchData.class.getDeclaredMethod("getSPNameBasedOnClaimType", String.class);
        method.setAccessible(true);

        String claimType = "VISION";
        String result = (String) method.invoke(memberClaimSearchData, claimType);

        assertEquals("spVisionMemberClaimSearch", result);
    }
    @Test
    public void testGetSPNameBasedOnClaimType_rx() throws Exception {

        Method method = MemberClaimSearchData.class.getDeclaredMethod("getSPNameBasedOnClaimType", String.class);
        method.setAccessible(true);

        String claimType = "RX";
        String result = (String) method.invoke(memberClaimSearchData, claimType);

        assertEquals("spRxMemberClaimSearch", result);
    }
    @Test
    public void testGetClaimHeaderDetails_ReturnsNull() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        request.setClaimTypes("INVALID");

    }
}
