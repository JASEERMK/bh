package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimLineDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@Slf4j
public class VisionClaimLineDetailsDataTest {

    @InjectMocks
    private VisionClaimLineDetailsData visionClaimLineDetailsData;

    @Mock
    private VisionClaimLineDetailsMapper visionClaimLineDetailsMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetVisionClaimLineDetails_Success() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String claimLineHccId = "testClaimLineHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        VisionClaimLineDetails visionClaimLineDetails = new VisionClaimLineDetails();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLineDetailsMapper)))
                .thenReturn(visionClaimLineDetails);

        // Act
        VisionClaimLineDetails result = visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);

        // Assert
        assertNotNull(result);
        assertEquals(visionClaimLineDetails, result);
    }

    @Test
    public void testGetVisionClaimLineDetails_EmptyResult() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String claimLineHccId = "testClaimLineHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLineDetailsMapper)))
                .thenThrow(new EmptyResultDataAccessException(1));

        // Act & Assert
        ClaimNotFoundException exception = assertThrows(ClaimNotFoundException.class, () -> {
            visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        });

        assertTrue(exception.getMessage().contains(ClaimConstants.VISION_CLAIM_LINE_DETAILS_NOT_FOUND));
    }

    @Test
    public void testGetVisionClaimLineDetails_CannotGetJdbcConnectionException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String claimLineHccId = "testClaimLineHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLineDetailsMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database connection error"));

        // Act & Assert
        CannotGetJdbcConnectionException exception = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        });

        assertEquals("Database connection error", exception.getMessage());
    }

    @Test
    public void testGetVisionClaimLineDetails_GeneralException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String claimLineHccId = "testClaimLineHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLineDetailsMapper)))
                .thenThrow(new RuntimeException("General error"));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        });

        assertEquals("General error", exception.getMessage());
    }
}