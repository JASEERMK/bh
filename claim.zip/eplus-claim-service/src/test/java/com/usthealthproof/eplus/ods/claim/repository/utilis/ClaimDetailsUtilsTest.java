package com.usthealthproof.eplus.ods.claim.repository.utilis;

import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimFactKeysMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@Slf4j
public class ClaimDetailsUtilsTest {

    @InjectMocks
    private AsyncExecutorUtils asyncExecutorUtils;

    @Mock
    private ClaimFactKeysMapper claimFactKeysMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimFactKeys_Success() throws Exception {
        // Arrange
        String claimHccId = "testHccId";
        List<String> claimFactKeys = Arrays.asList("factKey1", "factKey2");
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimFactKeysMapper)))
                .thenReturn(claimFactKeys);

        // Act
        CompletableFuture<List<String>> future = asyncExecutorUtils.getClaimFactKeys(claimHccId);
        List<String> actualClaimFactKeys = future.get();

        // Assert
        assertEquals(claimFactKeys, actualClaimFactKeys);
    }

    @Test
    public void testGetClaimFactKeys_EmptyResult() throws Exception {
        // Arrange
        String claimHccId = "testHccId";
        List<String> claimFactKeys = Arrays.asList();
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimFactKeysMapper)))
                .thenReturn(claimFactKeys);

        // Act
        CompletableFuture<List<String>> future = asyncExecutorUtils.getClaimFactKeys(claimHccId);
        List<String> actualClaimFactKeys = future.get();

        // Assert
        assertTrue(actualClaimFactKeys.isEmpty());
    }

    @Test
    public void testGetClaimFactKeys_Exception() {
        // Arrange
        String claimHccId = "testHccId";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(claimFactKeysMapper)))
                .thenThrow(new RuntimeException("Database error"));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            CompletableFuture<List<String>> future = asyncExecutorUtils.getClaimFactKeys(claimHccId);
            future.join();
        });

        assertEquals("Database error", exception.getMessage());

    }


}
