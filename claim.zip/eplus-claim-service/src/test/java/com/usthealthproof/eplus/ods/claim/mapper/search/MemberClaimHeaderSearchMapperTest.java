package com.usthealthproof.eplus.ods.claim.mapper.search;

import com.usthealthproof.eplus.ods.claim.model.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class MemberClaimHeaderSearchMapperTest {

    @InjectMocks
    private MemberClaimSearchMapper memberClaimSearchMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow_MedicalClaim() throws SQLException {
        memberClaimSearchMapper.claimType = "medical";

        // Setup mock behavior for ResultSet
        when(resultSet.getString("claim_number")).thenReturn("123456");
        when(resultSet.getString("claim_status")).thenReturn("Approved");
        when(resultSet.getString("dos")).thenReturn("2024-01-01");
        when(resultSet.getString("provider_name")).thenReturn("Dr. Smith");
        when(resultSet.getString("billed_amount")).thenReturn("1000");
        when(dateUtils.getFormattedApplicationDate("2024-01-01")).thenReturn("01-01-2024");

        // Execute mapRow
        ClaimSearchModel result = memberClaimSearchMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("123456", result.getClaimNumber());
        assertEquals("Approved", result.getClaimStatus());
        assertEquals("01-01-2024", result.getDos());
        assertEquals("Dr. Smith", result.getProviderName());
        assertEquals("1000", result.getBilledAmount());
    }

    @Test
    public void testMapRow_DentalClaim() throws SQLException {
        memberClaimSearchMapper.claimType = "dental";

        // Setup mock behavior for ResultSet
        when(resultSet.getString("claim_number")).thenReturn("789101");
        when(resultSet.getString("claim_status")).thenReturn("Pending");
        when(resultSet.getString("dos")).thenReturn("2024-02-01");
        when(resultSet.getString("provider_name")).thenReturn("Dr. Brown");
        when(resultSet.getString("payment_date")).thenReturn("2024-02-15");
        when(dateUtils.getFormattedApplicationDate("2024-02-01")).thenReturn("01-02-2024");
        when(dateUtils.getFormattedApplicationDate("2024-02-15")).thenReturn("15-02-2024");

        // Execute mapRow
        ClaimSearchModel result = memberClaimSearchMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("789101", result.getClaimNumber());
        assertEquals("Pending", result.getClaimStatus());
        assertEquals("01-02-2024", result.getDos());
        assertEquals("Dr. Brown", result.getProviderName());
        assertEquals("15-02-2024", result.getDatePaid());
    }

    @Test
    public void testMapRow_VisionClaim() throws SQLException {
        memberClaimSearchMapper.claimType = "vision";

        // Setup mock behavior for ResultSet
        when(resultSet.getString("claim_number")).thenReturn("112233");
        when(resultSet.getString("claim_status")).thenReturn("Approved");
        when(resultSet.getString("dos")).thenReturn("2024-03-01");
        when(resultSet.getString("provider_name")).thenReturn("Dr. Green");
        when(resultSet.getString("payment_date")).thenReturn("2024-03-10");
        when(dateUtils.getFormattedApplicationDate("2024-03-01")).thenReturn("01-03-2024");
        when(dateUtils.getFormattedApplicationDate("2024-03-10")).thenReturn("10-03-2024");

        // Execute mapRow
        ClaimSearchModel result = memberClaimSearchMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("112233", result.getClaimNumber());
        assertEquals("Approved", result.getClaimStatus());
        assertEquals("01-03-2024", result.getDos());
        assertEquals("Dr. Green", result.getProviderName());
        assertEquals("10-03-2024", result.getDatePaid());
    }

    @Test
    public void testMapRow_RxClaim() throws SQLException {
        memberClaimSearchMapper.claimType = "rx";

        // Setup mock behavior for ResultSet
        when(resultSet.getString("claim_number")).thenReturn("445566");
        when(resultSet.getString("claim_status")).thenReturn("Processed");
        when(resultSet.getString("drugwithdosage")).thenReturn("Aspirin 500mg");
        when(resultSet.getString("filled_date")).thenReturn("2024-04-01");
        when(resultSet.getString("PHARMACY_NAME")).thenReturn("Pharmacy A");
        when(resultSet.getString("prescription_id")).thenReturn("Rx123456");
        when(dateUtils.getFormattedApplicationDate("2024-04-01")).thenReturn("01-04-2024");

        // Execute mapRow
        ClaimSearchModel result = memberClaimSearchMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("445566", result.getClaimNumber());
        assertEquals("Processed", result.getClaimStatus());
        assertEquals("Aspirin 500mg", result.getDrugName());
        assertEquals("01-04-2024", result.getDateFilled());
        assertEquals("Pharmacy A", result.getPharmacyName());
        assertEquals("Rx123456", result.getPrescriptionId());
    }
}
