package com.usthealthproof.eplus.ods.claim.util;

import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CommonUtilTest {
    @Test
    void testGetProblemDetails() {
        String message = "Test error message";
        String status = "404";

        ProblemDetails problemDetails = CommonUtil.getProblemDetails(message, status);

        assertEquals(status, problemDetails.getStatus());
        assertEquals(List.of(message), problemDetails.getErrors());
    }
}
