package com.usthealthproof.eplus.ods.claim.service;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.ods.claim.model.pharmacy.RxClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.search.DenialCodes;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import com.usthealthproof.eplus.ods.claim.repository.denialcode.DenialCodeSearchData;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.dental.DentalClaimLinesData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalClaimLinesData;
import com.usthealthproof.eplus.ods.claim.repository.medical.MedicalExternalMessageDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.pharmacy.RxClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimLineDetailsData;
import com.usthealthproof.eplus.ods.claim.repository.vision.VisionClaimLinesData;
import com.usthealthproof.eplus.ods.claim.repository.portal.ClaimDetailsData;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClaimServicesTest {

    @Mock
    private MedicalClaimDetailsData medicalClaimDetailsData;
    @Mock
    private MedicalClaimLineDetailsData medicalClaimLineDetailsData;
    @Mock
    private MedicalClaimLinesData medicalClaimLinesData;
    @Mock
    private VisionClaimLineDetailsData visionClaimLineDetailsData;
    @Mock
    private VisionClaimDetailsData visionClaimDetailsData;
    @Mock
    private VisionClaimLinesData visionClaimLinesData;
    @Mock
    private DentalClaimDetailsData dentalClaimDetailsData;
    @Mock
    private DentalClaimLineDetailsData dentalClaimLineDetailsData;
    @Mock
    private DentalClaimLinesData dentalClaimLinesData;
    @Mock
    private RxClaimDetailsData rxClaimDetailsData;
    @Mock
    private MedicalExternalMessageDetailsData medicalExternalMessageDetailsData;
    @Mock
    private ClaimDetailsData claimDetailsData;
    @Mock
    private DenialCodeSearchData denialCodeSearchData;

    @InjectMocks
    private ClaimServices claimServices;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindClaimId() throws Exception {
        String claimHccId = "123";
        String claimFactKey = "abc";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        MedicalClaimDetails expectedDetails = new MedicalClaimDetails();
        when(medicalClaimDetailsData.findClaimId(claimHccId, claimFactKey, state, lob, product))
                .thenReturn(expectedDetails);

        MedicalClaimDetails result = claimServices.findClaimId(claimHccId, claimFactKey, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testGetClaimLines() throws Exception {
        String claimHccId = "123";
        String claimFactKey = "abc";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        List<MedicalClaimLines> expectedLines = List.of(new MedicalClaimLines());
        when(medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product))
                .thenReturn(expectedLines);

        List<MedicalClaimLines> result = claimServices.getClaimLines(claimHccId, claimFactKey, state, lob, product);
        assertEquals(expectedLines, result);
    }

    @Test
    void testGetClaimLineDetails() throws Exception {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String claimFactKey = "abc";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        MedicalClaimLineDetails expectedDetails = new MedicalClaimLineDetails();
        when(medicalClaimLineDetailsData.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product))
                .thenReturn(expectedDetails);

        MedicalClaimLineDetails result = claimServices.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testFindVisionClaimId() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        VisionClaimDetails expectedDetails = new VisionClaimDetails();
        when(visionClaimDetailsData.findVisionClaimId(claimHccId, state, lob, product)).thenReturn(expectedDetails);

        VisionClaimDetails result = claimServices.findVisionClaimId(claimHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testGetVisionClaimLines() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        List<VisionClaimLines> expectedLines = List.of(new VisionClaimLines());
        when(visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product)).thenReturn(expectedLines);

        List<VisionClaimLines> result = claimServices.getVisionClaimLines(claimHccId, state, lob, product);
        assertEquals(expectedLines, result);
    }

    @Test
    void testGetVisionClaimLineDetails() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        VisionClaimLineDetails expectedDetails = new VisionClaimLineDetails();
        when(visionClaimLineDetailsData.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product))
                .thenReturn(expectedDetails);

        VisionClaimLineDetails result = claimServices.getVisionClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testFindDentalClaimId() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";


        DentalClaimDetails expectedDetails = new DentalClaimDetails();
        when(dentalClaimDetailsData.findDentalClaimId(claimHccId, state, lob, product)).thenReturn(expectedDetails);

        DentalClaimDetails result = claimServices.findDentalClaimId(claimHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testGetDentalClaimLines() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        List<DentalClaimLines> expectedLines = List.of(new DentalClaimLines());
        when(dentalClaimLinesData.getDentalClaimLines(claimHccId,state,lob,product)).thenReturn(expectedLines);

        List<DentalClaimLines> result = claimServices.getDentalClaimLines(claimHccId, state, lob, product);
        assertEquals(expectedLines, result);
    }

    @Test
    void testGetDentalClaimLineDetails() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        DentalClaimLineDetails expectedDetails = new DentalClaimLineDetails();
        when(dentalClaimLineDetailsData.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product))
                .thenReturn(expectedDetails);

        DentalClaimLineDetails result = claimServices.getDentalClaimLineDetails(claimHccId, claimLineHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testFindRxClaimId() {
        String claimHccId = "123";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        RxClaimDetails expectedDetails = new RxClaimDetails();
        when(rxClaimDetailsData.findRxClaimId(claimHccId, state, lob, product)).thenReturn(expectedDetails);

        RxClaimDetails result = claimServices.findRxClaimId(claimHccId, state, lob, product);
        assertEquals(expectedDetails, result);
    }

    @Test
    void testGetExternalMessageDetails() {
        String claimHccId = "123";
        String claimLineHccId = "456";
        String claimFactKey = "abc";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";

        List<MedicalExternalMessage> expectedMessages = List.of(new MedicalExternalMessage());
        when(medicalExternalMessageDetailsData.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product))
                .thenReturn(expectedMessages);

        List<MedicalExternalMessage> result = claimServices.getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
        assertEquals(expectedMessages, result);
    }

    @Test
    void testGetClaimDetailsInfo() throws SQLException {
        ClaimDetailsRequest request = new ClaimDetailsRequest();
        ClaimDetailsResponse expectedResponse = new ClaimDetailsResponse();

        when(claimDetailsData.getClaimDetailsInfo(request)).thenReturn(expectedResponse);

        ClaimDetailsResponse result = claimServices.getClaimDetailsInfo(request);
        assertEquals(expectedResponse, result);
    }

    @Test
    public void testGetDenialCodesSuccess() {
        String claimHccId = "123ABC";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        DenialCodes mockResponse = new DenialCodes();
        mockResponse.setClaimId(claimHccId);

        when(denialCodeSearchData.getDenialCodes(claimHccId, state, lob, product)).thenReturn(mockResponse);

        DenialCodes result = claimServices.getDenialCodes(claimHccId, state, lob, product);

        assertEquals(mockResponse, result);
    }
}
