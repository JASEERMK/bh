package com.usthealthproof.eplus.ods.claim.util;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.mapper.portal.ClaimHeaderSearchMapper;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.util.LinkedCaseInsensitiveMap;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PortalClaimSearchUtilTest {

    @Mock
    private JdbcTemplate integrationJdbcTemplate;

    @Mock
    private ClaimHeaderSearchMapper claimHeaderSearchMapper;

    @InjectMocks
    private PortalClaimSearchUtil portalClaimSearchUtil;

    private ClaimSearchRequest claimSearchRequest;
    private List<ClaimSearchModel> claimSearchModelList;
    private SimpleJdbcCall simpleJdbcCall;
    private DataSource dataSource;
    private Connection connection;

    @BeforeEach
    void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);

        claimSearchRequest = new ClaimSearchRequest();
        claimSearchRequest.setMemberNumber("123");
        claimSearchRequest.setClaimNumber("456");
        claimSearchRequest.setServiceFromDate(String.valueOf(new Date()));
        claimSearchRequest.setServiceToDate(String.valueOf(new Date()));
        claimSearchRequest.setExcludedProvider(Arrays.asList("provider1", "provider2"));
        claimSearchRequest.setIncludedProvider(Arrays.asList("provider3", "provider4"));
        claimSearchRequest.setIncludedMedicalGroups(Arrays.asList("group1", "group2"));
        claimSearchRequest.setExcludedMedicalGroups(Arrays.asList("group3", "group4"));

        claimSearchModelList = new ArrayList<>();
        ClaimSearchModel model = new ClaimSearchModel();
        claimSearchModelList.add(model);

        simpleJdbcCall = mock(SimpleJdbcCall.class);
        dataSource = mock(DataSource.class);
        connection = mock(Connection.class);

        when(integrationJdbcTemplate.getDataSource()).thenReturn(dataSource);
        when(dataSource.getConnection()).thenReturn(connection);
    }

    @Test
    void testGetClaimSearchResult() throws SQLException {
        Map<String, Object> result = new HashMap<>();
        result.put(ClaimConstants.RETURN_STATUS, 0);
        result.put(ClaimConstants.RESULT_SET, claimSearchModelList);

        // Mock the behavior of SimpleJdbcCall methods
        when(simpleJdbcCall.withProcedureName(anyString())).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.declareParameters(any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlOutParameter.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.returningResultSet(anyString(), any(ClaimHeaderSearchMapper.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.execute(anyString(), anyString(), any(Date.class), any(Date.class), anyInt())).thenReturn(result);
    }

    @Test
    void testGetClaimSearchResult_WithError() {
        Map<String, Object> result = new HashMap<>();
        result.put(ClaimConstants.RETURN_STATUS, 1.0);
        List<LinkedCaseInsensitiveMap<String>> errorList = new ArrayList<>();
        LinkedCaseInsensitiveMap<String> error = new LinkedCaseInsensitiveMap<>();
        error.put("ErrorMessage", "Some error occurred");
        errorList.add(error);
        result.put(ClaimConstants.RESULT_SET2, errorList);

        // Mock the behavior of SimpleJdbcCall methods
        when(simpleJdbcCall.withProcedureName(anyString())).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.declareParameters(any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlOutParameter.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.returningResultSet(anyString(), any(ClaimHeaderSearchMapper.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.execute(anyString(), anyString(), any(Date.class), any(Date.class), anyInt())).thenReturn(result);

    }

    @Test
    void testSetClaimSearchResponse() {
        ClaimSearchResponse response = portalClaimSearchUtil.setClaimSearchResponse(claimSearchModelList);

        assertEquals(claimSearchModelList, response.getResults());
        assertEquals(claimSearchModelList.size(), response.getCount());
        assertEquals(ClaimConstants.SUCCESS, response.getStatus());
    }

    @Test
    void testGetProviderClaimSearchResult() throws SQLException {
        Map<String, Object> result = new HashMap<>();
        result.put(ClaimConstants.RETURN_STATUS, 0);
        result.put(ClaimConstants.RESULT_SET, claimSearchModelList);

        // Mock the behavior of SimpleJdbcCall methods
        when(simpleJdbcCall.withProcedureName(anyString())).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.declareParameters(any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlParameter.class), any(SqlOutParameter.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.returningResultSet(anyString(), any(ClaimHeaderSearchMapper.class))).thenReturn(simpleJdbcCall);
        when(simpleJdbcCall.execute(anyString(), anyString(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(), anyString(), anyInt())).thenReturn(result);
  }
}
