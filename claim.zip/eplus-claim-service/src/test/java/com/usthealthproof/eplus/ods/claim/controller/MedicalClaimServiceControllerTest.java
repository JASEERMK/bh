package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLineDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLinesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Collections;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MedicalClaimServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
    private MedicalClaimServiceController medicalClaimServiceController;

    @Mock
    private ClaimServices claimServices;

    @Mock
    private Validator validator;

    private String claimHccId;
    private String claimFactKey;
    private String state;
    private String lob;
    private String product;
    private String claimLineHccId;
    private MedicalClaimDetails medicalClaimDetails;
    private MedicalClaimLinesResponse medicalClaimLinesResponse;
    private MedicalClaimLineDetailsResponse medicalClaimLineDetailsResponse;

    @BeforeEach
    void setUp() {
        claimHccId = "validClaimHccId";
        claimFactKey = "validClaimFactKey";
        state = "validState";
        lob = "validLob";
        product = "validProduct";
        claimLineHccId = "validClaimLineHccId";

        medicalClaimDetails = new MedicalClaimDetails();
        medicalClaimLinesResponse = new MedicalClaimLinesResponse();
        medicalClaimLinesResponse.setMedicalClaimLines(Collections.singletonList(new MedicalClaimLines()));
        medicalClaimLineDetailsResponse = new MedicalClaimLineDetailsResponse();
        medicalClaimLineDetailsResponse.setMedicalClaimLineDetailsList(Collections.singletonList(new MedicalClaimLineDetails()));
        medicalClaimLineDetailsResponse.setClaimHccId(claimHccId);
    }

    @Test
    void testGetClaimDetails() throws Exception {
        when(claimServices.findClaimId(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(medicalClaimDetails);

        ResponseEntity<MedicalClaimDetails> response = medicalClaimServiceController.getClaimDetails(claimHccId, claimFactKey, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(medicalClaimDetails, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).findClaimId(claimHccId, claimFactKey, state, lob, product);
    }

    @Test
    void testGetClaimLines() throws Exception {
        when(claimServices.getClaimLines(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(medicalClaimLinesResponse.getMedicalClaimLines());

        ResponseEntity<MedicalClaimLinesResponse> response = medicalClaimServiceController.getClaimLines(claimHccId, claimFactKey, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(medicalClaimLinesResponse, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId);
        verify(claimServices, times(1)).getClaimLines(claimHccId, claimFactKey, state, lob, product);
    }

    @Test
    void testGetClaimLineDetails() throws Exception {
        when(claimServices.getClaimLineDetails(anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(new MedicalClaimLineDetails());

        ResponseEntity<MedicalClaimLineDetailsResponse> response = medicalClaimServiceController.getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(medicalClaimLineDetailsResponse, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId, claimLineHccId);
        verify(claimServices, times(1)).getClaimLineDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
    }

    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\"
    })

    void testGetMedicalClaimDetails_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/medical")
                        .param("claimHccId", pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\",
    })

    void testGetMedicalClaimLine_invalidClaimFactKeyPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/medical/claimlines")
                        .param("claimHccId", "1234")
                        .param("claimFactKey",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimFactKey is not in valid format"));
    }


    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "1234566>",
            "1234566=",
            "1234566&",
            "1234566%",
            "1234566#",
            "1234566&",
            "1234566(",
            "1234566)",
            "1234566@",
            "1234566\\,",
            "1234566/",
            "1234566*",
            "1234566|",
            "1234566;",
            "1234566!",
            "1234566--",
            "1234566\\\\",
    })

    void testGetMedicalClaimLineDetails_invalidClaimFactKeyPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/medical/claimline")
                        .param("claimHccId", "1234")
                        .param("claimLineHccId",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimLineHccId is not in valid format"));
    }
}
