package com.usthealthproof.eplus.ods.claim.repository.utilis;

import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AsyncExecutorUtilsTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimDetailsMapper medicalClaimDetailsMapper;

    @InjectMocks
    private AsyncExecutorUtils asyncExecutorUtils;

    private MedicalClaimDetails mockMedicalClaimDetails;

    @BeforeEach
    void setUp() {
        mockMedicalClaimDetails = new MedicalClaimDetails();
        mockMedicalClaimDetails.setClaimHccId("12345");
    }

    @Test
    void testGetMedicalClaimDetailsWithoutFactKey_Success() {
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimDetailsMapper)))
                .thenReturn(mockMedicalClaimDetails);

        CompletableFuture<MedicalClaimDetails> future = asyncExecutorUtils.getMedicalClaimDetailsWithoutFactKey("HCC123", "NY", "MED", "ProductX");

        assertNotNull(future);
        assertEquals("12345", future.join().getClaimHccId()); // Ensure correct data is returned
    }

    @Test
    void testGetMedicalClaimDetailsWithFactKey_Success() {
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(medicalClaimDetailsMapper)))
                .thenReturn(mockMedicalClaimDetails);

        CompletableFuture<MedicalClaimDetails> future = asyncExecutorUtils.getMedicalClaimDetailsWithFactKey("HCC123", "FACT456", "NY", "MED", "ProductX");

        assertNotNull(future);
        assertEquals("12345", future.join().getClaimHccId()); // Ensure correct data is returned
    }
}
