package com.usthealthproof.eplus.ods.claim.mapper.portal;

import com.usthealthproof.eplus.ods.claim.model.portal.*;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.*;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ClaimDetailsMapperTest {

    private static final String CLAIM_STATUS = "claim_status";
    private static final String CLAIM_LINE_STATUS = "claim_line_status";
    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet rs;

    @InjectMocks
    private ClaimDetailsMapper claimDetailsMapper;

    private Map<String, String> claimDetailsStatusMap;
    private Map<String, String> claimLineStatusMap;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        claimDetailsStatusMap = new HashMap<>();
        claimDetailsStatusMap.put("Paid", "Paid");
        claimDetailsStatusMap.put("Others", "Others");
        claimLineStatusMap = new HashMap<>();
        claimLineStatusMap.put("Approved", "Approved");
        claimLineStatusMap.put("Rejected", "Rejected");

        // Use reflection to set the private fields
        setPrivateField(claimDetailsMapper, "claimDetailsStatusMap", claimDetailsStatusMap);
        setPrivateField(claimDetailsMapper, "claimLineStatusMap", claimLineStatusMap);
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void testMapRow() throws SQLException {
        when(rs.getString("claim_number")).thenReturn("12345");
        when(rs.getString("claim_status")).thenReturn("Paid");
        when(rs.getString("claim_category")).thenReturn("Medical");
        when(rs.getString("service_date")).thenReturn("2023-01-01");
        when(dateUtils.getFormattedClientDate("2023-01-01")).thenReturn("01-Jan-2023");
        when(rs.getString("total_submitted_amount")).thenReturn("1000");
        when(rs.getString("total_patient_responsibility_amount")).thenReturn("200");
        when(rs.getString("total_paid_amount")).thenReturn("800");
        when(rs.getString("total_copay_amount")).thenReturn("50");
        when(rs.getString("total_coinsurance_amount")).thenReturn("150");
        when(rs.getString("total_deductible_amount")).thenReturn("100");
        when(rs.getString("total_billed_amount")).thenReturn("1200");
        when(rs.getString("payment_status")).thenReturn("Paid");
        when(rs.getString("payment_date")).thenReturn("2023-01-15");
        when(dateUtils.getFormattedClientDate("2023-01-15")).thenReturn("15-Jan-2023");
        when(rs.getString("modifiers_Value")).thenReturn("Modifier");
        when(rs.getString("line_number")).thenReturn("1");
        when(rs.getString("diagnosis_code")).thenReturn("D123");
        when(rs.getString("diagnosis_description")).thenReturn("Diagnosis Description");

        ClaimDetails claimDetails = claimDetailsMapper.mapRow(rs, 0);

        assertEquals("12345", claimDetails.getClaimNumber());
        assertEquals("Paid", claimDetails.getClaimStatus());
        assertEquals("Medical", claimDetails.getClaimType());
        assertEquals("01-Jan-2023", claimDetails.getServiceDate());
        assertEquals("1000", claimDetails.getTotalSubmittedAmount());
        assertEquals("200", claimDetails.getTotalPatientResponsibilityAmount());
        assertEquals("800", claimDetails.getTotalPaidAmount());
        assertEquals("50", claimDetails.getTotalCopayAmount());
        assertEquals("150", claimDetails.getTotalCoinsuranceAmount());
        assertEquals("100", claimDetails.getTotalDeductibleAmount());
        assertEquals("1200", claimDetails.getTotalBilledAmount());
        assertEquals("Paid", claimDetails.getPaymentStatus());
        assertEquals("15-Jan-2023", claimDetails.getPaymentDate());
        assertEquals("Modifier", claimDetails.getModifiedBy());

        assertNotNull(claimDetails.getDiagnosesList());
        assertEquals(1, claimDetails.getDiagnosesList().size());
        Diagnoses diagnosis = claimDetails.getDiagnosesList().get(0);
        assertEquals("D123", diagnosis.getDiagnosisCode());
        assertEquals("Diagnosis Description", diagnosis.getDiagnosisDescription());
    }
    @Test
    void testGetClaimLineDetailsListWithValidStatus() throws Exception {
        // Mock the ResultSet
        ResultSet rs = Mockito.mock(ResultSet.class);
        // Mock the claimLineStatusMap
        Map<String, String> claimLineStatusMap = Mockito.mock(Map.class);

        // Arrange
        Mockito.when(rs.getString("service_from_date")).thenReturn("2023-01-01");
        Mockito.when(rs.getString("service_to_date")).thenReturn("2023-01-02");
        Mockito.when(rs.getString("billed_amount")).thenReturn("100");
        Mockito.when(rs.getString("service_units")).thenReturn("1");
        Mockito.when(rs.getString("deductible_amount")).thenReturn("10");
        Mockito.when(rs.getString("amount_not_covered")).thenReturn("5");
        Mockito.when(rs.getString("paid_amount")).thenReturn("85");
        Mockito.when(rs.getString("coinsurance_amount")).thenReturn("15");
        Mockito.when(rs.getString("copay_amount")).thenReturn("10");
        Mockito.when(rs.getString("patient_responsibility_amount")).thenReturn("20");
        Mockito.when(rs.getString(CLAIM_LINE_STATUS)).thenReturn("Approved");

        // Arrange claimLineStatusMap
        Mockito.when(claimLineStatusMap.get("Unknown")).thenReturn(null);

        // Access private method via reflection
        Method method = ClaimDetailsMapper.class.getDeclaredMethod("getClaimLineDetailsList", ResultSet.class, String.class);
        method.setAccessible(true);

        // Act

        @SuppressWarnings("unchecked")
        List<ClaimLineDetails> detailsList = (List<ClaimLineDetails>) method.invoke(claimDetailsMapper, rs, "1");

        // Assert
        assertNotNull(detailsList);
        assertFalse(detailsList.isEmpty());
        ClaimLineDetails details = detailsList.get(0);
        assertEquals("Approved", details.getStatus());

    }
    @Test
    void testGetClaimLineDetailsListWithInvalidStatus() throws Exception {
        // Mock the ResultSet
        ResultSet rs = Mockito.mock(ResultSet.class);
        // Mock the claimLineStatusMap
        Map<String, String> claimLineStatusMap = Mockito.mock(Map.class);

        // Arrange
        Mockito.when(rs.getString("service_from_date")).thenReturn("2023-01-01");
        Mockito.when(rs.getString("service_to_date")).thenReturn("2023-01-02");
        Mockito.when(rs.getString("billed_amount")).thenReturn("100");
        Mockito.when(rs.getString("service_units")).thenReturn("1");
        Mockito.when(rs.getString("deductible_amount")).thenReturn("10");
        Mockito.when(rs.getString("amount_not_covered")).thenReturn("5");
        Mockito.when(rs.getString("paid_amount")).thenReturn("85");
        Mockito.when(rs.getString("coinsurance_amount")).thenReturn("15");
        Mockito.when(rs.getString("copay_amount")).thenReturn("10");
        Mockito.when(rs.getString("patient_responsibility_amount")).thenReturn("20");
        Mockito.when(rs.getString(CLAIM_LINE_STATUS)).thenReturn("Unknown");

        // Arrange claimLineStatusMap
        Mockito.when(claimLineStatusMap.get("Unknown")).thenReturn(null);

        // Access private method via reflection
        Method method = ClaimDetailsMapper.class.getDeclaredMethod("getClaimLineDetailsList", ResultSet.class, String.class);
        method.setAccessible(true);

        // Act

        @SuppressWarnings("unchecked")
        List<ClaimLineDetails> detailsList = (List<ClaimLineDetails>) method.invoke(claimDetailsMapper, rs, "1");

        // Assert
        assertNotNull(detailsList);
        assertFalse(detailsList.isEmpty());
        ClaimLineDetails details = detailsList.get(0);
        assertEquals("Unknown", details.getStatus());
    }

    @Test
    void testMapRowWithUnknownStatus() throws SQLException {
        when(rs.getString("claim_status")).thenReturn("UnknownStatus");
        when(rs.getString(CLAIM_STATUS)).thenReturn("UnknownStatus");

        ClaimDetails claimDetails = claimDetailsMapper.mapRow(rs, 0);

        assertEquals("Others", claimDetails.getClaimStatus());
    }
    @Test
    void testMapRowWithClaimLineDetailsMissingData() throws SQLException {
        when(rs.getString("line_number")).thenReturn("1");
        when(rs.getString("service_from_date")).thenReturn(null);
        when(rs.getString("billed_amount")).thenReturn("500");
        ClaimDetails claimDetails = claimDetailsMapper.mapRow(rs, 0);

        assertNotNull(claimDetails.getClaimLineDetailsList());
        assertEquals(1, claimDetails.getClaimLineDetailsList().size());
        ClaimLineDetails claimLineDetails = claimDetails.getClaimLineDetailsList().get(0);
        assertNull(claimLineDetails.getServiceStartDate());
        assertEquals("500", claimLineDetails.getBilledAmount());
    }
    @Test
    void testGetClaimLineProcedureList() throws Exception {
        // Arrange
        when(rs.getString("claimlineProcedures_procedure_code")).thenReturn("PROC123");
        when(rs.getString("claimlineProcedures_procedure_description")).thenReturn("Procedure Description");

        // Use reflection to access private method
        Method method = ClaimDetailsMapper.class.getDeclaredMethod("getClaimLineProcedureList", ResultSet.class);
        method.setAccessible(true);

        // Act
        @SuppressWarnings("unchecked")
        List<ClaimLineProcedure> procedures = (List<ClaimLineProcedure>) method.invoke(claimDetailsMapper, rs);

        // Assert
        assertNotNull(procedures);
        assertFalse(procedures.isEmpty());
        ClaimLineProcedure procedure = procedures.get(0);
        assertEquals("PROC123", procedure.getProcedureCode());
        assertEquals("Procedure Description", procedure.getProcedureDescription());
    }
}
