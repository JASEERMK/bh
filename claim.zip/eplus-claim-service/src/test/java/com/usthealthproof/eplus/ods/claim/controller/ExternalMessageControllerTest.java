package com.usthealthproof.eplus.ods.claim.controller;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessagesResponse;
import com.usthealthproof.eplus.ods.claim.service.ClaimServices;
import com.usthealthproof.eplus.ods.claim.validator.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ExternalMessageControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @InjectMocks
    private ExternalMessageController externalMessageController;

    @Mock
    private ClaimServices claimServices;

    @Mock
    private Validator validator;

    private String claimHccId;
    private String claimLineHccId;
    private String claimFactKey;
    private String state;
    private String lob;
    private String product;
    private List<MedicalExternalMessage> medicalExternalMessages;
    private MedicalExternalMessagesResponse medicalExternalMessagesResponse;

    @BeforeEach
    void setUp() {
        claimHccId = "validClaimHccId";
        claimLineHccId = "validClaimLineHccId";
        claimFactKey = "validClaimFactKey";
        state = "TX";
        lob = "Medical";
        product = "Health";
        medicalExternalMessages = List.of(new MedicalExternalMessage());
        medicalExternalMessagesResponse = new MedicalExternalMessagesResponse();
        medicalExternalMessagesResponse.setExternalMessages(medicalExternalMessages);
    }

    @Test
    void testGetExternalmessageDetails() {
        when(claimServices.getExternalMessageDetails(anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(medicalExternalMessages);

        ResponseEntity<MedicalExternalMessagesResponse> response = externalMessageController.getExternalmessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(medicalExternalMessagesResponse, response.getBody());

        verify(validator, times(1)).validateRequestField(claimHccId, claimLineHccId);
        verify(claimServices, times(1)).getExternalMessageDetails(claimHccId, claimLineHccId, claimFactKey, state, lob, product);
    }

    @ParameterizedTest
    @CsvSource({
            "1234566<",
            "K1234566>",
            "K1234566=",
            "K1234566&",
            "K1234566%",
            "K1234566#",
            "K1234566&",
            "K1234566(",
            "K1234566)",
            "K1234566@",
            "K1234566\\,",
            "K1234566/",
            "K1234566*",
            "K1234566|",
            "K1234566;",
            "K1234566!",
            "K1234566--",
            "K1234566\\\\",
    })

    void testGetExternalMessageDetails_invalidClaimHccIdPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/external/messages")
                        .param("claimHccId", pattern)
                        .param("claimLineHccId", "12345"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: claimHccId is not in valid format"));
    }

    @ParameterizedTest
    @CsvSource({
            "Medicaid<",
            "Medicaid>",
            "Medicaid=",
            "Medicaid&",
            "Medicaid%",
            "Medicaid#",
            "Medicaid&",
            "Medicaid(",
            "Medicaid)",
            "Medicaid@",
            "Medicaid\\,",
            "Medicaid/",
            "Medicaid*",
            "Medicaid|",
            "Medicaid;",
            "Medicaid!",
            "Medicaid--",
            "Medicaid\\\\",
    })

    void testGetExternalMessageDetails_invalidProductPattern(String pattern) throws Exception {
        mockMvc.perform(get("/v1/claims/external/messages")
                        .param("claimHccId", "12345")
                        .param("claimLineHccId", "12345")
                        .param("product",pattern))
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.status")
                        .value("FAILURE"))  // Assert the status is "FAILURE"
                .andExpect(MockMvcResultMatchers.jsonPath("$.problemDetails.errors[0]")
                        .value("Invalid Request: product is not in valid format"));
    }

}
