package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchModel;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.search.ClaimSearchResponse;
import com.usthealthproof.eplus.ods.claim.util.PortalClaimSearchUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@Slf4j
public class ClaimSearchDataTest {

    @InjectMocks
    private ClaimSearchData claimSearchData;

    @Mock
    private PortalClaimSearchUtil portalClaimSearchUtil;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimHeaderSearchInfo_Success_Medical() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.MEDICAL_CLAIM_TYPE);

        List<ClaimSearchModel> claimSearchModelList = Collections.singletonList(new ClaimSearchModel());
        when(portalClaimSearchUtil.getClaimSearchResult(any(ClaimSearchRequest.class), anyString()))
                .thenReturn(claimSearchModelList);

    }

    @Test
    public void testGetClaimHeaderSearchInfo_NoDataFound() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.MEDICAL_CLAIM_TYPE);

        when(portalClaimSearchUtil.getClaimSearchResult(any(ClaimSearchRequest.class), anyString()))
                .thenReturn(Collections.emptyList());

    }

    @Test
    public void testGetClaimHeaderSearchInfo_CannotGetJdbcConnectionException() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.MEDICAL_CLAIM_TYPE);

        when(portalClaimSearchUtil.getClaimSearchResult(any(ClaimSearchRequest.class), anyString()))
                .thenThrow(new CannotGetJdbcConnectionException("Database connection error"));

        // Act & Assert
        CannotGetJdbcConnectionException exception = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            claimSearchData.getClaimHeaderSearchInfo(request, "spMedical", "spDental", "spVision");
        });
        assertEquals("Database connection error", exception.getMessage());
    }

    @Test
    public void testGetClaimHeaderSearchInfo_GeneralException() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.MEDICAL_CLAIM_TYPE);

        when(portalClaimSearchUtil.getClaimSearchResult(any(ClaimSearchRequest.class), anyString()))
                .thenThrow(new RuntimeException("General error"));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            claimSearchData.getClaimHeaderSearchInfo(request, "spMedical", "spDental", "spVision");
        });
        assertEquals("General error", exception.getMessage());
    }

    @Test
    public void testGetClaimHeaderSearchInfo_VisionClaimType() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.VISION_CLAIM_TYPE);

        List<ClaimSearchModel> claimSearchModelList = Collections.singletonList(new ClaimSearchModel());
        when(portalClaimSearchUtil.getClaimSearchResult(any(ClaimSearchRequest.class), anyString()))
                .thenReturn(claimSearchModelList);

    }

    @Test
    public void testGetClaimHeaderSearchInfo_AllClaimTypes() throws InterruptedException, ExecutionException, SQLException {
        // Arrange
        ClaimSearchRequest request = new ClaimSearchRequest();
        request.setClaimTypes(ClaimConstants.CLAIM_TYPE_ALL);

        List<ClaimSearchModel> medicalClaimSearchModelList = Collections.singletonList(new ClaimSearchModel());
        List<ClaimSearchModel> dentalClaimSearchModelList = Collections.singletonList(new ClaimSearchModel());
        List<ClaimSearchModel> visionClaimSearchModelList = Collections.singletonList(new ClaimSearchModel());

        when(portalClaimSearchUtil.getAllClaimSearchResult(any(ClaimSearchRequest.class), eq("spMedical")))
                .thenReturn(CompletableFuture.completedFuture(medicalClaimSearchModelList));
        when(portalClaimSearchUtil.getAllClaimSearchResult(any(ClaimSearchRequest.class), eq("spDental")))
                .thenReturn(CompletableFuture.completedFuture(dentalClaimSearchModelList));
        when(portalClaimSearchUtil.getAllClaimSearchResult(any(ClaimSearchRequest.class), eq("spVision")))
                .thenReturn(CompletableFuture.completedFuture(visionClaimSearchModelList));

    }
}
