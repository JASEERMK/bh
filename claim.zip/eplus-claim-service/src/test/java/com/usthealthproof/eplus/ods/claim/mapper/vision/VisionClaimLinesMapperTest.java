package com.usthealthproof.eplus.ods.claim.mapper.vision;

import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class VisionClaimLinesMapperTest {

    @Mock
    private ResultSet resultSet;

    @InjectMocks
    private VisionClaimLinesMapper visionClaimLinesMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        when(resultSet.getString("claimhccid")).thenReturn("HCC12345");
        when(resultSet.getString("claimlinenumber")).thenReturn("LN67890");
        when(resultSet.getString("status")).thenReturn("Processed");
        when(resultSet.getString("service_date")).thenReturn("2022-01-01");

        VisionClaimLines visionClaimLines = visionClaimLinesMapper.mapRow(resultSet, 1);

        assertEquals("HCC12345", visionClaimLines.getClaimHccId());
        assertEquals("LN67890", visionClaimLines.getClaimLineNumber());
        assertEquals("Processed", visionClaimLines.getStatus());
        assertEquals("2022-01-01", visionClaimLines.getServiceStartDate());
    }
}
