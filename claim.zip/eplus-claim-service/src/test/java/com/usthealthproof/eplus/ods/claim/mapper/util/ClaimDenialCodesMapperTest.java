package com.usthealthproof.eplus.ods.claim.mapper.util;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.usthealthproof.eplus.ods.claim.mapper.medical.ClaimDenialCodesMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.usthealthproof.eplus.ods.claim.model.search.DenialCode;

public class ClaimDenialCodesMapperTest {

    private ClaimDenialCodesMapper claimDenialCodesMapper;
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        claimDenialCodesMapper = new ClaimDenialCodesMapper();
        resultSet = mock(ResultSet.class);
    }

    @Test
    public void testMapRow() throws SQLException {
        when(resultSet.getString("adjudication_message_code")).thenReturn("DEN001");
        when(resultSet.getString("adjudication_message_desc")).thenReturn("Test Denial Code Description");

        DenialCode result = claimDenialCodesMapper.mapRow(resultSet, 1);

        assertNotNull(result);
        assertEquals("DEN001", result.getCode());
        assertEquals("Test Denial Code Description", result.getDescription());
    }

    @Test
    public void testMapRowWithNullValues() throws SQLException {
        when(resultSet.getString("adjudication_message_code")).thenReturn(null);
        when(resultSet.getString("adjudication_message_desc")).thenReturn(null);

        DenialCode result = claimDenialCodesMapper.mapRow(resultSet, 1);

        assertNotNull(result);
        assertNull(result.getCode());
        assertNull(result.getDescription());
    }

    @Test
    public void testMapRowSQLException() throws SQLException {
        when(resultSet.getString(anyString())).thenThrow(new SQLException("Test SQL Exception"));

        assertThrows(SQLException.class, () -> claimDenialCodesMapper.mapRow(resultSet, 1));
    }
}
