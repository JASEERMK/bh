package com.usthealthproof.eplus.ods.claim.repository.portal;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.portal.ClaimDetailsMapper;
import com.usthealthproof.eplus.ods.claim.model.portal.Diagnoses;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetails;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsRequest;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimDetailsResponse;
import com.usthealthproof.eplus.ods.claim.model.portal.detail.ClaimLineDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClaimDetailsDataTest {

    @Mock
    private JdbcTemplate integrationJdbcTemplate;

    @Mock
    private ClaimDetailsMapper claimDetailsMapper;

    @InjectMocks
    private ClaimDetailsData claimDetailsData;

    private ClaimDetailsRequest claimDetailsRequest;
    private List<ClaimDetails> claimDetailsList;

    @BeforeEach
    public void setUp() throws Exception {
        claimDetailsRequest = new ClaimDetailsRequest();
        claimDetailsRequest.setMemberNumber("123");
        claimDetailsRequest.setClaimNumber("456");

        claimDetailsList = new ArrayList<>();
        claimDetailsList.add(new ClaimDetails());

        setPrivateField(claimDetailsData, "spPortalMedicalClaimDetails", "spPortalMedicalClaimDetails");
        setPrivateField(claimDetailsData, "spPortalDentalClaimDetails", "spPortalDentalClaimDetails");
        setPrivateField(claimDetailsData, "spPortalVisionClaimDetails", "spPortalVisionClaimDetails");
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    public void testGetResults() throws Exception {
        Method method = ClaimDetailsData.class.getDeclaredMethod("getResults", List.class);
        method.setAccessible(true);

        ClaimDetails claimDetails = new ClaimDetails();
        List<ClaimLineDetails> claimLineDetailsList = new ArrayList<>();
        List<Diagnoses> diagnosesList = new ArrayList<>();

        claimDetails.setClaimLineDetailsList(claimLineDetailsList);
        claimDetails.setDiagnosesList(diagnosesList);

        claimDetailsList.add(claimDetails);
        ClaimDetails result = (ClaimDetails) method.invoke(claimDetailsData, claimDetailsList);

        assert result != null;
        assert result.getClaimLineDetailsList() != null;
    }

    @Test
    public void testGetDiagnosisList() throws Exception {
        Method method = ClaimDetailsData.class.getDeclaredMethod("getDiagnosisList", List.class);
        method.setAccessible(true);

        ClaimDetails claimDetails = new ClaimDetails();
        List<Diagnoses> diagnosesList = new ArrayList<>();
        diagnosesList.add(new Diagnoses());
        claimDetails.setDiagnosesList(diagnosesList);
        claimDetailsList.add(claimDetails);

    }

    @Test
    public void testGetClaimLinesList() throws Exception {
        Method method = ClaimDetailsData.class.getDeclaredMethod("getClaimLinesList", List.class);
        method.setAccessible(true);

        ClaimDetails claimDetails = new ClaimDetails();
        List<ClaimLineDetails> claimLineDetailsList = new ArrayList<>();
        claimLineDetailsList.add(new ClaimLineDetails());
        claimDetails.setClaimLineDetailsList(claimLineDetailsList);
        claimDetailsList.add(claimDetails);

    }

    private Map<String, Object> getMockResultMap(int returnStatus) {
        Map<String, Object> out = new HashMap<>();
        out.put(ClaimConstants.RETURN_STATUS, returnStatus);
        out.put(ClaimConstants.RESULT, claimDetailsList);
        return out;
    }
}
