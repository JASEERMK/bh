package com.usthealthproof.eplus.ods.claim.model.dental;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class DentalClaimLinesTest {

    @Test
    public void testCompareTo() {
        DentalClaimLines claimLine1 = new DentalClaimLines();
        claimLine1.setClaimLineNumber("123");

        DentalClaimLines claimLine2 = new DentalClaimLines();
        claimLine2.setClaimLineNumber("456");

        DentalClaimLines claimLine3 = new DentalClaimLines();
        claimLine3.setClaimLineNumber("123");

        // Test case where claimLine1 is less than claimLine2
        assertTrue(claimLine1.compareTo(claimLine2) < 0, "Expected claimLine1 to be less than claimLine2");

        // Test case where claimLine1 is equal to claimLine3
        assertEquals(0, claimLine1.compareTo(claimLine3), "Expected claimLine1 to be equal to claimLine3");

        // Test case where claimLine2 is greater than claimLine1
        assertTrue(claimLine2.compareTo(claimLine1) > 0, "Expected claimLine2 to be greater than claimLine1");
    }
}
