package com.usthealthproof.eplus.ods.claim.repository.search;

import com.usthealthproof.eplus.ods.claim.mapper.search.ClaimAvailabilityCheckMapper;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchRequest;
import com.usthealthproof.eplus.ods.claim.model.search.ClaimHeaderSearchResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

public class ClaimAvailabilityCheckDataTest {

    @InjectMocks
    private ClaimAvailabilityCheckData claimAvailabilityCheckData;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private ClaimAvailabilityCheckMapper claimAvailabilityCheckMapper;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testProviderClaimDataAvailabilityCheck_Success() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        ClaimHeaderSearchResponse expectedResponse = new ClaimHeaderSearchResponse();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(claimAvailabilityCheckMapper)))
                .thenReturn(expectedResponse);

        // Act
        ClaimHeaderSearchResponse actualResponse = claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(request);

        // Assert
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void testProviderClaimDataAvailabilityCheck_JdbcConnectionException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(claimAvailabilityCheckMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database not available"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(request);
        });

        assertEquals("Database not available", thrown.getMessage());

    }

    @Test
    public void testProviderClaimDataAvailabilityCheck_EmptyResultDataAccessException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(claimAvailabilityCheckMapper)))
                .thenThrow(new EmptyResultDataAccessException(0));

        // Act
        ClaimHeaderSearchResponse response = claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(request);

        // Assert
        assertEquals("False", response.getDataAvailabilityFlag());

    }

    @Test
    public void testProviderClaimDataAvailabilityCheck_GenericException() {
        // Arrange
        ClaimHeaderSearchRequest request = new ClaimHeaderSearchRequest();
        when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), eq(claimAvailabilityCheckMapper)))
                .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            claimAvailabilityCheckData.providerClaimDataAvailabilityCheck(request);
        });

        assertEquals("Unexpected error", thrown.getMessage());

    }
}
