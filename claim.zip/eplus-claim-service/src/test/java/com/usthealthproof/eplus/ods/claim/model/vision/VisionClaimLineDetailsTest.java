package com.usthealthproof.eplus.ods.claim.model.vision;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VisionClaimLineDetailsTest {

    @Test
    public void testCompareTo() {
        VisionClaimLineDetails claimLine1 = new VisionClaimLineDetails();
        claimLine1.setClaimLineNumber("123");

        VisionClaimLineDetails claimLine2 = new VisionClaimLineDetails();
        claimLine2.setClaimLineNumber("456");

        VisionClaimLineDetails claimLine3 = new VisionClaimLineDetails();
        claimLine3.setClaimLineNumber("123");

        // Test case where claimLine1's claimLineNumber is less than claimLine2's claimLineNumber
        assertTrue(claimLine1.compareTo(claimLine2) < 0, "Expected claimLine1 to be less than claimLine2");

        // Test case where claimLine1's claimLineNumber is equal to claimLine3's claimLineNumber
        assertEquals(0, claimLine1.compareTo(claimLine3), "Expected claimLine1 to be equal to claimLine3");

        // Test case where claimLine2's claimLineNumber is greater than claimLine1's claimLineNumber
        assertTrue(claimLine2.compareTo(claimLine1) > 0, "Expected claimLine2 to be greater than claimLine1");
    }
}
