package com.usthealthproof.eplus.ods.claim.repository.medical;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.medical.MedicalClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimRejectionDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.MedicalClaimLines;
import com.usthealthproof.eplus.ods.claim.repository.utilis.AsyncExecutorUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

public class MedicalClaimLinesDataTest {

    @InjectMocks
    private MedicalClaimLinesData medicalClaimLinesData;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private MedicalClaimLinesMapper medicalClaimLinesMapper;
    @Mock
    private AsyncExecutorUtils asyncExecutorUtils;
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClaimLines_WithClaimFactKey() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "6789";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        List<ClaimRejectionDetails> rejectionList = new ArrayList<>();
        MedicalClaimLines claimLines = new MedicalClaimLines();
        claimLines.setUserMessage("347 - Primary diagnosis code on this claim line is invalid");
        CompletableFuture<List<ClaimRejectionDetails>> rejectionFuture = CompletableFuture.completedFuture(rejectionList);
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, null, claimFactKey, state, lob, product)).thenReturn(rejectionFuture);

        // Mock claim lines future
        List<MedicalClaimLines> claimLinesList = new ArrayList<>();
        MedicalClaimLines lineDetails = new MedicalClaimLines();
        lineDetails.setClaimLineNumber(claimHccId);
        lineDetails.setClaimFactKey(claimFactKey);
        claimLinesList.add(lineDetails);
        CompletableFuture<List<MedicalClaimLines>> claimLinesFuture = CompletableFuture.completedFuture(claimLinesList);
        when(asyncExecutorUtils.getMedicalClaimLinesWithFactKey(claimHccId, claimFactKey, state, lob, product)).thenReturn(claimLinesFuture);

        // Act
        List<MedicalClaimLines> result = medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals("6789", result.get(0).getClaimFactKey());
    }

    @Test
    public void testGetClaimLines_WithoutClaimFactKey() throws Exception {
        // Arrange
        String claimHccId = "1";
        String claimFactKey = "6789";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        List<ClaimRejectionDetails> rejectionList = new ArrayList<>();
        ClaimRejectionDetails rejectionDetails = new ClaimRejectionDetails();
        rejectionDetails.setRejectionCodeDesc("347 - Primary diagnosis code on this claim line is invalid");
        rejectionDetails.setClaimLineNumber("1");
        rejectionList.add(rejectionDetails);
        CompletableFuture<List<ClaimRejectionDetails>> rejectionFuture = CompletableFuture.completedFuture(rejectionList);
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, null, null, state, lob, product)).thenReturn(rejectionFuture);

        // Mock claim lines future
        List<MedicalClaimLines> claimLinesList = new ArrayList<>();
        MedicalClaimLines lineDetails = new MedicalClaimLines();
        lineDetails.setClaimLineNumber(claimHccId);
        lineDetails.setClaimFactKey(claimFactKey);
        claimLinesList.add(lineDetails);
        CompletableFuture<List<MedicalClaimLines>> claimLinesFuture = CompletableFuture.completedFuture(claimLinesList);
        when(asyncExecutorUtils.getMedicalClaimLinesWithoutFactKey(claimHccId, state, lob, product)).thenReturn(claimLinesFuture);

        // Act
        List<MedicalClaimLines> result = medicalClaimLinesData.getClaimLines(claimHccId, null, state, lob, product);

        assertNotNull(result);
        assertFalse(result.isEmpty());
    }

    @Test
    public void testGetClaimLines_claimNotFound() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "6789";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        List<ClaimRejectionDetails> rejectionList = new ArrayList<>();
        ClaimRejectionDetails rejectionDetails = new ClaimRejectionDetails();
        rejectionDetails.setRejectionCodeDesc("347 - Primary diagnosis code on this claim line is invalid");
        rejectionList.add(rejectionDetails);
        CompletableFuture<List<ClaimRejectionDetails>> rejectionFuture = CompletableFuture.completedFuture(rejectionList);
        when(asyncExecutorUtils.getRejectionCodeDesc(claimHccId, null, null, state, lob, product)).thenReturn(rejectionFuture);

        CompletableFuture<List<MedicalClaimLines>> claimLinesFuture = CompletableFuture.completedFuture(Collections.EMPTY_LIST);
        when(asyncExecutorUtils.getMedicalClaimLinesWithoutFactKey(claimHccId, state, lob, product)).thenReturn(claimLinesFuture);

        // Act
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);
        });

        assertEquals(ClaimConstants.CLAIM_LINES_NOT_FOUND + claimHccId, thrown.getMessage());

    }

    @Test
    public void testGetClaimLines_EmptyResult() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        when(asyncExecutorUtils.getMedicalClaimLinesWithFactKey(claimHccId, claimFactKey, state, lob, product)).thenThrow(new ClaimNotFoundException(ClaimConstants.CLAIM_LINES_NOT_FOUND + claimHccId));

        // Act & Assert
        ClaimNotFoundException thrown = assertThrows(ClaimNotFoundException.class, () -> {
            medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);
        });

        assertEquals(ClaimConstants.CLAIM_LINES_NOT_FOUND + claimHccId, thrown.getMessage());
    }

    @Test
    public void testGetClaimLines_JdbcConnectionException() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        when(asyncExecutorUtils.getMedicalClaimLinesWithFactKey(claimHccId, claimFactKey, state, lob, product))
                .thenThrow(new CannotGetJdbcConnectionException("DB Connection Failed"));

        // Act & Assert
        CannotGetJdbcConnectionException thrown = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);
        });

        assertEquals("DB Connection Failed", thrown.getMessage());
    }

    @Test
    public void testGetClaimLines_GenericException() throws Exception {
        // Arrange
        String claimHccId = "12345";
        String claimFactKey = "factKey";
        String state = "TX";
        String lob = "LOB";
        String product = "PRODUCT";

        when(asyncExecutorUtils.getMedicalClaimLinesWithFactKey(claimHccId, claimFactKey, state, lob, product))
                .thenThrow(new RuntimeException("Unexpected Error"));

        // Act & Assert
        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            medicalClaimLinesData.getClaimLines(claimHccId, claimFactKey, state, lob, product);
        });

        assertEquals("Unexpected Error", thrown.getMessage());
    }
}
