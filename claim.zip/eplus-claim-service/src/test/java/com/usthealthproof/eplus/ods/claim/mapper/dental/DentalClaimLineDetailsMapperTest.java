package com.usthealthproof.eplus.ods.claim.mapper.dental;

import com.usthealthproof.eplus.ods.claim.model.dental.DentalClaimLineDetails;
import com.usthealthproof.eplus.ods.claim.util.DateUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class DentalClaimLineDetailsMapperTest {

    @InjectMocks
    private DentalClaimLineDetailsMapper dentalClaimLineDetailsMapper;

    @Mock
    private DateUtils dateUtils;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("claimhccid")).thenReturn("claimHccId123");
        when(resultSet.getString("Codedescription")).thenReturn("Code Description");
        when(resultSet.getString("serviceStartDate")).thenReturn("2023-01-01");
        when(resultSet.getString("surface")).thenReturn("Surface");
        when(resultSet.getString("tooth")).thenReturn("Tooth");
        when(resultSet.getString("allowedamount")).thenReturn("100.00");
        when(resultSet.getString("paidAmount")).thenReturn("80.00");
        when(resultSet.getString("deductible")).thenReturn("10.00");
        when(resultSet.getString("co_pay")).thenReturn("5.00");
        when(resultSet.getString("co_insurance")).thenReturn("15.00");
        when(resultSet.getString("overmax")).thenReturn("0.00");
        when(resultSet.getString("cob_amount")).thenReturn("0.00");
        when(resultSet.getString("payment_notes")).thenReturn("No issues");
        when(resultSet.getString("area_of_oral_cavity")).thenReturn("Area of Oral Cavity");
        when(resultSet.getString("authorization_id")).thenReturn("Auth123");
        when(resultSet.getString("service_exception")).thenReturn("Exception");
        when(resultSet.getString("billed_amount")).thenReturn("150.00");

        // Setup mock behavior for DateUtils
        when(dateUtils.getFormattedApplicationDate(anyString())).thenReturn("formattedDate");

        // Execute mapRow
        DentalClaimLineDetails result = dentalClaimLineDetailsMapper.mapRow(resultSet, 1);

        // Verify results
        assertEquals("claimHccId123", result.getClaimHccId());
        assertEquals("Code Description", result.getCodeDescription());
        assertEquals("formattedDate", result.getServiceStartDate());
        assertEquals("Surface", result.getSurface());
        assertEquals("Tooth", result.getTooth());
        assertEquals("100.00", result.getAllowedAmount());
        assertEquals("80.00", result.getPaidAmount());
        assertEquals("10.00", result.getDeductible());
        assertEquals("5.00", result.getCoPay());
        assertEquals("15.00", result.getCoInsurance());
        assertEquals("0.00", result.getOverMax());
        assertEquals("0.00", result.getCobAmount());
        assertEquals("No issues", result.getPaymentNotes());
        assertEquals("Area of Oral Cavity", result.getAreaOfOralCavity());
        assertEquals("Auth123", result.getAuthorizationNumber());
        assertEquals("Exception", result.getServiceException());
        assertEquals("150.00", result.getBilledAmount());
    }
}
