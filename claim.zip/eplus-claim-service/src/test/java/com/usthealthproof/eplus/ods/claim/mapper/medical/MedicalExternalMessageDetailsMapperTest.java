package com.usthealthproof.eplus.ods.claim.mapper.medical;

import com.usthealthproof.eplus.ods.claim.model.medical.MedicalExternalMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class MedicalExternalMessageDetailsMapperTest {

    @InjectMocks
    private MedicalExternalMessageDetailsMapper medicalExternalMessageDetailsMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRow() throws SQLException {
        // Setup mock behavior for ResultSet
        when(resultSet.getString("ACTION")).thenReturn("Action1");
        when(resultSet.getString("MESSAGE_CODE")).thenReturn("Code123");
        when(resultSet.getString("DESCRIPTION")).thenReturn("Description of the message");
        when(resultSet.getString("SOURCE")).thenReturn("Source1");
        when(resultSet.getString("CLAIM_FACT_KEY")).thenReturn("FactKey123");

        // Execute mapRow
        MedicalExternalMessage result = medicalExternalMessageDetailsMapper.mapRow(resultSet, 1);

        // Validate the mapped result
        assertEquals("Action1", result.getAction());
        assertEquals("Code123", result.getMessageCode());
        assertEquals("Description of the message", result.getDescription());
        assertEquals("Source1", result.getSource());
        assertEquals("FactKey123", result.getClaimFactKey());
    }
}
