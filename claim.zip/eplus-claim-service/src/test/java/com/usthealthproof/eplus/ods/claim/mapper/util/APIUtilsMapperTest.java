package com.usthealthproof.eplus.ods.claim.mapper.util;

import com.usthealthproof.eplus.ods.claim.model.common.ErrorResponse;
import com.usthealthproof.eplus.ods.claim.model.common.ProblemDetails;
import com.usthealthproof.eplus.ods.claim.model.medical.ClaimNotes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class APIUtilsMapperTest {

    @InjectMocks
    private APIUtils apiUtils;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        setPrivateField(apiUtils, "claimNotesDelimiter", "||");
        setPrivateField(apiUtils, "claimNotesPrioritySeparator", "^");
    }
    private void setPrivateField(Object target, String fieldName, String value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void testGetClaimNotes_ValidInput() {
        String claimNotesFromQuery = "Note1^1||Note2^2||Note3^3";

        List<ClaimNotes> result = apiUtils.getClaimNotes(claimNotesFromQuery);

        assertEquals(3, result.size());
        assertEquals("Note1", result.get(0).getClaimNote());
        assertEquals(1, result.get(0).getPriority());
        assertEquals(1, result.get(0).getSerialNo());

        assertEquals("Note2", result.get(1).getClaimNote());
        assertEquals(2, result.get(1).getPriority());
        assertEquals(2, result.get(1).getSerialNo());

        assertEquals("Note3", result.get(2).getClaimNote());
        assertEquals(3, result.get(2).getPriority());
        assertEquals(3, result.get(2).getSerialNo());
    }

    @Test
    void testGetClaimNotes_EmptyInput() {
        String claimNotesFromQuery = "";

        List<ClaimNotes> result = apiUtils.getClaimNotes(claimNotesFromQuery);

        assertNull(result);
    }

    @Test
    void testGetClaimNotes_InvalidInput() {
        String claimNotesFromQuery = "Note1|Note2|Note3";

        List<ClaimNotes> result = apiUtils.getClaimNotes(claimNotesFromQuery);

        assertNull(result);
    }

    @Test
    void testSetErrorDetails() {
        String message = "Some error occurred";
        String status = "400";

        ErrorResponse errorResponse = apiUtils.setErrorDetails(message, status);

        assertEquals(1, errorResponse.getProblemDetails().getErrors().size());
        assertEquals(message, errorResponse.getProblemDetails().getErrors().get(0));
        assertEquals(status, errorResponse.getProblemDetails().getStatus());
    }

    @Test
    void testCreateProblemDetails() {
        String errorMsg = "Error message";
        String status = "404";

        ProblemDetails problemDetails = apiUtils.createProblemDetails(errorMsg, status);

        assertEquals(1, problemDetails.getErrors().size());
        assertEquals(errorMsg, problemDetails.getErrors().get(0));
        assertEquals(status, problemDetails.getStatus());
    }

}
