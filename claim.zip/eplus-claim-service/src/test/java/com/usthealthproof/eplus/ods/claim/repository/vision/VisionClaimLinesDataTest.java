package com.usthealthproof.eplus.ods.claim.repository.vision;

import com.usthealthproof.eplus.ods.claim.constants.ClaimConstants;
import com.usthealthproof.eplus.ods.claim.exception.ClaimNotFoundException;
import com.usthealthproof.eplus.ods.claim.mapper.vision.VisionClaimLinesMapper;
import com.usthealthproof.eplus.ods.claim.model.vision.VisionClaimLines;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@Slf4j
public class VisionClaimLinesDataTest {

    @InjectMocks
    private VisionClaimLinesData visionClaimLinesData;

    @Mock
    private VisionClaimLinesMapper visionClaimLinesMapper;

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetVisionClaimLines_Success() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        List<VisionClaimLines> visionClaimLines = new ArrayList<>();
        visionClaimLines.add(new VisionClaimLines());
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLinesMapper)))
                .thenReturn(visionClaimLines);

        // Act
        List<VisionClaimLines> result = visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product);

        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(visionClaimLines, result);
    }

    @Test
    public void testGetVisionClaimLines_EmptyResult() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLinesMapper)))
                .thenReturn(new ArrayList<>());

        // Act & Assert
        ClaimNotFoundException exception = assertThrows(ClaimNotFoundException.class, () -> {
            visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product);
        });

        assertTrue(exception.getMessage().contains(ClaimConstants.VISION_CLAIM_LINES_NOT_FOUND));
    }

    @Test
    public void testGetVisionClaimLines_CannotGetJdbcConnectionException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLinesMapper)))
                .thenThrow(new CannotGetJdbcConnectionException("Database connection error"));

        // Act & Assert
        CannotGetJdbcConnectionException exception = assertThrows(CannotGetJdbcConnectionException.class, () -> {
            visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product);
        });

        assertEquals("Database connection error", exception.getMessage());
    }

    @Test
    public void testGetVisionClaimLines_GeneralException() {
        // Arrange
        String claimHccId = "testClaimHccId";
        String state = "TX";
        String lob = "Medical";
        String product = "Health";
        when(namedParameterJdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), eq(visionClaimLinesMapper)))
                .thenThrow(new RuntimeException("General error"));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            visionClaimLinesData.getVisionClaimLines(claimHccId, state, lob, product);
        });

        assertEquals("General error", exception.getMessage());
    }
}
