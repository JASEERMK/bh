package com.usthealthproof.eplus.ods.claim.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class DateUtilsTest {

    @InjectMocks
    private DateUtils dateUtils;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(dateUtils, "applicationDateFormat", "MM/dd/yyyy");
        ReflectionTestUtils.setField(dateUtils, "clientDateFormat", "yyyy-MM-dd");
    }

    @Test
    void testGetFormattedApplicationDate() {
        String applicationDate = "2023-07-30 12:34:56.789";
        String expectedDate = "07/30/2023";
        String formattedDate = dateUtils.getFormattedApplicationDate(applicationDate);
        assertEquals(expectedDate, formattedDate);
    }

    @Test
    void testGetFormattedApplicationDate_NullOrBlank() {
        assertNull(dateUtils.getFormattedApplicationDate(null));
        assertNull(dateUtils.getFormattedApplicationDate(""));
        assertNull(dateUtils.getFormattedApplicationDate("  "));
    }

    @Test
    void testGetFormattedClientDate() {
        String clientDate = "2023-07-30 12:34:56.789";
        String expectedDate = "2023-07-30";
        String formattedDate = dateUtils.getFormattedClientDate(clientDate);
        assertEquals(expectedDate, formattedDate);
    }

    @Test
    void testGetFormattedClientDate_NullOrBlank() {
        assertNull(dateUtils.getFormattedClientDate(null));
        assertNull(dateUtils.getFormattedClientDate(""));
        assertNull(dateUtils.getFormattedClientDate("  "));
    }
}