package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Intake Request")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IntakeRequest {
    @JsonProperty(required = true)
    @Schema(description = "Member Id")
    public String memberId;
//    @Schema(description = "Preffered Language")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Preffered Language is not in valid format")
//    public String prefferedLanguage;
    @Schema(description = "Submitter Type")
    public String submitterType;
    @Schema(description = "Submitter Details")
    @Valid
    public SubmitterDetails submitterDetails;
//    @Schema(description = "Member Behalf")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Member Behalf is not in valid format")
//    public String memberBehalf;
    @Schema(description = "Submitter Id")
    public String submitterId;
    @Schema(description = "Representative Details")
    @Valid
    public RepresentativeDetails representativeDetails;
//    @Schema(description = "Primary PhoneNumber")
//    @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Primary PhoneNumber should be Numeric")
//    public String primaryPhoneNumber;

    @JsonProperty(required = true)
    @Schema(description = "Complaint Type")
    public String complaintType;

    @JsonProperty(required = true)
    @Schema(description = "Complaint Type")
    public String complaintClass;

    @Schema(description = "Complaint Category")
    public String complaintCategory;

    @JsonProperty(required = true)
    @Schema(description = "Appeal Type")
    public String appealType;

    @Schema(description = "Appeals Detail")
    @Valid
    public AppealsDetail appealsDetail;
//    @Schema(description = "Grievances Detail")
//    @Valid
//    public GrievancesDetail grievancesDetail;
    @Schema(description = "Issue Date")
    public String issueDate;
    @Schema(description = "Complaint Description")
    public String complaintDescription;
    @Schema(description = "Intake Staff")
    public String intakeStaff;
    @Schema(description = "Responsible Staff")
    public String responsibleStaff;
    @Schema(description = "WorkQueue")
    @Valid
    public WorkQueue workQueue;

    @JsonProperty(required = true)
    @Schema(description = "Notification Method")
    public String notificationMethod;

//    @JsonProperty(required = true)
//    @Schema(description = "Priority")
//    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Priority is not in valid format")
//    public String priority;

    @Schema(description = "Intake Department")
    @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Intake Department is not in valid format")
    public String intakeDepartment;

    @Schema(description = "Responsible Department")
    public String responsibleDepartment;

    @Schema(description = "Level Of Service")
    public String levelOfService;

    @Schema(description = "Provider Type")
    public String providerType;

//    @Data
//    public static class GrievancesDetail {
//        @Schema(description = "Complaint Category")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Category is not in valid format")
//        public String complaintCategory;
//        @Schema(description = "Complaint SubCategory")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint SubCategory is not in valid format")
//        public String complaintSubCategory;
//        @Schema(description = "Complaint RelatedTo")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint RelatedTo is not in valid format")
//        public String complaintRelatedTo;
//        @Schema(description = "Complaint Againt Details")
//        @Pattern(regexp = "^[a-zA-Z0-9 !@#$%^&*()_+|=-]*$", message = "Invalid Request: Complaint Againt  Details is not in valid format")
//        public String complaintAgaintDetails;
//    }

    @Data
    public static class Address {
        @Schema(description = "Address")
        public String address;
        @Schema(description = "City")
        public String city;
        @Schema(description = "State")
        public String state;
        @Schema(description = "Zip")
        public String zip;
        @Schema(description = "Phone Number")
        public String phoneNumber;
    }

    @Data
    public static class SubmitterDetails {
        @Schema(description = "First Name")
        public String firstName;
        @Schema(description = "Last Name")
        public String lastName;
        @Schema(description = "Submitter Address")
        @Valid
        public Address submitterAddress;
        @Schema(description = "Submitter Relationship")
        public String submitterRelationship;
    }

    @Data
    public static class RepresentativeDetails {
        @Schema(description = "First Name")
        public String firstName;
        @Schema(description = "Last Name")
        public String lastName;
        @Schema(description = "Representative Address")
        @Valid
        public Address representativeAddress;
    }

    @Data
    public static class AppealsDetail {
        @Schema(description = "Appeal Type")
        public String appealType;
        @Schema(description = "Id")
        public String id;
        @Schema(description = "Service Start Date")
        public String serviceStartDate;
    }

    @Data
    public static class WorkQueue {
        @Schema(description = "Department Name")
        public String departmentName;
    }
}