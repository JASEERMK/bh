package com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants;

public final class AppealsAndGrievanceConstants {

	private AppealsAndGrievanceConstants() {
	}

	public static final String GC_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String GC_DATE_FORMAT = "yyyy-MM-dd";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String MEMBER_ID_NOT_FOUND = "Invalid Request: MemberId is mandatory";
	public static final String COMPLAINT_TYPE_NOT_FOUND = "Invalid Request: ComplaintType is mandatory";
	public static final String COMPLAINT_ID_NOT_FOUND = "Invalid Request: Complaint ID is not found in the request";
	public static final String PROVIDER_ID_NOT_FOUND = "Invalid Request: Provider ID is mandatory";
	public static final String PROVIDER_TYPE_NOT_FOUND = "Invalid Request: providerType is mandatory";
	public static final String WRONG_DATE_FORMAT = "Invalid Request : Invalid date format";

	public static final String WRONG_MEMBER_ID = "Invalid Request: Member ID is mandatory";

	public static final String WRONG_SUBMITTER_TYPE = "Invalid Request: Submitter Type is mandatory";

	public static final String WRONG_COMPLAINT_TYPE = "Invalid Request: Complaint Type is mandatory";

	public static final String WRONG_COMPLAINT_CLASS = "Invalid Request: Complaint Class is mandatory";

	public static final String WRONG_COMPLAINT_CATEGORY = "Invalid Request: Complaint Category is mandatory";
	public static final String WRONG_APPEAL_TYPE = "Invalid Request: Invalid Appeal Type";
	public static final String WRONG_APPEAL_ID_NOT_FOUND = "Invalid Request: Appeal ID is mandatory";

	public static final String WRONG_ISSUE_DATE = "Invalid Request: Issue Date is mandatory";

	public static final String FORMAT_TO_USE = " Please use format - ";
	public static final String EXCEPTION_OCCURRED = "Something went wrong, please check the log for more details.";
	public static final String NO_RESPONSE_ON_ERROR = "Something went wrong, not getting proper response";
	public static final String UN_AUTHERIZED_SERVER_ERROR = "External Login Failed : Please contact your supervisor";
	public static final String PAGE_LIMIT_EXCEED = "Search Result Limit Exceeded : Please narrow your search.";
	public static final String NO_DATA_FOUND = "No data found";
	public static final String NO_ELIGIBILITY_DATA_FOUND = "No member eligibility data found";
	public static final String GRIEVANCE_TYPE = "Grievance";
	public static final String APPEAL_TYPE = "Appeal";
	public static final String TIMEOUT_EXCEPTION_MESSAGE = "Connection refused, please contact your supervisor";
	public static final String OPEN = "Open";
	public static final String ANG_CLAIM = "Claim";
	public static final String ANG_AUTHERIZATION = "Authorization";
	public static final String CLIENT_PATIENT_ID = "clientPatientID";
	public static final String COMPLAINT_TYPE = "complaintType";
	public static final String PAGE_SIZE = "pageSize";
	public static final String PROVIDER_ID = "providerID";
	public static final String COMPLAINT_CREATED_FROM_DATE = "complaintCreatedFromDate";
	public static final String COMPLAINT_CREATED_TO_DATE = "complaintCreatedToDate";

	//Note Field Names
	public static final String NEW_LINE = "\n";
	public static final String SUBMITTER_DETAILS = "Submitter Details";
	public static final String REPRESENTATIVE_DETAILS = "Representative Details";
	public static final String FIRST_NAME = "First Name : ";
	public static final String LAST_NAME = "Last Name : ";
	public static final String ADDRESS = "Address : ";
	public static final String CITY = "City : ";
	public static final String STATE = "State : ";
	public static final String ZIP = "Zip : ";
	public static final String PHONE = "Phone : ";

//	Intake Supplemental Information
	public static final String SUPPLEMENTAL_INFORMATION_NAME = "External Claim, Tracking, or Case Number";
	public static final String INCIDENT_DATE_NAME = "Date of Incident";


}
