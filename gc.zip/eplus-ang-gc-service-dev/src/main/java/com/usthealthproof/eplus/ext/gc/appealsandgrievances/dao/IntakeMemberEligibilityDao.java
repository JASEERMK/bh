package com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.LoginResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.MemberEligibilityResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.util.RestResponseUtil;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.CLIENT_PATIENT_ID;

@Repository
@Slf4j
public class IntakeMemberEligibilityDao {
    @Autowired
    private WebClient webClient;
    @Autowired
    private APIUtils apiUtils;
    @Autowired
    private Validator validator;
    @Value("${gc.url.service.ang-member-eligibility}")
    private String angMemberEligibility;
    public MemberEligibilityResponse.Eligibility callMemberEligibility(String clientPatientID, String issueDate, LoginResponse loginResponse) throws Exception {
        try {
        log.info("Calling Member Eligibility Altruita service");
        MemberEligibilityResponse memberEligibilityResponse=null;
        memberEligibilityResponse = webClient.get()
                .uri(uriBuilder -> uriBuilder.path(angMemberEligibility)
                        .queryParam(CLIENT_PATIENT_ID, clientPatientID)
                        .build()).
                headers(headers -> headers.setBearerAuth(loginResponse.getAccessToken())).
                retrieve().
                onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.NO_CONTENT), RestResponseUtil::getNoContentException).
                onStatus(httpStatus -> httpStatus.isSameCodeAs(HttpStatus.BAD_REQUEST), RestResponseUtil::getBadRequestIntake).
                bodyToMono(MemberEligibilityResponse.class).
                block();
        log.info("memberEligibilityResponse {}",memberEligibilityResponse);
        validator.validatememberEligibilityResponse(memberEligibilityResponse);
        return getLobId(memberEligibilityResponse.getEligibilities(), issueDate);
        } catch (WebClientResponseException webClientResponseException) {
            log.error("Failed to receive the Member Eligibility response {}", webClientResponseException);
            throw webClientResponseException;
        } catch (Exception exception) {
            log.error("Failed to receive the Member Eligibility response for the request", exception);
            throw exception;
        }
        }

    /**
     * Retrieves the Line of Business (LOB) Benefit ID based on the provided issue date
     * and a list of eligibility periods.
     *
     * @param eligibilities A list of eligibility periods to check against.
     * @param issueDate     The issue date to be matched within the eligibility periods.
     * @return The corresponding LOB Benefit ID if found, or null if not found.
     */
    private MemberEligibilityResponse.Eligibility getLobId(List<MemberEligibilityResponse.Eligibility> eligibilities, String issueDate) throws Exception {
        for (MemberEligibilityResponse.Eligibility eligibility : eligibilities) {
            try {
                //checking issue date between startdate and enddate
                boolean flag = validateIssueDate(eligibility.getStartDate(), eligibility.getEndDate(), issueDate);
                if (flag) {
                    return eligibility;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return null;
    }
    /**
     * Checks if the issue date is within the specified date range defined by
     * the start date and end date.
     *
     * @param issueDate         The date to be checked for inclusion in the range.
     * @param startDate         The start date of the date range (inclusive).
     * @param endDate           The end date of the date range (inclusive).
     * @return                  True if the issue date falls within the date range,
     *                          false otherwise.
     */
    private boolean validateIssueDate(String startDate, String endDate, String issueDate) throws Exception {
        Date startDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
        Date endDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
        Date issueDate1 = new SimpleDateFormat("yyyy-MM-dd").parse(issueDate);
        if (startDate1.equals(issueDate1) | startDate1.before(issueDate1)) {
            return endDate1.equals(issueDate1) | endDate1.after(issueDate1);
        }
        return false;
    }
}
