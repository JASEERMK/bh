package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.APIUtils;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsDetailsResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.SupplementalInformation;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
public class MemberComplaintMapper {

    @Autowired
    private APIUtils apiUtils;
    @Autowired
    private CommonComplaintMapper commonComplaintMapper;

    @Value("${app-config.applicationDateTimeFormat}")
    public String applicationDateTimeFormat;

    @Value("${gc.config.provider.practitioner-prefix}")
    private String practitionerPrefix;

    @Value("${gc.config.provider.supplier-prefix}")
    private String supplierPrefix;

    @Value("${gc.config.provider.supplier-location-prefix}")
    private String supplierLocationPrefix;


    public AppealsOrGrievanceDetails memberDetailsResponseMapper(ServiceMemberAppealsDetailsResponse detailsResponse) throws Exception {
        log.info("Inside memberAppealDetailsResponseMapper() in mapper class");
        AppealsOrGrievanceDetails appealsOrGrievanceDetails = new AppealsOrGrievanceDetails();
        appealsOrGrievanceDetails.setComplaintID(detailsResponse.getComplaintID());
        appealsOrGrievanceDetails.setComplaintCategory(detailsResponse.getComplaintCategory());
        appealsOrGrievanceDetails.setComplaintSubCategory(detailsResponse.getComplaintSubCategory());
        appealsOrGrievanceDetails.setComplaintClass(detailsResponse.getComplaintClass());
        appealsOrGrievanceDetails.setReceivedDate(apiUtils.getFormattedGCApplicationDateTime(detailsResponse.getCreatedDateTime()));
        appealsOrGrievanceDetails.setCreatedDate(apiUtils.getFormattedGCApplicationDateTime(detailsResponse.getNotificationDateTime()));
        if (appealsOrGrievanceDetails.getReceivedDate() != null) {
            LocalDate currentDate = LocalDate.now();
            LocalDate receivedDate = LocalDate.parse(appealsOrGrievanceDetails.getReceivedDate(), DateTimeFormatter.ofPattern(applicationDateTimeFormat).withLocale(java.util.Locale.US));
            long complaintAge = ChronoUnit.DAYS.between(receivedDate, currentDate);
            if (complaintAge < 0) {
                log.info("complaintAge value is: {} as the receivedDate is greater than currentDate", complaintAge);
            }
            appealsOrGrievanceDetails.setComplaintAge(String.valueOf((int) complaintAge));
        }
        appealsOrGrievanceDetails.setComplaintStatus(detailsResponse.getStatus());
        appealsOrGrievanceDetails.setLevel(detailsResponse.getLevel());
        appealsOrGrievanceDetails.setNotificationMethod(detailsResponse.getNotificationMethod());
        appealsOrGrievanceDetails.setRequestor(detailsResponse.getWhoInitiatedComplaint());
        appealsOrGrievanceDetails.setDueDate(apiUtils.getFormattedGCApplicationDateTime(detailsResponse.getDueDateTime()));
        appealsOrGrievanceDetails.setLevelOfService(detailsResponse.getLevelOfService());
        if(!CollectionUtils.isEmpty(detailsResponse.getIntakeSupplementalInformation())) {
            Optional<SupplementalInformation> supplemental = detailsResponse.getIntakeSupplementalInformation().stream().filter(supplementalInformation -> supplementalInformation.getName().equals(AppealsAndGrievanceConstants.INCIDENT_DATE_NAME)).findFirst();
            if(supplemental.isPresent() && supplemental.get().getValue() != null) {
                appealsOrGrievanceDetails.setIncidentDate(apiUtils.formatAPIResponseDate(supplemental.get().getValue()[0]));
            }
        }
        appealsOrGrievanceDetails.setResponsibleDepartment(detailsResponse.getResponsibleDepartment());
        appealsOrGrievanceDetails.setResponsibleStaff(detailsResponse.getResponsibleStaff());
        appealsOrGrievanceDetails.setMemberId(detailsResponse.getClientPatientID());
        appealsOrGrievanceDetails.setComplaintStatusReason(detailsResponse.getStatusReason());
        appealsOrGrievanceDetails.setIntakeDepartment(detailsResponse.getIntakeDepartment());
        appealsOrGrievanceDetails.setIntakeStaff(detailsResponse.getIntakeStaff());
        appealsOrGrievanceDetails.setProviderId(removeproviderPrefix(detailsResponse.getProviderID()));
        appealsOrGrievanceDetails.setComplaintType(detailsResponse.getComplaintType());
        if (detailsResponse.getParticipants() != null) {
            appealsOrGrievanceDetails.setContactName(detailsResponse.getParticipants().get(0).getName());
            appealsOrGrievanceDetails.setContactNumber(detailsResponse.getParticipants().get(0).getPhone());
        }
        if (!CollectionUtils.isEmpty(detailsResponse.getInternalClaims())) {
            appealsOrGrievanceDetails.setInternaClaimID(detailsResponse.getInternalClaims().get(0).getClaimNumber());
        }
        if (!CollectionUtils.isEmpty(detailsResponse.getInternalAuthorizations())) {
                appealsOrGrievanceDetails.setInternalAuthorizationID(detailsResponse.getInternalAuthorizations().get(0).getAuthorizationID());
        }
        if (!CollectionUtils.isEmpty(detailsResponse.getExternalClaims())) {
            appealsOrGrievanceDetails.setExternalClaimID(detailsResponse.getExternalClaims().get(0).getClaimNumber());
        }
        if (!CollectionUtils.isEmpty(detailsResponse.getExternalAuthorizations())) {
            appealsOrGrievanceDetails.setExternalAuthorizationID(detailsResponse.getExternalAuthorizations().get(0).getExternalAuthorizationID());
        }
        if (!CollectionUtils.isEmpty(detailsResponse.getWorkQueues())) {
            appealsOrGrievanceDetails.setWorkQueueDepartmentName(detailsResponse.getWorkQueues().get(0).getDepartmentName());
        }
        log.info("appealsOrGrievanceDetails: {} ", appealsOrGrievanceDetails);
        return appealsOrGrievanceDetails;

    }
    public List<AppealsOrGrievanceSummary> memberSearchResponseMapper(List<ServiceAppealsSummaryResponse> serviceAppealsSearchResponse)  {
        return serviceAppealsSearchResponse.stream().map(memberAppeal -> {
            AppealsOrGrievanceSummary angsSummary;
                angsSummary=commonComplaintMapper.commoneSearchResponseMapper(memberAppeal);
                angsSummary.setComplaintClass(memberAppeal.getComplaintClass());
        return angsSummary;
    }).collect(Collectors.toList());
    }

    private String removeproviderPrefix(String id) {
        if (id != null) {
            String[] prefixes = {practitionerPrefix, supplierPrefix, supplierLocationPrefix};
            for (String prefix : prefixes) {
                if (id.startsWith(prefix)) {
                    return id.substring(prefix.length());
                }
            }
        }
        return id;
    }

    }
