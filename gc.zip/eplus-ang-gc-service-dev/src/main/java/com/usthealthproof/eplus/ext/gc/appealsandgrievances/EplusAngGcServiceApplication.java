package com.usthealthproof.eplus.ext.gc.appealsandgrievances;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

import java.util.TimeZone;

@SpringBootApplication
@SecurityScheme(name = "Appeals and Grievances Service", scheme = "bearer", type = SecuritySchemeType.HTTP , in = SecuritySchemeIn.HEADER)
public class EplusAngGcServiceApplication {
    @Value("${application.timeZone}")
    private String timeZone;
    public static void main(String[] args) {
        SpringApplication.run(EplusAngGcServiceApplication.class, args);
    }
    @PostConstruct
    public void init() {
        // Setting Spring Boot SetTimeZone
        TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
    }
}
