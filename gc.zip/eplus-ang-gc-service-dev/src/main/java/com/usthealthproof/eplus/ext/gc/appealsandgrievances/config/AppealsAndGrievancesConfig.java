package com.usthealthproof.eplus.ext.gc.appealsandgrievances.config;


import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;

import javax.net.ssl.KeyManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import io.swagger.v3.oas.models.servers.Server;

@Slf4j
@Configuration
public class AppealsAndGrievancesConfig {

    @Value("${gc.certificate-file}")
    private String certificateFile;

    @Value("${gc.certificate-password}")
    private String certificatePassword;

    @Value("${gc.base-url}")
    private String baseUrl;

    @Value("${springdoc.servers.url}")
    private String swaggerServerUrl;

    @Bean
    public WebClient webClient() {
        final ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1)).build();

        // Create a custom HttpClient with the SSL context
        HttpClient httpClient = HttpClient.create()
                .secure(sslContextSpec -> sslContextSpec.sslContext(getSslContext()));

        // Create the WebClient using the custom HttpClient
        WebClient.Builder webClientBuilder = WebClient.builder()
                .baseUrl(baseUrl)
                .clientConnector(new ReactorClientHttpConnector(getHttpClient()))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).exchangeStrategies(strategies);

        return webClientBuilder.build();
    }

    private SslContext getSslContext() {
        SslContext sslContext = null;
        try {

            // Load PFX certificate from the filepath
            InputStream pfxInputStream = new FileInputStream(certificateFile);
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(pfxInputStream, certificatePassword.toCharArray());

            // Create a KeyManagerFactory and initialize it with the PFX certificate
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, certificatePassword.toCharArray());

            // Create SSL context with the PFX certificate
            sslContext = SslContextBuilder.forClient()
                    .keyManager(kmf)
                    .trustManager(InsecureTrustManagerFactory.INSTANCE)
                    .build();
        } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException | UnrecoverableKeyException e) {
            log.error("Exception while creation SSL context");
            throw new RuntimeException();
        }
        return sslContext;
    }

    private HttpClient getHttpClient() {
        ConnectionProvider provider = ConnectionProvider.builder("fixed").maxConnections(500).maxIdleTime(Duration.ofSeconds(20))
                .maxLifeTime(Duration.ofSeconds(60)).pendingAcquireTimeout(Duration.ofSeconds(60))
                .evictInBackground(Duration.ofSeconds(120)).build();
        return HttpClient.create(provider)
                .secure(sslContextSpec -> sslContextSpec.sslContext(getSslContext()))
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 20000).doOnConnected(
                        conn -> conn.addHandlerLast(new ReadTimeoutHandler(20)).addHandlerLast(new WriteTimeoutHandler(20)));
    }

    /**
     * Swagger Document API: http://localhost:8080/eplus/eplus-ang-gc-service/api-docs
     * Swagger UI: http://localhost:8080/eplus/eplus-ang-gc-service/index.html
     */

    @Bean
    public OpenAPI springShopOpenAPI() {
        List<Server> servers = new ArrayList<>();
        Server server = new Server();
        server.setUrl(swaggerServerUrl);
        servers.add(server);
        return new OpenAPI().info(new Info().title("Appeals and Grievance Services").description(
                        "This is a wrapper service which calls GuidingCare services for retrieving and submitting Member Appeals and Grievances\n\n"
                                + "The consumers are provided with a url and credentials to get the access and refresh token . The service calls are made with valid access token in the header.")
                .version("5.0.0"));
    }

}
