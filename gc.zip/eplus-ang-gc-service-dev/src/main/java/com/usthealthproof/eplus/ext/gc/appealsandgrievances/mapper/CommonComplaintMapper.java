package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.APIUtils;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CommonComplaintMapper {

    @Autowired
    private APIUtils apiUtils;

    public AppealsOrGrievanceSummary commoneSearchResponseMapper(ServiceAppealsSummaryResponse serviceAppealsSearchResponse)  {
        log.info("Inside commoneSearchResponseMapper() in mapper class");
            AppealsOrGrievanceSummary angsSummary = new AppealsOrGrievanceSummary();

            angsSummary.setComplaintID(serviceAppealsSearchResponse.getComplaintID());
            angsSummary.setStatus(serviceAppealsSearchResponse.getStatus());
            angsSummary.setComplaintCategory(serviceAppealsSearchResponse.getComplaintCategory());
            angsSummary.setReceivedDate(apiUtils.getFormattedGCApplicationDateTime(serviceAppealsSearchResponse.getReceivedDateTime()));
            return angsSummary;
    }
}
