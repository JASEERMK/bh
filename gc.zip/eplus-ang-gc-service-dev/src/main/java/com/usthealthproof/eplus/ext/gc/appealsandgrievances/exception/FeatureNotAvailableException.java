package com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception;

public class FeatureNotAvailableException extends RuntimeException {

	private static final long serialVersionUID = -2625891751125517298L;

	public FeatureNotAvailableException() {

	}

	public FeatureNotAvailableException(String message) {
		super(message);
	}

}
