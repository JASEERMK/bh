package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


@Schema(description = "Provider Appeals or Grievance Summary")
public class ProviderComplaintSummaryResponse extends ComplaintsummaryResponse{
    @Schema(description = "Member Id")
    private String memberId;
}
