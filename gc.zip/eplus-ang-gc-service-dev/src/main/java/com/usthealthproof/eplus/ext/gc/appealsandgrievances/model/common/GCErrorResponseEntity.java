package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common;

import lombok.Data;

@Data
public class GCErrorResponseEntity {

    public String category;
    public String code;
    public String detail;
    public String field;

}
