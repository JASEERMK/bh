package com.usthealthproof.eplus.ext.gc.appealsandgrievances.service;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.MemberAppealsDao;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper.CommonComplaintMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper.MemberComplaintMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper.ProviderComplaintMapper;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceMemberAppealsDetailsResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AppealsAndGrievanceService {

    @Autowired
    private MemberComplaintMapper memberComplaintMapper;
    @Autowired
    private CommonComplaintMapper commonComplaintMapper;
    @Autowired
    private ProviderComplaintMapper providerComplaintMapper;
    @Autowired
    private MemberAppealsDao memberAppealsDao;

    @Value("${gc.config.provider.practitioner-prefix}")
    private String practitionerPrefix;

    @Value("${gc.config.provider.supplier-prefix}")
    private String supplierPrefix;

    @Value("${gc.config.provider.supplier-location-prefix}")
    private String supplierLocationPrefix;

    public List<AppealsOrGrievanceSummary> getMemberAppealsOrGrievanceSummary(String memberId, String complaintType) throws Exception {
        log.info("Inside getMemberAppealsOrGrievanceSummary() in service class");
        List<ServiceAppealsSummaryResponse> serviceMemberSearchAppealsResponses = memberAppealsDao.getMemberAppealsSummary(memberId,
                complaintType);
        log.info("serviceMemberSearchAppealsResponses: {} ", serviceMemberSearchAppealsResponses);
        return memberComplaintMapper.memberSearchResponseMapper(serviceMemberSearchAppealsResponses);

    }

    public List<AppealsOrGrievanceSummary> getProviderAppealsOrGrievanceSummary(String providerId, String providerType, String complaintType, @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Created From Date is not in valid format") String createdFromDate, @Pattern(regexp = "^[0-9-]*$", message = "Invalid Request: Created Start Date is not in valid format") String createdToDate) throws Exception {
        log.info("Inside getProviderAppealsOrGrievanceSummary() in service class");
        String providerIdWithPrefix = getProviderTypeWithPrefix(providerType,providerId);
        List<ServiceAppealsSummaryResponse> serviceMemberSearchAppealsResponses = memberAppealsDao.getProviderAppealsSummary(providerIdWithPrefix,
                complaintType, createdFromDate, createdToDate);
        log.info("serviceMemberSearchAppealsResponses: {} ", serviceMemberSearchAppealsResponses);
        return providerComplaintMapper.providerSearchResponseMapper(serviceMemberSearchAppealsResponses);
    }

    public AppealsOrGrievanceDetails getAppealsOrGrievanceDetails(String complaintId) throws Exception {
        log.info("Inside getAppealsOrGrievanceDetails() in service class");
        if (StringUtils.isNotBlank(complaintId)) {
            log.info("Going for memberAppealsDetails call");
            ServiceMemberAppealsDetailsResponse serviceMemberDetailsAppealsResponses = memberAppealsDao.getMemberAppealsDetails(
                    complaintId);
            serviceMemberDetailsAppealsResponses.setComplaintID(complaintId);
            log.info("serviceMemberDetailsAppealsResponses: {} ", serviceMemberDetailsAppealsResponses);
            return memberComplaintMapper.memberDetailsResponseMapper(serviceMemberDetailsAppealsResponses);
        } else {
            throw new RequestValidationException("Invalid Request: Please provide a valid complaintId");
        }
    }

    private String getProviderTypeWithPrefix(String providerType,String providerId) {
        String providerIdWithPrefix = null;
        if (providerType.equals("practitioner")) {
            providerIdWithPrefix = practitionerPrefix + providerId;
        } else if (providerType.equals("supplier")) {
            providerIdWithPrefix = supplierPrefix + providerId;
        } else if (providerType.equals("supplier location")) {
            providerIdWithPrefix = supplierLocationPrefix + providerId;
        }
        return providerIdWithPrefix;
    }
}
