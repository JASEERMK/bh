package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import lombok.Data;

@Data
public class SupplementalInformation {
    private String name;
    private String[] value;
}
