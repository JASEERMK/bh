package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Member Appeals or Grievance Details")
@JsonInclude(value = Include.NON_EMPTY)
public class AppealsOrGrievanceDetails {
	@Schema(description = "Complaint Category")
	private String complaintCategory;
	@Schema(description = "Complaint ID")
	private String complaintID;
	@Schema(description = "Complaint Class")
	private String complaintClass;
	@Schema(description = "Complaint Sub Category")
	private String complaintSubCategory;
	@Schema(description = "Receive Date time")
	private String receivedDate;
	@Schema(description = "Created Date")
	private String createdDate;
	@Schema(description = "Complaint Age")
	private String complaintAge;
	@Schema(description = "Appeal Level")
	private String level;
	@Schema(description = "Complaint Status")
	private String complaintStatus;
	@Schema(description = "Notification Method")
	private String notificationMethod;
	@Schema(description = "Requestor")
	private String requestor;
	@Schema(description = "Due Date")
	private String dueDate;
	@Schema(description = "Level Of Service")
	private String levelOfService;
	@Schema(description = "Incident Date")
	private String incidentDate;
	@Schema(description = "Responsible Department")
	private String responsibleDepartment;
	@Schema(description = "Responsible Staff")
	private String responsibleStaff;
	@Schema(description = "Contact Name")
	private String contactName;
	@Schema(description = "Contact Number")
	private String contactNumber;
	@Schema(description = "Complaint Status Reason")
	private String complaintStatusReason;
	@Schema(description = "Member Id")
	private String memberId;
	@Schema(description = "Complaint Type")
	private String complaintType;
	@Schema(description = "Intake Department")
	private String intakeDepartment;
	@Schema(description = "Intake Staff")
	private String intakeStaff;
	@Schema(description = "Provider Id")
	private String providerId;
	@Schema(description = "Department Name")
	private String workQueueDepartmentName;
	@Schema(description = "Internal Authorization ID")
	private String internalAuthorizationID;
	@Schema(description = "External Authorization ID")
	private String externalAuthorizationID;
	@Schema(description = "Internal Claim ID")
	private String internaClaimID;
	@Schema(description = "External Claim ID")
	private String externalClaimID;

}
