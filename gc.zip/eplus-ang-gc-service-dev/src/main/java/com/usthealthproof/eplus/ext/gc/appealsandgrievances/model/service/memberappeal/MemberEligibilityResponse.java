package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import lombok.Data;

import java.util.List;

@Data
public class MemberEligibilityResponse {
    private String memberFirstName;
    private String memberLastName;
    private String gender;
    private String memberDOB;
    private String clientPatientID;
    private String medicareID;
    private String medicaidID;
    private List<Eligibility> eligibilities;

    @Data
    public static class Eligibility {
        private int lobBenID;
        private String uniqueEligibilityID;
        private String carrierMemberID;
        private List<EligibilityRecord> eligibilityRecords;
        private String eligibilityPath;
        private String startDate;
        private String endDate;
        private String status;
    }

    @Data
    public static class EligibilityRecord {
        private int level;
        private String code;
        private String desc;
    }
}
