package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
//@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Object for holding Member Appeals Details response received from the external service")
public class ServiceMemberAppealsDetailsResponse {
    private String complaintID;
    private String complaintCategory;
    private String complaintClass;
    private String createdDateTime;
    private String notificationDateTime;
    private String caseAge;
    private String level;
    private String status;
    private String complaintSubCategory;
    private String notificationMethod;
    private String whoInitiatedComplaint;
    private String dueDateTime;
    private String levelOfService;
    private String dateTimeOfIncident;
    private String responsibleDepartment;
    private String responsibleStaff;
    private String statusReason;
    private String clientPatientID;
    private String complaintType;
    private List<InternalClaims> internalClaims;
    private List<ExternalClaims> externalClaims;
    private List<Participants> participants;
    private List<InternalAuthorizations> internalAuthorizations;
    private List<ExternalAuthorizations> externalAuthorizations;
    private List<SupplementalInformation> intakeSupplementalInformation;
    private List<WorkQueue> workQueues;
    private String intakeDepartment;
    private String intakeStaff;
    private String providerID;

}
