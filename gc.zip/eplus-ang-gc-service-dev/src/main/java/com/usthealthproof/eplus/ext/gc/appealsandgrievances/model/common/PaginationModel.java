package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Object for pagination details from external service")
public class PaginationModel {

    private String pageSize;
    private String pageNo;
    private String pageCount;
}
