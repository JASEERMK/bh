package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common;

import lombok.Data;

import java.util.List;

@Data
public class GCErrorResponse {
    private List<GCErrorResponseEntity> error;

}
