package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.APIUtils;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeAltruistaRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.MemberEligibilityResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class MemberComplaintIntakeMapper {
    @Value("${gc.config.responsible-staff}")
    private String responsibleStaff;
    @Value("${gc.config.intake-staff}")
    private String intakeStaff;
    @Value("${gc.config.work-queue-referral}")
    private boolean workQueueReferral;
    @Value("${gc.config.work-queue-dept-name}")
    private String workQueueDeptName;

    @Value("${gc.config.provider.practitioner-prefix}")
    private String practitionerPrefix;

    @Value("${gc.config.provider.supplier-prefix}")
    private String supplierPrefix;

    @Value("${gc.config.provider.supplier-location-prefix}")
    private String supplierLocationPrefix;

    @Autowired
    private APIUtils apiUtils;

    private static final String SUPPLEMENTAL_INFORMATION_VALUE = "N/A";

    public IntakeAltruistaRequest setAltruistaRequest(IntakeRequest intakeRequest, MemberEligibilityResponse.Eligibility eligibility) throws Exception {
        IntakeAltruistaRequest intakeAltruistaRequest=new IntakeAltruistaRequest();
        intakeAltruistaRequest.setClientPatientID(intakeRequest.memberId);
        if (intakeRequest.getMemberId() != null && intakeRequest.getIssueDate() != null) {
            intakeAltruistaRequest.setLobBenID(String.valueOf(eligibility.getLobBenID()));
            intakeAltruistaRequest.setEligibilityStartDate(eligibility.getStartDate());
        }
        intakeAltruistaRequest.setWhoInitiatedComplaint(intakeRequest.getSubmitterType());
        intakeAltruistaRequest.setProviderID(getProviderId(intakeRequest.getProviderType(),intakeRequest.getSubmitterId()));
        intakeAltruistaRequest.setComplaintType(intakeRequest.getComplaintType());
        intakeAltruistaRequest.setComplaintClass(intakeRequest.getComplaintClass());
        intakeAltruistaRequest.setComplaintCategory(intakeRequest.getComplaintCategory());
        if (null != intakeRequest.getAppealsDetail() && null != intakeRequest.getAppealType()) {
            setClaimsAndAuth(intakeAltruistaRequest,intakeRequest.getAppealsDetail(), intakeRequest.getAppealType());
        }
        intakeAltruistaRequest.setInitialComplaintNote(intakeRequest.getComplaintDescription());
        intakeAltruistaRequest.setIntakeStaff(intakeRequest.getIntakeStaff());
        intakeAltruistaRequest.setResponsibleStaff(intakeRequest.getResponsibleStaff());
        if (null != intakeRequest.getWorkQueue()) {
            setWorkQueue(intakeAltruistaRequest,intakeRequest);
        }
        intakeAltruistaRequest.setNotificationMethod(intakeRequest.getNotificationMethod());
        intakeAltruistaRequest.setIntakeDepartment(intakeRequest.getIntakeDepartment());
        intakeAltruistaRequest.setStatus(AppealsAndGrievanceConstants.OPEN);
        intakeAltruistaRequest.setNotificationDateTime(setNotificationDateTime());
        intakeAltruistaRequest.setResponsibleDepartment(intakeRequest.getResponsibleDepartment());
        intakeAltruistaRequest.setLevelOfService(intakeRequest.getLevelOfService());

        List<IntakeAltruistaRequest.SupplementalInformation> supplementalInformationList = new ArrayList<IntakeAltruistaRequest.SupplementalInformation>();
        IntakeAltruistaRequest.SupplementalInformation information = intakeAltruistaRequest.new SupplementalInformation();
        information.setName(AppealsAndGrievanceConstants.SUPPLEMENTAL_INFORMATION_NAME);
        information.setValue(new String[]{SUPPLEMENTAL_INFORMATION_VALUE});
        supplementalInformationList.add(information);
        if(StringUtils.containsIgnoreCase(intakeRequest.getComplaintType(),AppealsAndGrievanceConstants.GRIEVANCE_TYPE)) {
            IntakeAltruistaRequest.SupplementalInformation incidentDate = intakeAltruistaRequest.new SupplementalInformation();
            incidentDate.setName(AppealsAndGrievanceConstants.INCIDENT_DATE_NAME);
            incidentDate.setValue(new String[]{apiUtils.formatAPIRequestDate(intakeRequest.getIssueDate())});
            supplementalInformationList.add(incidentDate);
        }
        intakeAltruistaRequest.setIntakeSupplementalInformation(supplementalInformationList);
        return intakeAltruistaRequest;
    }

    private String setNotificationDateTime() {
        OffsetDateTime currentDate = OffsetDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
        formatter = formatter.withZone(ZoneOffset.UTC);
        String formattedDate = currentDate.format(formatter);
        return formattedDate;
    }

    private void setClaimsAndAuth(IntakeAltruistaRequest intakeAltruistaRequest,IntakeRequest.AppealsDetail appealsDetail, String appealType) {
        String id = appealsDetail.getId();
        if (appealType.equalsIgnoreCase(AppealsAndGrievanceConstants.ANG_CLAIM)) {
            IntakeAltruistaRequest.InternalClaim internalClaim = intakeAltruistaRequest.new InternalClaim();
            internalClaim.setClaimNumber(id);
            intakeAltruistaRequest.setInternalClaims(Arrays.asList(internalClaim));
        } else if (appealType.equalsIgnoreCase(AppealsAndGrievanceConstants.ANG_AUTHERIZATION)) {
            IntakeAltruistaRequest.InternalAuthorization internalAuthorization = intakeAltruistaRequest.new InternalAuthorization();
            internalAuthorization.setAuthorizationID(id);
            internalAuthorization.setIsPrimary("true");
            intakeAltruistaRequest.setInternalAuthorizations(Arrays.asList(internalAuthorization));
        }
    }

    private void setWorkQueue(IntakeAltruistaRequest intakeAltruistaRequest,IntakeRequest intakeRequest) {
        IntakeAltruistaRequest.WorkQueue workQueue = intakeAltruistaRequest.new WorkQueue();
        workQueue.setDepartmentName(intakeRequest.getWorkQueue().getDepartmentName());
        IntakeAltruistaRequest.WorkQueue[] workQueues = new IntakeAltruistaRequest.WorkQueue[1];
        workQueues[0] = workQueue;
        intakeAltruistaRequest.setWorkQueues(workQueues);
        intakeAltruistaRequest.setIsWorkQueueReferral("true");
    }
    private String getProviderId(String providerType, String providerId) {
        if(StringUtils.isBlank(providerType)) {
            return providerId;
        }
        else{
            String providerIdWithPrefix = null;
            if (providerType.equals("practitioner")) {
                providerIdWithPrefix = practitionerPrefix + providerId;
            } else if (providerType.equals("supplier")) {
                providerIdWithPrefix = supplierPrefix + providerId;
            } else if (providerType.equals("supplier location")) {
                providerIdWithPrefix = supplierLocationPrefix + providerId;
            }
            return providerIdWithPrefix;
        }
    }
}
