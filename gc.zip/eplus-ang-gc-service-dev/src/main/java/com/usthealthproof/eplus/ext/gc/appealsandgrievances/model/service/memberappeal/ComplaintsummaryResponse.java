package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
@Schema(description = "Appeals or Grievance Summary")
@JsonInclude(value = JsonInclude.Include.NON_EMPTY)
public abstract  class ComplaintsummaryResponse {

    @Schema(description = "Appeal/Grievance Number")
    private String complaintID;
    @Schema(description = "Complaint Category")
    private String complaintCategory;
    @Schema(description = "complaint Sub Category")
    private String complaintSubCategory;
    @Schema(description = "Status")
    private String status;
    @Schema(description = "Receive Date time")
    private String receivedDate;

}
