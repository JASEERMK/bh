package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common;

import lombok.Data;

@Data
public class OAuthErrorResponse {
    private String error_description;
    private String error;
}
