package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Member Appeals or Grievance Summary")
public class MemberComplaintSummaryResponse {
    @Schema(description = "Complaint Class")
    private String complaintClass;
}
