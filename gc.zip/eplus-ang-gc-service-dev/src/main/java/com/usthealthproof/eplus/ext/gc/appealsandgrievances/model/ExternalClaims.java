package com.usthealthproof.eplus.ext.gc.appealsandgrievances.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Object for holding ExternalClaims details received from the external service")
public class ExternalClaims {

    private String claimNumber;

}
