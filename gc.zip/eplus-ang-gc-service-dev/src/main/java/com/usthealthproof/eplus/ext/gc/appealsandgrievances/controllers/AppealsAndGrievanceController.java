package com.usthealthproof.eplus.ext.gc.appealsandgrievances.controllers;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceDetails;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.error.ErrorResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.service.AppealsAndGrievanceService;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.service.IntakeService;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.validator.Validator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/ang")
@Tag(name = "Appeals and Grievances")
@Validated
@Slf4j
@SecurityRequirement(name = "Appeals and Grievances Service")
public class AppealsAndGrievanceController {

    @Autowired
    AppealsAndGrievanceService appealsAndGrievanceService;

    @Autowired
    Validator validator;
    @Autowired
    IntakeService intakeService;

    /**
     * Service retrieves Member Appeals/Grievances summary for given memberId
     *
     * @param memberId
     * @param complaintType
     * @return AppealsOrGrievanceSummary List
     */
    @Operation(summary = "Get Member Appeals/Grievances summary", method = "GET", description = "Service for retrieving all Appeals/Grievances summary based on memberId and complaint type of a member", responses = {
            @ApiResponse(responseCode = "200", description = "Appeals/Grievances summary response", content = {
                    @Content(array = @ArraySchema(schema = @Schema(implementation = AppealsOrGrievanceSummary.class)))}),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "204", description = "No data found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = "/member/complaints", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<List<AppealsOrGrievanceSummary>> getMemberAppealsOrGrievancesSummary(
            @RequestParam(value = "memberId", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: memberId is not in valid format") String memberId,
            @RequestParam(value = "complaintType", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: complaintType is not in valid format") String complaintType)
            throws Exception {
        log.info("Inside getMemberAppealsOrgrievancesSummary() in controller class");
        validator.validateMemberAppealsAndGrievancesSummary(memberId, complaintType);
        return new ResponseEntity<>(appealsAndGrievanceService.getMemberAppealsOrGrievanceSummary(memberId, complaintType),
                HttpStatus.OK);
    }

    /**
     * Service retrieves Member Appeals/Grievances summary for given memberId
     *
     * @param providerId
     * @param complaintType
     * @return AppealsOrGrievanceSummary List
     */
    @Operation(summary = "Get Member Appeals/Grievances summary", method = "GET", description = "Service for retrieving all Appeals/Grievances summary based on memberId and complaint type of a member", responses = {
            @ApiResponse(responseCode = "200", description = "Appeals/Grievances summary response", content = {
                    @Content(array = @ArraySchema(schema = @Schema(implementation = AppealsOrGrievanceSummary.class)))}),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "204", description = "No data found", content = @Content),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = "/provider/complaints", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<List<AppealsOrGrievanceSummary>> getProviderAppealsOrGrievancesSummary(
            @RequestParam(value = "providerId", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: providerId is not in valid format") String providerId,
            @RequestParam(value = "providerType", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: providerType is not in valid format") String providerType,
            @RequestParam(value = "complaintType", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: complaintType is not in valid format") String complaintType,
            @RequestParam(value = "createdFromDate", required = false) @Pattern(regexp = "^\\d{4}[-](0[1-9]|1[012])[-](0[1-9]|[12]\\d|3[01])$", message = "Invalid Request: Created From Date is not in valid format") String createdFromDate,
            @RequestParam(value = "createdToDate", required = false) @Pattern(regexp = "^\\d{4}[-](0[1-9]|1[012])[-](0[1-9]|[12]\\d|3[01])$", message = "Invalid Request: Created To Date is not in valid format") String createdToDate)

            throws Exception {
        log.info("Inside getProviderAppealsOrGrievancesSummary() in controller class");
        validator.validateProviderAppealsSummary(providerId,providerType,complaintType);
        return new ResponseEntity<>(appealsAndGrievanceService.getProviderAppealsOrGrievanceSummary(providerId,providerType, complaintType, createdFromDate, createdToDate ),
                HttpStatus.OK);
    }

    /**
     * Service retrieves Member Appeals/Grievances details for given complaintId and
     * memberId
     *
     * @param complaintId
     * @return AppealsOrGrievanceDetails
     */
    @Operation(summary = "Get Member Appeals/Grievances details", method = "GET", description = "Service for retrieving member Appeals/Grievances details of a particular complaint ", responses = {
            @ApiResponse(responseCode = "200", description = "Appeals/Grievances details response", content = {
                    @Content(schema = @Schema(implementation = AppealsOrGrievanceDetails.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Un-Authorized user", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))}),
            @ApiResponse(responseCode = "204", description = "No data found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {
                    @Content(schema = @Schema(implementation = ErrorResponse.class))})})
    @GetMapping(value = {"provider/complaint/details", "member/complaint/details"}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    public ResponseEntity<AppealsOrGrievanceDetails> getMemberAppealsOrgrievancesDetails(
            @RequestParam(value = "complaintId", required = true) @Pattern(regexp = "^[^<>]*$", message = "Invalid Request: complaintId is not in valid format") String complaintId) throws Exception {
        log.info("Inside getMemberAppealsOrgrievancesDetails() in controller class");
        validator.validateMemberAppealsAndGrievancesDetails(complaintId);
        return new ResponseEntity<>(( appealsAndGrievanceService.getAppealsOrGrievanceDetails(complaintId) ),
                HttpStatus.OK);


    }

}
