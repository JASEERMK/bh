package com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception.RequestValidationException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.LoginResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.util.RestResponseUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

@Component
public class APIUtils {

    @Value("${app-config.applicationDateFormat}")
    public String applicationDateFormat;

    @Value("${app-config.applicationDateTimeFormat}")
    public String applicationDateTimeFormat;

    @Autowired
    private WebClient webClient;

    @Value("${gc.url.login-url}")
    private String loginUrl;

    @Value("${gc.username}")
    private String username;

    @Value("${gc.password}")
    private String password;

    public static final String BEARER_TOKEN = "Bearer ";

    public LoginResponse login() {
        return webClient.method(HttpMethod.POST)
                .uri(loginUrl)
                .headers(httpHeaders -> {
                    httpHeaders.setBasicAuth(username,password);
                } )
                .body(BodyInserters.fromFormData("grant_type", "client_credentials"))
                .retrieve()
                .onStatus(httpStatus -> httpStatus.isError(),
                        RestResponseUtil::getUnAuthorizedException)
                .onStatus(httpStatus -> httpStatus.is5xxServerError(),
                        RestResponseUtil::getUnAuthorizedServerException)
                .bodyToMono(LoginResponse.class)
                .block();
    }

    public Consumer<HttpHeaders> getHeaders(LoginResponse loginResponse) {
        return httpHeaders -> {
            httpHeaders.set(HttpHeaders.AUTHORIZATION, BEARER_TOKEN + loginResponse.getAccessToken());
        };
    }

    public String getFormattedGCApplicationDate(String applicationDate,String dateType) {
        if (StringUtils.isNotBlank(applicationDate)) {
            try {
                LocalTime dateFormat = LocalTime.of(0, 0, 0);
                if(dateType.equals("toDate")) {
                     dateFormat = LocalTime.of(23, 59, 59);
                }
                LocalDateTime localDateTime = LocalDate.parse(applicationDate, DateTimeFormatter.ofPattern(applicationDateFormat))
                        .atTime(dateFormat);
                return localDateTime.format(DateTimeFormatter.ofPattern(AppealsAndGrievanceConstants.GC_DATE_TIME_FORMAT));
            } catch (Exception e) {
                throw new RequestValidationException(AppealsAndGrievanceConstants.WRONG_DATE_FORMAT + AppealsAndGrievanceConstants.FORMAT_TO_USE + applicationDateFormat);
            }
        }

        return null;
    }

    /**
     *
     * @param date Date in application time format
     * @return Date in GC Required Format
     */
    public String formatAPIRequestDate(String date) {
        LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        return localDate.format(DateTimeFormatter.ofPattern(AppealsAndGrievanceConstants.GC_DATE_FORMAT));

    }

    /**
     *
     * @param date Date from external system
     * @return Date for API resopnse
     */
    public String formatAPIResponseDate(String date) {
        LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern(AppealsAndGrievanceConstants.GC_DATE_TIME_FORMAT));
        return localDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

    }

    public String getFormattedGCApplicationDateTime(String applicationDate) {
        if (StringUtils.isNotBlank(applicationDate)) {
            try {

                LocalDateTime receivedDate =
                        LocalDateTime.parse(applicationDate,DateTimeFormatter.ISO_ZONED_DATE_TIME);
                return receivedDate.format(DateTimeFormatter.ofPattern(applicationDateTimeFormat).withLocale(java.util.Locale.US));
            } catch (Exception e) {
                throw new RequestValidationException(AppealsAndGrievanceConstants.WRONG_DATE_FORMAT + AppealsAndGrievanceConstants.FORMAT_TO_USE + applicationDateTimeFormat);
            }
        }

        return null;
    }

}
