package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.ServiceAppealsSummaryResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.AppealsOrGrievanceSummary;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ProviderComplaintMapper {

    @Autowired
    private CommonComplaintMapper commonComplaintMapper;

    public List<AppealsOrGrievanceSummary> providerSearchResponseMapper(List<ServiceAppealsSummaryResponse> serviceAppealsSearchResponse) {
        return serviceAppealsSearchResponse.stream().map(memberAppeal -> {
            AppealsOrGrievanceSummary angsSummary;
            angsSummary=commonComplaintMapper.commoneSearchResponseMapper(memberAppeal);
            angsSummary.setMemberId(memberAppeal.getClientPatientID());
            return angsSummary;
        }).collect(Collectors.toList());
    }
}
