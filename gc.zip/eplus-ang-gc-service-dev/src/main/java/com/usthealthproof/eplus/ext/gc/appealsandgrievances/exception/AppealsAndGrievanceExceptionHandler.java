package com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.error.ErrorResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.wrapper.error.ProblemDetails;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ControllerAdvice
@Slf4j
public class AppealsAndGrievanceExceptionHandler extends ResponseEntityExceptionHandler {

//	@Autowired
//	ProblemDetails problemDetails;

	/**
	 * Handler for handling the request validations
	 *
	 * @param requestValidationException
	 * @return
	 */
	@ExceptionHandler(RequestValidationException.class)
	public ResponseEntity<ErrorResponse> requestValidationExceptionHandler(
			RequestValidationException requestValidationException) {
		log.error("Request Validation Exception Occurred", requestValidationException);
		return new ResponseEntity<>(
				setErrorDetails(requestValidationException.getMessage(), AppealsAndGrievanceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handler for handling the response validations
	 *
	 * @param responseValidationException
	 * @return
	 */
	@ExceptionHandler(ResponseValidationException.class)
	public ResponseEntity<ErrorResponse> responseValidationExceptionHandler(
			ResponseValidationException responseValidationException) {
		log.error("Response Validation Exception Occurred");
		String status = AppealsAndGrievanceConstants.FAILURE;
		if (responseValidationException.getStatus() == HttpStatus.NOT_FOUND){
			status=AppealsAndGrievanceConstants.SUCCESS;
		}
			return new ResponseEntity<>(
					setErrorDetails(responseValidationException.getMessage(), status),
					responseValidationException.getStatus());

	}

	/**
	 * Handler for handling the internal exceptions
	 *
	 * @param e
	 * @return
	 */
	@ExceptionHandler(InternalException.class)
	public ResponseEntity<ErrorResponse> internalExceptionHandler(InternalException e) {
		log.error("Exception occurred in appeals and grievances : ", e.getMessage(), e);
		return new ResponseEntity<>(
				setErrorDetails(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED, AppealsAndGrievanceConstants.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);

	}

	/**
	 * Handler for handling the webClient exceptions
	 *
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(WebClientException.class)
	public final ResponseEntity<ErrorResponse> webclientExceptionHandler(WebClientException ex, WebRequest request) {
		log.error("WebClientException Caught : {} , {}", ex, ex.getMessage());

		return new ResponseEntity<>(
				setErrorDetails(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED, AppealsAndGrievanceConstants.FAILURE),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * Handles the exception thrown by WebClientResponseException, especially when
	 * there is any exception in the client response
	 *
	 * @param ex
	 * @param request
	 * @return ErrorResponse
	 */
	@ExceptionHandler(WebClientResponseException.class)
	public final ResponseEntity<ErrorResponse> webClientResponseExceptionHandler(WebClientResponseException ex,
			WebRequest request) {
		log.error("WebClientResponseException Caught : {} {}", ex.getMessage(), ex);

		int httpStatusCode = ex.getStatusCode().value();
		String exceptionMessage = null;
		try {
			JSONObject exceptionJsonMessage = new JSONObject(ex.getResponseBodyAsString());
			if (StringUtils.isNotBlank(exceptionJsonMessage.get("httpCode").toString())) {
				httpStatusCode = Integer.parseInt(exceptionJsonMessage.get("httpCode").toString());
				exceptionMessage = exceptionJsonMessage.get("message").toString();
			} else {
				exceptionMessage = AppealsAndGrievanceConstants.EXCEPTION_OCCURRED;
			}
		} catch (Exception e) {
			log.info("The received error message can't convert into JSON object");
			exceptionMessage = ex.getResponseBodyAsString();
			if (StringUtils.isBlank(exceptionMessage)) {
				exceptionMessage = AppealsAndGrievanceConstants.EXCEPTION_OCCURRED;
			}
		}
		String status = AppealsAndGrievanceConstants.FAILURE;
		if (404 == ex.getStatusCode().value()) {
			status = AppealsAndGrievanceConstants.SUCCESS;
		}

		return new ResponseEntity<>(setErrorDetails(exceptionMessage, status), HttpStatus.valueOf(httpStatusCode));
	}

	/**
	 * Handler for handling the global exceptions
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> globalHandler(Exception ex, WebRequest request) {
		log.error("Exception Caught : {} {}", ex.getMessage(), ex);

		if (StringUtils.containsAnyIgnoreCase(ex.getMessage(), "Could not receive Message", "Could not send Message",
				"Connection reset", "Read timed out")
				|| StringUtils.containsAnyIgnoreCase(ex.toString(), "Connection reset", "Read timed out")) {
			return new ResponseEntity<>(
					setErrorDetails(AppealsAndGrievanceConstants.TIMEOUT_EXCEPTION_MESSAGE, AppealsAndGrievanceConstants.FAILURE),
					HttpStatus.REQUEST_TIMEOUT);
		} else {
			return new ResponseEntity<>(
					setErrorDetails(AppealsAndGrievanceConstants.EXCEPTION_OCCURRED, AppealsAndGrievanceConstants.FAILURE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Handler for handling the MethodArgumentNotValidException
	 *
	 * @param ex
	 * @param headers
	 * @param status
	 * @param request
	 * @return
	 */
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		log.error("MethodArgumentNotValidException Caught : {} {}", ex.getMessage(), ex);
		return new ResponseEntity<>(
				setErrorDetailsAsList(ex.getBindingResult().getFieldErrors(), AppealsAndGrievanceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	/**
	 * Handler for handling the ConstraintViolationException
	 *
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse> handleconstraintViolationException(ConstraintViolationException ex, WebRequest request) {
		log.error("ConstraintViolationException Caught : {} {}", ex.getMessage(), ex);
		List<String> errorMessage = new ArrayList<>();
		ex.getConstraintViolations().forEach(cv -> errorMessage.add(cv.getMessage()));
		return new ResponseEntity<>(
				setErrorDetailsAsListForConstraintViolation(errorMessage, AppealsAndGrievanceConstants.FAILURE),
				HttpStatus.BAD_REQUEST);
	}

	private ErrorResponse setErrorDetails(String message, String status) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setProblemDetails(createProblemDetails(message, status));
		return errorResponse;
	}

	public ProblemDetails createProblemDetails(String errorMsg, String status) {
		log.info("Inside createProblemDetails() in APIUtils");
		ProblemDetails problemDetails = new ProblemDetails();
		problemDetails.setErrors(Collections.singletonList(errorMsg));
		problemDetails.setStatus(status);
		return problemDetails;
	}

	private ErrorResponse setErrorDetailsAsListForConstraintViolation(List<String> list, String status) {
		log.info("Inside setErrorDetailsAsListForConstraintViolation()");
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		problemDetails.setErrors(list);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

	public ErrorResponse setErrorDetailsAsList(List<FieldError> fieldErrors, String status) {
		log.info("Inside setErrorDetailsAsList()");
		ErrorResponse errorResponse = new ErrorResponse();
		var problemDetails = new ProblemDetails();
		problemDetails.setStatus(status);
		ArrayList<String> errorList = new ArrayList<>();
		for (FieldError fieldError : fieldErrors) {
			errorList.add(fieldError.getDefaultMessage());
		}
		problemDetails.setErrors(errorList);
		errorResponse.setProblemDetails(problemDetails);
		return errorResponse;
	}

}
