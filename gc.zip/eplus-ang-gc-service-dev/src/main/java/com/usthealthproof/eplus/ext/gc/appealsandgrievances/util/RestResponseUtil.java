package com.usthealthproof.eplus.ext.gc.appealsandgrievances.util;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.exception.ResponseValidationException;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.GCErrorResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.OAuthErrorResponse;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.common.GCErrorResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.NO_RESPONSE_ON_ERROR;
import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.UN_AUTHERIZED_SERVER_ERROR;

@Slf4j
public class RestResponseUtil {

    private RestResponseUtil() {
    }

    public static Mono<ResponseValidationException> getUnAuthorizedException(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(OAuthErrorResponse.class).map(entity -> {
            String responseMessage = entity.getError() + " : " + entity.getError_description();
            return new ResponseValidationException(responseMessage, HttpStatus.UNAUTHORIZED);
        });
    }
    public static Mono<ResponseValidationException> getUnAuthorizedServerException(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(OAuthErrorResponse.class).map(entity -> {
            return new ResponseValidationException(UN_AUTHERIZED_SERVER_ERROR, HttpStatus.UNAUTHORIZED);
        });
    }

    public static Mono<ResponseValidationException> getNoContentException(ClientResponse clientResponse) {
        log.info("Inside getNoContentException() function");
        return Mono.error(new ResponseValidationException("No Data Found", HttpStatus.NOT_FOUND));
    }

    public static Mono<ResponseValidationException> getBadRequest(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(new ParameterizedTypeReference<GCErrorResponse>() {}).map(body -> {
            if(CollectionUtils.isEmpty(body.getError())) {
                return new ResponseValidationException(NO_RESPONSE_ON_ERROR, HttpStatus.BAD_REQUEST);
            }
            GCErrorResponseEntity entity = body.getError().get(0);
            String responseMessage = null;
            responseMessage = entity.getCategory() + " : " + entity.getDetail();
            return new ResponseValidationException(responseMessage, HttpStatus.BAD_REQUEST);
        });
    }
    public static Mono<ResponseValidationException> getBadRequestIntake(ClientResponse clientResponse) {
        log.info("Inside getNoContentException() function");
        return clientResponse.bodyToMono(new ParameterizedTypeReference<GCErrorResponse>() {}).map(body -> {
            String responseMessage = null;
            List<GCErrorResponseEntity> errorList = body.getError();
            StringBuilder responseMessageBuilder = new StringBuilder();
            errorList.forEach(errorDetail -> {
                responseMessageBuilder
                        .append(errorDetail.getCategory()).append(" : ")
                        .append(errorDetail.getDetail()).append(" ");
            });

            responseMessage = responseMessageBuilder.toString();
            return new ResponseValidationException(responseMessage, HttpStatus.BAD_REQUEST);
        });

    }
//    public static Mono<BatchRestServiceException> getSFRestErrorException(Object request, ClientResponse clientResponse) {
//        log.error("EXCEPTION#SF_RESPONSE SF Rest Error Request {}, Response {} ", request, clientResponse);
//        return clientResponse.bodyToMono(String.class).map(body -> new BatchRestServiceException(ErrorCodeConstant.SF_ERROR_RESPONSE, body));
//    }

}
