package com.usthealthproof.eplus.ext.gc.appealsandgrievances.mapper;

import com.usthealthproof.eplus.ext.gc.appealsandgrievances.dao.IntakeMemberEligibilityDao;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeAltruistaRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.IntakeRequest;
import com.usthealthproof.eplus.ext.gc.appealsandgrievances.model.service.memberappeal.NoteRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.usthealthproof.eplus.ext.gc.appealsandgrievances.constants.AppealsAndGrievanceConstants.*;

@Component
@Slf4j
public class NoteMapper {
    @Autowired
    IntakeMemberEligibilityDao intakeMemberEligibilityDao;
    @Autowired
    private IntakeAltruistaRequest intakeAltruistaRequest;
    @Value("${gc.config.responsible-staff}")
    private String responsibleStaff;
    @Value("${gc.config.intake-staff}")
    private String intakeStaff;
    @Value("${gc.config.work-queue-referral}")
    private boolean workQueueReferral;
    @Value("${gc.config.work-queue-dept-name}")
    private String workQueueDeptName;

    @Value("${gc.config.note-type}")
    private String noteType;

    @Value("${gc.config.note-level}")
    private String noteLevel;

    public NoteRequest createNote(IntakeRequest.SubmitterDetails submitterDetails) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(SUBMITTER_DETAILS);
        addNewLine(sb,FIRST_NAME, submitterDetails.getFirstName());
        addNewLine(sb,LAST_NAME, submitterDetails.getLastName());
        if(submitterDetails.getSubmitterAddress() != null) {
            IntakeRequest.Address subAddress = submitterDetails.getSubmitterAddress();
            addNewLine(sb,ADDRESS, subAddress.getAddress());
            addNewLine(sb,CITY, subAddress.getCity());
            addNewLine(sb,STATE, subAddress.getState());
            addNewLine(sb,ZIP, subAddress.getZip());
            addNewLine(sb,PHONE, subAddress.getPhoneNumber());
        }
        NoteRequest noteRequest = new NoteRequest();
        noteRequest.setNoteType(noteType);
        noteRequest.setLevel(noteLevel);
        noteRequest.setNotes(sb.toString());
        return noteRequest;
    }

    public NoteRequest createNote(IntakeRequest.RepresentativeDetails representativeDetails) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append(REPRESENTATIVE_DETAILS);
        addNewLine(sb,FIRST_NAME, representativeDetails.getFirstName());
        addNewLine(sb,LAST_NAME, representativeDetails.getLastName());
        if(representativeDetails.getRepresentativeAddress() != null) {
            IntakeRequest.Address repAddress = representativeDetails.getRepresentativeAddress();
            addNewLine(sb,ADDRESS, repAddress.getAddress());
            addNewLine(sb,CITY, repAddress.getCity());
            addNewLine(sb,STATE, repAddress.getState());
            addNewLine(sb,ZIP, repAddress.getZip());
            addNewLine(sb,PHONE, repAddress.getPhoneNumber());
        }
        NoteRequest noteRequest = new NoteRequest();
        noteRequest.setNoteType(noteType);
        noteRequest.setLevel(noteLevel);
        noteRequest.setNotes(sb.toString());
        return noteRequest;
    }

    private void addNewLine(StringBuilder stringBuilder, String fieldName, String value) {
        if(!StringUtils.hasText(value)) {
            return;
        }
        stringBuilder
                .append(NEW_LINE)
                .append(fieldName)
                .append(value);
    }
}
