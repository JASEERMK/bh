package com.usthealthproof.eplus.ext.gc.appealsandgrievances;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class EplusAngGcServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
