package com.usthealthproof.eplus.commons.batch.pcp.db.repository;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 210409
 */
    public interface MemberPcpRepository<T extends MemberPcp> extends JpaRepository<T, Integer> {
    @Override
    Page<T> findAll(Pageable pageable);
    String FIND_DISTINCT_PCP= "SELECT COUNT(DISTINCT CIL_PCP_KEY) FROM EPLUS_MEMBER_PCP";
    @Query(value = FIND_DISTINCT_PCP, nativeQuery = true)
    long distinctCount();
    @Query(value = "select PCP_CIL_ID from EPLUS_MEMBER_PCP", nativeQuery = true)
    List<BigDecimal> findKeys(Pageable pageable);

    List<T> findByPcpCilIdIn(List<BigDecimal> keys);

    @Transactional
    @Procedure(value = "sp_eplus_GetPCPDtl", outputParameterName = "returnstatus")
    int getPcpDetailsSP(@Param("InterfaceId") String interfaceId, @Param("processdate") String lastRuntime, @Param("runtype") String runType, @Param("SelectiveLoad") String selectiveLoad);

}
