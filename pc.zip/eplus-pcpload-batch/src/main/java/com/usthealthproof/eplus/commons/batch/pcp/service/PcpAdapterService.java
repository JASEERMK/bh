package com.usthealthproof.eplus.commons.batch.pcp.service;

import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.response.PcpBatchLoadResponse;

public interface PcpAdapterService {
    public void updateRequest(Graphs graphs);

    public void updateResponse(PcpBatchLoadResponse response);

}
