package com.usthealthproof.eplus.commons.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud.ServiceCloudPcpRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.BLANK_STRING;
import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.*;

@Slf4j
@Component
public class ServiceCloudMappingUtil implements MappingUtil {
    @Value("${pcp.record.service.url}")
    private String pcpRecordServiceUrl;

    @Autowired
    PcpServiceCloudAdapterMapping clientMapping;

    /**
     * This is the main bean method which creates pcp batch request which contain pcp info.
     *
     * @param data pcp data
     * @return converted account request
     */
    public PcpGraphRequest createMemberPcpRequest(MemberPcp data) {

        ServiceCloudPcpRecord serviceCloudPcpRecord = getPcpInfo(data);
        if (serviceCloudPcpRecord == null) {
            return null;
        }
        List<CompositeRequest> requests = new ArrayList<>();
        clientMapping.updateScRecord(data, serviceCloudPcpRecord);
        CompositeRequest pcpRecordRequest = new CompositeRequest();
        String externalId = data.getCilPcpKey();
        pcpRecordRequest.setUrl(pcpRecordServiceUrl.concat(externalId));
        pcpRecordRequest.setReferenceId(formatRefId(externalId));
        pcpRecordRequest.setBody(serviceCloudPcpRecord);
        requests.add(pcpRecordRequest);

        PcpGraphRequest request = new PcpGraphRequest();
        request.setGraphId("PCP_".concat(externalId));
        request.setCompositeRequest(requests);
        return request;
    }



    /**
     * pcp record mapping
     */
    private ServiceCloudPcpRecord getPcpInfo(MemberPcp data) {
        if (data.getCilPcpKey() == null) {
            return null;
        }
        ServiceCloudPcpRecord serviceCloudPcpRecord = new ServiceCloudPcpRecord();

        if (null != data.getMemberId()) {
            serviceCloudPcpRecord.setMemberKey(Map.of("UST_EPLUS__CIL_Member_Key__c", data.getMemberId()));
        } else {
            serviceCloudPcpRecord.setMemberReferenceKey(BLANK_STRING);
        }

        if (null != data.getProviderId()) {
            serviceCloudPcpRecord.setProviderNameKey(Map.of("UST_EPLUS__CIL_Provider_Key__c", data.getProviderId()));
        } else {
            serviceCloudPcpRecord.setProviderNameReferenceKey(BLANK_STRING);
        }

        if (null != data.getHcPractitionerFacility()) {
            serviceCloudPcpRecord.setPractitionerLocation(
                    Map.of("UST_EPLUS__CIL_Practitioner_Location_Key__c", data.getHcPractitionerFacility()));
        } else {
            serviceCloudPcpRecord.setPractitionerLocationReferenceKey(BLANK_STRING);
        }
        serviceCloudPcpRecord.setPanel((data.getPanel()));
        serviceCloudPcpRecord.setIsCurrentPCP(validateBooleanValueYorN(data.getIsCurrent()));

        if (data.getPcpEndDate() != null) {
            String date = extractDate(data.getPcpEndDate());
            serviceCloudPcpRecord.setPcpEndDate(date);
        }
        if (data.getPcpStartDate() != null) {
            String date = extractDate(data.getPcpStartDate());
            serviceCloudPcpRecord.setPcpStartDate(date);
        }
        serviceCloudPcpRecord.setPcpName(trimString(data.getProviderName()));
        serviceCloudPcpRecord.setPcpPhone(data.getPcpPhone());
        serviceCloudPcpRecord.setAutoAssigned(validateBooleanValue(data.getAutoAssigned()));
        return serviceCloudPcpRecord;
    }

    private String formatRefId(String referenceId) {
        return CommonUtils.removeSpecialCharacter(referenceId.replace("-", "_"));
    }
    private String trimString(String input) {
        if (input == null) {
            return null;
        }
        return input.length() > 80 ? input.substring(0, 80) : input;
    }
}
