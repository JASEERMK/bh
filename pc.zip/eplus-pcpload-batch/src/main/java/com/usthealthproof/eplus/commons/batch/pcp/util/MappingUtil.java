package com.usthealthproof.eplus.commons.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;

public interface MappingUtil {

    PcpGraphRequest createMemberPcpRequest(MemberPcp data);


}
