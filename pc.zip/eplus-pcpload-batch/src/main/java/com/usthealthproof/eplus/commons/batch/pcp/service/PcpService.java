package com.usthealthproof.eplus.commons.batch.pcp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.BatchProcessingException;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.common.service.SpErrorLogService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.DateUtil;
import com.usthealthproof.eplus.commons.batch.pcp.config.constant.PcpConstant;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.response.PcpBatchLoadResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.*;
import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.*;
import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.writeDebugMessage;

/**
 * @author 210409
 */
@Slf4j
@Service
public class PcpService {

    @Autowired
    MemberPcpRepository memberPcpRepository;

    @Autowired
    AuditService auditService;

    @Autowired
    RestCallService<PcpBatchLoadResponse> restCallService;

    @Autowired
    AdhocService adhocService;

    @Autowired
    private SpErrorLogService spErrorLogService;

    @Autowired
    private AuditErrorMessageUtil auditErrorMessageUtil;

    @Autowired
    private WebClient webClient;
    @Autowired
    private PcpAdapterService pcpAdapterService;

    @Value("${logging.level.com.usthealthproof.eplus.batch}")
    private String batchLoggingLevel;

    @Value("${salesforce.url.loadUrl}")
    private String memberPcpLoadURL;


    @Value("${batch.log.write}")
    private boolean writePcpDetails;

    @Value("${batch.log.path}")
    private String logFilePath;
    
    @Value("${batch.audit.request}")
    boolean auditRequest;
    @Value("${batch.interface-id}")
    private String interfaceId;


    /**
     * errorCounter
     */
    private AtomicInteger errorCounter = new AtomicInteger();

    /**
     * DataLoadSuccessCounter
     */
    private AtomicInteger successCounter = new AtomicInteger();

    public PcpService(AuditService auditService, AdhocService adhocService,
                      RestCallService<PcpBatchLoadResponse> restCallService,
                      MemberPcpRepository memberPcpRepository,
                      PcpAdapterService pcpAdapterService, SpErrorLogService spErrorLogService, AuditErrorMessageUtil auditErrorMessageUtil) {
        this.auditService = auditService;
        this.adhocService = adhocService;
        this.restCallService = restCallService;
        this.memberPcpRepository = memberPcpRepository;
        this.pcpAdapterService = pcpAdapterService;
        this.spErrorLogService = spErrorLogService;
        this.auditErrorMessageUtil = auditErrorMessageUtil;
    }

    public void callStoredProcedureService(StepExecution stepExecution, String spRunTypeParam, String selectiveLoad) {
        log.debug("Inside callStoredProcedureService() in PcpService class");
        ExecutionContext context = stepExecution.getJobExecution().getExecutionContext();
        String lastRuntime = (String) context.get(Constant.RUNTIME);
        Date newRuntime = (Date) context.get(Constant.NEW_RUNTIME);
        String jobId = getJobId(stepExecution);
        int storedProcedureResult = memberPcpRepository.getPcpDetailsSP(interfaceId,lastRuntime, spRunTypeParam, selectiveLoad);
        log.info("Stored Procedure Output : {}", storedProcedureResult);
        if (storedProcedureResult == 1) {
            log.info("Stored Procedure not executed Successfully : {}", storedProcedureResult);
            AuditBatch auditBatch= spErrorLogService.addSPErrorLog(newRuntime,
                    PcpConstant.PARAMETER_GET_PCP_DETAILS_SP);
            if(auditBatch != null) {
                auditService.auditStepStatus(jobId, Constant.PROCESS_STEP_SP, PROCESS_STATUS_ERROR_VALUE, auditBatch.getErrorMessage(), auditBatch.getErrorDetails());
            }
            stepExecution.setTerminateOnly();
        } else {
            log.info("Stored Procedure executed Successfully : {}", storedProcedureResult);
            auditService.auditStepStatus(jobId,Constant.PROCESS_STEP_SP,PROCESS_STATUS_SUCCESS_VALUE,null,null);
        }
    }

    public String addMemberPCPService(Graphs graphs, StepExecution stepExecution) {
        log.debug("Inside addMemberPCPService() in PcpService class");
        log.debug("PCP List Included {} ", graphs.getPcpGraphRequests().size());
        pcpAdapterService.updateRequest(graphs);
        writePcpRequestLog(graphs);
        writeDebugMessage("PCP Request {} ", CommonUtils.getObjectAsString(graphs));
        PcpBatchLoadResponse pcpResponse = restCallService.callPostRequest(memberPcpLoadURL,
                PcpBatchLoadResponse.class,graphs, stepExecution);
        writePcpResponseLog(pcpResponse);
        pcpAdapterService.updateResponse(pcpResponse);
        List<Map<String, String>> errorList = new ArrayList<>();
        boolean isAuditRequired = auditPcpDataLoadStatus(pcpResponse, errorList);
        if (isAuditRequired) {
        	String request=null;
        	if(auditRequest) {
        		request=CommonUtils.getObjectAsString(graphs);
        	}
            String jobId = getJobId(stepExecution);
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditSFDataLoadWriteError(jobId,errorList, stepExecution.getStepName(),request);
            if(!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }
            adhocService.setAdhocTableEntries(errorList, interfaceId);
        }
        writeDebugMessage("addPcpService Response {} ", CommonUtils.getObjectAsString(pcpResponse));
        return "Success";
    }

    void writePcpRequestLog(Graphs graphs) {
        log.debug("Inside writePcpRequestLoge() in PcpService class");
        if(batchLoggingLevel.equalsIgnoreCase("debug")) {
            log.debug("Request Graph {} ", CommonUtils.getObjectAsString(graphs));
        }
        if (!Boolean.TRUE.equals(writePcpDetails)) {
            return;
        }
        try {
            String str = CommonUtils.getObjectAsString(graphs);
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(logFilePath + "/PCP/REQUEST/" + DateUtil.dateForFileCreation(new Date())));
            writer.write(str);
            writer.close();
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException writing request to log", e);
            throw new BatchProcessingException("JsonProcessingException", e);
        } catch (IOException e) {
            log.error("IOException writing request to log", e);
            throw new BatchProcessingException("IOException", e);
        }
    }

    void writePcpResponseLog(PcpBatchLoadResponse pcpBatchLoadResponse) {
        log.debug("Inside writePcpResponseLog() in PcpService class");

        if (!Boolean.TRUE.equals(writePcpDetails)) {
            return;
        }
        String str = null;
        try {
            str = CommonUtils.getObjectAsString(pcpBatchLoadResponse);
            BufferedWriter writer = null;
            writer = new BufferedWriter(
                    new FileWriter(logFilePath + "/PCP/RESPONSE/" + DateUtil.dateForFileCreation(new Date())));
            writer.write(str);
            writer.close();
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException writing response to log", e);
            throw new BatchProcessingException("JsonProcessingException", e);
        } catch (IOException e) {
            log.error("IOException writing response to log", e);
            throw new BatchProcessingException("IOException", e);
        }
    }

    /**
     * Method which store errors in an error list, if there is any fallouts getting
     * from salesforce while inserting or upserting pcp records. Later this
     * error list used in router class to insert those fall outs in Audit table.
     */
    public boolean auditPcpDataLoadStatus(PcpBatchLoadResponse pcpBatchLoadResponse, List<Map<String, String>> errorList) {
        log.debug("Inside auditPcpDataLoadStatus() in PcpService class");
        if (pcpBatchLoadResponse == null || CollectionUtils.isEmpty(pcpBatchLoadResponse.getGraphs())
                || pcpBatchLoadResponse.getGraphs().get(0) == null
                || pcpBatchLoadResponse.getGraphs().get(0).getGraphResponse() == null || CollectionUtils
                .isEmpty(pcpBatchLoadResponse.getGraphs().get(0).getGraphResponse().getCompositeResponse())) {
            log.error("Service Response body is empty or null");
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put("referenceId", StringUtils.EMPTY);
            errorMap.put("responseText", "Service Response is empty");
            errorList.add(errorMap);
            return true;
        }
        setPcpDataLoadErrorStatus(pcpBatchLoadResponse, errorList);
        return !CollectionUtils.isEmpty(errorList);
    }

    /**
     * @param pcpBatchLoadResponse pcp batch load response
     *
     */
    private void setPcpDataLoadErrorStatus(PcpBatchLoadResponse pcpBatchLoadResponse, List<Map<String, String>> errorList) {
        log.debug("Inside setPcpDataLoadErrorStatus() in PcpService class");
        List<String> successList = new ArrayList<String>();
        for (Graph graph : pcpBatchLoadResponse.getGraphs()) {

            String correlationId = pcpBatchLoadResponse.getGraphs().get(0).getGraphResponse().getCompositeResponse().get(0)
                    .getReferenceId();

            for (CompositeResponse compositeResponse : graph.getGraphResponse().getCompositeResponse()) {
                if (compositeResponse.getHttpStatusCode().toString().startsWith("2")) {
                    log.debug("Success ID: {}", compositeResponse.getReferenceId());
                    successCounter.incrementAndGet();
                    successList.add(compositeResponse.getReferenceId());
                    continue;
                }
                processErrorResponse(errorList, graph, correlationId, compositeResponse);
            }
        }
        log.info("Successful ID list is {}",successList);
    }

    private void processErrorResponse(List<Map<String, String>> errorList, Graph graph, String correlationId, CompositeResponse compositeResponse) {
        Map<String, String> errorMap = initializeErrorMap(graph, correlationId, compositeResponse);
        if (compositeResponse.getBody() instanceof ArrayNode node) {
            if (node == null || node.isEmpty()) {
                return;
            }
            JsonNode jsonNode = node.get(0).get("message");
            if (jsonNode != null && !jsonNode.asText().contains("rolled back")) {
                String message = jsonNode.asText();
                errorMap.put(MESSAGE, message);
                errorList.add(errorMap);
                String referenceId = errorMap.get(REFERENCE_ID);
                log.error("Error for PCP : {}, error: {}", referenceId, message);
                errorCounter.incrementAndGet();
            }
        }
    }

    private Map<String, String> initializeErrorMap(Graph graph, String correlationId, CompositeResponse compositeResponse) {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put(REFERENCE_ID, compositeResponse.getReferenceId());
        errorMap.put(GRAPH_ID, compositeResponse.getReferenceId());
        errorMap.put(RESPONSE_TEXT, CommonUtils.getObjectAsString(graph));
        errorMap.put(CORRELATION_ID, correlationId);
        return errorMap;
    }

    public void updateSFDataLoadSuccessAndErrorCountAudit(StepExecution stepExecution) {
        log.debug("Inside updateSFDataLoadSuccessAndErrorCountAudit() in PcpService class");
        String jobId = getJobId(stepExecution);
        long totalCount= memberPcpRepository.distinctCount();
        auditService.auditExecuteQueryCountStatus(jobId,totalCount, 0,PROCESS_STATUS_SUCCESS_VALUE,PcpConstant.PCP_TOTAL_COUNT);
        Integer sCount = successCounter.get();
        Integer fCount = errorCounter.get();
        if ((sCount > 0) || (fCount > 0)) {
            auditService.auditExecuteQueryCountStatus(jobId,0,successCounter.get(),PROCESS_STATUS_SUCCESS_VALUE,PcpConstant.PCP_SUCCESS_COUNT);
            auditService.auditExecuteQueryCountStatus(jobId,0, errorCounter.get(),PROCESS_STATUS_ERROR_VALUE,PcpConstant.PCP_FAILURE_COUNT);
        }
    }

    private String getJobId(StepExecution stepExecution) {
        String jobId= String.valueOf(stepExecution.getJobExecution().getJobId());
        return jobId;
    }

    public void resetCounter() {
        successCounter = new AtomicInteger();
        errorCounter = new AtomicInteger();
    }

}
