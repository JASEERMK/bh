package com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpRequest;
import lombok.Data;

import java.util.Map;

@Data
public class ServiceCloudPcpRecord extends PcpRequest {

    @JsonProperty("UST_EPLUS__Practitioner_Location__r")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Map<String, String> practitionerLocation;

    @JsonProperty("UST_EPLUS__Practitioner_Location__c")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String practitionerLocationReferenceKey;

    @JsonProperty("UST_EPLUS__Provider_Name_SC__r")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Map<String, String> providerNameKey;

    @JsonProperty("UST_EPLUS__Provider_Name_SC__c")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String providerNameReferenceKey;

}
