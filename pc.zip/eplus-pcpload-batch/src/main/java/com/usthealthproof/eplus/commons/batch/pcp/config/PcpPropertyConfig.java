package com.usthealthproof.eplus.commons.batch.pcp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = "classpath:pcp-application.yml", factory = YamlPropertySourceFactory.class)
public class PcpPropertyConfig {
}
