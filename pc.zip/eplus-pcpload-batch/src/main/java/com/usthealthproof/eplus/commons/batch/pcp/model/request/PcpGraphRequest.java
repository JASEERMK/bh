package com.usthealthproof.eplus.commons.batch.pcp.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import lombok.Data;

import java.util.List;

@Data
public class PcpGraphRequest {

    private String graphId;

    @JsonProperty("compositeRequest")
    private List<CompositeRequest> compositeRequest;

}
