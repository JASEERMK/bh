package com.usthealthproof.eplus.commons.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.commons.batch.common.service.RuntimeService;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class PCPAncillarySteps {

    @Autowired
    private RuntimeService runTimeService;

    @Autowired
    private TaskletExceptionHandler taskletExceptionHandler;
    @Autowired
    private ExceptionListener exceptionListener;



    @Value("${batch.sp.enabled}")
    private boolean spEnabled;

    @Value("${batch.sp.is-selective-load}")
    private  String isSelectiveLoad;

    @Autowired
    public PCPAncillarySteps(RuntimeService runTimeService,
                             TaskletExceptionHandler taskletExceptionHandler,
                             ExceptionListener exceptionListener) {
        this.runTimeService = runTimeService;
        this.taskletExceptionHandler = taskletExceptionHandler;
        this.exceptionListener = exceptionListener;
    }
    /**
     * @return Step for reading current runtime
     */
    @Bean
    @Qualifier("readRuntimeStep")
    public Step readRuntimeStep(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        log.debug("Inside readRuntimeStep() in PCPAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_READ_RUNTIME,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    ExecutionContext executionContext = chunkContext.getStepContext()
                            .getStepExecution().getJobExecution().getExecutionContext();
                    executionContext.put("jobId", chunkContext
                            .getStepContext().getStepExecution().getJobExecution().getJobId());
                    runTimeService.readRuntime(executionContext);
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .transactionManager(platformTransactionManager)
                .build();
    }

    /**
     * @return Step for calling stored procedure
     */
    @Bean
    @Qualifier("callStoredProcedureStep")
    public Step callStoredProcedureStep(@Value("${batch.sp.parameter.runtype}") String spRunTypeParam, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, PcpService pcpService) {
        log.debug("Inside callStoredProcedureStep() in PCPAncillarySteps class");
        String selectiveLoad = (isSelectiveLoad.equals("Y")) ? "Y" : "N";
        log.info("Selective load : {}", selectiveLoad);
        return new StepBuilder(Constant.PROCESS_STEP_SP,jobRepository).tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    StepExecution stepExecution = chunkContext.getStepContext().getStepExecution();
                    log.info("Calling StoredProcedure Enabled  : {}", spEnabled);
                    if(spEnabled) { // check if calling stored procedure enabled
                        pcpService.callStoredProcedureService(stepExecution, spRunTypeParam,selectiveLoad);
                    }
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .transactionManager(platformTransactionManager)
                .build();
    }

    /**
     * @return Step for calling login service for getting token
     */
    @Bean
    @Qualifier("callLoginServiceStep")
    public Step callLoginServiceStep(JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, LoginService loginService) {
        log.info("Inside callLoginServiceStep() in PCPAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_SF_LOGIN,jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    loginService.callLoginService(chunkContext.getStepContext().getStepExecution());
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler).build();
    }

    @Bean
    @Qualifier("updateLastRuntimeStep")
    public Step updateLastRuntimeStep( CountUpdateListener  countUpdateListener,JobRepository jobRepository, PlatformTransactionManager platformTransactionManager) {
        log.info("Inside updateLastRuntimeStep() in PCPAncillarySteps class");
        return new StepBuilder(Constant.PROCESS_STEP_UPDATE_RUNTIME, jobRepository)
                .tasklet((StepContribution stepContribution, ChunkContext chunkContext) -> {
                    if (!isSelectiveLoad.equalsIgnoreCase("Y")) {
                        ExecutionContext executionContext = chunkContext
                                .getStepContext().getStepExecution().getJobExecution().getExecutionContext();
                        runTimeService.updateRuntime(executionContext);
                    }
                    return RepeatStatus.FINISHED;
                }, platformTransactionManager)
                .transactionManager(platformTransactionManager)
                .listener(exceptionListener)
                .exceptionHandler(taskletExceptionHandler)
                .listener(countUpdateListener) // To update success and failure count before this step
                .build();
    }
}

