package com.usthealthproof.eplus.commons.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.healthcloud.HealthCloudPcpRecord;

public interface PcpHealthCloudAdapterMapping {
     void updateRecord(MemberPcp entity, HealthCloudPcpRecord pcpRecord);

}
