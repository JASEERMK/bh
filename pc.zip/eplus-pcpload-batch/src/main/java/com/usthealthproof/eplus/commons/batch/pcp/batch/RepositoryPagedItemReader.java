package com.usthealthproof.eplus.commons.batch.pcp.batch;

/*
 * Copyright 2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"),
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *
 * --------------------------------------------------------------------
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.adapter.DynamicMethodInvocationException;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.MethodInvoker;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * A {@link org.springframework.batch.item.ItemReader} that reads records
 * utilizing a
 * {@link PagingAndSortingRepository}.
 * </p>
 *
 * <p>
 * Performance of the reader is dependent on the repository implementation,
 * however setting a reasonably large page size and matching that to the commit
 * interval should yield better performance.
 * </p>
 *
 * <p>
 * The reader must be configured with a
 * {@link PagingAndSortingRepository}, a
 * {@link Sort}, and a pageSize greater than 0.
 * </p>
 *
 * <p>
 * This implementation is thread-safe between calls to
 * {@link #open(ExecutionContext)}, but remember to use
 * <code>saveState=false</code> if used in a multi-threaded client (no restart
 * available).
 * </p>
 */
public class RepositoryPagedItemReader extends AbstractItemCountingItemStreamItemReader<List<MemberPcp>>
implements InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(RepositoryPagedItemReader.class);

    private MemberPcpRepository<MemberPcp> repository;

    private Sort sort;

    protected int page = 0;

    private int pageSize = 10;

    private List<?> arguments;

    private List<List<BigDecimal>> results;

    private final Object lock = new Object();

    private String methodName;

    public RepositoryPagedItemReader() {
        setName(ClassUtils.getShortName(RepositoryPagedItemReader.class));
    }

    /**
     * Arguments to be passed to the data providing method.
     *
     * @param arguments
     *            list of method arguments to be passed to the repository
     */
    public void setArguments(List<?> arguments) {
        this.arguments = arguments;
    }

    /**
     * Provides ordering of the results so that order is maintained between
     * paged queries
     *
     * @param sorts
     *            the fields to sort by and the directions
     */
    public void setSort(Map<String, Sort.Direction> sorts) {
        this.sort = convertToSort(sorts);
    }

    /**
     * @param pageSize
     *            The number of items to retrieve per page.
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * The
     * {@link PagingAndSortingRepository}
     * implementation used to read input from.
     *
     * @param repository
     *            underlying repository for input to be read from.
     */
    public void setRepository(MemberPcpRepository repository) {
        this.repository = repository;
    }

    /**
     * Specifies what method on the repository to call. This method must take
     * {@link Pageable} as the <em>last</em>
     * argument.
     */
    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public void setPage(int page) {
        this.page = page;
    }

    @Override
    public void afterPropertiesSet() {
        Assert.state(repository != null, "A PagingAndSortingRepository is required");
        Assert.state(pageSize > 0, "Page size must be greater than 0");
        Assert.state(sort != null, "A sort is required");
    }

    @Override
    protected List<MemberPcp> doRead() {

        synchronized (lock) {
            if (results == null) {
                if (-1 == page) {
                    return null;
                }
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug(
                            "Reading page " + page + " in doRead  synchronized method in RepositoryPagedItemReader ");
                }
                results = doPageRead();
                page = -1;
                if (results.isEmpty()) {
                    return null;
                }
            }

            if (!results.isEmpty()) {
                List<BigDecimal> memberPcpIdList = results.get(0);
                List<MemberPcp> curList = repository.findByPcpCilIdIn(memberPcpIdList);
                results.remove(0);
                return curList;
            } else {
                return null;
            }
        }
    }

    @Override
    protected void jumpToItem(int itemLastIndex) {
        synchronized (lock) {
            page = (itemLastIndex - 1) / pageSize;
            results = doPageRead();
            page++;
        }
    }

    /**
     * Performs the actual reading of a page via the repository. Available for
     * overriding as needed.
     *
     * @return the list of items that make up the page
     */
    @SuppressWarnings("unchecked")
    protected List<List<BigDecimal>> doPageRead() {
        Pageable pageRequest = PageRequest.of(page, pageSize, sort);

        MethodInvoker invoker = createMethodInvoker(repository, methodName);

        List<Object> parameters = new ArrayList<>();

        /**
         * Changed as args were not passed
         */


        if (arguments != null && !arguments.isEmpty()) {
            parameters.addAll(arguments);
        }

        parameters.add(pageRequest);

        invoker.setArguments(parameters.toArray());

        ArrayList<BigDecimal> curPage= (ArrayList<BigDecimal>) doInvoke(invoker);
        return new ArrayList<>(ListUtils.partition(curPage, 10));
    }

    @Override
    protected void doOpen() {
        // Comment to avoid sonar issue Methods should not be empty squid : S1186.
    }

    @Override
    protected void doClose() {
        synchronized (lock) {
            page = 0;
            results = null;
        }
    }

    private Sort convertToSort(Map<String, Sort.Direction> sorts) {
        List<Sort.Order> sortValues = new ArrayList<>();

        for (Map.Entry<String, Sort.Direction> curSort : sorts.entrySet()) {
            sortValues.add(new Sort.Order(curSort.getValue(), curSort.getKey()));
        }

        return Sort.by(sortValues);//Updated
    }

    private Object doInvoke(MethodInvoker invoker) {
        try {
            invoker.prepare();
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            throw new DynamicMethodInvocationException(e);
        }

        try {
            return invoker.invoke();
        } catch (InvocationTargetException | IllegalAccessException e) {
            throw new DynamicMethodInvocationException(e);
        }
    }

    private MethodInvoker createMethodInvoker(Object targetObject, String targetMethod) {
        MethodInvoker invoker = new MethodInvoker();
        invoker.setTargetObject(targetObject);
        invoker.setTargetMethod(targetMethod);
        return invoker;
    }
}
