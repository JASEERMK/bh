package com.usthealthproof.eplus.commons.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud.ServiceCloudPcpRecord;

public interface PcpServiceCloudAdapterMapping {
     void updateScRecord(MemberPcp entity, ServiceCloudPcpRecord pcpRecord);
}
