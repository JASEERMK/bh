package com.usthealthproof.eplus.commons.batch.pcp.db.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 210409
 */
@Data
@MappedSuperclass
public class MemberPcp {

    @Id
    @Column(name = "PCP_CIL_ID")
    private BigDecimal pcpCilId;

    @Column(name = "CIL_PCP_KEY")
    private String cilPcpKey;

    @Column(name = "PROVIDER_ID")
    private String providerId;

    @Column(name = "HC_PRACTITIONER_FACILITY")
    private String hcPractitionerFacility;

    @Column(name = "MEMBER_ID")
    private String memberId;

    @Column(name = "PANEL")
    private String panel;

    @Column(name = "PCP_START_DATE")
    private Date pcpStartDate;

    @Column(name = "PCP_END_DATE")
    private Date pcpEndDate;

    @Column(name = "AUTO_ASIGNED")
    private String autoAssigned;

    @Column(name = "IS_CURRENT")
    private String isCurrent;

    @Column(name = "PROVIDER_NAME")
    private String providerName;

    @Column(name = "PCP_PHONE")
    private String pcpPhone;

}
