package com.usthealthproof.eplus.commons.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.exception.SkippedItemsExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import com.usthealthproof.eplus.commons.batch.pcp.util.MappingUtil;
import com.usthealthproof.eplus.commons.batch.pcp.util.ServiceCloudMappingUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class PcpDataProcessingSteps {

    protected static final String OVERRIDDEN_BY_EXPRESSION = null;
    protected static final ServiceCloudMappingUtil OVERRIDDEN_BY_EXPRESSION_MAPPING_UTIL = null;
    private static final String FIND_ALL_PCP = "findKeys";
    private static final String STEP_EXECUTION_CONTEXT_START = "#{stepExecutionContext['";
    private static final String STEP_EXECUTION_CONTEXT_END = "']}";
    private static final String STEP_CONTEXT_CURRENT_PAGE = "CURRENT_PAGE";

    private static int pageSize = 0;

    private MemberPcpRepository<MemberPcp> memberPcpRepository;

    private PcpService pcpService;

    private Environment env;

    private SkippedItemsExceptionListener skippedItemsExceptionListener;
    @Autowired
    public PcpDataProcessingSteps(@Qualifier(value = "PcpAdapterRepository") MemberPcpRepository memberPcpRepository,
                                  PcpService pcpService, Environment env,
                                  SkippedItemsExceptionListener skippedItemsExceptionListener) {
        this.memberPcpRepository = memberPcpRepository;
        this.pcpService = pcpService;
        this.env = env;
        this.skippedItemsExceptionListener = skippedItemsExceptionListener;

    }

    @Bean
    @Qualifier("pcpLoadStep")
    public Step supplierLoadStep(ItemWriter<List<PcpGraphRequest>> itemWriter, @Qualifier("asyncExecutor") TaskExecutor executor, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, @Qualifier("pcpMappingUtil") MappingUtil mappingUtil)  {
        log.info("Inside supplierLoadStep() in PcpDataProcessingSteps class");
        return getPcpProcessingStep(itemWriter, executor,jobRepository,platformTransactionManager, mappingUtil);
    }

    @Bean
    @StepScope
    public RepositoryPagedItemReader reader(
            @Value(STEP_EXECUTION_CONTEXT_START + STEP_CONTEXT_CURRENT_PAGE + STEP_EXECUTION_CONTEXT_END) String currentPage) {
        log.info("Inside reader() in PcpDataProcessingSteps class");
        log.info("Repo Reader Initialization Current Page {} ", currentPage);
        RepositoryPagedItemReader reader = new RepositoryPagedItemReader();
        reader.setRepository(memberPcpRepository);
        reader.setMethodName(FIND_ALL_PCP);
        reader.setPage(Integer.parseInt(currentPage));
        reader.setPageSize(pageSize);
        Map<String, Sort.Direction> sorts = new HashMap<>();
        sorts.put("PCP_CIL_ID", Sort.Direction.ASC);
        reader.setSort(sorts);
        return reader;
    }

    @Bean
    public ItemProcessor<List<MemberPcp>, List<PcpGraphRequest>> processor(@Qualifier("pcpMappingUtil") MappingUtil mappingUtil) {
        log.debug("Inside ItemProcessor() in PcpDataProcessingSteps class");
        return pcpBatchList -> pcpBatchList.stream().map(mappingUtil::createMemberPcpRequest
        ).toList();
    }

    @Bean
    public ItemWriter<List<PcpGraphRequest>> write() {
        log.debug("Inside ItemWriter() in PcpDataProcessingSteps class");

        return new ItemWriter<List<PcpGraphRequest>>() {
            private StepExecution stepExecution;

            @BeforeStep
            public void beforeStep(StepExecution stepExecution) {
                this.stepExecution = stepExecution;
            }
            public void write(Chunk<? extends List<PcpGraphRequest>> accountRequests)  {
                log.debug("Inside item writer ");
                writePcp(accountRequests, stepExecution);
            }
        };
    }

    private void writePcp(Chunk<? extends List<PcpGraphRequest>> accountRequests2, StepExecution stepExecution) {
        List<PcpGraphRequest> accountRequests = filterAccountList(accountRequests2);
        List<Graphs> graphRequests = splitAccountRequestList(accountRequests);
        graphRequests.forEach(graphs -> pcpService.addMemberPCPService(graphs, stepExecution));
        log.debug("Graph Requests {} ", CommonUtils.getObjectAsString(graphRequests));
    }

    private List<PcpGraphRequest> filterAccountList(Chunk<? extends List<PcpGraphRequest>> accountRequests2) {
        Map<String,PcpGraphRequest> accountRequestMap = new HashMap<>();
        accountRequests2.forEach(accountRequests -> accountRequests.forEach(accountRequest -> {
            PcpGraphRequest req = accountRequestMap.get(accountRequest.getGraphId());
            if(req == null) {
                accountRequestMap.put(accountRequest.getGraphId(), accountRequest);
            } else {
                req.getCompositeRequest().addAll(accountRequest.getCompositeRequest());
            }
        }));
        return new ArrayList<>(accountRequestMap.values());
    }


    /**
     * If a Graph request exceeding 500 limit, splitting the request and creating a
     * new graph request to limit graph objects below 500
     *
     * @param graphRequestMain main graph request
     * @return List<Graphs> converted graph request
     */
    private List<Graphs> splitAccountRequestList(List<PcpGraphRequest> graphRequestMain) {
        int size = 0;
        log.debug("Size of AccountRequest Received {} ", graphRequestMain.size());
        List<Graphs> listOfGraphRequest = new ArrayList<>();
        List<PcpGraphRequest> accountReqListForGraphReq = new ArrayList<>();
        listOfGraphRequest.add(Graphs.builder().pcpGraphRequests(accountReqListForGraphReq).build());
        for (PcpGraphRequest request : graphRequestMain) {
            size += request.getCompositeRequest().size();
            /**Logic to limit maximum composite request to 500
             * or maximum account requests to 30 which ever comes first **/
            if (size > 500 || accountReqListForGraphReq.size() == 30 ) {
                size = request.getCompositeRequest().size();
                accountReqListForGraphReq = new ArrayList<>();
                listOfGraphRequest.add(Graphs.builder().pcpGraphRequests(accountReqListForGraphReq).build());
            }
            accountReqListForGraphReq.add(request);
        }

        return listOfGraphRequest;
    }

    private Step getPcpProcessingStep(ItemWriter<List<PcpGraphRequest>> itemWriter, TaskExecutor executor, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, @Qualifier("pcpMappingUtil") MappingUtil mappingUtil) {
        Step step = getChunkStep(itemWriter,jobRepository,platformTransactionManager, mappingUtil);
        return getPartitionerStep(step, executor,jobRepository);
    }

    private TaskletStep getChunkStep(ItemWriter<List<PcpGraphRequest>> itemWriter, JobRepository jobRepository, PlatformTransactionManager platformTransactionManager, @Qualifier("pcpMappingUtil") MappingUtil mappingUtil) {
        return new StepBuilder(Constant.PROCESS_STEP_SF_DATA_LOAD,jobRepository)
                .<List<MemberPcp>, List<PcpGraphRequest>>chunk(Integer.parseInt(env.getProperty("batch.execution.chunk-size")),platformTransactionManager)
                .reader(reader(OVERRIDDEN_BY_EXPRESSION))
                .processor(processor(OVERRIDDEN_BY_EXPRESSION_MAPPING_UTIL))
                .writer(itemWriter)
                .faultTolerant()
                .skip(Exception.class)
                .skipLimit(1000)
                .processorNonTransactional()
                .listener((StepExecutionListener) skippedItemsExceptionListener)
                .build();
    }

    private Step getPartitionerStep(Step step, TaskExecutor executor,JobRepository jobRepository ) {
        return new StepBuilder("stepPartition_pcp",jobRepository)
                .partitioner(step)
                .partitioner("stepPartition", getPartitioner())
                .taskExecutor(executor)
                .build();
    }

    Partitioner getPartitioner() {

        return gridSize -> {
            log.info("Inside partition Function");
            Map<String, ExecutionContext> result = new HashMap<>();
            Long totalRecords = memberPcpRepository.count();
            log.info("The totalRecords available in database :{} ", totalRecords);
            Long preferredPartitionSize = Long.valueOf(env.getProperty("batch.execution.partition-count"));
            double partitionSize = totalRecords.doubleValue() / preferredPartitionSize.doubleValue();
            pageSize = (int) Math.ceil(partitionSize);
            Long numberOfThreads = preferredPartitionSize;
            if (partitionSize < 1) {
                numberOfThreads = totalRecords;
            }
            log.info("The Number of threads that will be spawned :{}", numberOfThreads);
            int index;
            for (index = 0; index < numberOfThreads; index++) {
                ExecutionContext value = new ExecutionContext();
                value.putInt(STEP_CONTEXT_CURRENT_PAGE, index);
                result.put("partition" + index, value);
            }
            return result;
        };
    }

}
