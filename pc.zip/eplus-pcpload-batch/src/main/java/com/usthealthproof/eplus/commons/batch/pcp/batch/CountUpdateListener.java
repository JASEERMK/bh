package com.usthealthproof.eplus.commons.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author 210409
 *
 */
@Component
@StepScope
public class CountUpdateListener implements StepExecutionListener {

    @Autowired
    PcpService pcpService;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        pcpService.updateSFDataLoadSuccessAndErrorCountAudit(stepExecution);
    }

    @Override
    public                ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }
}
