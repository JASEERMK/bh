package com.usthealthproof.eplus.commons.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.common.model.request.CompositeRequest;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.healthcloud.HealthCloudPcpRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.BLANK_STRING;
import static com.usthealthproof.eplus.commons.batch.common.util.CommonUtils.*;

/**
 * @author 210409
 */
@Slf4j
@Component
public class HealthCloudMappingUtil implements MappingUtil {

    @Value("${pcp.record.service.url}")
    private String pcpRecordServiceUrl;

    @Autowired
    PcpHealthCloudAdapterMapping clientMapping;

    /**
     * This is the main bean method which creates pcp batch request which contain pcp info.
     *
     * @param data pcp data
     * @return converted account request
     */
    public PcpGraphRequest createMemberPcpRequest(MemberPcp data) {

        HealthCloudPcpRecord pcpRecord = getPcpInfo(data);
        if (pcpRecord == null) {
            return null;
        }
        List<CompositeRequest> requests = new ArrayList<>();
        clientMapping.updateRecord(data, pcpRecord);
        CompositeRequest pcpRecordRequest = new CompositeRequest();
        String externalId = data.getCilPcpKey();
        pcpRecordRequest.setUrl(pcpRecordServiceUrl.concat(externalId));
        pcpRecordRequest.setReferenceId(formatRefId(externalId));
        pcpRecordRequest.setBody(pcpRecord);
        requests.add(pcpRecordRequest);

        PcpGraphRequest request = new PcpGraphRequest();
        request.setGraphId("PCP_".concat(externalId));
        request.setCompositeRequest(requests);
        return request;
    }

    /**
     * pcp record mapping
     */
    private HealthCloudPcpRecord getPcpInfo(MemberPcp data) {
        if (data.getCilPcpKey() == null) {
            return null;
        }
        HealthCloudPcpRecord pcpRecord = new HealthCloudPcpRecord();

        if (null != data.getMemberId()) {
            pcpRecord.setMemberKey(Map.of("UST_EPLUS__CIL_Member_Key__c", data.getMemberId()));
        } else {
            pcpRecord.setMemberReferenceKey(BLANK_STRING);
        }

        if (null != data.getProviderId()) {
            pcpRecord.setProviderNameKey(Map.of("UST_EPLUS__CIL_Provider_Key__c", data.getProviderId()));
        } else {
            pcpRecord.setProviderNameReferenceKey(BLANK_STRING);
        }

        if (null != data.getHcPractitionerFacility()) {
            pcpRecord.setPractitionerFacilityKey(
                    Map.of("UST_EPLUS__CIL_Practitioner_Facility_Key__c", data.getHcPractitionerFacility()));
        } else {
            pcpRecord.setPractitionerFacilityReferenceKey(BLANK_STRING);
        }
        pcpRecord.setPanel((data.getPanel()));
        pcpRecord.setIsCurrentPCP(validateBooleanValueYorN(data.getIsCurrent()));

        if (data.getPcpEndDate() != null) {
            String date = extractDate(data.getPcpEndDate());
            pcpRecord.setPcpEndDate(date);
        }
        if (data.getPcpStartDate() != null) {
            String date = extractDate(data.getPcpStartDate());
            pcpRecord.setPcpStartDate(date);
        }
        pcpRecord.setPcpName(data.getProviderName());
        pcpRecord.setPcpPhone(data.getPcpPhone());
        pcpRecord.setAutoAssigned(validateBooleanValue(data.getAutoAssigned()));
        return pcpRecord;
    }

    private String formatRefId(String referenceId) {
        return CommonUtils.removeSpecialCharacter(referenceId.replace("-", "_"));
    }
}
