package com.usthealthproof.eplus.commons.batch.pcp.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.usthealthproof.eplus.commons.batch.common.model.request.Body;
import lombok.Data;

import java.util.Map;

@Data
public abstract class PcpRequest extends Body {
    @JsonProperty("UST_EPLUS__Member__r")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Map<String, String> memberKey;

    @JsonProperty("UST_EPLUS__Member__c")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String memberReferenceKey;

    @JsonProperty("UST_EPLUS__Panel__c")
    private String panel;

    @JsonProperty("UST_EPLUS__PCP_Start_Date__c")
    private String pcpStartDate;

    @JsonProperty("UST_EPLUS__PCP_End_Date__c")
    private String pcpEndDate;

    @JsonProperty("Name")
    private String pcpName;

    @JsonProperty("UST_EPLUS__Is_Current_PCP__c")
    private String isCurrentPCP;

    @JsonProperty("UST_EPLUS__PCP_Phone__c")
    private String pcpPhone;

    @JsonProperty("UST_EPLUS__Auto_Assigned__c")
    private String autoAssigned;

    // New field mapping end here
    // Map for adding client specific fields which is not in product

}
