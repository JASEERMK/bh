package com.usthealthproof.eplus.commons.batch.pcp.config.constant;

public class PcpConstant {

    private PcpConstant() {}

    /*DB Params*/
    public static final String PARAMETER_GET_PCP_DETAILS_SP = "GET_PCP_DETAILS_SP";
    public static final String PCP_TOTAL_COUNT = "MemberPCPTotalCount";
    public static final String PCP_SUCCESS_COUNT = "MemberPCPSuccessCount";
    public static final String PCP_FAILURE_COUNT = "MemberPCPFailureCount";

}
