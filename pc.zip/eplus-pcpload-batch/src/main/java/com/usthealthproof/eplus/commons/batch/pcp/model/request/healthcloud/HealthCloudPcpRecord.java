package com.usthealthproof.eplus.commons.batch.pcp.model.request.healthcloud;

import com.fasterxml.jackson.annotation.*;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpRequest;
import lombok.Data;

import java.util.Map;

@Data
public class HealthCloudPcpRecord extends PcpRequest {


	@JsonProperty("UST_EPLUS__Healthcare_Practitioner_Facility__r")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Map<String, String> practitionerFacilityKey;

	@JsonProperty("UST_EPLUS__Healthcare_Practitioner_Facility__c")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String practitionerFacilityReferenceKey;

	@JsonProperty("UST_EPLUS__Provider_Name__r")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Map<String, String> providerNameKey;

	@JsonProperty("UST_EPLUS__Provider_Name__c")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String providerNameReferenceKey;


}
