package com.usthealthproof.eplus.commons.batch.pcp.config;

import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.db.entity.AuditBatch;
import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @author 210409
 */
@Slf4j
@Configuration
public class JobConfiguration {


    @Autowired
    private PcpService pcpService;

    @Autowired
    private JobAuditListener jobAuditListener;

    @Autowired
    private AuditErrorMessageUtil auditErrorMessageUtil;

    protected static final Step OVERRIDDEN_STEP_BY_EXPRESSION = null;
    @Autowired
    public JobConfiguration(PcpService pcpService, JobAuditListener jobAuditListener) {
        this.pcpService = pcpService;
        this.jobAuditListener = jobAuditListener;
    }

    @Bean
    public Job profileUpdateJob(@Qualifier("readRuntimeStep") Step readRuntimeStep,
                                @Qualifier("callStoredProcedureStep") Step callStoredProcedure,
                                @Qualifier("callLoginServiceStep") Step callLoginService,
                                @Qualifier("pcpLoadStep") Step pcpLoadStep,
                                @Qualifier("updateLastRuntimeStep") Step updateLastRuntimeStep, JobRepository jobRepository, PlatformTransactionManager transactionManager,AuditService auditService) {
        Job job = null;
        try {
            job = new JobBuilder("pcpBatchJob",jobRepository).incrementer(new RunIdIncrementer())
                    .listener(getJobListenerCount())
                    .listener(jobAuditListener)
                    .start(readRuntimeStep)
                    .next(callStoredProcedure)
                    .next(callLoginService)
                    .next(pcpLoadStep)
                    .next(updateLastRuntimeStep)
                    .build();
        } catch (Exception e) {
            log.error("Exception while running the job ", e);
            List<AuditBatch> auditBatchList = auditErrorMessageUtil.auditException(null,e, Constant.PROCESS_JOB);
            if(!CollectionUtils.isEmpty(auditBatchList)) {
                auditService.auditException(auditBatchList);
            }
        }
        return job;
    }

    public JobExecutionListener getJobListenerCount() {
        return new JobExecutionListener() {
            @Override
            public void beforeJob(JobExecution jobExecution) {
                pcpService.resetCounter();
            }

            @Override
            public void afterJob(JobExecution jobExecution) {
                pcpService.resetCounter();
            }
        };
    }
    @Scheduled(cron = "${batch.schedule}")
    public void launchJob() throws Exception {
        JobParameters param = new JobParametersBuilder().addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        taskExecutorJobLauncher(null)
                .run(profileUpdateJob(OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        OVERRIDDEN_STEP_BY_EXPRESSION, OVERRIDDEN_STEP_BY_EXPRESSION,
                        OVERRIDDEN_STEP_BY_EXPRESSION,
                        null, null, null), param);
    }

    @Bean
    public TaskExecutorJobLauncher taskExecutorJobLauncher(JobRepository jobRepository) {
        TaskExecutorJobLauncher launcher = new TaskExecutorJobLauncher();
        launcher.setJobRepository(jobRepository);
        return launcher;
    }


}
