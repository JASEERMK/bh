package com.usthealthproof.eplus.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.pcp.batch.RepositoryPagedItemReader;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.adapter.DynamicMethodInvocationException;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
class RepositoryPagedItemReaderTest {

    @InjectMocks
    private RepositoryPagedItemReader repositoryPagedItemReader;

    @Mock
    private MemberPcpRepository repository;

    @Mock
    private ExecutionContext executionContextMock;

    @BeforeEach
    void setUp() {
        repositoryPagedItemReader.setRepository(repository);
        repositoryPagedItemReader.setPageSize(10);
        Map<String, Sort.Direction> sortMap = new HashMap<>();
        sortMap.put("propertyName1", Sort.Direction.ASC);
        sortMap.put("propertyName2", Sort.Direction.DESC);
        repositoryPagedItemReader.setSort(sortMap);
    }

    @Test
    void testAfterPropertiesShouldPass() throws Exception {
        repositoryPagedItemReader.afterPropertiesSet();
    }

    @Test
    void testAfterPropertiesShouldThrowException() {
        repositoryPagedItemReader.setRepository(null);

        assertThrows(IllegalStateException.class, () -> {
            repositoryPagedItemReader.afterPropertiesSet();
        });
    }

    @Test
    void testAfterPropertiesSetPageSizeIsZero() {
        repositoryPagedItemReader.setPageSize(0);

        assertThrows(IllegalStateException.class, () -> {
            repositoryPagedItemReader.afterPropertiesSet();
        });
    }

    @Test
    void testSortIsNullShouldThrowException() {

        assertThrows(NullPointerException.class, () -> {
            repositoryPagedItemReader.setSort(null);;
        });
    }

    @Test
    void testDoReadShouldThrowNoSuchMethod() throws IllegalAccessException, NoSuchFieldException {
        Field methodNameField = repositoryPagedItemReader.getClass().getDeclaredField("methodName");
        methodNameField.setAccessible(true);
        methodNameField.set(repositoryPagedItemReader, "testMethod");

        assertThrows(DynamicMethodInvocationException.class, () -> {
            repositoryPagedItemReader.read();
        });
    }

    @Test
    void testDoOpenShouldInitializeState() throws IllegalAccessException, NoSuchFieldException {
        repositoryPagedItemReader.open(executionContextMock);
        Field pageField = repositoryPagedItemReader.getClass().getDeclaredField("page");
        pageField.setAccessible(true);
        int page = (int) pageField.get(repositoryPagedItemReader);
        assertEquals(0, page);
        Field resultsField = repositoryPagedItemReader.getClass().getDeclaredField("results");
        resultsField.setAccessible(true);
        Object results = resultsField.get(repositoryPagedItemReader);
        assertNull(results);
    }


    @Test
    void testDoCloseShouldResetState() throws NoSuchFieldException, IllegalAccessException {
        repositoryPagedItemReader.close();
        Field pageField = repositoryPagedItemReader.getClass().getDeclaredField("page");
        pageField.setAccessible(true);
        int page = (int) pageField.get(repositoryPagedItemReader);
        assertEquals(0, page);
        Field resultsField = repositoryPagedItemReader.getClass().getDeclaredField("results");
        resultsField.setAccessible(true);
        Object results = resultsField.get(repositoryPagedItemReader);
        assertNull(results);
    }

}
