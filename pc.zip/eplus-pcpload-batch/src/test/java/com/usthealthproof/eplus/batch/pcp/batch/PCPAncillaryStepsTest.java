package com.usthealthproof.eplus.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.common.exception.ExceptionListener;
import com.usthealthproof.eplus.commons.batch.common.exception.TaskletExceptionHandler;
import com.usthealthproof.eplus.commons.batch.common.model.response.RecordIdMainResponse;
import com.usthealthproof.eplus.commons.batch.common.service.LoginService;
import com.usthealthproof.eplus.commons.batch.common.service.RuntimeService;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.pcp.batch.CountUpdateListener;
import com.usthealthproof.eplus.commons.batch.pcp.batch.PCPAncillarySteps;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class PCPAncillaryStepsTest {
    @Mock
    private StepBuilder stepBuilder;

    @Mock
    private ExecutionContext executionContext;

    @Mock
    private ChunkContext chunkContextMock;
    @Mock
    private StepContext stepContextMock;

    @Mock
    JobExecution jobExecutionMock;
    @Mock
    private static StepExecution stepExecutionMock;

    @Mock
    private RuntimeService runTimeServiceMock;

    @Mock
    private ExceptionListener exceptionListenerMock;

    @Mock
    private TaskletExceptionHandler taskletExceptionHandlerMock;

    @Mock
    private ExecutionContext executionContextMock;
    @Mock
    private JobRepository jobRepositoryMock;

    @Mock
    private PlatformTransactionManager platformTransactionManagerMock;

    @Mock
    private PCPAncillarySteps pcpAncillarySteps;
    @Mock
    private PcpService pcpService;
    @Mock
    LoginService loginServiceMock;
    @Mock
    CountUpdateListener countUpdateListenerMock;
    @Mock
    JobInstance jobInstanceMock;

    @Mock
    CommonUtils commonUtilsMock;
    @Mock
    RecordIdMainResponse recordIdMainResponseMock;
    @BeforeEach
    public void setUp() {
        TransactionSynchronizationManager.initSynchronization();
        MockitoAnnotations.openMocks(this);
        pcpAncillarySteps = new PCPAncillarySteps(runTimeServiceMock, taskletExceptionHandlerMock, exceptionListenerMock);
    }

    @AfterEach
    public void setDown() {
        TransactionSynchronizationManager.clear();
    }

    void initialise(String stepName) {
        ReflectionTestUtils.setField(pcpAncillarySteps, "spEnabled", true);

        when(stepExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        // Set the stepName in StepExecution
        when(stepExecutionMock.getStepName()).thenReturn(stepName);
    }
@Test
    void testReadRuntimeStep() throws Exception {
        log.info("inside testReadRuntimeStep");
        initialise("ReadRunTimeStep");
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        doNothing().when(runTimeServiceMock).readRuntime(any(ExecutionContext.class));
        pcpAncillarySteps.readRuntimeStep(jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(runTimeServiceMock).readRuntime(eq(executionContextMock));

        // verify(runTimeServiceMock).readRuntime(executionContext);
    }

    @Test
        //@Transactional
    void callStoredProcedureStep() throws Exception {
        log.info("inside callStoredProcedureStep");
        String runType = "NORMAL";
        initialise("StoredProcedureStep");
        ReflectionTestUtils.setField(pcpAncillarySteps, "isSelectiveLoad", "N");
        pcpAncillarySteps.callStoredProcedureStep(runType, jobRepositoryMock, platformTransactionManagerMock, pcpService)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(pcpService).callStoredProcedureService(stepExecutionMock, runType, "N");
    }

    @Test
    void loginTest() throws JobInterruptedException {
        log.info("inside loginTest");
        initialise("CallLoginServiceStep");
        //executing callLoginServiceStep()
        pcpAncillarySteps.callLoginServiceStep( jobRepositoryMock, platformTransactionManagerMock,loginServiceMock).execute(stepExecutionMock);
        //verify it is executed
        verify(loginServiceMock).callLoginService(stepExecutionMock);
    }

    @Test
    void testLastRuntimeStep() throws Exception {
        log.info("inside testLastRuntimeStep");
        initialise("UpdateLastRuntimeStep");
        ReflectionTestUtils.setField(pcpAncillarySteps, "isSelectiveLoad", "N");
        when(jobExecutionMock.getJobInstance()).thenReturn(jobInstanceMock);
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        doNothing().when(runTimeServiceMock).updateRuntime(any(ExecutionContext.class));
        pcpAncillarySteps.updateLastRuntimeStep(countUpdateListenerMock, jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);
        // Verify that the runTimeService.readRuntime() method was called with the ExecutionContext
        verify(runTimeServiceMock).updateRuntime(eq(executionContextMock));

    }

    @Test
    void testLastRuntimeStepForSelectiveLoad() throws Exception {
        log.info("inside testLastRuntimeStep");
        initialise("UpdateLastRuntimeStep");
        ReflectionTestUtils.setField(pcpAncillarySteps, "isSelectiveLoad", "Y");
        when(jobExecutionMock.getJobInstance()).thenReturn(jobInstanceMock);
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        //when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        //doNothing().when(runTimeServiceMock).updateRuntime(any(ExecutionContext.class));
        pcpAncillarySteps.updateLastRuntimeStep(countUpdateListenerMock, jobRepositoryMock, platformTransactionManagerMock)
                .execute(stepExecutionMock);

    }

}
