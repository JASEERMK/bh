package com.usthealthproof.eplus.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.util.PcpExceptionUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class PcpExceptionUtilTest {
    @InjectMocks
    private PcpExceptionUtil pcpExceptionUtil;



    @Test
    public void tesGetProcessErrorDetails() {
        // Test data
        List<MemberPcp> memberPcpList = new ArrayList<>();
        MemberPcp memberPcp = new MemberPcp(); // Assuming ProviderBatch is a class
        memberPcpList.add(memberPcp);
        // Test invocation
        List<Map<String, String>> result = pcpExceptionUtil.getProcessErrorDetails(memberPcpList, true);
        // Assertion
        assertEquals(1, result.size());
        // Test invocation with null
        List<Map<String, String>> nullResult = pcpExceptionUtil.getProcessErrorDetails(null, true);
        assertNull(nullResult);
    }
    @Test
    public void testGetWriteErrorDetails() {
        String providerIdMock = "providerId";
        List<PcpGraphRequest> pcpGraphRequests = new ArrayList<>();
        PcpGraphRequest pcpGraphRequest = new PcpGraphRequest(); // Assuming AccountRequest is a class
        pcpGraphRequest.setGraphId(providerIdMock);
        pcpGraphRequests.add(pcpGraphRequest);

        // Test invocation
        List<Map<String, String>> result = pcpExceptionUtil.getWriteErrorDetails(pcpGraphRequests, true);

        // Assertion
        assertEquals(1, result.size());
        Map<String, String> processError = result.get(0);
        assertEquals(providerIdMock, processError.get("graphId"));
        assertEquals(providerIdMock, processError.get("referenceId"));

        // Test invocation with null
        List<Map<String, String>> nullResult = pcpExceptionUtil.getWriteErrorDetails(null, true);
        assertNull(nullResult);


    }
}
