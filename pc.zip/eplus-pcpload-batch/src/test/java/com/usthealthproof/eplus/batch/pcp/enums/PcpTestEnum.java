package com.usthealthproof.eplus.batch.pcp.enums;

public enum PcpTestEnum {

	PCP_PANEL("PcpPanel"),
	PROVIDER_NAME("Provider"),
	Y("Y"),
	CIL_PCP_KEY("345454"),
	PHONE("1234567890"),
	PROVIDER_ID("54366"),
	MEMBER_ID("48756"),
	PCP_CIL_ID("634632453"),
	HC_PF("7721323"),
	START_DATE("2020-12-12"),
	END_DATE("2022-12-12");

	private String value;

	PcpTestEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}