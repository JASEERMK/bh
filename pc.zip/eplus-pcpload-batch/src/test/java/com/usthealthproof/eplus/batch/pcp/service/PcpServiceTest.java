package com.usthealthproof.eplus.batch.pcp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.usthealthproof.eplus.commons.batch.common.constant.Constant;
import com.usthealthproof.eplus.commons.batch.common.model.response.CompositeResponse;
import com.usthealthproof.eplus.commons.batch.common.model.response.Graph;
import com.usthealthproof.eplus.commons.batch.common.model.response.GraphResponse;
import com.usthealthproof.eplus.commons.batch.common.service.AdhocService;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.common.service.RestCallService;
import com.usthealthproof.eplus.commons.batch.common.service.SpErrorLogService;
import com.usthealthproof.eplus.commons.batch.common.util.AuditErrorMessageUtil;
import com.usthealthproof.eplus.commons.batch.common.util.CommonUtils;
import com.usthealthproof.eplus.commons.batch.common.util.DateUtil;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.response.PcpBatchLoadResponse;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpAdapterService;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.usthealthproof.eplus.commons.batch.common.constant.AuditConstants.PROCESS_STATUS_SUCCESS_VALUE;
import static com.usthealthproof.eplus.commons.batch.common.constant.Constant.RESPONSE_TEXT;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PcpServiceTest {

    @InjectMocks
    private PcpService pcpService;

    @Mock
    private MemberPcpRepository memberPcpRepository;

    @Mock
    private AuditService auditService;
    @Mock
    private DateUtil dateUtil;
    @Mock
    private RestCallService<PcpBatchLoadResponse> restCallService;

    @Mock
    private AdhocService adhocService;

    @Mock
    private PcpAdapterService pcpAdapterService;
    @Mock
    private SpErrorLogService spErrorLogService;
    @Mock
    private AuditErrorMessageUtil auditErrorMessageUtil;

    @Mock
    private FileWriter fileWriterMock;
    @Mock
    private PcpBatchLoadResponse pcpBatchLoadResponseMock;
    @Mock
    private BufferedWriter bufferedWriterMock;

    @Spy
    private AtomicInteger atomicInteger;
    @Mock
    private Graphs graphs;

    @Mock
    private StepExecution stepExecutionMock;

    @Mock
    private JobExecution jobExecutionMock;

    @Mock
    private ExecutionContext executionContextMock;
    @Mock
    private RestCallService restCallServiceMock;
    @Mock
    private CommonUtils commonUtils;

    @Value("${salesforce.url.loadUrl}")
    private String memberPcpLoadURL;

    @Value("${batch.log.write}")
    private boolean writePcpDetails;

    @Value("${batch.log.path}")
    private String logFilePath;

    @Value("${batch.audit.request}")
    private boolean auditRequest;

    private AtomicInteger successCounter;
    private AtomicInteger failureCounter;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
        pcpService=new PcpService(auditService,adhocService,restCallServiceMock,memberPcpRepository, pcpAdapterService,spErrorLogService,auditErrorMessageUtil);
        successCounter = new AtomicInteger(0);
        failureCounter = new AtomicInteger(0);
    }


    @Test
    void testCallStoredProcedureService_Success() {
        String lastRuntime = "2023-04-24";
        Date newRuntime = new Date();
        String spRunTypeParam = "someParam";
        int storedProcedureResult = 0;
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RUNTIME)).thenReturn(lastRuntime);
        when(executionContextMock.get(Constant.NEW_RUNTIME)).thenReturn(newRuntime);
        when(memberPcpRepository.getPcpDetailsSP(any(),eq(lastRuntime), eq(spRunTypeParam),any())).thenReturn(storedProcedureResult);

        pcpService.callStoredProcedureService(stepExecutionMock, spRunTypeParam, "N");

        verify(auditService).auditStepStatus(anyString(), eq(Constant.PROCESS_STEP_SP), eq(PROCESS_STATUS_SUCCESS_VALUE),
                isNull(), isNull());
        verify(stepExecutionMock, never()).setTerminateOnly();
    }

    @Test
    void testCallStoredProcedureService_Error() {
        String lastRuntime = "2023-04-24";
        Date newRuntime = new Date();
        String spRunTypeParam = "someParam";
        int storedProcedureResult = 1;
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RUNTIME)).thenReturn(lastRuntime);
        when(executionContextMock.get(Constant.NEW_RUNTIME)).thenReturn(newRuntime);
        when(memberPcpRepository.getPcpDetailsSP(any(),eq(lastRuntime), eq(spRunTypeParam), any())).thenReturn(storedProcedureResult);

        pcpService.callStoredProcedureService(stepExecutionMock, spRunTypeParam, "N");

        verify(stepExecutionMock).setTerminateOnly();
    }

    @Test
    void testCallStoredProcedureService_selectiveLoad_Success() {
        String lastRuntime = "2023-04-24";
        Date newRuntime = new Date();
        String spRunTypeParam = "someParam";
        int storedProcedureResult = 0;
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(jobExecutionMock.getExecutionContext()).thenReturn(executionContextMock);
        when(executionContextMock.get(Constant.RUNTIME)).thenReturn(lastRuntime);
        when(executionContextMock.get(Constant.NEW_RUNTIME)).thenReturn(newRuntime);
        when(memberPcpRepository.getPcpDetailsSP(any(),eq(lastRuntime), eq(spRunTypeParam),any())).thenReturn(storedProcedureResult);

        pcpService.callStoredProcedureService(stepExecutionMock, spRunTypeParam, "Y");

        verify(auditService).auditStepStatus(anyString(), eq(Constant.PROCESS_STEP_SP), eq(PROCESS_STATUS_SUCCESS_VALUE),
                isNull(), isNull());
        verify(stepExecutionMock, never()).setTerminateOnly();
    }

    @Test
    void testAuditPcpDataLoadStatus_WhenResponseIsNull() {
        List<Map<String, String>> errorList = new ArrayList<>();
        boolean result = pcpService.auditPcpDataLoadStatus(null, errorList);

        assertTrue(result);
        assertFalse(errorList.isEmpty());
        assertEquals("Service Response is empty", errorList.get(0).get("responseText"));
    }

    @Test
    void testAuditPcpDataLoadStatus_WithEmptyGraphs() {
        PcpBatchLoadResponse response = new PcpBatchLoadResponse();
        response.setGraphs(new ArrayList<>());
        List<Map<String, String>> errorList = new ArrayList<>();
        boolean result = pcpService.auditPcpDataLoadStatus(response, errorList);

        assertTrue(result);
        assertFalse(errorList.isEmpty());
        assertEquals("Service Response is empty", errorList.get(0).get("responseText"));
    }


    @Test
    void testAuditPcpDataLoadStatus_WithEmptyErrorList() {
        List<Map<String, String>> errorList = new ArrayList<>();
        boolean result = pcpService.auditPcpDataLoadStatus(null, errorList);

        assertTrue(result);
        assertFalse(errorList.isEmpty());
        assertEquals("Service Response is empty", errorList.get(0).get("responseText"));
    }

    @Test
    public void testAuditProviderDataLoadStatus_WhenProviderBatchLoadResponseIsNull() {
        List<Map<String, String>> errorList = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("referenceId", "");
        errorMap.put(RESPONSE_TEXT, "Service Response is empty");
        errorList.add(errorMap);
        assertTrue(pcpService.auditPcpDataLoadStatus(null, errorList));
        assertEquals(2, errorList.size());
        assertEquals("Service Response is empty", errorList.get(0).get(RESPONSE_TEXT));
    }
    @Test
    public void testAuditProviderDataLoadStatus_WhenProviderBatchLoadResponseIs() throws JsonProcessingException {
        List<Map<String, String>> errorList = new ArrayList<>();
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("referenceId", "");
        errorMap.put(RESPONSE_TEXT, "Service Response is empty");
        errorList.add(errorMap);
        assertTrue(pcpService.auditPcpDataLoadStatus(mockPcpBatchLoadResponse(), errorList));
        assertEquals(2, errorList.size());
        assertEquals("Service Response is empty", errorList.get(0).get(RESPONSE_TEXT));
    }


    private PcpBatchLoadResponse mockPcpBatchLoadResponse() throws JsonProcessingException {
        PcpBatchLoadResponse mockResponse = mock(PcpBatchLoadResponse.class);
        List<Graph> graphs = createDummyGraphs(1);
        when(mockResponse.getGraphs()).thenReturn(graphs);
        return mockResponse;
    }

    private List<Graph> createDummyGraphs(int count) throws JsonProcessingException {
        List<Graph> dummyGraphs = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Graph graph = new Graph();
            graph.setGraphId("GraphId" + i);
            GraphResponse graphResponse = new GraphResponse();
            CompositeResponse compositeResponse1 = new CompositeResponse();
            compositeResponse1.setReferenceId("123");
            compositeResponse1.setHttpStatusCode(200);
            CompositeResponse compositeResponse2 = new CompositeResponse();
            compositeResponse2.setReferenceId("345");
            compositeResponse2.setHttpStatusCode(400);

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonString = "[{\"message\":\"Transaction declined due to insufficient funds\",\"age\":29,\"message\":\"message\"}]";
            ArrayNode arrayNode = (ArrayNode) objectMapper.readTree(jsonString);
            compositeResponse2.setBody(arrayNode);

            List<CompositeResponse> compositeResponseList = new ArrayList<>();
            compositeResponseList.add(compositeResponse1);
            compositeResponseList.add(compositeResponse2);

            graphResponse.setCompositeResponse(compositeResponseList);
            graph.setGraphResponse(graphResponse);
            dummyGraphs.add(graph);
        }
        return dummyGraphs;
    }


    @Test
    public void testUpdateSFDataLoadSuccessAndErrorCountAudit_WithCounts() {
        // Mock counts
        ReflectionTestUtils.setField(pcpService, "successCounter", new AtomicInteger(5));
        ReflectionTestUtils.setField(pcpService, "errorCounter", new AtomicInteger(3));
        doNothing().when(auditService).auditExecuteQueryCountStatus(anyString(),anyLong(), anyLong(),anyString(), anyString());
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        when(memberPcpRepository.distinctCount()).thenReturn(10l);
        pcpService.updateSFDataLoadSuccessAndErrorCountAudit(stepExecutionMock);
        verify(auditService,times(3)).auditExecuteQueryCountStatus(anyString(),anyLong(), anyLong(),anyString(), anyString());
    }

    @Test
    public void testResetCounter() {
        // Call the method
        pcpService.resetCounter();
    }

    @Test
    public void testAddMemberPCPService_NullResponse() throws Exception {
        ReflectionTestUtils.setField(pcpService, "batchLoggingLevel", "debug");

        // Arrange
        when(graphs.getPcpGraphRequests()).thenReturn(new ArrayList<>());
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        // Act
        String result = pcpService.addMemberPCPService(graphs, stepExecutionMock);

        // Assert
        verify(pcpAdapterService).updateRequest(graphs);
        verify(pcpAdapterService).updateResponse(null);
    }

    @Test
    public void testAddMemberPCPService_NullResponse_LogLevelInfo() throws Exception {
        ReflectionTestUtils.setField(pcpService, "batchLoggingLevel", "info");

        // Arrange
        when(graphs.getPcpGraphRequests()).thenReturn(new ArrayList<>());
        when(stepExecutionMock.getJobExecution()).thenReturn(jobExecutionMock);
        // Act
        String result = pcpService.addMemberPCPService(graphs, stepExecutionMock);

        // Assert
        verify(pcpAdapterService).updateRequest(graphs);
        verify(pcpAdapterService).updateResponse(null);
    }

}
