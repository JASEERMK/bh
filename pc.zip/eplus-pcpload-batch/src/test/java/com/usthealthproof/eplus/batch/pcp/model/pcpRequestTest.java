package com.usthealthproof.eplus.batch.pcp.model;


import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class PcpRequestTest {

    private PcpRequest pcpRequest;

    @BeforeEach
    void setUp() {
        // Create a concrete subclass of PcpRequest for testing purposes
        pcpRequest = new PcpRequest() {};
    }

    @Test
    void testSetCustomFields() {
        String key1 = "customKey1";
        String value1 = "customValue1";
        String key2 = "customKey2";
        String value2 = "customValue2";

        // Test setting custom fields
        pcpRequest.setCustomFields(key1, value1);
        pcpRequest.setCustomFields(key2, value2);

        // Retrieve the custom fields map
        Map<String, Object> customFields = pcpRequest.getCustomFields();

        // Verify that the custom fields map is not null
        assertNotNull(customFields);

        // Verify that the custom fields contain the correct key-value pairs
        assertEquals(value1, customFields.get(key1));
        assertEquals(value2, customFields.get(key2));
    }

    @Test
    void testGetCustomFields() {
        String key1 = "customKey1";
        String value1 = "customValue1";
        String key2 = "customKey2";
        String value2 = "customValue2";

        // Test setting custom fields
        pcpRequest.setCustomFields(key1, value1);
        pcpRequest.setCustomFields(key2, value2);

        // Retrieve the custom fields map
        Map<String, Object> customFields = pcpRequest.getCustomFields();

        // Verify that the custom fields map is not null
        assertNotNull(customFields);

        // Verify that the custom fields contain the correct key-value pairs
        assertEquals(value1, customFields.get(key1));
        assertEquals(value2, customFields.get(key2));
    }
}
