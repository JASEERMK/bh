package com.usthealthproof.eplus.batch.pcp.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.batch.pcp.enums.PcpTestEnum;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud.ServiceCloudPcpRecord;
import com.usthealthproof.eplus.commons.batch.pcp.util.PcpServiceCloudAdapterMapping;
import com.usthealthproof.eplus.commons.batch.pcp.util.ServiceCloudMappingUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.ParseException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class ServiceCloudMappingUtilTest {
    @InjectMocks
    private ServiceCloudMappingUtil mappingUtil;
    public static final String BLANK_STRING = "";
    String pcpUrl = "testurl/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
    @Mock
    PcpServiceCloudAdapterMapping clientMapping;
    @Mock
    private TestMappingUtil testMappingUtil;


    @Test
    void pcpTest() throws ParseException, JsonProcessingException {
        log.info("inside pcpTest");
        ReflectionTestUtils.setField(mappingUtil, "pcpRecordServiceUrl", pcpUrl);
        doNothing().when(clientMapping).updateScRecord(any(),any());
        MemberPcp pcpRecord = testMappingUtil.setPcpRecord();
        PcpGraphRequest pcpRequest = mappingUtil.createMemberPcpRequest(pcpRecord);
        // testing graph id
        assertEquals(pcpRequest.getGraphId(), ( "PCP_".concat(pcpRecord.getCilPcpKey()) ));
        // testing url
        assertEquals(pcpRequest.getCompositeRequest().get(0).getUrl(), ( pcpUrl + pcpRecord.getCilPcpKey() ));
        ServiceCloudPcpRecord pcpInfo = (ServiceCloudPcpRecord) pcpRequest.getCompositeRequest().get(0).getBody();
        ObjectMapper objectMapper = new ObjectMapper();
        // Convert the MemberInfo object to a JSON string
        String jsonStringPcp = objectMapper.writeValueAsString(pcpInfo);
        // Parse the JSON string into a JsonNode
        JsonNode pcpJsonNode = objectMapper.readTree(jsonStringPcp);
        // testing pcpInfo
        assertEquals(PcpTestEnum.PROVIDER_ID.getValue(), pcpJsonNode.get("UST_EPLUS__Provider_Name_SC__r").get("UST_EPLUS__CIL_Provider_Key__c").textValue());
        assertEquals(PcpTestEnum.MEMBER_ID.getValue(), pcpJsonNode.get("UST_EPLUS__Member__r").get("UST_EPLUS__CIL_Member_Key__c").textValue());
        assertEquals(PcpTestEnum.HC_PF.getValue(), pcpJsonNode.get("UST_EPLUS__Practitioner_Location__r").get("UST_EPLUS__CIL_Practitioner_Location_Key__c").textValue());
        assertEquals(PcpTestEnum.PCP_PANEL.getValue(), pcpJsonNode.get("UST_EPLUS__Panel__c").textValue());
        assertEquals(PcpTestEnum.START_DATE.getValue(), pcpJsonNode.get("UST_EPLUS__PCP_Start_Date__c").textValue());
        assertEquals(PcpTestEnum.END_DATE.getValue(), pcpJsonNode.get("UST_EPLUS__PCP_End_Date__c").textValue());
        assertEquals(PcpTestEnum.PROVIDER_NAME.getValue(), pcpJsonNode.get("Name").textValue());
        assertEquals(String.valueOf(true), pcpJsonNode.get("UST_EPLUS__Is_Current_PCP__c").textValue());
        assertEquals(PcpTestEnum.PHONE.getValue(), pcpJsonNode.get("UST_EPLUS__PCP_Phone__c").textValue());
        assertEquals("y", pcpJsonNode.get("UST_EPLUS__Auto_Assigned__c").textValue());
    }

    @Test
    void pcpNullTest() throws JsonProcessingException, ParseException {
        log.info("inside pcpNullTest");
        ReflectionTestUtils.setField(mappingUtil, "pcpRecordServiceUrl", pcpUrl);
        MemberPcp pcpRecord = new MemberPcp();
        PcpGraphRequest pcpRequest = mappingUtil.createMemberPcpRequest(pcpRecord);
        assertNull(pcpRequest);

        pcpRecord = testMappingUtil.setPcpRecord();
        pcpRecord.setMemberId(null);
        pcpRecord.setProviderId(null);
        pcpRecord.setHcPractitionerFacility(null);
        pcpRecord.setCilPcpKey("TEST-12");
        pcpRequest = mappingUtil.createMemberPcpRequest(pcpRecord);
        ServiceCloudPcpRecord pcpInfo = (ServiceCloudPcpRecord) pcpRequest.getCompositeRequest().get(0).getBody();

        //Validate condition for MemberId is null
        assertEquals(pcpInfo.getMemberReferenceKey(), ( BLANK_STRING ));
        //Validate condition for ProviderId is null
        assertEquals(pcpInfo.getProviderNameReferenceKey(), ( BLANK_STRING ));
        //Validate condition for CcPractitionerFacility is null
        assertEquals(pcpInfo.getPractitionerLocationReferenceKey(), ( BLANK_STRING ));
        //checking cilpcpkey is replaced - with _
        assertEquals("TEST_12", ( pcpRequest.getCompositeRequest().get(0).getReferenceId() ));

    }

}
