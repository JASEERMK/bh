package com.usthealthproof.eplus.batch.pcp.config;

import com.usthealthproof.eplus.commons.batch.common.exception.JobAuditListener;
import com.usthealthproof.eplus.commons.batch.common.service.AuditService;
import com.usthealthproof.eplus.commons.batch.pcp.config.JobConfiguration;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.*;
import org.springframework.batch.core.job.builder.SimpleJobBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.TaskExecutorJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Slf4j
class JobConfigurationTest {

    @Mock
    private PcpService pcpService;

    @Mock
    private JobAuditListener jobAuditListener;
    @Mock
    JobRepository jobRepository;

    @InjectMocks
    private JobConfiguration jobConfig;
    @Mock
    private JobLauncher jobLauncher;
    @Mock
    AuditService auditService;
    @Mock
    Job jobMock;
    @Mock
    JobExecution jobExecutionMock;
    @Mock
    JobConfiguration jobConfigMock;
    @Mock
    SimpleJobBuilder simpleJobBuilderMock;
    @Mock
    private PlatformTransactionManager transactionManager;
    @Mock
    private JobInstance jobInstanceMock;

    @Mock
    private Step step;
    @Mock
    TaskExecutorJobLauncher taskExecutorJobLauncher;
    @Mock
    Step stepMock;
    @Mock
    JobParameters param;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        ReflectionTestUtils.setField(jobConfig, "jobAuditListener", jobAuditListener);
        jobConfig = new JobConfiguration(pcpService, jobAuditListener);
        taskExecutorJobLauncher.setJobRepository(jobRepository);
        param = new JobParametersBuilder()
                .addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        jobExecutionMock = new JobExecution(new JobInstance(1L, "jobName"), param);


    }

    /**
     * Method under test: {@link JobConfiguration#getJobListenerCount()}
     */
    @Test
    public void testGetJobListenerCount() {
        log.info("inside testGetJobListenerCount");
        JobExecutionListener jobExecutionListener = jobConfig.getJobListenerCount();
        assertNotNull(jobExecutionListener);
        jobConfig.getJobListenerCount().beforeJob(jobExecutionMock);
        jobConfig.getJobListenerCount().afterJob(jobExecutionMock);
    }

    /**
     * Method under test: {@link JobConfiguration#taskExecutorJobLauncher(JobRepository)}
     */
    @Test
    public void testTaskExecutorJobLauncher() {
        log.info("inside testGetJobListenerCount");
        TaskExecutorJobLauncher launcher = jobConfig.taskExecutorJobLauncher(jobRepository);
        assertNotNull(launcher);
    }

    @Test
    void profileUpdateJob() throws Exception {

        // Call the method to be tested
        Job result = jobConfig.profileUpdateJob(
                stepMock,
                stepMock, stepMock, stepMock, stepMock,
                jobRepository,
                transactionManager,
                auditService
        );
        assertEquals("pcpBatchJob", result.getName());
    }

}