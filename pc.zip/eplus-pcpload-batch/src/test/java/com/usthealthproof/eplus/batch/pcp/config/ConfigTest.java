package com.usthealthproof.eplus.batch.pcp.config;

import com.usthealthproof.eplus.commons.batch.pcp.config.Config;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Slf4j
class ConfigTest {

    @InjectMocks
    Config config;
    @Mock
    Config configMock;
    @Mock
    private ThreadPoolTaskExecutor executorMock;
    @Mock
    WebClient.Builder webClientBuilder;
    Integer timeout = 120;
    int poolSize = 12;
    String interfaceId = "test-interface-id";
    String expectedTimeZone = "IST";


    @BeforeEach
    public void setUp() {
        executorMock.setCorePoolSize(poolSize);
        executorMock.setThreadNamePrefix(interfaceId);
        ReflectionTestUtils.setField(config, "connectionTimeout", timeout);
        ReflectionTestUtils.setField(config, "batchTimezone", expectedTimeZone);

    }

    @Test
    public void testAsyncExecutor() {
        log.info("inside testAsyncExecutor");
        // Create mock values for properties
        TaskExecutor taskExecutor = config.asyncExecutor(String.valueOf(poolSize), interfaceId);
        // Set up the mock behavior
        when(configMock.asyncExecutor(String.valueOf(poolSize), interfaceId)).thenReturn(executorMock);
        // Call the method under test
        ThreadPoolTaskExecutor result = (ThreadPoolTaskExecutor) configMock.asyncExecutor(String.valueOf(poolSize), interfaceId);
        // Verify the properties of the executor
        assertEquals(executorMock.getCorePoolSize(), result.getPoolSize());
        assertEquals(executorMock.getThreadNamePrefix(), result.getThreadNamePrefix());

    }

    @Test
    public void testWebClient() {
        log.info("inside testWebClient");
        config.webClient().get();
        verifyNoMoreInteractions(webClientBuilder); // Ensure no other interactions with webClientBuilder
    }

    @Test
    void testSetTimeZone() {
        // Set up
        // Call the method to be tested
        config.setTimeZone();
        // Verify
        assertEquals(expectedTimeZone, "IST");
    }

    @Test
    void testCloudEnviornmentSelection() {
        // Call the method to be tested
        config.beanSelection(true);
        config.beanSelection(false);

    }

}