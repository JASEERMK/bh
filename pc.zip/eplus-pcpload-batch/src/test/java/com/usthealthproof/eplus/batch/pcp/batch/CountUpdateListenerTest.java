package com.usthealthproof.eplus.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.pcp.batch.CountUpdateListener;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.StepExecution;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class CountUpdateListenerTest {

    @InjectMocks
    CountUpdateListener countUpdateListenerMock;
    @Mock
    StepExecution stepExecutionMock;
    @Mock
    PcpService pcpService;


    @Test
    public void testCountUpdate() {
        countUpdateListenerMock.beforeStep(stepExecutionMock);
        countUpdateListenerMock.afterStep(stepExecutionMock);

    }
}