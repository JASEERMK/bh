package com.usthealthproof.eplus.batch.pcp.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.batch.pcp.enums.PcpTestEnum;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Slf4j
public class TestMappingUtil {
    // setting test values
    public static MemberPcp setPcpRecord() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        MemberPcp pcpRecord = new MemberPcp();
        pcpRecord.setMemberId(PcpTestEnum.MEMBER_ID.getValue());
        pcpRecord.setProviderId(PcpTestEnum.PROVIDER_ID.getValue());
        pcpRecord.setPanel(PcpTestEnum.PCP_PANEL.getValue());
        pcpRecord.setPcpStartDate(formatter.parse(PcpTestEnum.START_DATE.getValue()));
        pcpRecord.setPcpEndDate(formatter.parse(PcpTestEnum.END_DATE.getValue()));
        pcpRecord.setProviderName(PcpTestEnum.PROVIDER_NAME.getValue());
        pcpRecord.setIsCurrent(PcpTestEnum.Y.getValue());
        pcpRecord.setPcpPhone(PcpTestEnum.PHONE.getValue());
        pcpRecord.setAutoAssigned(PcpTestEnum.Y.getValue());
        pcpRecord.setCilPcpKey(PcpTestEnum.CIL_PCP_KEY.getValue());
        pcpRecord.setPcpCilId(new BigDecimal(PcpTestEnum.PCP_CIL_ID.getValue()));
        pcpRecord.setHcPractitionerFacility(PcpTestEnum.HC_PF.getValue());
        return pcpRecord;
    }

}
