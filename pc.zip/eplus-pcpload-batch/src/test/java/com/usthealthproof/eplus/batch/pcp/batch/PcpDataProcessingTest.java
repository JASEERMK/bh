package com.usthealthproof.eplus.batch.pcp.batch;

import com.usthealthproof.eplus.commons.batch.common.exception.SkippedItemsExceptionListener;
import com.usthealthproof.eplus.commons.batch.pcp.batch.PcpDataProcessingSteps;
import com.usthealthproof.eplus.commons.batch.pcp.batch.RepositoryPagedItemReader;
import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.PcpGraphRequest;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpService;
import com.usthealthproof.eplus.batch.pcp.util.*;
import com.usthealthproof.eplus.commons.batch.pcp.util.HealthCloudMappingUtil;
import com.usthealthproof.eplus.commons.batch.pcp.util.MappingUtil;
import com.usthealthproof.eplus.commons.batch.pcp.util.PcpHealthCloudAdapterMapping;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.item.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class PcpDataProcessingTest {

    @InjectMocks
    HealthCloudMappingUtil healthCloudMappingUtil;
    @Mock
    @Qualifier("pcpMappingUtil")
    private MappingUtil mappingUtil;
    @InjectMocks
    PcpDataProcessingSteps pcpDataProcessingSteps;
    @Mock
    MemberPcpRepository memberPcpRepository;
    @Mock
    private PcpService pcpService;
    @Mock
    private Environment envMock;
    @Mock
    private SkippedItemsExceptionListener skippedItemsExceptionListenerMock;

    @Mock
    PcpHealthCloudAdapterMapping clientMapping;
    @Mock
    private ItemWriter<List<PcpGraphRequest>> itemWriter;

    @Mock
    private TaskExecutor executor;

    @Mock
    private JobRepository jobRepository;

    @Mock
    private PlatformTransactionManager platformTransactionManager;

    @Mock
    private ItemProcessor<MemberPcp, List<PcpGraphRequest>> itemProcessor;

    @Mock
    private ItemReader<MemberPcp> itemReader;
    @Mock
    private Environment env;
    @Mock
    private Partitioner partitioner;
    @Mock
    private TestMappingUtil testMappingUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        pcpDataProcessingSteps = new PcpDataProcessingSteps(memberPcpRepository, pcpService, envMock, skippedItemsExceptionListenerMock);
    }

    @Test
    public void testWrite() throws Exception {
        String pcpUrl = "testurl/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
        ReflectionTestUtils.setField(healthCloudMappingUtil, "pcpRecordServiceUrl", pcpUrl);
        doNothing().when(clientMapping).updateRecord(any(),any());
        MemberPcp pcpRequest1 = testMappingUtil.setPcpRecord();
        PcpGraphRequest request1 = healthCloudMappingUtil.createMemberPcpRequest(pcpRequest1);
        PcpGraphRequest request2 = healthCloudMappingUtil.createMemberPcpRequest(pcpRequest1);

        // Create a mock ItemWriter
        ItemWriter<List<PcpGraphRequest>> itemWriterMock = mock(ItemWriter.class);

        // Set up the stepExecutionMock on the itemWriterMock using @BeforeStep method
        List<PcpGraphRequest> accountRequests = new ArrayList<>();
        accountRequests.add(request1);
        accountRequests.add(request2);

        // Create a Chunk object with the test data
        Chunk<List<PcpGraphRequest>> chunk = new Chunk<>(Collections.singletonList(accountRequests));

        // Call the method to test
        pcpDataProcessingSteps.write().write(chunk);
        // Assert that the itemWriterMock wrote the correct number of items
        assertEquals(1, chunk.getItems().size());

        ArgumentCaptor<Graphs> argumentGraph = ArgumentCaptor.forClass(Graphs.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);
        verify(pcpService).addMemberPCPService(argumentGraph.capture(), argumentStepExecution.capture());

        //checking graph id
        assertEquals(argumentGraph.getValue().getPcpGraphRequests().get(0).getGraphId(), request1.getGraphId());
        //checking url
        assertEquals(argumentGraph.getValue().getPcpGraphRequests().get(0).getCompositeRequest().get(0).getUrl(), request1.getCompositeRequest().get(0).getUrl());
        //checking reference id
        assertEquals(argumentGraph.getValue().getPcpGraphRequests().get(0).getCompositeRequest().get(0).getReferenceId(), request1.getCompositeRequest().get(0).getReferenceId());
        //checking method
        assertEquals(argumentGraph.getValue().getPcpGraphRequests().get(0).getCompositeRequest().get(1).getMethod(), request1.getCompositeRequest().get(1).getMethod());
        //checking size of graph
        assertEquals(1, argumentGraph.getAllValues().size());
        //checking size of composite request
        assertEquals(2, argumentGraph.getValue().getPcpGraphRequests().get(0).getCompositeRequest().size());

        // Create an empty Chunk object
        Chunk<List<PcpGraphRequest>> emptyChunk = new Chunk<>(Collections.emptyList());

        // Call the write method with the empty chunk
        pcpDataProcessingSteps.write().write(emptyChunk);

        // Prepare test data
        List<PcpGraphRequest> accountRequestsList = new ArrayList<>();
        // Create a Chunk object with the test data
        Chunk<List<PcpGraphRequest>> chunkList = new Chunk<>(Collections.singletonList(accountRequestsList));

        // Throw an exception when the write method is called
        doThrow(new RuntimeException("Failed to write data")).when(itemWriterMock).write(chunkList);

        // Call the write method
        assertThrows(RuntimeException.class, () -> itemWriterMock.write(chunkList));
    }

    @Test
    public void multipleWriteTest() throws Exception {
        String pcpUrl = "testurl/services/data/v50.0/sobjects/Account/UST_EPLUS__CIL_Member_Key__c/";
        ReflectionTestUtils.setField(healthCloudMappingUtil, "pcpRecordServiceUrl", pcpUrl);
        //when(accountRequestMock.getGraphId()).thenReturn("graph123");

        List<PcpGraphRequest> accountRequests = new ArrayList<>();
        //creating request with size 36
        for (int i = 0; i <= 35; i++) {
            MemberPcp request = new MemberPcp();
            request.setCilPcpKey("TESTPID_" + i);
            PcpGraphRequest accountInfo = healthCloudMappingUtil.createMemberPcpRequest(request);
            accountRequests.add(accountInfo);
        }
        // Create a Chunk object with the test data
        Chunk<List<PcpGraphRequest>> chunk = new Chunk<>(Collections.singletonList(accountRequests));

        pcpDataProcessingSteps.write().write(chunk);

        ArgumentCaptor<Graphs> argumentGraphs = ArgumentCaptor.forClass(Graphs.class);
        ArgumentCaptor<StepExecution> argumentStepExecution = ArgumentCaptor.forClass(StepExecution.class);

        // Verify that the addMemberPCPService function is called exactly twice
        verify(pcpService, times(2)).addMemberPCPService(argumentGraphs.capture(), argumentStepExecution.capture());
        //checking no of request
        assertEquals(2, argumentGraphs.getAllValues().size());
        //checking size of first request
        assertEquals(30, argumentGraphs.getAllValues().get(0).getPcpGraphRequests().size());
        //checking size of second request
        assertEquals(6, argumentGraphs.getAllValues().get(1).getPcpGraphRequests().size());
    }


    @Test
    void testReader() throws Exception {
        // Call the method to be tested
        RepositoryPagedItemReader result = pcpDataProcessingSteps.reader("1");
        // Verify initialization
        assertEquals(0, result.getCurrentItemCount());
    }

    @Test
    public void testProcess() throws Exception {
        // initialise();
        List<MemberPcp> pcpList=new ArrayList<>();
        MemberPcp memberPcp= new MemberPcp();
        memberPcp.setMemberId("12345");
        pcpList.add(memberPcp);
        List<PcpGraphRequest> result=pcpDataProcessingSteps.processor(mappingUtil).process(pcpList);
        assertNotNull(result);
    }

    @Test
    void testGetPartitionerStep() throws Exception {
        Step step = mock(Step.class);
        Method method = PcpDataProcessingSteps.class.getDeclaredMethod("getPartitionerStep", Step.class, TaskExecutor.class, JobRepository.class);
        method.setAccessible(true);

        Step partitionerStep = (Step) method.invoke(pcpDataProcessingSteps, step, executor, jobRepository);

        assertNotNull(partitionerStep);
    }
    @Test
    public void testSupplierLoadStepException() throws Exception {
        assertThrows(NumberFormatException.class, () ->
        {
            pcpDataProcessingSteps.supplierLoadStep(itemWriter,executor, jobRepository, platformTransactionManager,mappingUtil);

        });
    }
    @Test
    public void testMockGetPartitionerStep() throws Exception {
        Step mockStep = Mockito.mock(Step.class);
        TaskExecutor mockExecutor = Mockito.mock(TaskExecutor.class);
        JobRepository mockJobRepository = Mockito.mock(JobRepository.class);

        // Mock the return value of the getPartitioner method if needed
        String mockPartitionerStepName = "mockPartitionerStepName";
        // Access the private method using reflection
        Method getPartitionerStepMethod = PcpDataProcessingSteps.class.getDeclaredMethod("getPartitionerStep", Step.class, TaskExecutor.class, JobRepository.class);
        getPartitionerStepMethod.setAccessible(true);

        // Mock the private method
        when(getPartitionerStepMethod.invoke(pcpDataProcessingSteps, mockStep, mockExecutor, mockJobRepository))
                .thenReturn(mockPartitionerStepName);
        // Call the method indirectly or verify it is used somewhere in the class
        Step resultStep = (Step) getPartitionerStepMethod.invoke(pcpDataProcessingSteps, mockStep, mockExecutor, mockJobRepository);

        // Verify the result
        assert resultStep != null;
        assertEquals(resultStep.getName(), "stepPartition_pcp");

    }

    @Test
    public void testMockGetPartitioner() throws Exception {
        when(envMock.getProperty("batch.execution.partition-count")).thenReturn("5");
        when(memberPcpRepository.count()).thenReturn(5L);

        Long value = Long.valueOf(envMock.getProperty("batch.execution.partition-count"));
        if (value == null) {
            throw new IllegalArgumentException("The configuration 'batch.execution.partition-count' must not be null.");
        }

        // Access the private method using reflection
        Method getPartitionerMethod = PcpDataProcessingSteps.class.getDeclaredMethod("getPartitioner");
        getPartitionerMethod.setAccessible(true);

        // Invoke the method via reflection and verify the result
        Partitioner resultPartitioner = (Partitioner) getPartitionerMethod.invoke(pcpDataProcessingSteps);
        Map<String, ExecutionContext> result = resultPartitioner.partition(10);

        // Verify that the partition map is not null and contains the expected data
        assert result != null;
        assert result.containsKey("partition3");
        assert result.containsKey("partition2");
    }


}




