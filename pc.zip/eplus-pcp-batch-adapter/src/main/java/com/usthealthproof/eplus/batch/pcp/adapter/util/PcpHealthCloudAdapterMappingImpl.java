package com.usthealthproof.eplus.batch.pcp.adapter.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.healthcloud.HealthCloudPcpRecord;
import com.usthealthproof.eplus.commons.batch.pcp.util.PcpHealthCloudAdapterMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
@Slf4j
@Component
public class PcpHealthCloudAdapterMappingImpl implements PcpHealthCloudAdapterMapping {

    @Override
    public void updateRecord(MemberPcp entity, HealthCloudPcpRecord pcpRecord) {

        // Update HealthCloudPcpRecord here

    }
}
