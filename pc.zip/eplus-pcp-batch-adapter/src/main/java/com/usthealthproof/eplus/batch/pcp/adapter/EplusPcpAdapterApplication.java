package com.usthealthproof.eplus.batch.pcp.adapter;

import com.usthealthproof.eplus.commons.batch.pcp.config.EnablePcpBatchLibrary;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication(scanBasePackages = {"com.usthealthproof.eplus.commons.batch.pcp",
        "com.usthealthproof.eplus.commons.batch.common", "com.usthealthproof.eplus.batch.pcp.adapter"})
@EntityScan(basePackages = {"com.usthealthproof.eplus.commons.batch.pcp.db.entity",
        "com.usthealthproof.eplus.commons.batch.common.db.entity", "com.usthealthproof.eplus.batch.pcp.adapter.entity"})
@EnableJpaRepositories(basePackages = {
        "com.usthealthproof.eplus.commons.batch.common.db.repository", "com.usthealthproof.eplus.batch.pcp.adapter.repo"})
@EnablePcpBatchLibrary
public class EplusPcpAdapterApplication {

    public static void main(String[] args) {
        SpringApplication.run(EplusPcpAdapterApplication.class, args);
    }

}
