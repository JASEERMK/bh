package com.usthealthproof.eplus.batch.pcp.adapter.entity;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name ="EPLUS_MEMBER_PCP")
public class PcpAdapterEntity extends MemberPcp {
    /*
     * Customer specific columns can be added in the class
     */
/*     @Column(name = "PROVIDER_NAME")
    private String providerName;*/
}
