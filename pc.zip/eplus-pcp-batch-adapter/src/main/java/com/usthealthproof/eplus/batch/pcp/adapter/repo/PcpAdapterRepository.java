package com.usthealthproof.eplus.batch.pcp.adapter.repo;

import com.usthealthproof.eplus.batch.pcp.adapter.entity.PcpAdapterEntity;
import com.usthealthproof.eplus.commons.batch.pcp.db.repository.MemberPcpRepository;
import org.springframework.stereotype.Repository;

@Repository(value = "PcpAdapterRepository")
public interface PcpAdapterRepository extends MemberPcpRepository<PcpAdapterEntity> {
    /*
     * Please make sure the annotation repository have value pcpAdapterRepository
     */

}
