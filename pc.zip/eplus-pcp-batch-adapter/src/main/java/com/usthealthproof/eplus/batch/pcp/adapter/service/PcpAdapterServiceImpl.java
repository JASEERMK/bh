package com.usthealthproof.eplus.batch.pcp.adapter.service;

import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.response.PcpBatchLoadResponse;
import com.usthealthproof.eplus.commons.batch.pcp.service.PcpAdapterService;
import org.springframework.stereotype.Service;

@Service
public class PcpAdapterServiceImpl implements PcpAdapterService {

    /*
     * Update the request graph object if require
     *
     * @param graphs This will be the request sending to SF
     */
    @Override
    public void updateRequest(Graphs graphs) {
        // Update request object here
    }
    /*
     * Update the response object if require
     * @param response Response object received from SF
     */
    @Override
    public void updateResponse(PcpBatchLoadResponse response) {
        // Update request object here
    }
}
