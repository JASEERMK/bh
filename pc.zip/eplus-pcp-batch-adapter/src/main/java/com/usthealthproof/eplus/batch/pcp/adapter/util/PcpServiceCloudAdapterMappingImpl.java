package com.usthealthproof.eplus.batch.pcp.adapter.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud.ServiceCloudPcpRecord;
import com.usthealthproof.eplus.commons.batch.pcp.util.PcpServiceCloudAdapterMapping;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
@Slf4j
@Component
public class PcpServiceCloudAdapterMappingImpl implements PcpServiceCloudAdapterMapping {

    @Override
    public void updateScRecord(MemberPcp entity, ServiceCloudPcpRecord pcpRecord) {

        // Update ServiceCloudPcpRecord here

    }
}
