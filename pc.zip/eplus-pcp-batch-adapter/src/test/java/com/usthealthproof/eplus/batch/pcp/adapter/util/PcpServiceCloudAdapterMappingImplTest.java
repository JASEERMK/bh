package com.usthealthproof.eplus.batch.pcp.adapter.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.servicecloud.ServiceCloudPcpRecord;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class PcpServiceCloudAdapterMappingImplTest {
    @InjectMocks
    PcpServiceCloudAdapterMappingImpl pcpServiceCloudAdapterMapping;
    @Mock
    MemberPcp memberPcp;
    @Mock
    ServiceCloudPcpRecord serviceCloudPcpRecord;
    @Test
    public void testUpdateScRecord() {
        log.info("inside testUpdateScRecord");
        pcpServiceCloudAdapterMapping.updateScRecord(memberPcp, serviceCloudPcpRecord);
    }
}
