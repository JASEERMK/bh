package com.usthealthproof.eplus.batch.pcp.adapter;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringApplication;


@Slf4j
@ExtendWith(MockitoExtension.class)
class EplusPcpAdapterEntityApplicationTests {

    @InjectMocks
    EplusPcpAdapterApplication eplusPcpAdapterApplication;

    @Test
    void applicationContextLoads() {
        log.info("inside applicationContextLoads");
        try (MockedStatic<SpringApplication> mockedStatic = Mockito.mockStatic(SpringApplication.class)) {
            // Call the main method of DemoApplication
            EplusPcpAdapterApplication.main(new String[]{});

            // Verify that SpringApplication.run() was called exactly once with DemoApplication.class as an argument
            mockedStatic.verify(() -> SpringApplication.run(EplusPcpAdapterApplication.class, new String[]{}));
        }
    }
}
