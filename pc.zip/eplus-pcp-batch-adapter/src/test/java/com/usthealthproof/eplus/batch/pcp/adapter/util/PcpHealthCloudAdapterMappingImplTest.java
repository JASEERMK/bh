package com.usthealthproof.eplus.batch.pcp.adapter.util;

import com.usthealthproof.eplus.commons.batch.pcp.db.entity.MemberPcp;
import com.usthealthproof.eplus.commons.batch.pcp.model.request.healthcloud.HealthCloudPcpRecord;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
class PcpHealthCloudAdapterMappingImplTest {
    @InjectMocks
    PcpHealthCloudAdapterMappingImpl pcpAdapterMappingImplMock;
    @Mock
    MemberPcp memberPcp;
    @Mock
    HealthCloudPcpRecord healthCloudPcpRecord;
    @Test
    public void testUpdateRecord() {
        log.info("inside testUpdateRecord");
        pcpAdapterMappingImplMock.updateRecord(memberPcp, healthCloudPcpRecord);
    }
}