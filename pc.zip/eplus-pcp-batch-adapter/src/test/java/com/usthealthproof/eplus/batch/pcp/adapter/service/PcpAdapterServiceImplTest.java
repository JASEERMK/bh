package com.usthealthproof.eplus.batch.pcp.adapter.service;

import com.usthealthproof.eplus.commons.batch.pcp.model.request.Graphs;
import com.usthealthproof.eplus.commons.batch.pcp.model.response.PcpBatchLoadResponse;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@Slf4j
@ExtendWith(MockitoExtension.class)
class PcpAdapterServiceImplTest {

    @InjectMocks
    PcpAdapterServiceImpl pcpAdapterServiceImplMock;
    @Mock
    Graphs graphMock;
    @Mock
    PcpBatchLoadResponse pcpBatchLoadResponse;
    @Test
    public void testUpdateRequest() {
        log.info("inside testUpdateRequest");
        pcpAdapterServiceImplMock.updateRequest(graphMock);
    }
    @Test
    public void testUpdateResponse() {
        log.info("inside testUpdateResponse");
        pcpAdapterServiceImplMock.updateResponse(pcpBatchLoadResponse);
    }

}